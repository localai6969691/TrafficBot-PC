"""Quản lý mạng đa vùng: gateway pool, sticky session, health check,
HTTP client ngoài trình duyệt, Retry-After / Exponential Backoff / Circuit Breaker."""
from __future__ import annotations

import asyncio
import hashlib
import logging
import random
import time
from collections import deque
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
from typing import Any, Optional

from config_loader import Environment, GatewayEntry, Settings

LOGGER = logging.getLogger("qa.network")


class GatewayUnavailable(RuntimeError):
    """Có cấu hình gateway nhưng không còn gateway khả dụng cho vùng yêu cầu."""


# ============================================================================ backoff
def parse_retry_after(value: Optional[str]) -> Optional[float]:
    """Retry-After: số giây hoặc HTTP-date -> số giây chờ (>= 0)."""
    if not value:
        return None
    value = value.strip()
    if value.isdigit():
        return float(value)
    try:
        when = parsedate_to_datetime(value)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        return max(0.0, (when - datetime.now(timezone.utc)).total_seconds())
    except (TypeError, ValueError):
        return None


class BackoffPolicy:
    def __init__(self, base_s: float, cap_s: float) -> None:
        self.base_s, self.cap_s = base_s, cap_s

    def delay(self, attempt: int, retry_after: Optional[float] = None) -> float:
        """Ưu tiên Retry-After của máy chủ; nếu không có thì exponential + jitter."""
        if retry_after is not None:
            return min(retry_after, self.cap_s) + random.uniform(0, 0.5)
        exp = min(self.base_s * (2 ** attempt), self.cap_s)
        return random.uniform(exp / 2, exp)


# ============================================================================ circuit breaker
class CircuitBreaker:
    """closed -> open (lỗi vượt ngưỡng) -> half-open (sau cooldown, thả 1 lượt thử)."""

    def __init__(self, threshold: float, min_samples: int, cooldown_s: float, window: int = 20) -> None:
        self.threshold, self.min_samples, self.cooldown_s = threshold, min_samples, cooldown_s
        self.state = "closed"
        self._results: deque[bool] = deque(maxlen=window)
        self._opened_at = 0.0
        self._probing = False

    def allow(self) -> bool:
        if self.state == "open":
            if time.monotonic() - self._opened_at < self.cooldown_s:
                return False
            self.state = "half_open"
        if self.state == "half_open":
            if self._probing:
                return False
            self._probing = True
        return True

    def record(self, ok: bool) -> None:
        if self.state == "half_open":
            self._probing = False
            if ok:
                self.state = "closed"
                self._results.clear()
            else:
                self._trip()
            return
        self._results.append(ok)
        if len(self._results) >= self.min_samples:
            failure_rate = self._results.count(False) / len(self._results)
            if failure_rate > self.threshold:
                self._trip()

    def _trip(self) -> None:
        self.state = "open"
        self._opened_at = time.monotonic()
        self._probing = False
        LOGGER.error("Circuit breaker MỞ - tạm ngừng gọi trong %.0fs", self.cooldown_s)


class BreakerRegistry:
    def __init__(self, s: Settings) -> None:
        self._s = s
        self._items: dict[str, CircuitBreaker] = {}

    def get(self, key: str) -> CircuitBreaker:
        if key not in self._items:
            self._items[key] = CircuitBreaker(self._s.breaker_failure_threshold,
                                              self._s.breaker_min_samples, self._s.breaker_cooldown_s)
        return self._items[key]

    def snapshot(self) -> dict[str, str]:
        return {k: b.state for k, b in self._items.items()}


# ============================================================================ gateway pool
@dataclass
class GatewayState:
    entry: GatewayEntry
    healthy: bool = True
    latency_ms: Optional[float] = None
    consecutive_failures: int = 0


class GatewayPool:
    FAIL_THRESHOLD = 2

    def __init__(self, entries: list[GatewayEntry], timeout_s: float, interval_s: float) -> None:
        self._states = [GatewayState(e) for e in entries if e.browser_compatible]
        self._timeout_s, self._interval_s = timeout_s, interval_s
        self._task: Optional[asyncio.Task[None]] = None
        self.configured = bool(entries)

    # --- health check nền
    def start(self) -> None:
        if self._states and self._task is None:
            self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def _loop(self) -> None:
        while True:
            await self.check_all()
            await asyncio.sleep(self._interval_s)

    async def check_all(self) -> None:
        await asyncio.gather(*(self._check(s) for s in self._states))

    async def _check(self, state: GatewayState) -> None:
        t0 = time.perf_counter()
        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(state.entry.host, state.entry.port), self._timeout_s)
            writer.close()
            await writer.wait_closed()
            state.latency_ms = (time.perf_counter() - t0) * 1000
            if not state.healthy:
                LOGGER.info("Gateway %s hoạt động trở lại", state.entry.masked)
            state.healthy, state.consecutive_failures = True, 0
        except (OSError, asyncio.TimeoutError):
            self._mark_failure(state)

    def _mark_failure(self, state: GatewayState) -> None:
        state.consecutive_failures += 1
        if state.healthy and state.consecutive_failures >= self.FAIL_THRESHOLD:
            state.healthy = False
            LOGGER.warning("Loại gateway %s khỏi danh sách khả dụng (mất kết nối)", state.entry.masked)

    def report_failure(self, entry: Optional[GatewayEntry]) -> None:
        for s in self._states:
            if s.entry == entry:
                self._mark_failure(s)

    # --- gán gateway
    def assign(self, profile_id: str, region: Optional[str]) -> Optional[GatewayEntry]:
        """Sticky: cùng profile_id luôn nhận cùng gateway (rendezvous hashing) chừng nào
        gateway đó còn khỏe. None = đi thẳng (khi không cấu hình gateway nào)."""
        if not self.configured:
            return None
        region = region.lower() if region else None
        cands = [s for s in self._states if s.healthy and (region in (None, "any") or s.entry.region in (region, "any"))]
        if not cands:
            raise GatewayUnavailable(f"Không có gateway khả dụng cho vùng {region or 'bất kỳ'}")
        best = max(cands, key=lambda s: hashlib.sha1(f"{profile_id}|{s.entry.url}".encode()).digest())
        return best.entry

    def snapshot(self) -> list[dict[str, Any]]:
        return [{"gateway": s.entry.masked, "region": s.entry.region, "healthy": s.healthy,
                 "latency_ms": None if s.latency_ms is None else round(s.latency_ms, 1)} for s in self._states]

    # Phase 11.2: Seamless Gateway Hot-Swap. Khác với report_failure() (chỉ tăng
    # consecutive_failures, chờ đủ FAIL_THRESHOLD lần mới loại) - hot_swap() LOẠI
    # NGAY LẬP TỨC gateway lỗi (không chờ ngưỡng) và cấp phát một gateway KHỎE
    # khác CÙNG MÃ QUỐC GIA (dùng trường `region` làm proxy cho mã quốc gia theo
    # đúng quy ước hiện có của assign()), để phiên làm việc không bị gián đoạn bởi
    # việc exit IP đổi sang quốc gia khác giữa chừng kịch bản.
    #
    # LƯU Ý: `profiles_data/<profile_id>/` không hề bị ảnh hưởng bởi lệnh gọi này -
    # thư mục profile được khoá theo profile_id (xem engine.py `safe_name(sc.profile_id)`),
    # hoàn toàn độc lập với gateway đang dùng, nên "giữ nguyên profiles_data/" là
    # đặc tính sẵn có của kiến trúc, không cần code thêm gì ở đây.
    def hot_swap(self, profile_id: str, failed_entry: GatewayEntry) -> Optional[GatewayEntry]:
        """Loại `failed_entry` ngay lập tức và trả về gateway khỏe khác cùng
        `region` (mã quốc gia). Trả None nếu không còn gateway nào cùng vùng.

        Dùng rendezvous hashing với SEED KHÁC profile_id gốc (nối thêm "|hotswap")
        để tránh việc hash lại ra ĐÚNG gateway vừa bị loại (dù nó đã healthy=False
        nên về lý thuyết không được chọn lại, seed khác vẫn giúp phân tán đều hơn
        nếu có nhiều phiên hot-swap liên tiếp)."""
        for s in self._states:
            if s.entry == failed_entry:
                s.healthy = False
                s.consecutive_failures = self.FAIL_THRESHOLD
                LOGGER.warning("Hot-swap: loại NGAY %s (mất kết nối giữa chừng)", failed_entry.masked)
                break
        region = failed_entry.region
        cands = [s for s in self._states if s.healthy and
                (region in (None, "any") or s.entry.region in (region, "any"))
                and s.entry != failed_entry]
        if not cands:
            LOGGER.error("Hot-swap: không còn gateway nào khỏe cùng vùng '%s' cho profile %s",
                        region, profile_id)
            return None
        best = max(cands, key=lambda s: hashlib.sha1(f"{profile_id}|hotswap|{s.entry.url}".encode()).digest())
        LOGGER.info("Hot-swap: %s -> %s (cùng vùng '%s', profile=%s)",
                   failed_entry.masked, best.entry.masked, region, profile_id)
        return best.entry


# ============================================================================ HTTP client ngoài trình duyệt
@dataclass
class ProbeResult:
    status: Optional[int] = None
    elapsed_ms: Optional[float] = None
    error: Optional[str] = None


def accept_language(locale: Optional[str]) -> str:
    if not locale:
        return "en-US,en;q=0.9"
    base = locale.split("-")[0]
    return f"{locale},{base};q=0.9" if base != locale else locale


class HttpProbe:
    """httpx (HTTP/2) với User-Agent / Accept-Language đồng bộ với môi trường kiểm thử
    và đi qua đúng gateway của profile. httpx là phụ thuộc tùy chọn."""

    def __init__(self, timeout_s: float = 10.0, exit_ip_ttl_s: float = 300.0) -> None:
        self._timeout_s, self._ttl = timeout_s, exit_ip_ttl_s
        self._ip_cache: dict[str, tuple[float, Optional[str]]] = {}

    def _client(self, env: Environment, gateway: Optional[GatewayEntry]) -> Any:
        import httpx  # nạp muộn

        headers = {"Accept-Language": accept_language(env.locale)}
        if env.user_agent:
            headers["User-Agent"] = env.user_agent
        kwargs: dict[str, Any] = dict(headers=headers, timeout=self._timeout_s, follow_redirects=True)
        if gateway:
            kwargs["proxy"] = gateway.url
        try:
            return httpx.AsyncClient(http2=True, **kwargs)
        except ImportError:  # thiếu gói 'h2'
            return httpx.AsyncClient(http2=False, **kwargs)

    async def health_check(self, url: str, env: Environment,
                           gateway: Optional[GatewayEntry] = None) -> ProbeResult:
        try:
            t0 = time.perf_counter()
            async with self._client(env, gateway) as client:
                resp = await client.get(url)
            return ProbeResult(resp.status_code, (time.perf_counter() - t0) * 1000)
        except ImportError:
            return ProbeResult(error="Chưa cài httpx")
        except Exception as exc:  # noqa: BLE001
            return ProbeResult(error=f"{type(exc).__name__}: {exc}")

    async def exit_ip(self, ip_url: Optional[str], env: Environment,
                      gateway: Optional[GatewayEntry]) -> Optional[str]:
        if not ip_url:
            return None
        key = gateway.masked if gateway else "direct"
        cached = self._ip_cache.get(key)
        if cached and time.monotonic() - cached[0] < self._ttl:
            return cached[1]
        ip: Optional[str] = None
        try:
            async with self._client(env, gateway) as client:
                ip = (await client.get(ip_url)).text.strip()[:64] or None
        except Exception as exc:  # noqa: BLE001 - kể cả thiếu httpx
            LOGGER.debug("Không lấy được exit IP: %s", exc)
        self._ip_cache[key] = (time.monotonic(), ip)
        return ip
