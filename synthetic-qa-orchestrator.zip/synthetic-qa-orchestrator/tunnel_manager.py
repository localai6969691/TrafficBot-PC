"""Phân hệ Sidecar Tunnel Manager - quản lý tiến trình định tuyến cục bộ.

Khởi chạy và quản lý vòng đời các tiến trình định tuyến mạng (Xray-core, Sing-box,
hoặc bất kỳ binary tương thích) để mở cổng SOCKS5/UDP cục bộ, dùng cho:
  * Kiểm thử ứng dụng qua mạng VPN/proxy doanh nghiệp phức tạp.
  * Mô phỏng người dùng truy cập từ các hạ tầng mạng khác nhau.
  * Kiểm định TLS/HTTP2 compatibility qua các loại CDN/load balancer khác nhau.

Cách dùng trong scenarios.json:
  {
    "action": "use_tunnel",
    "tunnel": "my-xray-proxy",
    "proxy_url": "socks5://127.0.0.1:10808"
  }

Hoặc qua API:
  async with TunnelManager(db) as tm:
      socks_url = await tm.start("my-tunnel", config_path)
      # dùng socks_url làm proxy cho BrowserContext

GIỚI HẠN ĐÃ BIẾT:
  - Binary (`xray`, `sing-box`, v.v.) phải được đặt sẵn trong thư mục
    `runtime/tunnels/` hoặc nằm trong PATH. Hệ thống KHÔNG tự tải binary.
  - Trên Windows, `kill()` có thể để lại tiến trình zombie nếu binary không
    xử lý SIGTERM - dùng `taskkill /F /PID` nếu cần.
  - Chỉ kiểm tra cổng SOCKS5 TCP bằng socket connect; không xác minh
    UDP forwarding thật sự (cần dùng Playwright context với trang test thật).
  - Config JSON được truyền nguyên văn tới binary - không validate nội dung.
    Người vận hành chịu trách nhiệm bảo mật cấu hình.
  - Nhiều tunnel cùng tên: lần sau gọi start() sẽ REUSE tiến trình đang chạy
    (không khởi động lại) trừ khi gọi stop() trước.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import signal
import socket
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.tunnel")

# Thư mục mặc định chứa binary tunnel
_RUNTIME_DIR = Path("runtime/tunnels")
# Cổng SOCKS5 mặc định nếu config không chỉ định
_DEFAULT_SOCKS5_PORT = 10808
# Thời gian chờ tunnel sẵn sàng (giây)
_READY_TIMEOUT_S = 10.0
# Khoảng cách kiểm tra cổng (giây)
_POLL_INTERVAL_S = 0.3


@dataclass
class TunnelInfo:
    name: str
    pid: int
    socks5_host: str
    socks5_port: int
    started_at: float = field(default_factory=time.time)
    config_path: Optional[str] = None

    @property
    def proxy_url(self) -> str:
        return f"socks5://{self.socks5_host}:{self.socks5_port}"

    @property
    def age_s(self) -> float:
        return time.time() - self.started_at


def _detect_binary(name: str) -> Optional[Path]:
    """Tìm binary trong runtime/tunnels/ hoặc PATH."""
    candidates = [
        _RUNTIME_DIR / name,
        _RUNTIME_DIR / (name + ".exe"),
        _RUNTIME_DIR / name / name,
    ]
    for c in candidates:
        if c.exists() and c.is_file():
            return c
    # Thử PATH
    import shutil
    found = shutil.which(name)
    return Path(found) if found else None


def _probe_socks5_port(host: str, port: int, timeout_s: float = 1.0) -> bool:
    """Kiểm tra cổng SOCKS5 đã mở chưa (kết nối TCP đơn giản)."""
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            return True
    except (OSError, ConnectionRefusedError):
        return False


async def _wait_for_port(host: str, port: int, timeout_s: float = _READY_TIMEOUT_S) -> bool:
    """Chờ đến khi cổng mở hoặc hết timeout."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if _probe_socks5_port(host, port):
            return True
        await asyncio.sleep(_POLL_INTERVAL_S)
    return False


def _extract_socks5_port(config: dict[str, Any]) -> int:
    """Đọc cổng SOCKS5 từ config JSON (hỗ trợ cả format Xray-core lẫn Sing-box)."""
    # Xray-core format: inbounds[].protocol == "socks" -> port
    for inbound in config.get("inbounds", []):
        if inbound.get("protocol") in ("socks", "socks5"):
            return int(inbound.get("port", _DEFAULT_SOCKS5_PORT))
    # Sing-box format: inbounds[].type == "socks" -> listen_port
    for inbound in config.get("inbounds", []):
        if inbound.get("type") in ("socks", "mixed"):
            return int(inbound.get("listen_port", _DEFAULT_SOCKS5_PORT))
    # Fallback: tìm bất kỳ trường "port" nào có giá trị hợp lý
    return config.get("socks5_port", _DEFAULT_SOCKS5_PORT)


class TunnelManager:
    """Quản lý vòng đời các tiến trình tunnel cục bộ.

    Dùng như async context manager để tự động dọn dẹp:
        async with TunnelManager(db) as tm:
            url = await tm.start("my-tunnel", "runtime/tunnels/config.json")
    """

    def __init__(self, db: Optional[Database] = None) -> None:
        self.db = db
        self._tunnels: dict[str, TunnelInfo] = {}
        self._procs: dict[str, asyncio.subprocess.Process] = {}

    async def __aenter__(self) -> "TunnelManager":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.stop_all()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def start(
        self,
        name: str,
        config_path: "Optional[str | Path]" = None,
        binary: str = "xray",
        socks5_host: str = "127.0.0.1",
        extra_args: Optional[list[str]] = None,
    ) -> str:
        """Khởi động tunnel và trả về proxy_url (socks5://host:port).

        Nếu tunnel `name` đã đang chạy, trả về URL ngay không khởi động lại.
        """
        if name in self._tunnels:
            info = self._tunnels[name]
            LOGGER.debug("tunnel '%s' đã chạy (PID %d, %.0fs)", name, info.pid, info.age_s)
            return info.proxy_url

        # Tìm binary
        bin_path = _detect_binary(binary)
        if bin_path is None:
            raise FileNotFoundError(
                f"tunnel_manager: không tìm thấy binary '{binary}'. "
                f"Đặt vào {_RUNTIME_DIR}/ hoặc cài vào PATH."
            )

        # Đọc config & xác định cổng
        port = _DEFAULT_SOCKS5_PORT
        cfg_file: Optional[Path] = None

        if config_path:
            cfg_file = Path(config_path)
            if not cfg_file.exists():
                raise FileNotFoundError(f"tunnel_manager: không tìm thấy config '{config_path}'")
            with cfg_file.open() as f:
                cfg_data = json.load(f)
            port = _extract_socks5_port(cfg_data)
        else:
            # Tạo config tối thiểu (SOCKS5 inbound không auth, không outbound - chỉ dùng để test)
            cfg_data = {
                "inbounds": [{"protocol": "socks", "port": port, "listen": socks5_host,
                               "settings": {"auth": "noauth", "udp": True}}],
                "outbounds": [{"protocol": "freedom"}],
                "log": {"loglevel": "warning"},
            }
            tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
            json.dump(cfg_data, tmp)
            tmp.close()
            cfg_file = Path(tmp.name)
            LOGGER.info("tunnel_manager: dùng config mặc định tạm tại %s", cfg_file)

        # Khởi tiến trình
        cmd = [str(bin_path), "run", "-c", str(cfg_file)] + (extra_args or [])
        LOGGER.info("tunnel_manager: khởi động '%s' -> %s:%d (cmd: %s)",
                    name, socks5_host, port, " ".join(cmd))

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
            # Tạo nhóm tiến trình riêng để kill cả cây khi cần
            start_new_session=True,
        )

        # Chờ cổng sẵn sàng
        ready = await _wait_for_port(socks5_host, port)
        if not ready:
            # Lấy stderr để chẩn đoán
            try:
                _, stderr_data = await asyncio.wait_for(proc.communicate(), timeout=2.0)
                err_msg = (stderr_data or b"").decode(errors="replace")[:500]
            except asyncio.TimeoutError:
                err_msg = "(không đọc được stderr)"
                proc.kill()
            raise RuntimeError(
                f"tunnel_manager: '{name}' không sẵn sàng sau {_READY_TIMEOUT_S}s. "
                f"Lỗi tiến trình: {err_msg}"
            )

        info = TunnelInfo(
            name=name, pid=proc.pid,
            socks5_host=socks5_host, socks5_port=port,
            config_path=str(cfg_file),
        )
        self._tunnels[name] = info
        self._procs[name] = proc
        LOGGER.info("tunnel_manager: '%s' sẵn sàng tại %s (PID %d)", name, info.proxy_url, proc.pid)

        # Lưu trạng thái vào DB nếu có
        if self.db:
            await self.db.aset_tunnel_state(name, {
                "pid": proc.pid, "proxy_url": info.proxy_url,
                "config_path": str(cfg_file),
                "started_at": info.started_at,
            })
        return info.proxy_url

    async def stop(self, name: str) -> None:
        """Dừng tunnel theo tên."""
        proc = self._procs.pop(name, None)
        self._tunnels.pop(name, None)
        if proc is None:
            LOGGER.debug("tunnel_manager: '%s' không đang chạy", name)
            return
        try:
            if platform.system() == "Windows":
                proc.kill()
            else:
                # Gửi SIGTERM cho cả nhóm tiến trình
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            await asyncio.wait_for(proc.wait(), timeout=5.0)
            LOGGER.info("tunnel_manager: đã dừng '%s'", name)
        except (ProcessLookupError, PermissionError):
            pass
        except asyncio.TimeoutError:
            LOGGER.warning("tunnel_manager: '%s' không dừng sau 5s - kill", name)
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        if self.db:
            await self.db.adelete_tunnel_state(name)

    async def stop_all(self) -> None:
        """Dừng toàn bộ tunnel đang chạy."""
        for name in list(self._tunnels):
            await self.stop(name)

    def get_info(self, name: str) -> Optional[TunnelInfo]:
        return self._tunnels.get(name)

    def list_running(self) -> list[TunnelInfo]:
        return list(self._tunnels.values())

    async def health_check(self, name: str) -> bool:
        """Kiểm tra tunnel còn sống: tiến trình còn chạy VÀ cổng còn mở."""
        info = self._tunnels.get(name)
        proc = self._procs.get(name)
        if info is None or proc is None:
            return False
        if proc.returncode is not None:
            LOGGER.warning("tunnel_manager: '%s' đã thoát (code %d)", name, proc.returncode)
            return False
        return _probe_socks5_port(info.socks5_host, info.socks5_port)

    async def restart_if_dead(self, name: str, **start_kwargs: Any) -> Optional[str]:
        """Khởi động lại tunnel nếu không còn healthy. Trả về proxy_url hoặc None."""
        if await self.health_check(name):
            info = self._tunnels[name]
            return info.proxy_url
        LOGGER.warning("tunnel_manager: '%s' không còn healthy - khởi động lại", name)
        await self.stop(name)
        try:
            return await self.start(name, **start_kwargs)
        except Exception as exc:
            LOGGER.error("tunnel_manager: khởi động lại '%s' thất bại: %s", name, exc)
            return None

    # ------------------------------------------------------------------
    # Transport Layer Diagnostics
    # ------------------------------------------------------------------

    async def diagnose(self, target_url: str, name: Optional[str] = None) -> dict[str, Any]:
        """Chẩn đoán kết nối qua tunnel (hoặc trực tiếp) tới target_url.

        Trả về dict:
          - tcp_connect_ms: thời gian kết nối TCP
          - tls_handshake_ms: thời gian TLS (nếu HTTPS)
          - ttfb_ms: Time To First Byte (qua httpx)
          - proxy_url: proxy đã dùng (None = kết nối thẳng)
          - error: chuỗi lỗi nếu thất bại
        """
        import httpx
        from urllib.parse import urlsplit

        result: dict[str, Any] = {
            "target": target_url,
            "proxy_url": None,
            "tcp_connect_ms": None,
            "tls_handshake_ms": None,
            "ttfb_ms": None,
            "http_status": None,
            "error": None,
        }

        proxy_url: Optional[str] = None
        if name and name in self._tunnels:
            proxy_url = self._tunnels[name].proxy_url
            result["proxy_url"] = proxy_url

        try:
            # Đo TCP connect riêng
            parsed = urlsplit(target_url)
            host = parsed.hostname or ""
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            t_tcp = time.perf_counter()
            # Chỉ đo kết nối trực tiếp (không qua proxy) để có con số tham chiếu
            with socket.create_connection((host, port), timeout=5.0):
                result["tcp_connect_ms"] = round((time.perf_counter() - t_tcp) * 1000, 1)

            # Đo TTFB qua httpx (có thể qua proxy)
            proxies = {"http://": proxy_url, "https://": proxy_url} if proxy_url else None
            t_req = time.perf_counter()
            async with httpx.AsyncClient(proxies=proxies, timeout=15.0, http2=True) as client:
                resp = await client.get(target_url, follow_redirects=True)
                result["ttfb_ms"] = round((time.perf_counter() - t_req) * 1000, 1)
                result["http_status"] = resp.status_code
                # Đọc TLS info nếu có
                if hasattr(resp, "extensions"):
                    tls_info = resp.extensions.get("tls_established")
                    if tls_info:
                        result["tls_established"] = True

        except Exception as exc:
            result["error"] = str(exc)[:300]
            LOGGER.warning("tunnel_manager diagnose '%s' qua %s: %s", target_url, name, exc)

        return result
