"""Công Cụ Chọn Phần Tử Trực Quan (Point-and-Click Visual Element Picker).

Mở trình duyệt thật với lớp phủ JS (Overlay Highlighter). Khi người dùng
di chuột → border sáng lên; click → trích xuất CSS/XPath/ARIA selector bền vững
nhất → gửi về dashboard qua WebSocket SSE.

Luồng:
  dashboard "Pick Element" → POST /picker/start {url}
  → visual_picker mở Chromium headful (1 tab)
  → inject overlay JS
  → user click phần tử trên browser
  → JS → expose_function → Python extract selector
  → Server-Sent Event → dashboard nhận, điền ô cấu hình
  → browser đóng

GIỚI HẠN ĐÃ BIẾT:
  - Phải có màn hình (DISPLAY) để chạy headful. Trên Linux headless server:
    cài Xvfb và set DISPLAY=:99 trước khi gọi picker.
  - Cross-origin iframes không inspect được (Same-Origin Policy).
  - Selector trích xuất ưu tiên: id → aria-label → role+text → CSS path → XPath.
    Với nội dung động (class ngẫu nhiên kiểu BEM hash), CSS path có thể không bền.
  - Mỗi lần chỉ chạy được 1 phiên picker; gọi /picker/stop để huỷ sớm.
  - Browser mở đúng 1 tab, không navigate sang trang khác trong session picker.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

LOGGER = logging.getLogger("qa.picker")

# ---------------------------------------------------------------------------
# JS Overlay Highlighter — inject vào trang để bắt sự kiện phần tử
# ---------------------------------------------------------------------------
_OVERLAY_JS = """
(callbackName) => {
  if (window.__qa_picker_active) return 'already_active';
  window.__qa_picker_active = true;

  // ── Tạo overlay style ────────────────────────────────────────────────
  const style = document.createElement('style');
  style.id = '__qa_picker_style';
  style.textContent = `
    .__qa_hover {
      outline: 2px solid #1f6f5c !important;
      outline-offset: 1px !important;
      cursor: crosshair !important;
    }
    #__qa_tooltip {
      position: fixed; z-index: 2147483647;
      background: #1f6f5c; color: #fff;
      font: 11px/1.4 monospace; padding: 4px 8px;
      border-radius: 4px; pointer-events: none;
      max-width: 400px; word-break: break-all;
      box-shadow: 0 2px 8px rgba(0,0,0,.3);
    }
    #__qa_banner {
      position: fixed; top: 0; left: 0; right: 0; z-index: 2147483646;
      background: #1f6f5cdd; color: #fff;
      font: 13px/1.5 system-ui; padding: 6px 16px;
      text-align: center; letter-spacing: .3px;
    }
  `;
  document.head.appendChild(style);

  // Banner thông báo
  const banner = document.createElement('div');
  banner.id = '__qa_banner';
  banner.textContent = '🎯 QA Picker đang hoạt động — Di chuột để chọn phần tử, nhấp để xác nhận. Nhấn ESC để huỷ.';
  document.body.prepend(banner);

  // Tooltip
  const tip = document.createElement('div');
  tip.id = '__qa_tooltip';
  document.body.appendChild(tip);

  let hovered = null;

  // ── Helpers trích xuất selector ──────────────────────────────────────
  function getAriaLabel(el) {
    return el.getAttribute('aria-label') || el.getAttribute('placeholder') ||
           el.getAttribute('title') || el.getAttribute('alt') || '';
  }
  function getRole(el) { return el.getAttribute('role') || el.tagName.toLowerCase(); }
  function getInnerText(el) {
    const t = (el.innerText || el.textContent || '').trim().replace(/\\s+/g, ' ');
    return t.length > 60 ? t.slice(0, 60) + '…' : t;
  }

  function cssPath(el) {
    const parts = [];
    while (el && el !== document.body) {
      let sel = el.tagName.toLowerCase();
      if (el.id) return '#' + CSS.escape(el.id) + (parts.length ? ' > ' + parts.join(' > ') : '');
      const cls = [...el.classList].filter(c => !c.match(/^[a-z0-9]{6,}$/i) && c.length < 30);
      if (cls.length) sel += '.' + cls.slice(0, 2).map(c => CSS.escape(c)).join('.');
      const siblings = [...(el.parentElement?.children || [])].filter(s => s.tagName === el.tagName);
      if (siblings.length > 1) sel += ':nth-of-type(' + (siblings.indexOf(el) + 1) + ')';
      parts.unshift(sel);
      el = el.parentElement;
    }
    return 'body > ' + parts.join(' > ');
  }

  function xpathOf(el) {
    const parts = [];
    while (el && el.nodeType === 1) {
      let idx = 1;
      let sib = el.previousElementSibling;
      while (sib) { if (sib.tagName === el.tagName) idx++; sib = sib.previousElementSibling; }
      parts.unshift(el.tagName.toLowerCase() + (idx > 1 ? '[' + idx + ']' : ''));
      el = el.parentElement;
    }
    return '//' + parts.join('/');
  }

  function extractSelector(el) {
    // Ưu tiên ID
    if (el.id) return { type: 'css', value: '#' + el.id, confidence: 'high' };
    // ARIA label
    const aria = getAriaLabel(el);
    if (aria) return { type: 'aria', value: aria, confidence: 'high',
                       css: cssPath(el), xpath: xpathOf(el) };
    // role + text (chỉ dùng khi text ngắn và ổn định)
    const txt = getInnerText(el);
    const role = getRole(el);
    if (txt && txt.length <= 40 && !txt.match(/\\d{4,}/))
      return { type: 'text', value: txt, role, confidence: 'medium',
               css: cssPath(el), xpath: xpathOf(el) };
    // CSS path
    const css = cssPath(el);
    return { type: 'css', value: css, confidence: 'low',
             xpath: xpathOf(el) };
  }

  function describeEl(el) {
    const tag = el.tagName.toLowerCase();
    const aria = getAriaLabel(el);
    const txt = getInnerText(el);
    const id = el.id ? '#' + el.id : '';
    return [tag, id, aria && ('aria: ' + aria), txt && ('"' + txt.slice(0,30) + '"')]
      .filter(Boolean).join(' ');
  }

  // ── Event handlers ────────────────────────────────────────────────────
  function onMouseOver(e) {
    const el = e.target;
    if (el.id && el.id.startsWith('__qa_')) return;
    if (hovered) hovered.classList.remove('__qa_hover');
    el.classList.add('__qa_hover');
    hovered = el;
    const sel = extractSelector(el);
    tip.textContent = describeEl(el) + '  →  ' + sel.value;
    tip.style.display = 'block';
  }

  function onMouseMove(e) {
    const x = e.clientX, y = e.clientY;
    const tw = tip.offsetWidth, th = tip.offsetHeight;
    tip.style.left = (x + 12 + tw > window.innerWidth ? x - tw - 8 : x + 12) + 'px';
    tip.style.top  = (y + 20 + th > window.innerHeight ? y - th - 6 : y + 16) + 'px';
  }

  function onMouseOut(e) {
    if (hovered && e.target === hovered) {
      hovered.classList.remove('__qa_hover');
      hovered = null;
      tip.style.display = 'none';
    }
  }

  function onClick(e) {
    const el = e.target;
    if (el.id && el.id.startsWith('__qa_')) return;
    e.preventDefault(); e.stopPropagation();
    const sel = extractSelector(el);
    sel.tag = el.tagName.toLowerCase();
    sel.inner_text = getInnerText(el);
    sel.aria_label = getAriaLabel(el);
    sel.role = el.getAttribute('role') || '';
    sel.element_type = el.type || '';
    sel.name = el.name || '';
    // Gửi về Python
    try { window[callbackName](JSON.stringify(sel)); } catch(err) {}
    cleanup();
  }

  function onKeyDown(e) {
    if (e.key === 'Escape') { cleanup(); window[callbackName](JSON.stringify({cancelled:true})); }
  }

  function cleanup() {
    document.removeEventListener('mouseover', onMouseOver, true);
    document.removeEventListener('mousemove', onMouseMove, true);
    document.removeEventListener('mouseout',  onMouseOut,  true);
    document.removeEventListener('click',     onClick,     true);
    document.removeEventListener('keydown',   onKeyDown,   true);
    document.getElementById('__qa_picker_style')?.remove();
    document.getElementById('__qa_tooltip')?.remove();
    document.getElementById('__qa_banner')?.remove();
    if (hovered) hovered.classList.remove('__qa_hover');
    window.__qa_picker_active = false;
  }

  document.addEventListener('mouseover', onMouseOver, true);
  document.addEventListener('mousemove', onMouseMove, true);
  document.addEventListener('mouseout',  onMouseOut,  true);
  document.addEventListener('click',     onClick,     true);
  document.addEventListener('keydown',   onKeyDown,   true);
  return 'started';
}
"""


# ---------------------------------------------------------------------------
# PickerSession
# ---------------------------------------------------------------------------

@dataclass
class PickedElement:
    """Kết quả người dùng chọn từ picker."""
    type: str            # css | aria | text
    value: str           # selector value
    confidence: str      # high | medium | low
    css: str = ""
    xpath: str = ""
    tag: str = ""
    inner_text: str = ""
    aria_label: str = ""
    role: str = ""
    element_type: str = ""
    name: str = ""
    cancelled: bool = False
    picked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def best_selector(self) -> str:
        """Trả về selector tốt nhất theo thứ tự ưu tiên."""
        if self.type == "css" and self.value.startswith("#"):
            return self.value
        if self.type == "aria" and self.aria_label:
            return f"[aria-label='{self.aria_label}']"
        if self.css:
            return self.css
        return self.value

    def to_step(self, action: str = "click") -> dict[str, Any]:
        """Chuyển thành step JSON cho scenarios.json."""
        return {
            "action": action,
            "selector": self.best_selector(),
            "_picker_meta": {
                "type": self.type,
                "confidence": self.confidence,
                "inner_text": self.inner_text[:60],
                "xpath": self.xpath,
                "aria_label": self.aria_label,
            },
        }


class VisualPickerSession:
    """Một phiên picker: mở browser headful, inject overlay, chờ user click."""

    def __init__(self, url: str, timeout_s: float = 120.0) -> None:
        self.url = url
        self.timeout_s = timeout_s
        self._result: Optional[PickedElement] = None
        self._done = asyncio.Event()

    def _on_pick(self, json_str: str) -> None:
        """Callback từ JS khi user click một phần tử."""
        try:
            d = json.loads(json_str)
            if d.get("cancelled"):
                self._result = PickedElement(type="css", value="", confidence="high",
                                              cancelled=True)
            else:
                self._result = PickedElement(
                    type=d.get("type", "css"),
                    value=d.get("value", ""),
                    confidence=d.get("confidence", "low"),
                    css=d.get("css", ""),
                    xpath=d.get("xpath", ""),
                    tag=d.get("tag", ""),
                    inner_text=d.get("inner_text", ""),
                    aria_label=d.get("aria_label", ""),
                    role=d.get("role", ""),
                    element_type=d.get("element_type", ""),
                    name=d.get("name", ""),
                )
            self._done.set()
        except Exception as exc:
            LOGGER.warning("picker: parse callback error: %s", exc)

    async def run(self) -> Optional[PickedElement]:
        """Chạy session picker. Trả về PickedElement hoặc None nếu timeout."""
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            LOGGER.error("picker: Playwright chưa được cài")
            return None

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(
                headless=False,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--start-maximized",
                    "--no-first-run",
                ],
            )
            context = await browser.new_context(no_viewport=True)
            page = await context.new_page()

            # Navigate
            LOGGER.info("picker: mở %s", self.url)
            await page.goto(self.url, wait_until="domcontentloaded", timeout=30_000)

            # Inject overlay
            await page.expose_function("__qa_picker_cb__", self._on_pick)
            result = await page.evaluate(_OVERLAY_JS, "__qa_picker_cb__")
            LOGGER.info("picker: overlay inject = %s, chờ user click…", result)

            try:
                await asyncio.wait_for(self._done.wait(), timeout=self.timeout_s)
            except asyncio.TimeoutError:
                LOGGER.info("picker: timeout sau %.0fs", self.timeout_s)
                self._result = None

            await browser.close()

        if self._result and not self._result.cancelled:
            LOGGER.info("picker: đã chọn [%s] selector='%s' confidence=%s",
                        self._result.tag, self._result.value[:60], self._result.confidence)
        return self._result


# ---------------------------------------------------------------------------
# Global singleton (1 session at a time)
# ---------------------------------------------------------------------------
_active_session: Optional[VisualPickerSession] = None
_active_task: Optional[asyncio.Task] = None


async def start_picker(url: str, timeout_s: float = 120.0) -> dict[str, Any]:
    """API: bắt đầu phiên picker. Trả về ngay, kết quả qua /picker/result."""
    global _active_session, _active_task
    if _active_task and not _active_task.done():
        return {"status": "busy", "message": "Đang có phiên picker khác chạy"}

    _active_session = VisualPickerSession(url, timeout_s)
    _active_task = asyncio.create_task(_active_session.run())
    return {"status": "started", "url": url, "timeout_s": timeout_s}


async def get_picker_result(wait_s: float = 0.5) -> Optional[dict[str, Any]]:
    """API: lấy kết quả picker. None nếu chưa xong."""
    if _active_task is None:
        return {"status": "no_session"}
    if not _active_task.done():
        try:
            await asyncio.wait_for(asyncio.shield(_active_task), timeout=wait_s)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            return {"status": "pending"}
    result = _active_task.result()
    if result is None:
        return {"status": "timeout"}
    if result.cancelled:
        return {"status": "cancelled"}
    return {"status": "ok", "element": result.__dict__,
            "step_click": result.to_step("click"),
            "step_type": result.to_step("type")}


async def stop_picker() -> dict[str, Any]:
    """API: huỷ phiên picker đang chạy."""
    global _active_task
    if _active_task and not _active_task.done():
        _active_task.cancel()
        return {"status": "cancelled"}
    return {"status": "not_running"}
