"""Bộ Ghi Nhận & Phát Lại Tương Tác Chuẩn Hóa (Deterministic Action Recorder & Replayer).

Hai thành phần chính:
  1. TraceRecorder  - Ghi toàn bộ sự kiện người dùng (chuột, bàn phím, cuộn) vào
                      `recorded_trace.json` khi chạy browser ở chế độ HEADLESS=false.
  2. TraceReplayer  - Nạp `recorded_trace.json`, áp Gaussian Jitter lên thời gian
                      và toạ độ, phát lại trên Playwright page để mô phỏng người thật.

Format file `recorded_trace.json`:
  {
    "version": 1,
    "url": "https://...",
    "recorded_at": "2026-11-14T10:00:00Z",
    "viewport": {"width": 1280, "height": 800},
    "events": [
      {"type": "navigate",   "t": 0,    "url": "..."},
      {"type": "mousemove",  "t": 120,  "x": 450, "y": 320},
      {"type": "click",      "t": 850,  "x": 450, "y": 320, "button": "left"},
      {"type": "keydown",    "t": 1200, "key": "Tab"},
      {"type": "keyup",      "t": 1250, "key": "Tab"},
      {"type": "type",       "t": 1300, "text": "hello", "selector": "#search"},
      {"type": "scroll",     "t": 2000, "x": 0, "y": 400, "delta_y": 300},
      {"type": "wait",       "t": 3000, "duration_ms": 500},
    ]
  }

GIỚI HẠN ĐÃ BIẾT:
  - TraceRecorder dùng CDP (Chrome DevTools Protocol) → chỉ hoạt động với Chromium.
    Firefox/WebKit không hỗ trợ CDP session.expose_function (giới hạn Playwright).
  - Jitter được áp theo Gaussian(μ=0, σ=jitter_sigma_ms) lên thời gian trễ.
    Giá trị âm sau jitter được clamp về 0 (không thể đi ngược thời gian).
  - Toạ độ jitter bị clamp trong viewport để tránh click ngoài màn hình.
  - Trace không ghi được: drag-and-drop phức tạp, file upload dialog,
    hành động trong popup/new tab (giới hạn của CDP Input domain).
  - Phát lại có thể thất bại nếu trang đích thay đổi layout so với lúc ghi.
    Dùng selector-based fallback khi toạ độ không còn hợp lệ.
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import random
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.trace")


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class TraceEvent:
    type: str                              # navigate|mousemove|click|keydown|keyup|type|scroll|wait
    t: float                               # ms kể từ đầu trace
    # Toạ độ (chuột / cuộn)
    x: Optional[float] = None
    y: Optional[float] = None
    delta_y: Optional[float] = None
    # Bàn phím
    key: Optional[str] = None
    text: Optional[str] = None
    selector: Optional[str] = None        # CSS selector dùng làm fallback khi replay
    button: Optional[str] = None          # "left" | "right" | "middle"
    # Điều hướng
    url: Optional[str] = None
    # Chờ
    duration_ms: Optional[float] = None


@dataclass
class Trace:
    version: int = 1
    url: str = ""
    recorded_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    viewport: dict[str, int] = field(default_factory=lambda: {"width": 1280, "height": 800})
    events: list[TraceEvent] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["events"] = [
            {k: v for k, v in e.items() if v is not None}
            for e in d["events"]
        ]
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Trace":
        events = [TraceEvent(**{k: v for k, v in e.items()
                                if k in TraceEvent.__dataclass_fields__})
                  for e in d.get("events", [])]
        return cls(
            version=d.get("version", 1),
            url=d.get("url", ""),
            recorded_at=d.get("recorded_at", ""),
            viewport=d.get("viewport", {"width": 1280, "height": 800}),
            events=events,
        )

    @classmethod
    def load(cls, path: "str | Path") -> "Trace":
        with open(path) as f:
            return cls.from_dict(json.load(f))

    def save(self, path: "str | Path") -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
        LOGGER.info("trace: đã lưu %d sự kiện → %s", len(self.events), path)


# ---------------------------------------------------------------------------
# JavaScript injection cho recording
# ---------------------------------------------------------------------------

_JS_RECORDER_BOOTSTRAP = """
(config) => {
  if (window.__qa_recorder) return 'already_running';
  const cfg = config || {};
  const t0 = Date.now();
  const events = window.__qa_events = [];
  const rec = (obj) => events.push({ ...obj, t: Date.now() - t0 });

  // Mousemove - sample mỗi 50ms để tránh flood
  let lastMove = 0;
  document.addEventListener('mousemove', (e) => {
    if (Date.now() - lastMove < 50) return;
    lastMove = Date.now();
    rec({ type: 'mousemove', x: Math.round(e.clientX), y: Math.round(e.clientY) });
  }, true);

  document.addEventListener('click', (e) => {
    rec({ type: 'click', x: Math.round(e.clientX), y: Math.round(e.clientY),
          button: ['left','middle','right'][e.button] || 'left',
          selector: e.target ? (e.target.id ? '#'+e.target.id :
                    e.target.className ? '.'+e.target.className.split(' ')[0] : e.target.tagName.toLowerCase()) : null });
  }, true);

  document.addEventListener('keydown', (e) => {
    if (!cfg.record_keys) return;
    rec({ type: 'keydown', key: e.key });
  }, true);

  document.addEventListener('keyup', (e) => {
    if (!cfg.record_keys) return;
    rec({ type: 'keyup', key: e.key });
  }, true);

  document.addEventListener('scroll', (e) => {
    rec({ type: 'scroll', x: Math.round(window.scrollX), y: Math.round(window.scrollY),
          delta_y: 0 });
  }, { passive: true, capture: true });

  // Ghi lại input text (không ghi mật khẩu)
  document.addEventListener('input', (e) => {
    if (!cfg.record_input) return;
    if (e.target && e.target.type === 'password') return;
    if (e.target && e.target.type === 'text') {
      rec({ type: 'type', text: e.data || '', selector: e.target.id ? '#'+e.target.id : e.target.tagName });
    }
  }, true);

  window.__qa_recorder = { started_at: t0 };
  return 'started';
}
"""

_JS_EXPORT_EVENTS = "() => window.__qa_events || []"
_JS_CLEAR_EVENTS = "() => { window.__qa_events = []; }"


# ---------------------------------------------------------------------------
# Recorder
# ---------------------------------------------------------------------------

class TraceRecorder:
    """Ghi lại chuỗi sự kiện người dùng thông qua Playwright CDP + JS injection."""

    def __init__(
        self,
        page: Any,
        record_keys: bool = True,
        record_input: bool = True,
    ) -> None:
        self.page = page
        self._config = {"record_keys": record_keys, "record_input": record_input}
        self._start_url: str = ""
        self._start_time: float = 0.0
        self._events: list[TraceEvent] = []

    async def start(self) -> None:
        """Bắt đầu ghi - inject JS recorder vào trang hiện tại."""
        self._start_url = self.page.url
        self._start_time = time.perf_counter()
        # Lắng nghe navigation để ghi sự kiện navigate
        self.page.on("framenavigated", self._on_navigate)
        result = await self.page.evaluate(_JS_RECORDER_BOOTSTRAP, self._config)
        LOGGER.info("trace_recorder: bắt đầu ghi tại %s (result=%s)", self._start_url, result)

    def _on_navigate(self, frame: Any) -> None:
        if frame == self.page.main_frame:
            t = (time.perf_counter() - self._start_time) * 1000
            self._events.append(TraceEvent(type="navigate", t=t, url=self.page.url))

    async def checkpoint(self) -> int:
        """Thu thập sự kiện từ JS buffer, trả về số sự kiện mới."""
        try:
            raw: list[dict[str, Any]] = await self.page.evaluate(_JS_EXPORT_EVENTS)
        except Exception:
            return 0
        for item in raw:
            evt = TraceEvent(**{k: v for k, v in item.items()
                                if k in TraceEvent.__dataclass_fields__})
            self._events.append(evt)
        await self.page.evaluate(_JS_CLEAR_EVENTS)
        return len(raw)

    async def stop(self) -> Trace:
        """Dừng ghi, thu thập sự kiện còn lại, trả về Trace."""
        await self.checkpoint()
        try:
            self.page.remove_listener("framenavigated", self._on_navigate)
        except Exception:
            pass
        vp = self.page.viewport_size or {"width": 1280, "height": 800}
        trace = Trace(
            url=self._start_url,
            viewport={"width": vp["width"], "height": vp["height"]},
            events=sorted(self._events, key=lambda e: e.t),
        )
        LOGGER.info("trace_recorder: dừng ghi - %d sự kiện", len(trace.events))
        return trace

    async def stop_and_save(self, path: "str | Path") -> Trace:
        trace = await self.stop()
        trace.save(path)
        return trace


# ---------------------------------------------------------------------------
# Gaussian Jitter
# ---------------------------------------------------------------------------

class JitterEngine:
    """Áp Gaussian Jitter lên thời gian và toạ độ của trace."""

    def __init__(
        self,
        time_sigma_ms: float = 50.0,     # độ lệch chuẩn jitter thời gian (ms)
        coord_sigma_px: float = 3.0,     # độ lệch chuẩn jitter toạ độ (pixel)
        seed: Optional[int] = None,
    ) -> None:
        self.time_sigma = time_sigma_ms
        self.coord_sigma = coord_sigma_px
        self.rng = random.Random(seed)

    def jitter_time(self, delay_ms: float) -> float:
        """Áp jitter lên khoảng thời gian trễ, clamp về ≥ 0."""
        return max(0.0, delay_ms + self.rng.gauss(0, self.time_sigma))

    def jitter_coord(self, x: float, y: float,
                     vp_w: int = 1280, vp_h: int = 800) -> tuple[float, float]:
        """Áp jitter lên toạ độ, clamp trong viewport."""
        nx = max(0.0, min(float(vp_w), x + self.rng.gauss(0, self.coord_sigma)))
        ny = max(0.0, min(float(vp_h), y + self.rng.gauss(0, self.coord_sigma)))
        return nx, ny

    def apply(self, trace: Trace) -> Trace:
        """Trả về Trace mới với jitter đã áp, không sửa trace gốc."""
        vp_w = trace.viewport.get("width", 1280)
        vp_h = trace.viewport.get("height", 800)
        new_events: list[TraceEvent] = []
        prev_t = 0.0
        for ev in trace.events:
            delay = ev.t - prev_t
            jittered_delay = self.jitter_time(delay)
            new_t = prev_t + jittered_delay
            prev_t = ev.t  # dựa vào t gốc để tính delay tiếp theo

            new_ev = TraceEvent(
                type=ev.type,
                t=round(new_t, 1),
                x=None, y=None,
                key=ev.key, text=ev.text,
                selector=ev.selector,
                button=ev.button,
                url=ev.url,
                delta_y=ev.delta_y,
                duration_ms=ev.duration_ms,
            )
            if ev.x is not None and ev.y is not None:
                jx, jy = self.jitter_coord(ev.x, ev.y, vp_w, vp_h)
                new_ev.x = round(jx, 1)
                new_ev.y = round(jy, 1)
            else:
                new_ev.x = ev.x
                new_ev.y = ev.y

            new_events.append(new_ev)

        return Trace(
            version=trace.version,
            url=trace.url,
            recorded_at=trace.recorded_at,
            viewport=trace.viewport,
            events=new_events,
        )


# ---------------------------------------------------------------------------
# Replayer
# ---------------------------------------------------------------------------

class TraceReplayer:
    """Phát lại trace trên Playwright page với jitter tự nhiên."""

    def __init__(
        self,
        page: Any,
        jitter: Optional[JitterEngine] = None,
        speed_factor: float = 1.0,     # < 1.0 = phát nhanh hơn, > 1.0 = chậm hơn
        skip_navigate: bool = False,    # True = bỏ qua sự kiện navigate (đã ở đúng trang)
    ) -> None:
        self.page = page
        self.jitter = jitter or JitterEngine()
        self.speed = max(0.05, speed_factor)
        self.skip_navigate = skip_navigate

    async def replay(self, trace: "Trace | str | Path") -> dict[str, Any]:
        """Phát lại trace. Trả về dict kết quả."""
        if isinstance(trace, (str, Path)):
            trace = Trace.load(trace)

        # Áp jitter
        jittered = self.jitter.apply(trace)
        LOGGER.info("trace_replayer: phát lại %d sự kiện (speed=%.1fx)",
                    len(jittered.events), self.speed)

        stats = {"events_total": len(jittered.events), "events_ok": 0,
                 "events_error": 0, "errors": []}
        prev_t = 0.0

        for ev in jittered.events:
            # Chờ delay
            delay_ms = (ev.t - prev_t) * self.speed
            prev_t = ev.t
            if delay_ms > 0:
                await asyncio.sleep(delay_ms / 1000.0)

            try:
                await self._dispatch(ev)
                stats["events_ok"] += 1
            except Exception as exc:
                stats["events_error"] += 1
                err_msg = f"{ev.type}@{ev.t:.0f}ms: {exc}"
                stats["errors"].append(err_msg)
                LOGGER.debug("trace_replayer lỗi: %s", err_msg)

        LOGGER.info("trace_replayer: xong %d/%d sự kiện",
                    stats["events_ok"], stats["events_total"])
        return stats

    async def _dispatch(self, ev: TraceEvent) -> None:
        """Phát lại một sự kiện đơn lẻ."""
        if ev.type == "navigate":
            if not self.skip_navigate and ev.url:
                await self.page.goto(ev.url, wait_until="domcontentloaded")

        elif ev.type == "mousemove":
            if ev.x is not None and ev.y is not None:
                await self.page.mouse.move(ev.x, ev.y)

        elif ev.type == "click":
            if ev.x is not None and ev.y is not None:
                btn = ev.button or "left"
                await self.page.mouse.click(ev.x, ev.y, button=btn)
            elif ev.selector:
                # Fallback: dùng selector
                loc = self.page.locator(ev.selector).first
                await loc.click(timeout=3000)

        elif ev.type == "keydown":
            if ev.key:
                await self.page.keyboard.down(ev.key)

        elif ev.type == "keyup":
            if ev.key:
                await self.page.keyboard.up(ev.key)

        elif ev.type == "type":
            if ev.text:
                if ev.selector:
                    try:
                        await self.page.locator(ev.selector).first.type(
                            ev.text, delay=self.jitter.jitter_time(30))
                        return
                    except Exception:
                        pass
                await self.page.keyboard.type(ev.text,
                                              delay=self.jitter.jitter_time(30))

        elif ev.type == "scroll":
            x = ev.x or 0
            y = ev.y or 0
            dy = ev.delta_y or 0
            await self.page.evaluate(
                f"window.scrollTo({{left:{x}, top:{y+dy}, behavior:'smooth'}})"
            )

        elif ev.type == "wait":
            ms = ev.duration_ms or 500
            await asyncio.sleep(ms / 1000.0)


# ---------------------------------------------------------------------------
# Public convenience functions (dùng từ engine._run_step)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Phase 12: Visual Action-to-Node Recorder (singleton session, theo pattern
# visual_picker.py) - mở browser thật, ghi thao tác người dùng, khi dừng thì
# chuyển TraceEvent -> step JSON tương thích Flow Studio (action=click/type/
# scroll/wait/goto) để vẽ thẳng lên Drawflow canvas.
# ---------------------------------------------------------------------------

_recorder_session: dict[str, Any] = {}


def _trace_to_flow_steps(trace: "Trace") -> list[dict[str, Any]]:
    """Chuyển chuỗi TraceEvent thô thành step JSON gọn (gộp mousemove liên tục,
    bỏ qua sự kiện nhiễu), kèm `duration_ms` là khoảng NGHỈ THỰC TẾ trước hành
    động đó (mục 'kèm thời gian dừng thực tế' trong đặc tả)."""
    steps: list[dict[str, Any]] = [{"action": "goto", "url": trace.url}]
    last_t = 0.0
    for evt in trace.events:
        gap = max(0, round(evt.t - last_t))
        if evt.type == "navigate" and evt.url:
            if gap > 300:
                steps.append({"action": "wait", "duration_ms": gap})
            steps.append({"action": "goto", "url": evt.url})
        elif evt.type == "click":
            if gap > 300:
                steps.append({"action": "wait", "duration_ms": gap})
            steps.append({"action": "click", "selector": evt.selector or "", "_x": evt.x, "_y": evt.y})
        elif evt.type == "type" and evt.text:
            steps.append({"action": "type", "selector": evt.selector or "", "text": evt.text})
        elif evt.type == "scroll" and evt.delta_y is not None:
            steps.append({"action": "scroll", "delta_y": evt.delta_y})
        else:
            continue
        last_t = evt.t
    return steps


async def start_recording_session(url: str, headless: bool = False) -> dict[str, Any]:
    """Mở một trình duyệt THẬT (headless=False mặc định - người dùng cần THẤY
    và thao tác trực tiếp), điều hướng tới `url`, bắt đầu `TraceRecorder`.
    Chỉ một phiên ghi tại một thời điểm (singleton, như visual_picker.py)."""
    global _recorder_session
    if _recorder_session.get("active"):
        return {"ok": False, "error": "Đã có một phiên ghi đang chạy - dừng phiên đó trước."}
    try:
        from playwright.async_api import async_playwright
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(headless=headless)
        page = await browser.new_page()
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        recorder = TraceRecorder(page)
        await recorder.start()
        _recorder_session = {"active": True, "pw": pw, "browser": browser,
                             "page": page, "recorder": recorder, "url": url}
        return {"ok": True, "url": url}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


async def get_recording_status() -> dict[str, Any]:
    if not _recorder_session.get("active"):
        return {"active": False}
    try:
        n = await _recorder_session["recorder"].checkpoint()
        return {"active": True, "url": _recorder_session["url"],
                "events_captured": len(_recorder_session["recorder"]._events),
                "new_events_this_check": n}
    except Exception as exc:  # noqa: BLE001
        return {"active": True, "error": str(exc)[:200]}


async def stop_recording_session() -> dict[str, Any]:
    """Dừng ghi, đóng browser, trả về step JSON đã chuyển đổi sẵn cho Flow Studio."""
    global _recorder_session
    if not _recorder_session.get("active"):
        return {"ok": False, "error": "Không có phiên ghi nào đang chạy."}
    session = _recorder_session
    _recorder_session = {}
    try:
        trace = await session["recorder"].stop()
        steps = _trace_to_flow_steps(trace)
        return {"ok": True, "events_raw": len(trace.events), "steps": steps}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    finally:
        try:
            await session["browser"].close()
            await session["pw"].stop()
        except Exception:  # noqa: BLE001
            pass


async def run_trace_record(
    page: Any,
    output_path: "str | Path",
    duration_s: float = 30.0,
    record_keys: bool = True,
    record_input: bool = True,
) -> dict[str, Any]:
    """Record tự động trong `duration_s` giây (dùng trong test automation).
    Với người dùng thật: gọi start() / stop_and_save() thủ công.
    """
    recorder = TraceRecorder(page, record_keys=record_keys, record_input=record_input)
    await recorder.start()
    # Poll checkpoint mỗi 2 giây
    t0 = time.perf_counter()
    while (time.perf_counter() - t0) < duration_s:
        await asyncio.sleep(2.0)
        await recorder.checkpoint()
    trace = await recorder.stop_and_save(output_path)
    return {"events_recorded": len(trace.events), "output": str(output_path)}


async def run_trace_replay(
    page: Any,
    trace_path: "str | Path",
    cfg: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Entry point cho action='trace_replay' trong step config."""
    cfg = cfg or {}
    jitter = JitterEngine(
        time_sigma_ms=cfg.get("time_sigma_ms", 50.0),
        coord_sigma_px=cfg.get("coord_sigma_px", 3.0),
        seed=cfg.get("seed"),
    )
    replayer = TraceReplayer(
        page,
        jitter=jitter,
        speed_factor=cfg.get("speed_factor", 1.0),
        skip_navigate=cfg.get("skip_navigate", False),
    )
    return await replayer.replay(trace_path)
