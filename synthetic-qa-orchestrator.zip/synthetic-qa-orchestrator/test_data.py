"""Sinh dữ liệu kiểm thử cho biểu mẫu: bộ sinh nội bộ + LLM tùy chọn
(Ollama cục bộ hoặc dịch vụ tương thích OpenAI). LLM lỗi -> tự dùng bộ sinh nội bộ."""
from __future__ import annotations

import logging
import os
import random
import re
import string
from typing import Any, Optional

LOGGER = logging.getLogger("qa.testdata")

_FIRST = ["An", "Bình", "Châu", "Dũng", "Hà", "Khoa", "Lan", "Minh", "Nam", "Phương", "Quân", "Trang"]
_LAST = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Vũ", "Đặng", "Bùi"]
_SENT = ["Tôi muốn hỏi về thời gian giao hàng cho đơn gần nhất.",
         "Vui lòng cho biết chính sách đổi trả của sản phẩm này.",
         "Trang thanh toán đôi khi tải chậm, mong được kiểm tra giúp.",
         "Cảm ơn đội ngũ hỗ trợ, tôi sẽ phản hồi thêm nếu cần.",
         "Tôi cần xuất hóa đơn cho đơn hàng đã đặt tuần trước."]


class TestDataGenerator:
    __test__ = False  # tránh pytest hiểu nhầm là lớp test

    def __init__(self, llm: Optional[dict[str, Any]] = None, rng: Optional[random.Random] = None,
                 max_llm_calls_per_run: int = 3) -> None:
        self.llm = llm or {"provider": "none"}
        self.rng = rng or random.Random()
        self._max_llm = max_llm_calls_per_run
        self._llm_calls = 0

    def new_run(self) -> None:
        self._llm_calls = 0

    # ------------------------------------------------------------ nội bộ
    def builtin(self, hint: str) -> str:
        h = hint.lower()
        tag = "".join(self.rng.choices(string.ascii_lowercase + string.digits, k=6))
        if "mail" in h:
            return f"qa.{tag}@example.com"
        if "pass" in h:
            return "Test#12345"
        if any(k in h for k in ("tel", "phone", "mobile", "sdt")):
            return "+15555550100"
        if "url" in h or "website" in h:
            return "https://example.com"
        if any(k in h for k in ("zip", "postal")):
            return "700000"
        if any(k in h for k in ("number", "age", "qty", "quantity")):
            return str(self.rng.randint(1, 9))
        if any(k in h for k in ("first", "given")):
            return self.rng.choice(_FIRST)
        if any(k in h for k in ("last", "family", "surname")):
            return self.rng.choice(_LAST)
        if "name" in h:
            return f"{self.rng.choice(_LAST)} {self.rng.choice(_FIRST)}"
        return self.rng.choice(_SENT)

    def resolve(self, text: str) -> str:
        """Thay token {data:email}, {data:name}... trong giá trị của bước fill."""
        return re.sub(r"\{data:([a-z_]+)\}", lambda m: self.builtin(m.group(1)), text)

    # ------------------------------------------------------------ LLM
    async def text(self, hint: str, free_text: bool = False) -> str:
        if free_text and self.llm.get("provider", "none") != "none" and self._llm_calls < self._max_llm:
            self._llm_calls += 1
            try:
                out = await self._ask_llm(hint)
                if out:
                    return out
            except Exception as exc:  # noqa: BLE001
                LOGGER.warning("LLM lỗi (%s), dùng dữ liệu nội bộ", exc)
        return self.builtin(hint)

    async def _ask_llm(self, hint: str) -> Optional[str]:
        import httpx

        prompt = (f"Viết một đoạn văn bản mẫu ngắn (tối đa 2 câu, tiếng Việt) để điền vào ô '{hint}' "
                  "của biểu mẫu kiểm thử. Chỉ trả về nội dung, không giải thích.")
        provider = self.llm["provider"]
        timeout = float(self.llm.get("timeout_s", 15))
        async with httpx.AsyncClient(timeout=timeout) as client:
            if provider == "ollama":
                base = self.llm.get("base_url", "http://127.0.0.1:11434").rstrip("/")
                r = await client.post(f"{base}/api/generate", json={
                    "model": self.llm.get("model", "llama3.2"), "prompt": prompt, "stream": False})
                r.raise_for_status()
                return r.json().get("response", "").strip()[:300] or None
            if provider == "openai":
                base = self.llm.get("base_url", "https://api.openai.com/v1").rstrip("/")
                key = os.environ.get(self.llm.get("api_key_env", "OPENAI_API_KEY"), "")
                r = await client.post(f"{base}/chat/completions",
                                      headers={"Authorization": f"Bearer {key}"},
                                      json={"model": self.llm.get("model", "gpt-4o-mini"),
                                            "messages": [{"role": "user", "content": prompt}],
                                            "max_tokens": 120})
                r.raise_for_status()
                return r.json()["choices"][0]["message"]["content"].strip()[:300] or None
        return None
