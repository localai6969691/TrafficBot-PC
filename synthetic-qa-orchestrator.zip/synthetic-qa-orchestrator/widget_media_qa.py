"""Thư viện kiểm định thành phần nhúng & đa phương tiện (Embedded Widget & Media QA).

Mở rộng module interaction.py thành bộ thư viện chuyên biệt dành cho:
  1. Cross-Origin Iframe Validator  - quét, đo lường, kiểm tra clickability của iframes.
  2. Media Streaming Telemetry      - đo buffering, retention, trạng thái trình phát HTML5/YouTube.

Tích hợp vào workflow qua action "widget_qa" và "media_qa" trong steps[].

GIỚI HẠN ĐÃ BIẾT:
  - Iframe cùng origin: Playwright có thể inspect nội dung đầy đủ.
  - Iframe cross-origin: CHỈ đọc được outer frame state (visible, loaded, size).
    Không đọc được DOM bên trong do Same-Origin Policy - đây là giới hạn bảo mật
    của trình duyệt, không phải lỗi implementation.
  - YouTube Embedded Player: đo gián tiếp qua postMessage API và DOM state của
    iframe container. Không can thiệp được vào player nội bộ của YouTube.
  - Media buffering time phụ thuộc vào băng thông mạng và CDN - giá trị đo
    trong môi trường headless có thể khác production thật.
  - autoplay trên Chromium headless bị block theo mặc định - script dùng
    `--autoplay-policy=no-user-gesture-required` khi launch browser.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

LOGGER = logging.getLogger("qa.widget_media")

# JS đo thuộc tính iframe từ parent frame (safe với cross-origin)
_JS_SCAN_IFRAMES = """
() => {
  const frames = Array.from(document.querySelectorAll('iframe'));
  return frames.map((f, i) => {
    const r = f.getBoundingClientRect();
    return {
      index: i,
      src: f.src || f.getAttribute('src') || '',
      name: f.name || f.id || '',
      width: Math.round(r.width),
      height: Math.round(r.height),
      visible: r.width > 0 && r.height > 0 && r.top < window.innerHeight && r.bottom > 0,
      loaded: f.contentDocument !== null || f.src !== '',
      sandbox: f.sandbox ? f.sandbox.toString() : null,
      allow: f.allow || null,
      loading: f.loading || 'eager',
    };
  });
}
"""

# JS kiểm tra iframe có phản hồi click không (gọi sau khi click)
_JS_CHECK_REDIRECT = """
(origUrl) => {
  return {
    current_url: window.location.href,
    navigated: window.location.href !== origUrl,
    popup_count: window.__qa_popup_count || 0,
  };
}
"""

# JS trước khi đo - gắn popup counter
_JS_HOOK_POPUPS = """
() => {
  if (!window.__qa_popup_count) {
    window.__qa_popup_count = 0;
    const orig = window.open;
    window.open = function(...args) { window.__qa_popup_count++; return orig.apply(this, args); };
  }
}
"""

# JS đo trạng thái HTMLMediaElement (video/audio)
_JS_MEDIA_STATE = """
(selector) => {
  const el = document.querySelector(selector || 'video');
  if (!el) return { found: false };
  return {
    found: true,
    src: el.currentSrc || el.src || '',
    readyState: el.readyState,
    networkState: el.networkState,
    paused: el.paused,
    ended: el.ended,
    currentTime: Math.round(el.currentTime * 1000) / 1000,
    duration: isFinite(el.duration) ? Math.round(el.duration * 1000) / 1000 : null,
    buffered_end: el.buffered.length > 0 ? Math.round(el.buffered.end(el.buffered.length-1)*1000)/1000 : 0,
    playbackRate: el.playbackRate,
    error: el.error ? { code: el.error.code, message: el.error.message } : null,
    autoplay: el.autoplay,
    muted: el.muted,
    volume: el.volume,
  };
}
"""

# JS khởi động đo buffering - lắng nghe sự kiện 'waiting' và 'playing'
_JS_ATTACH_BUFFER_OBSERVER = """
(selector) => {
  const el = document.querySelector(selector || 'video');
  if (!el) return false;
  if (el.__qa_buf) return true;
  el.__qa_buf = { waiting_count: 0, total_buffer_ms: 0, last_waiting_at: null, events: [] };
  el.addEventListener('waiting', () => {
    el.__qa_buf.waiting_count++;
    el.__qa_buf.last_waiting_at = Date.now();
    el.__qa_buf.events.push({ type: 'waiting', t: Date.now() });
  });
  el.addEventListener('playing', () => {
    if (el.__qa_buf.last_waiting_at !== null) {
      el.__qa_buf.total_buffer_ms += Date.now() - el.__qa_buf.last_waiting_at;
      el.__qa_buf.last_waiting_at = null;
    }
    el.__qa_buf.events.push({ type: 'playing', t: Date.now() });
  });
  el.addEventListener('error', (e) => {
    el.__qa_buf.events.push({ type: 'error', t: Date.now(), code: el.error?.code });
  });
  return true;
}
"""

_JS_GET_BUFFER_STATS = """
(selector) => {
  const el = document.querySelector(selector || 'video');
  if (!el || !el.__qa_buf) return null;
  return {
    waiting_count: el.__qa_buf.waiting_count,
    total_buffer_ms: el.__qa_buf.total_buffer_ms,
    events: el.__qa_buf.events.slice(-20),
  };
}
"""

# JS cho YouTube iframe - đọc state qua postMessage YT Player API
_JS_YOUTUBE_INJECT_API = """
() => {
  if (window.__qa_yt_state) return 'already_hooked';
  window.__qa_yt_state = { playerState: -1, messages: [] };
  window.addEventListener('message', (e) => {
    try {
      const d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
      if (d && d.event === 'infoDelivery' && d.info) {
        window.__qa_yt_state.playerState = d.info.playerState !== undefined
          ? d.info.playerState : window.__qa_yt_state.playerState;
        window.__qa_yt_state.currentTime = d.info.currentTime;
        window.__qa_yt_state.messages.push({ t: Date.now(), state: d.info.playerState });
      }
    } catch {}
  });
  // Yêu cầu YT iframe bật postMessage API
  document.querySelectorAll('iframe[src*="youtube"]').forEach(f => {
    try {
      f.contentWindow.postMessage('{"event":"listening"}', '*');
    } catch {}
  });
  return 'hooked';
}
"""

_JS_GET_YT_STATE = """
() => window.__qa_yt_state || { playerState: -1, messages: [] }
"""

# readyState constants
_MEDIA_READY_STATES = {0: "HAVE_NOTHING", 1: "HAVE_METADATA", 2: "HAVE_CURRENT_DATA",
                       3: "HAVE_FUTURE_DATA", 4: "HAVE_ENOUGH_DATA"}
_YT_PLAYER_STATES = {-1: "UNSTARTED", 0: "ENDED", 1: "PLAYING", 2: "PAUSED",
                      3: "BUFFERING", 5: "CUED"}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class IframeResult:
    index: int
    src: str
    name: str
    width: int
    height: int
    visible: bool
    loaded: bool
    load_time_ms: Optional[float] = None
    click_redirected: bool = False
    click_destination: Optional[str] = None
    popup_triggered: bool = False
    sandbox: Optional[str] = None
    allow: Optional[str] = None
    error: Optional[str] = None


@dataclass
class MediaResult:
    selector: str
    found: bool
    src: str = ""
    ready_state: int = 0
    ready_state_name: str = "HAVE_NOTHING"
    paused: bool = True
    ended: bool = False
    current_time_s: float = 0.0
    duration_s: Optional[float] = None
    buffered_end_s: float = 0.0
    buffering_events: int = 0
    total_buffer_ms: float = 0.0
    playback_ok: bool = False
    retention_window_s: float = 0.0
    actual_play_s: float = 0.0
    error: Optional[str] = None
    yt_player_state: Optional[int] = None
    yt_player_state_name: Optional[str] = None


# ---------------------------------------------------------------------------
# Iframe Validator
# ---------------------------------------------------------------------------

class IframeValidator:
    """Quét và kiểm tra tất cả iframe trên trang hiện tại."""

    def __init__(self, page: Any, timeout_ms: int = 10_000) -> None:
        self.page = page
        self.timeout_ms = timeout_ms

    async def scan(self) -> list[IframeResult]:
        """Quét tất cả iframe, đo load time, trả về danh sách IframeResult."""
        raw: list[dict[str, Any]] = await self.page.evaluate(_JS_SCAN_IFRAMES)
        results: list[IframeResult] = []
        for item in raw:
            r = IframeResult(
                index=item["index"],
                src=item["src"],
                name=item["name"],
                width=item["width"],
                height=item["height"],
                visible=item["visible"],
                loaded=item["loaded"],
                sandbox=item.get("sandbox"),
                allow=item.get("allow"),
            )
            # Đo load time nếu iframe có src và chưa loaded
            if r.src and not r.loaded:
                r.load_time_ms = await self._measure_iframe_load(item["index"])
            results.append(r)
        LOGGER.info("widget_qa: tìm thấy %d iframe(s)", len(results))
        return results

    async def _measure_iframe_load(self, idx: int) -> Optional[float]:
        """Đo thời gian iframe[idx] load xong bằng cách poll readyState."""
        js = f"""
        async () => {{
          const f = document.querySelectorAll('iframe')[{idx}];
          if (!f || !f.src) return null;
          const t0 = Date.now();
          return new Promise(res => {{
            if (f.contentDocument && f.contentDocument.readyState === 'complete') {{
              res(Date.now() - t0);
              return;
            }}
            f.addEventListener('load', () => res(Date.now() - t0), {{once: true}});
            setTimeout(() => res(null), {self.timeout_ms});
          }});
        }}
        """
        try:
            ms = await self.page.evaluate(js)
            return float(ms) if ms is not None else None
        except Exception:
            return None

    async def verify_clickability(
        self,
        results: list[IframeResult],
        only_visible: bool = True,
    ) -> list[IframeResult]:
        """Kiểm tra iframe có phản hồi khi click không (redirect / popup)."""
        await self.page.evaluate(_JS_HOOK_POPUPS)
        orig_url = self.page.url

        for r in results:
            if only_visible and not r.visible:
                continue
            if not r.src:
                continue
            try:
                # Click vào trung tâm iframe (parent frame)
                loc = self.page.locator(f"iframe:nth-of-type({r.index + 1})")
                box = await loc.bounding_box()
                if not box:
                    continue
                cx = box["x"] + box["width"] / 2
                cy = box["y"] + box["height"] / 2
                await self.page.mouse.click(cx, cy)
                await asyncio.sleep(0.5)
                state = await self.page.evaluate(_JS_CHECK_REDIRECT, orig_url)
                r.click_redirected = state.get("navigated", False)
                r.click_destination = state.get("current_url") if r.click_redirected else None
                r.popup_triggered = state.get("popup_count", 0) > 0
                # Nếu đã navigate ra ngoài, quay lại
                if r.click_redirected:
                    await self.page.go_back()
                    await self.page.wait_for_load_state("domcontentloaded",
                                                        timeout=self.timeout_ms)
                    orig_url = self.page.url
            except Exception as exc:
                r.error = str(exc)[:200]
                LOGGER.debug("widget_qa: click iframe[%d] lỗi: %s", r.index, exc)
        return results

    async def run_full(self, check_clicks: bool = True) -> list[IframeResult]:
        """Chạy toàn bộ: scan + đo load + verify clicks."""
        results = await self.scan()
        if check_clicks:
            results = await self.verify_clickability(results)
        return results


# ---------------------------------------------------------------------------
# Media Streaming Telemetry
# ---------------------------------------------------------------------------

class MediaTelemetry:
    """Đo lường trình phát HTML5 video và YouTube Embedded Player."""

    def __init__(self, page: Any, selector: str = "video") -> None:
        self.page = page
        self.selector = selector

    async def snapshot(self) -> MediaResult:
        """Lấy snapshot trạng thái hiện tại của media element."""
        raw: dict[str, Any] = await self.page.evaluate(_JS_MEDIA_STATE, self.selector)
        if not raw.get("found"):
            return MediaResult(selector=self.selector, found=False, error="element not found")

        r = MediaResult(
            selector=self.selector,
            found=True,
            src=raw.get("src", ""),
            ready_state=raw.get("readyState", 0),
            ready_state_name=_MEDIA_READY_STATES.get(raw.get("readyState", 0), "?"),
            paused=raw.get("paused", True),
            ended=raw.get("ended", False),
            current_time_s=raw.get("currentTime", 0.0),
            duration_s=raw.get("duration"),
            buffered_end_s=raw.get("buffered_end", 0.0),
        )
        if raw.get("error"):
            r.error = f"MediaError code={raw['error'].get('code')}"
        return r

    async def measure_buffering(
        self,
        retention_window_s: float = 10.0,
        poll_interval_s: float = 1.0,
        autoplay: bool = True,
    ) -> MediaResult:
        """Đo buffering trong khoảng thời gian `retention_window_s` giây.

        Trả về MediaResult với:
          - buffering_events: số lần buffering xảy ra
          - total_buffer_ms: tổng ms đang buffer
          - actual_play_s: thời gian thật sự phát được
          - playback_ok: True nếu video phát ít nhất 70% retention_window
        """
        # Gắn observer
        ok = await self.page.evaluate(_JS_ATTACH_BUFFER_OBSERVER, self.selector)
        if not ok:
            r = await self.snapshot()
            r.error = "không gắn được buffer observer (element không tồn tại?)"
            return r

        # Khởi động play nếu cần
        if autoplay:
            try:
                await self.page.evaluate(f"""
                () => {{
                  const el = document.querySelector({repr(self.selector)});
                  if (el && el.paused) el.play().catch(()=>{{}});
                }}
                """)
            except Exception:
                pass

        # Poll trong retention_window_s
        t_start = time.perf_counter()
        snapshots: list[dict[str, Any]] = []
        while (time.perf_counter() - t_start) < retention_window_s:
            await asyncio.sleep(poll_interval_s)
            snap: dict[str, Any] = await self.page.evaluate(_JS_MEDIA_STATE, self.selector)
            snap["wall_t"] = time.perf_counter() - t_start
            snapshots.append(snap)

        # Lấy buffer stats
        buf_stats: Optional[dict[str, Any]] = await self.page.evaluate(
            _JS_GET_BUFFER_STATS, self.selector
        )

        # Build kết quả
        last = snapshots[-1] if snapshots else {}
        r = MediaResult(
            selector=self.selector,
            found=True,
            src=last.get("currentSrc", last.get("src", "")),
            ready_state=last.get("readyState", 0),
            ready_state_name=_MEDIA_READY_STATES.get(last.get("readyState", 0), "?"),
            paused=last.get("paused", True),
            ended=last.get("ended", False),
            current_time_s=last.get("currentTime", 0.0),
            duration_s=last.get("duration"),
            buffered_end_s=last.get("buffered_end", 0.0),
            retention_window_s=retention_window_s,
        )
        if buf_stats:
            r.buffering_events = buf_stats.get("waiting_count", 0)
            r.total_buffer_ms = buf_stats.get("total_buffer_ms", 0.0)
        # Tính actual_play_s: thời gian currentTime tăng (video đang chạy thật)
        times = [s.get("currentTime", 0.0) for s in snapshots if not s.get("paused")]
        if len(times) >= 2:
            r.actual_play_s = max(times) - min(times)
        r.playback_ok = r.actual_play_s >= retention_window_s * 0.7
        if last.get("error"):
            r.error = f"MediaError code={last['error'].get('code')}"
        LOGGER.info(
            "media_qa: play=%.1fs / %.1fs, buffer=%dms (%d sự kiện), ok=%s",
            r.actual_play_s, retention_window_s,
            r.total_buffer_ms, r.buffering_events, r.playback_ok,
        )
        return r

    async def measure_youtube(
        self,
        retention_window_s: float = 10.0,
        poll_interval_s: float = 1.0,
    ) -> MediaResult:
        """Đo trạng thái YouTube Embedded Player qua postMessage API."""
        await self.page.evaluate(_JS_YOUTUBE_INJECT_API)
        await asyncio.sleep(1.0)  # Chờ YT player khởi tạo

        t_start = time.perf_counter()
        states: list[int] = []
        while (time.perf_counter() - t_start) < retention_window_s:
            await asyncio.sleep(poll_interval_s)
            yt_state: dict[str, Any] = await self.page.evaluate(_JS_GET_YT_STATE)
            ps = yt_state.get("playerState", -1)
            states.append(ps)

        # Tính thời gian playing (state == 1)
        playing_ticks = states.count(1)
        actual_play_s = playing_ticks * poll_interval_s
        last_state = states[-1] if states else -1

        r = MediaResult(
            selector="iframe[src*=youtube]",
            found=True,
            retention_window_s=retention_window_s,
            actual_play_s=actual_play_s,
            playback_ok=actual_play_s >= retention_window_s * 0.7,
            yt_player_state=last_state,
            yt_player_state_name=_YT_PLAYER_STATES.get(last_state, f"UNKNOWN({last_state})"),
            buffering_events=states.count(3),
        )
        LOGGER.info(
            "media_qa(yt): play=%.1fs / %.1fs, state=%s, ok=%s",
            actual_play_s, retention_window_s,
            r.yt_player_state_name, r.playback_ok,
        )
        return r


# ---------------------------------------------------------------------------
# Public convenience functions (dùng trực tiếp từ engine._run_step)
# ---------------------------------------------------------------------------

async def run_iframe_check(page: Any, cfg: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Entry point cho action='widget_qa' trong step config."""
    cfg = cfg or {}
    validator = IframeValidator(
        page,
        timeout_ms=cfg.get("timeout_ms", 10_000),
    )
    results = await validator.run_full(check_clicks=cfg.get("check_clicks", True))
    return {
        "iframe_count": len(results),
        "visible_count": sum(1 for r in results if r.visible),
        "redirected_count": sum(1 for r in results if r.click_redirected),
        "popup_count": sum(1 for r in results if r.popup_triggered),
        "iframes": [
            {
                "index": r.index,
                "src": r.src[:120],
                "visible": r.visible,
                "load_time_ms": r.load_time_ms,
                "click_redirected": r.click_redirected,
                "click_destination": r.click_destination,
                "popup_triggered": r.popup_triggered,
                "error": r.error,
            }
            for r in results
        ],
    }


async def run_media_check(page: Any, cfg: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Entry point cho action='media_qa' trong step config."""
    cfg = cfg or {}
    selector = cfg.get("selector", "video")
    is_youtube = cfg.get("youtube", False) or "youtube" in selector

    telemetry = MediaTelemetry(page, selector=selector)
    retention = cfg.get("retention_window_s", 10.0)

    if is_youtube:
        result = await telemetry.measure_youtube(
            retention_window_s=retention,
            poll_interval_s=cfg.get("poll_interval_s", 1.0),
        )
    else:
        result = await telemetry.measure_buffering(
            retention_window_s=retention,
            poll_interval_s=cfg.get("poll_interval_s", 1.0),
            autoplay=cfg.get("autoplay", True),
        )

    return {
        "found": result.found,
        "src": result.src[:120] if result.src else "",
        "ready_state": result.ready_state_name,
        "paused": result.paused,
        "ended": result.ended,
        "current_time_s": result.current_time_s,
        "duration_s": result.duration_s,
        "buffered_end_s": result.buffered_end_s,
        "buffering_events": result.buffering_events,
        "total_buffer_ms": result.total_buffer_ms,
        "actual_play_s": result.actual_play_s,
        "retention_window_s": result.retention_window_s,
        "playback_ok": result.playback_ok,
        "yt_player_state": result.yt_player_state_name,
        "error": result.error,
    }
