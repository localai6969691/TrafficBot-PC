"""Lõi điều phối: hàng đợi tác vụ (local / Redis), semaphore đồng thời,
Persistent Browser Context, workflow engine (tuyến tính + phân nhánh), thu metrics."""
from __future__ import annotations

import asyncio
import json
import logging
import math
import random
import re
import uuid
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Optional
from urllib.parse import urlparse, urlsplit

from bandwidth_optimizer import BandwidthConfig, BandwidthOptimizer
from config_loader import Config, Environment, GatewayEntry, Paths, Scenario, is_url_allowed
from database import Database
from engine_router import EngineKind, EngineRouter
from events import EventBus
from interaction import InteractionConfig, InteractionSimulator
from network_manager import (BackoffPolicy, BreakerRegistry, GatewayPool, GatewayUnavailable,
                             HttpProbe, parse_retry_after)
from plugin_manager import PluginManager
from secrets_store import SecretBox
from test_data import TestDataGenerator

LOGGER = logging.getLogger("qa.engine")
RETRY_STATUSES = {429, 503}
GATEWAY_ERRORS = ("ERR_PROXY", "ERR_TUNNEL", "ERR_SOCKS", "ERR_CONNECTION_REFUSED", "ERR_CONNECTION_TIMED_OUT")

# Tập lệnh đo Core Web Vitals, nạp trước khi trang tải.
# Phase 10.5 fix: patch navigator.webdriver=undefined + dọn các biến CDC_ mà
# ChromeDriver/Selenium để lại trên window/document (Playwright CDP không để
# lại các biến này, nhưng dọn phòng hờ cho an toàn khi connect_over_cdp tới
# driver khác). Chạy ở `add_init_script` nên áp dụng lại trên MỌI document
# mới (kể cả sau điều hướng/redirect) - đúng yêu cầu preflight_audit.py.
STEALTH_WEBDRIVER_JS = """
(() => {
  try {
    Object.defineProperty(Navigator.prototype, 'webdriver', { get: () => undefined, configurable: true });
  } catch (e) {
    try { Object.defineProperty(navigator, 'webdriver', { get: () => undefined, configurable: true }); } catch (e2) {}
  }
  for (const k of Object.keys(window)) {
    if (k.match(/^(cdc_|\\$cdc_|\\$chrome_asyncScriptInfo|__webdriver|__selenium|__driver_evaluate|__fxdriver)/)) {
      try { delete window[k]; } catch (e) {}
    }
  }
  try { delete document.$cdc_asdjflasutopfhvcZLmcfl_; } catch (e) {}
})();
"""

PERF_OBSERVER_JS = """
(() => {
  if (window.__qa_metrics) return;
  const m = window.__qa_metrics = { lcp: null, cls: 0, fcp: null };
  const obs = (type, fn) => { try { new PerformanceObserver(l => l.getEntries().forEach(fn)).observe({ type, buffered: true }); } catch (e) {} };
  obs('largest-contentful-paint', e => { m.lcp = e.startTime; });
  obs('layout-shift', e => { if (!e.hadRecentInput) m.cls += e.value; });
  obs('paint', e => { if (e.name === 'first-contentful-paint') m.fcp = e.startTime; });
})();
"""
COLLECT_METRICS_JS = """
() => {
  const nav = performance.getEntriesByType('navigation')[0];
  const m = window.__qa_metrics || {};
  const fcp = performance.getEntriesByName('first-contentful-paint')[0];
  const pos = v => (v && v > 0 ? Math.round(v * 10) / 10 : null);
  return {
    ttfb: nav ? pos(nav.responseStart) : null,
    fcp: fcp ? pos(fcp.startTime) : pos(m.fcp),
    lcp: pos(m.lcp),
    cls: Math.round((m.cls || 0) * 10000) / 10000,
    dcl: nav ? pos(nav.domContentLoadedEventEnd) : null,
    load: nav ? pos(nav.loadEventEnd) : null,
  };
}
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


# ============================================================================ hàng đợi
@dataclass
class Task:
    scenario_id: str
    url: str
    task_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, raw: str) -> "Task":
        return cls(**json.loads(raw))


class TaskQueue(ABC):
    """Giao diện hàng đợi: đổi giữa nội bộ và Redis mà không sửa Engine."""

    @abstractmethod
    async def put(self, task: Task) -> None: ...

    @abstractmethod
    async def get(self, timeout: float) -> Optional[Task]: ...

    @abstractmethod
    async def task_done(self) -> None: ...

    @abstractmethod
    async def is_empty(self) -> bool: ...

    @abstractmethod
    def profile_lock(self, profile_id: str) -> "asynccontextmanager[None]": ...

    async def aclose(self) -> None:
        return None


class LocalQueue(TaskQueue):
    def __init__(self) -> None:
        self._q: asyncio.Queue[Task] = asyncio.Queue()
        self._locks: dict[str, asyncio.Lock] = {}

    async def put(self, task: Task) -> None:
        self._q.put_nowait(task)

    async def get(self, timeout: float) -> Optional[Task]:
        try:
            return await asyncio.wait_for(self._q.get(), timeout)
        except asyncio.TimeoutError:
            return None

    async def task_done(self) -> None:
        self._q.task_done()

    async def is_empty(self) -> bool:
        return self._q.empty()

    @asynccontextmanager
    async def profile_lock(self, profile_id: str) -> AsyncIterator[None]:
        async with self._locks.setdefault(profile_id, asyncio.Lock()):
            yield


class RedisQueue(TaskQueue):
    """Producer/Consumer qua Redis list (LPUSH / BRPOP). Giao hàng 'at-most-once':
    worker chết giữa chừng sẽ làm mất tác vụ đang xử lý. Khóa profile là khóa Redis
    để hai máy không cùng mở một profile."""

    def __init__(self, url: str, name: str) -> None:
        import redis.asyncio as aioredis  # phụ thuộc tùy chọn

        self._r = aioredis.from_url(url, decode_responses=True)
        self._name = name

    async def put(self, task: Task) -> None:
        await self._r.lpush(self._name, task.to_json())

    async def get(self, timeout: float) -> Optional[Task]:
        item = await self._r.brpop(self._name, timeout=max(1, math.ceil(timeout)))
        return Task.from_json(item[1]) if item else None

    async def task_done(self) -> None:
        return None

    async def is_empty(self) -> bool:
        return await self._r.llen(self._name) == 0

    @asynccontextmanager
    async def profile_lock(self, profile_id: str) -> AsyncIterator[None]:
        lock = self._r.lock(f"{self._name}:profile:{profile_id}", timeout=900, blocking_timeout=900)
        await lock.acquire()
        try:
            yield
        finally:
            try:
                await lock.release()
            except Exception:  # noqa: BLE001
                pass

    async def aclose(self) -> None:
        await self._r.aclose()


# ============================================================================ kết quả / ngữ cảnh chạy
class StepFailed(Exception):
    """Một bước kịch bản thất bại (assert, HTTP >= 400, ...)."""


@dataclass
class RunResult:
    status: Optional[int] = None
    retry_after: Optional[float] = None
    error: Optional[str] = None
    exit_ip: Optional[str] = None
    metrics: Optional[dict[str, Any]] = None
    interaction: dict[str, Any] = field(default_factory=dict)
    gateway_error: bool = False
    engine: str = EngineKind.CHROMIUM.value
    bandwidth: Optional[dict[str, Any]] = None
    # Phase 10.5: Fail-Safe Gate & Analytics Telemetry Verification
    preflight_blocked: bool = False         # True nếu preflight audit chặn phiên này
    preflight_status: Optional[str] = None  # "ok" | "blocked" | "skipped" | None (chưa bật)
    analytics_verified: Optional[str] = None  # "VERIFIED_SUCCESS" | "NOT_VERIFIED" | "NOT_APPLICABLE" | None


@dataclass
class RunCtx:
    task: Task
    sc: Scenario
    url: str
    res: RunResult
    data: TestDataGenerator
    bopt: Optional[BandwidthOptimizer] = None
    last_screenshot: Optional[str] = None   # đường dẫn ảnh gần nhất chụp bằng step "screenshot" trong lượt này
    meta: dict = field(default_factory=dict)  # Phase 3: kết quả trung gian từ các action nâng cao


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", value) or "profile"


# ============================================================================ engine
class Engine:
    def __init__(self, cfg: Config, paths: Paths, db: Database, plugins: PluginManager,
                 pool: GatewayPool, probe: HttpProbe, bus: EventBus) -> None:
        self.cfg, self.settings, self.paths = cfg, cfg.settings, paths
        self.db, self.plugins, self.pool, self.probe, self.bus = db, plugins, pool, probe, bus
        self.scenarios = {s.id: s for s in cfg.scenarios}
        self.backoff = BackoffPolicy(self.settings.backoff_base_s, self.settings.backoff_max_s)
        self.breakers = BreakerRegistry(self.settings)
        try:
            default_engine = EngineKind(self.settings.router_default_engine)
        except ValueError:
            LOGGER.warning("router_default_engine=%r không hợp lệ, dùng chromium",
                           self.settings.router_default_engine)
            default_engine = EngineKind.CHROMIUM
        self.router = EngineRouter(db, default_engine)
        self.secrets = SecretBox(paths.secret_key)
        self.stop = asyncio.Event()
        self._pw: Any = None
        self._browsers: dict[tuple[EngineKind, str], Any] = {}
        self._cdp_browsers: dict[str, Any] = {}
        self._browsers_lock = asyncio.Lock()
        self.xvfb: Any = None  # Phase 11.1: gán ở start() nếu bật Virtual Display Mode
        # Phase 12: worker registry cho "Live Browser Workers Grid" (Command Center).
        # key=task_id, value={"scenario_id","profile_id","url","engine","current_step",
        # "started_at","page"(tham chiếu Playwright Page - KHÔNG serialize ra JSON,
        # chỉ dùng nội bộ cho snapshot/stop), "exit_ip","gateway"}.
        self._workers: dict[str, dict[str, Any]] = {}
        # Phase 8: Resource Governor
        from resource_governor import ResourceGovernor
        self.governor = ResourceGovernor(
            max_concurrency=self.settings.max_concurrency,
            ram_throttle_pct=getattr(self.settings, "ram_throttle_pct", 80.0),
            ram_pause_pct=getattr(self.settings, "ram_pause_pct", 90.0),
            cpu_throttle_pct=getattr(self.settings, "cpu_throttle_pct", 85.0),
        )

    # ------------------------------------------------------------ vòng đời Playwright
    async def start(self) -> None:
        from playwright.async_api import async_playwright

        # Phase 11.1: Virtual Display Mode (Xvfb) - bật qua system_settings
        # "virtual_display_enabled" trên Linux khi muốn chạy headless=false
        # (có cửa sổ GUI thật) mà không có màn hình vật lý/VNC.
        from linux_display_manager import XvfbManager, is_linux
        self.xvfb = XvfbManager()
        try:
            virtual_display_enabled = await self.db.aget_setting("virtual_display_enabled", False)
            if virtual_display_enabled and is_linux() and not self.settings.headless:
                vw = await self.db.aget_setting("virtual_display_width", 1920)
                vh = await self.db.aget_setting("virtual_display_height", 1080)
                await self.xvfb.start(width=int(vw), height=int(vh))
                LOGGER.info("Virtual Display Mode (Xvfb) đã bật tại %s", self.xvfb.handle.display)
        except Exception as exc:  # noqa: BLE001
            LOGGER.warning("Khởi tạo Xvfb lỗi (bỏ qua, chạy tiếp ở chế độ headless thường): %s", exc)

        self._pw = await async_playwright().start()
        # Phase 8: khởi động resource governor telemetry
        try:
            await self.governor.start()
        except Exception as exc:
            LOGGER.warning("governor start lỗi (bỏ qua): %s", exc)

    async def close(self) -> None:
        for browser in self._browsers.values():
            try:
                await browser.close()
            except Exception:  # noqa: BLE001
                pass
        self._browsers.clear()
        # KHÔNG đóng self._cdp_browsers: đó là trình duyệt bên ngoài do người dùng tự chạy,
        # runner chỉ kết nối tới (xem mục 4.1 - CDP Endpoint), không có quyền tắt nó.
        self._cdp_browsers.clear()
        if self._pw is not None:
            await self._pw.stop()
        # Phase 11.1: giải phóng Xvfb khi tắt ứng dụng.
        xvfb = getattr(self, "xvfb", None)
        if xvfb is not None:
            try:
                await xvfb.stop()
            except Exception as exc:  # noqa: BLE001
                LOGGER.debug("Dừng Xvfb lỗi (bỏ qua): %s", exc)
            self._pw = None
        # Phase 8: dừng governor
        try:
            await self.governor.stop()
        except Exception:
            pass

    def _browser_type(self, kind: EngineKind) -> Any:
        return {EngineKind.CHROMIUM: self._pw.chromium, EngineKind.FIREFOX: self._pw.firefox,
                EngineKind.WEBKIT: self._pw.webkit}[kind]

    async def _shared_browser(self, kind: EngineKind, executable_path: Optional[str],
                               use_pipe: bool = False,
                               extra_args: Optional[list[str]] = None) -> Any:
        """Một tiến trình trình duyệt dùng chung cho mỗi (loại engine, đường dẫn thực thi).

        Phase 5 bổ sung:
          - use_pipe=True: dùng OS pipe thay vì WebSocket CDP để giảm CDP artifacts.
            Chỉ hoạt động với Chromium. Firefox/WebKit bỏ qua pipe.
          - extra_args: truyền thêm cờ dòng lệnh cấp thấp vào browser process.
        """
        key = (kind, executable_path or "", use_pipe, tuple(extra_args or []))
        async with self._browsers_lock:
            if key not in self._browsers:
                launch_kwargs: dict[str, Any] = {"headless": self.settings.headless}
                if executable_path:
                    launch_kwargs["executable_path"] = executable_path
                # Phase 5+7: stealth args + automation flag removal
                default_stealth = [
                    "--disable-blink-features=AutomationControlled",
                    "--disable-features=ChromeWhatsNew,ChromeWhatsNewUI,CrashReporting",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--metrics-recording-only",
                    "--no-service-autorun",
                    "--password-store=basic",
                    "--use-mock-keychain",  # sẽ bị override bởi ignore_default_args nếu set
                ]
                all_args = default_stealth + (extra_args or [])

                # Phase 7: Remote DNS qua SOCKS5h (host resolver đẩy DNS qua proxy)
                proxy_url: Optional[str] = getattr(self.settings, "proxy_url", None)
                if proxy_url and proxy_url.startswith("socks5://"):
                    # Chuyển socks5:// → socks5h:// để DNS cũng qua proxy
                    socks5h = proxy_url.replace("socks5://", "socks5h://", 1)
                    all_args.append(f"--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1")
                    launch_kwargs["proxy"] = {"server": socks5h}

                # Phase 7: QUIC control
                disable_quic: bool = getattr(self.settings, "disable_quic", False)
                if disable_quic:
                    all_args.append("--disable-quic")
                    all_args.append("--disable-features=QUIC")

                launch_kwargs["args"] = all_args

                # Phase 7: ignore_default_args để loại bỏ cờ automation gây nhiễu
                launch_kwargs["ignore_default_args"] = [
                    "--enable-automation",
                    "--enable-blink-features=IdleDetection",
                    "--export-tagged-pdf",
                ]

                self._browsers[key] = await self._browser_type(kind).launch(**launch_kwargs)
            return self._browsers[key]

    async def _cdp_browser(self, endpoint: str) -> Any:
        """Kết nối tới một trình duyệt Chromium đang chạy sẵn bên ngoài qua Chrome DevTools
        Protocol (mục 4.1 - CDP Endpoint). CHỈ hỗ trợ họ Chromium - Playwright không có
        `connect_over_cdp` cho Firefox/WebKit. Nếu kịch bản yêu cầu engine firefox/webkit,
        cdp_endpoint bị bỏ qua cho kịch bản đó (xem _attempt_browser)."""
        async with self._browsers_lock:
            if endpoint not in self._cdp_browsers:
                self._cdp_browsers[endpoint] = await self._pw.chromium.connect_over_cdp(endpoint)
            return self._cdp_browsers[endpoint]

    # ------------------------------------------------------------ vòng lặp tiêu thụ
    async def run_tasks(self, queue: TaskQueue, drain: bool = True) -> None:
        """Lấy tác vụ từ hàng đợi với ResourceGovernor điều tiết động.
        drain=True: thoát khi hàng đợi cạn; False: chạy mãi (worker)."""
        inflight: set[asyncio.Task[None]] = set()
        while not self.stop.is_set():
            # Dùng governor.acquire thay vì Semaphore cứng — tự điều tiết theo RAM/CPU
            acquired = await self.governor.acquire_context_slot(timeout_s=5.0)
            if not acquired:
                # Governor pause: chờ rồi thử lại (không lấy task)
                await asyncio.sleep(1.0)
                continue
            task = await queue.get(timeout=0.5)
            if task is None:
                await self.governor.release_context_slot()
                if drain and not inflight and await queue.is_empty():
                    break
                continue
            job = asyncio.create_task(self._guarded_gov(task, queue))
            inflight.add(job)
            job.add_done_callback(inflight.discard)
        if inflight:
            await asyncio.gather(*inflight, return_exceptions=True)

    async def _guarded_gov(self, task: Task, queue: TaskQueue) -> None:
        """Wrapper giải phóng governor slot sau khi task xong."""
        try:
            await self.execute(task, queue)
        except Exception:
            pass
        finally:
            await self.governor.release_context_slot()

    async def _guarded(self, task: Task, queue: TaskQueue, sem: asyncio.Semaphore) -> None:
        try:
            await self.execute(task, queue)
        except Exception:  # noqa: BLE001
            LOGGER.exception("Lỗi không mong đợi", extra={"task": task.task_id})
        finally:
            sem.release()
            await queue.task_done()

    # ------------------------------------------------------------ một tác vụ
    async def execute(self, task: Task, queue: TaskQueue) -> None:
        sc = self.scenarios.get(task.scenario_id)
        if sc is None:
            LOGGER.error("Không có kịch bản '%s'", task.scenario_id, extra={"task": task.task_id})
            return
        env = self.cfg.environments.get(sc.environment) or self.cfg.environments["default"]
        tl = {"task": task.task_id}
        started = utc_now()
        result = RunResult()
        attempts = 0
        gateway: Optional[GatewayEntry] = None
        skipped = False
        breaker = self.breakers.get(urlsplit(task.url).netloc)

        self._workers[task.task_id] = {
            "task_id": task.task_id, "scenario_id": sc.id, "profile_id": sc.profile_id,
            "url": task.url, "engine": sc.engine, "current_step": "khởi tạo",
            "started_at": started, "page": None, "exit_ip": None, "gateway": None,
        }
        try:
            await self._execute_inner(task, queue, sc, env, tl, started, result, attempts, gateway, skipped, breaker)
        finally:
            self._workers.pop(task.task_id, None)

    async def _execute_inner(self, task: Task, queue: TaskQueue, sc: Any, env: Any, tl: dict,
                             started: str, result: "RunResult", attempts: int,
                             gateway: Optional[GatewayEntry], skipped: bool, breaker: Any) -> None:
        """Thân thực thi gốc của execute() (Phase 12 tách ra để bọc try/finally
        đăng ký/huỷ đăng ký worker ở _workers mà không đổi logic bên trong)."""
        if not is_url_allowed(task.url, self.settings.allowed_domains):
            result.error = f"{urlsplit(task.url).hostname} không nằm trong allowed_domains"
            LOGGER.error("[%s] %s", sc.id, result.error, extra=tl)
        elif not breaker.allow():
            result.error, skipped = "circuit_open: bỏ qua do tỷ lệ lỗi vượt ngưỡng", True
            LOGGER.warning("[%s] %s", sc.id, result.error, extra=tl)
        else:
            async with queue.profile_lock(sc.profile_id):
                while True:
                    attempts += 1
                    try:
                        gateway = self.pool.assign(sc.profile_id, sc.region or env.region)
                    except GatewayUnavailable as exc:
                        result = RunResult(error=str(exc))
                        breaker.record(False)
                        break
                    result = await self._attempt(task, sc, env, gateway)
                    breaker.record(result.error is None)
                    if result.gateway_error:
                        self.pool.report_failure(gateway)
                    needs_retry = result.status in RETRY_STATUSES or result.preflight_blocked
                    if needs_retry and attempts <= self.settings.max_retries:
                        delay = self.backoff.delay(attempts - 1, result.retry_after)
                        if result.preflight_blocked:
                            LOGGER.warning(
                                "[%s] Preflight Fail-Safe Gate CHẶN phiên - đổi gateway và thử lại "
                                "sau %.1fs (%d/%d)", sc.id, delay, attempts, self.settings.max_retries,
                                extra=tl)
                        else:
                            LOGGER.warning("[%s] HTTP %s - chờ %.1fs rồi thử lại (%d/%d)%s", sc.id,
                                           result.status, delay, attempts, self.settings.max_retries,
                                           " theo Retry-After" if result.retry_after is not None else "",
                                           extra=tl)
                        try:
                            await asyncio.wait_for(self.stop.wait(), timeout=delay)
                            break
                        except asyncio.TimeoutError:
                            if not breaker.allow():
                                result.error = "circuit_open: ngắt vòng thử lại"
                                break
                            continue
                    break

        status = "skipped" if skipped else ("ok" if result.error is None else "failed")
        run = dict(scenario_id=sc.id, profile_id=sc.profile_id, url=task.url, started_at=started,
                   finished_at=utc_now(), status=status, http_status=result.status,
                   exit_ip=result.exit_ip, gateway=gateway.masked if gateway else None,
                   attempts=attempts, error_message=result.error, engine=result.engine,
                   analytics_verified=result.analytics_verified, preflight_status=result.preflight_status)
        await self.db.asave_run(run, result.metrics)
        if result.preflight_blocked:
            # Mục 2.5: "ghi log cảnh báo lên Dashboard" - đẩy qua EventBus để
            # SSE /events hiển thị ngay trên log luồng của Command Center.
            self.bus.publish("log", level="warn", task=task.task_id,
                             message=f"[{sc.id}] Preflight Fail-Safe Gate CHẶN phiên trên gateway "
                                     f"{gateway.masked if gateway else '?'} — đã đổi gateway và thử lại.")
        await self.db.atouch_profile(sc.profile_id, sc.environment, sc.region or env.region,
                                     run["gateway"], run["finished_at"])
        await self.plugins.run("on_run_finished", run, scenario=sc)
        m = result.metrics or {}
        LOGGER.info("[%s] %s -> %s | engine=%s | HTTP %s | TTFB %s FCP %s LCP %s%s", sc.id, task.url,
                    status, result.engine, result.status or "-", m.get("ttfb"), m.get("fcp"), m.get("lcp"),
                    f" | {result.error}" if result.error else "", extra=tl)
        if result.bandwidth and result.bandwidth.get("total_blocked"):
            bw = result.bandwidth
            bytes_note = ""
            if bw.get("estimated_bytes_saved") or bw.get("bytes_unknown"):
                unknown_part = f" ({bw['bytes_unknown']} request không đo được)" if bw.get("bytes_unknown") else ""
                bytes_note = f" | ước lượng {bw['estimated_bytes_saved']} byte tránh tải{unknown_part}"
            LOGGER.info("[%s] Bandwidth optimizer: chặn %d request (%s)%s%s", sc.id,
                       bw["total_blocked"], bw["blocked_by_type"],
                       " | đã đóng hộp thoại cookie" if bw.get("consent_dismissed") else "",
                       bytes_note, extra=tl)
        self.bus.publish("run", scenario=sc.id, url=task.url, status=status, engine=result.engine,
                         http=result.status, ttfb=m.get("ttfb"), fcp=m.get("fcp"), lcp=m.get("lcp"),
                         bandwidth_blocked=(result.bandwidth or {}).get("total_blocked"),
                         bandwidth_bytes=(result.bandwidth or {}).get("estimated_bytes_saved"))

    # ------------------------------------------------------------ một lần thử
    async def _attempt(self, task: Task, sc: Scenario, env: Environment,
                       gateway: Optional[GatewayEntry]) -> RunResult:
        res = RunResult()
        host = EngineRouter.host_of(task.url)
        kind = await self.router.resolve(sc.engine, host, sc.steps)

        if kind is EngineKind.HTTP:
            http_client = await self.db.aget_setting("http_client", "httpx")
            probe = await self.router.probe_http(task.url, env, gateway, http_client)
            res.status, res.error, res.engine = probe.status, probe.error, EngineKind.HTTP.value
            res.metrics = {"ttfb": probe.elapsed_ms, "fcp": None, "lcp": None, "cls": None,
                          "dcl": None, "load": probe.elapsed_ms}
            if probe.status is not None and probe.status >= 400 and not probe.needs_escalation:
                res.error = res.error or f"HTTP {probe.status}"
            if not probe.needs_escalation:
                res.exit_ip = await self.probe.exit_ip(self.settings.exit_ip_url, env, gateway)
                return res
            await self.router.record_escalation(host, probe.escalation_reason, utc_now(),
                                                self.router.default_engine)
            kind = self.router.default_engine
            res = RunResult()  # bỏ kết quả Engine 1, chạy lại bằng trình duyệt thật bên dưới

        return await self._attempt_browser(task, sc, env, gateway, kind, res)

    async def _attempt_browser(self, task: Task, sc: Scenario, env: Environment,
                               gateway: Optional[GatewayEntry], kind: EngineKind,
                               res: RunResult) -> RunResult:
        res.engine = kind.value
        context = page = None
        cdp_mode = False
        shared_mode = self.settings.context_mode == "shared"
        state_path = self.paths.profiles / safe_name(sc.profile_id) / "storage_state.json"
        bandwidth_cfg = {**self.settings.bandwidth, **sc.bandwidth}
        bopt = BandwidthOptimizer(BandwidthConfig.from_dict(bandwidth_cfg),
                                  proxy_url=gateway.url if gateway else None)
        try:
            res.exit_ip = await self.probe.exit_ip(self.settings.exit_ip_url, env, gateway)
            kwargs = env.context_kwargs()
            if gateway:
                kwargs["proxy"] = gateway.playwright_proxy()

            # Mục 4.1 - Browser Runtime Settings, đọc từ bảng system_settings (Web UI).
            cdp_endpoint = await self.db.aget_setting("cdp_endpoint", "") or None
            exe_path = await self.db.aget_setting("browser_executable_path", "") or None

            if cdp_endpoint and kind is EngineKind.CHROMIUM:
                LOGGER.debug("Dùng trình duyệt CDP ngoài tại %s cho profile %s", cdp_endpoint, sc.profile_id)
                browser = await self._cdp_browser(cdp_endpoint)
                if state_path.is_file():
                    kwargs["storage_state"] = str(state_path)
                context = await browser.new_context(**kwargs)
                cdp_mode = True
            elif shared_mode:
                browser = await self._shared_browser(kind, exe_path)
                if state_path.is_file():
                    kwargs["storage_state"] = str(state_path)
                context = await browser.new_context(**kwargs)
            else:
                # Mỗi profile_id có thư mục riêng: cookies / localStorage / IndexedDB tách biệt
                # hoàn toàn (một tiến trình trình duyệt / profile).
                profile_dir = self.paths.profiles / safe_name(sc.profile_id)
                profile_dir.mkdir(parents=True, exist_ok=True)
                launch_kwargs: dict[str, Any] = {"headless": self.settings.headless, **kwargs}
                if exe_path:
                    launch_kwargs["executable_path"] = exe_path
                # Bug fix (phát hiện qua test e2e Phase 10.5): nhánh persistent-context (mặc
                # định khi không bật shared_mode) trước đây KHÔNG truyền "args" stealth gì cả,
                # trong khi _shared_browser() có. Thiếu --disable-blink-features=AutomationControlled
                # khiến navigator.webdriver KHÔNG THỂ ghi đè (property non-configurable), nên
                # STEALTH_WEBDRIVER_JS phía dưới luôn thất bại im lặng trên đường chạy phổ biến nhất.
                if kind is EngineKind.CHROMIUM:
                    launch_kwargs.setdefault("args", [])
                    launch_kwargs["args"] = list(launch_kwargs["args"]) + [
                        "--disable-blink-features=AutomationControlled",
                        "--no-first-run", "--no-default-browser-check",
                    ]
                context = await self._browser_type(kind).launch_persistent_context(
                    str(profile_dir), **launch_kwargs)

            context.set_default_timeout(sc.timeout_ms)
            # Phase 10.5 fix: preflight_audit.py đã ghi chú từ trước "navigator.webdriver=false
            # injection phải được thực hiện qua add_init_script" nhưng chưa ai implement - với
            # Fail-Safe Gate giờ bật mặc định, thiếu dòng này sẽ khiến MỌI phiên chromium/firefox/
            # webkit bị preflight tự chặn vô thời hạn (navigator.webdriver=true mặc định của
            # Playwright chưa patch). `--disable-blink-features=AutomationControlled` KHÔNG đủ
            # tự nó ẩn navigator.webdriver trên các bản Chromium gần đây, đặc biệt ở chế độ headless.
            await context.add_init_script(STEALTH_WEBDRIVER_JS)
            await context.add_init_script(PERF_OBSERVER_JS)
            for _name, js in self.plugins.init_scripts:
                await context.add_init_script(js)
            await bopt.apply(context)
            await self.plugins.run("on_context_created", context, scenario=sc)
            page = context.pages[0] if context.pages else await context.new_page()

            # Mục 2.5 — Cổng Kiểm Định An Toàn Bắt Buộc (Mandatory Fail-Safe Gate).
            # Bật/tắt qua system_settings "preflight_gate_enabled" (mặc định BẬT).
            # Chỉ áp dụng cho engine trình duyệt thật (không áp dụng Engine 1/HTTP -
            # không có page/DOM để audit).
            gate_enabled = (await self.db.aget_setting("preflight_gate_enabled", True))
            if gate_enabled:
                try:
                    from preflight_audit import run_preflight
                    report = await run_preflight(
                        page, self.db, run_id=task.task_id,
                        expected_timezone=env.timezone_id, expected_locale=env.locale,
                        exit_ip=res.exit_ip,
                        block_on_fail=True,
                    )
                    res.preflight_status = "blocked" if report.blocked else "ok"
                    if report.blocked:
                        res.preflight_blocked = True
                        res.gateway_error = True  # ép pool.report_failure() đổi gateway khác ở execute()
                        failed_names = [c.name for c in report.checks
                                       if not c.ok and c.severity == "block"]
                        res.error = f"preflight_blocked: {', '.join(failed_names) or 'audit chặn'}"
                        return res
                except StepFailed:
                    raise
                except Exception as exc:  # noqa: BLE001
                    # Audit tự thân lỗi (không phải môi trường bị chặn) - không chặn
                    # chạy, chỉ ghi nhận "skipped" để không im lặng nuốt lỗi.
                    res.preflight_status = "skipped"
                    LOGGER.debug("preflight audit bỏ qua (lỗi nội bộ): %s", exc)
            else:
                res.preflight_status = None

            # Mục 2.5 — Xác thực ghi nhận phân tích (Analytics Telemetry Verification).
            # Lắng nghe response tới các endpoint đo lường phổ biến (GA4 /g/collect,
            # Universal Analytics /collect, Meta Pixel, TikTok Pixel...) trong suốt
            # vòng đời page này. Đánh dấu VERIFIED_SUCCESS nếu có ít nhất 1 request
            # khớp mẫu và nhận HTTP 200/204.
            analytics_state = {"verified": False, "hits": 0}
            if await self.db.aget_setting("analytics_verification_enabled", True):
                from reporting import attach_analytics_listener
                attach_analytics_listener(page, analytics_state)
                res.analytics_verified = "NOT_VERIFIED"  # cập nhật lại VERIFIED_SUCCESS nếu bắt được hit
            else:
                res.analytics_verified = None

            ctx = RunCtx(task, sc, task.url, res, TestDataGenerator(self.settings.llm), bopt)
            ctx.meta["_analytics_state"] = analytics_state
            # Phase 9: autopilot mutation (nếu enabled trong scenario config)
            steps_to_run = sc.steps or self._default_steps(sc)
            if sc.__dict__.get("autopilot", {}).get("enabled"):
                try:
                    from autopilot_rewriter import AutopilotRewriter
                    rewriter = AutopilotRewriter()
                    mutated_sc = await rewriter.rewrite(
                        {"steps": steps_to_run, "autopilot": sc.__dict__.get("autopilot", {})})
                    steps_to_run = mutated_sc.get("steps", steps_to_run)
                    ctx.meta["autopilot_mutated"] = True
                except Exception as exc:
                    LOGGER.debug("autopilot rewrite bỏ qua: %s", exc)
            await self._run_steps(page, steps_to_run, ctx)
            if res.analytics_verified == "NOT_VERIFIED" and analytics_state.get("verified"):
                res.analytics_verified = "VERIFIED_SUCCESS"
        except StepFailed as exc:
            res.error = str(exc)
        except Exception as exc:  # noqa: BLE001
            msg = str(exc)
            res.error = f"{type(exc).__name__}: {msg[:400]}"
            res.gateway_error = gateway is not None and any(k in msg for k in GATEWAY_ERRORS)
        finally:
            res.bandwidth = bopt.stats.as_dict()
            if res.error and page is not None and sc.screenshot_on_error:
                await self._screenshot(page, sc, task)
            if context is not None:
                try:
                    if shared_mode or cdp_mode:
                        state_path.parent.mkdir(parents=True, exist_ok=True)
                        await context.storage_state(path=str(state_path))
                    await context.close()
                    # KHÔNG gọi browser.close() ở đây: trình duyệt dùng chung (shared_mode)
                    # sống hết vòng đời Engine; trình duyệt CDP (cdp_mode) là tiến trình bên
                    # ngoài không do runner khởi chạy nên runner không có quyền tắt nó.
                except Exception:  # noqa: BLE001
                    pass
        return res

    @staticmethod
    def _default_steps(sc: Scenario) -> list[dict[str, Any]]:
        steps: list[dict[str, Any]] = [{"action": "goto", "url": "{url}"}]
        if sc.interaction:
            steps.append({"action": "interact"})
        return steps

    async def _screenshot(self, page: Any, sc: Scenario, task: Task) -> None:
        path = self.paths.screenshots / f"{safe_name(sc.id)}_{task.task_id}.png"
        try:
            await page.screenshot(path=str(path), full_page=True)
            LOGGER.info("Đã lưu ảnh lỗi: %s", path.name, extra={"task": task.task_id})
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------ workflow
    async def _run_steps(self, page: Any, steps: list[dict[str, Any]], ctx: RunCtx) -> None:
        for step in steps:
            await self._run_step_with_retry(page, step, ctx)

    async def _run_step_with_retry(self, page: Any, step: dict[str, Any], ctx: RunCtx) -> None:
        """Hỗ trợ `max_retries` (thử lại CHÍNH bước này, không phải cả kịch bản) và
        `on_error_fallback` (một danh sách bước thay thế nếu vẫn lỗi sau khi hết lượt thử)."""
        # Phase 12: cập nhật worker registry cho Live Worker Grid.
        w = self._workers.get(ctx.task.task_id)
        if w is not None:
            w["current_step"] = step.get("action", "?")
            if w.get("page") is None:
                w["page"] = page
        max_retries = int(step.get("max_retries", 0))
        attempt = 0
        while True:
            try:
                await self._step(page, step, ctx)
                return
            except Exception as exc:
                if attempt < max_retries:
                    attempt += 1
                    delay = min(self.backoff.delay(attempt - 1), 5.0)  # giới hạn ở cấp bước
                    LOGGER.warning("Bước '%s' lỗi (%s) - thử lại %d/%d sau %.1fs",
                                   step.get("action"), exc, attempt, max_retries, delay,
                                   extra={"task": ctx.task.task_id})
                    await asyncio.sleep(delay)
                    continue
                fallback = step.get("on_error_fallback")
                if fallback:
                    LOGGER.warning("Bước '%s' thất bại sau %d lần thử - chuyển sang luồng dự phòng",
                                   step.get("action"), max_retries, extra={"task": ctx.task.task_id})
                    await self._run_steps(page, fallback, ctx)
                    return
                if step.get("optional"):
                    return
                raise

    def _allowed(self, url: str) -> bool:
        return is_url_allowed(url, self.settings.allowed_domains)

    async def _step(self, page: Any, step: dict[str, Any], ctx: RunCtx) -> None:
        action, sel = step.get("action"), step.get("selector")
        if action == "goto":
            target = str(step.get("url") or "{url}").replace("{url}", ctx.url)
            if not self._allowed(target):
                raise StepFailed(f"{target} không nằm trong allowed_domains")
            resp = await page.goto(target, wait_until="load")
            first = ctx.res.status is None
            if resp is not None and first:
                ctx.res.status = resp.status
                ctx.res.retry_after = parse_retry_after(resp.headers.get("retry-after"))
            if resp is not None and resp.status >= 400:
                raise StepFailed(f"HTTP {resp.status}")
            if ctx.bopt is not None:
                # Lưu ý: đóng banner cookie SAU khi trang đã load có thể gây thêm một layout
                # shift nhỏ (khi banner biến mất) - ảnh hưởng nhẹ tới CLS đo được, xem PROJECT.md.
                await ctx.bopt.dismiss_consent(page)
            await self.plugins.run("on_page_loaded", page, scenario=ctx.sc)
            if ctx.res.metrics is None:
                try:
                    await page.wait_for_load_state("networkidle", timeout=5000)
                except Exception:  # noqa: BLE001
                    pass
                ctx.res.metrics = await page.evaluate(COLLECT_METRICS_JS)
        elif action == "interact":
            cfg = InteractionConfig.from_dict({**ctx.sc.interaction, **step.get("config", {})})
            sim = InteractionSimulator(cfg, ctx.data)
            ctx.res.interaction = await sim.run(page, self._allowed)
        elif action == "scroll":
            # Phiên 19 fix: node "↕ Scroll" trên Flow Studio cho nhập field `delta_y`
            # nhưng TRƯỚC ĐÂY action này hoàn toàn không đọc bất kỳ field nào từ
            # step - luôn mô phỏng cuộn tự động theo ctx.sc.interaction (cấu hình
            # CẤP SCENARIO, không phải cấp step). Giữ hành vi cũ làm MẶC ĐỊNH (khi
            # không có delta_y - tương thích ngược hoàn toàn), nhưng nếu step có
            # delta_y cụ thể, cuộn CHÍNH XÁC số pixel đó bằng page.mouse.wheel().
            if "delta_y" in step:
                try:
                    dy = float(step["delta_y"])
                except (TypeError, ValueError):
                    dy = 0.0
                vp = page.viewport_size or {"width": 1280, "height": 720}
                await page.mouse.move(vp["width"] / 2, vp["height"] / 2)  # cần có trước wheel()
                await page.mouse.wheel(0, dy)
                await page.wait_for_timeout(100)  # wheel là bất đồng bộ - cần 1 nhịp để scroll thật sự áp dụng
            else:
                sim = InteractionSimulator(InteractionConfig.from_dict(ctx.sc.interaction), ctx.data)
                await sim.incremental_scroll(page)
        elif action == "click":
            await page.click(sel)
        elif action in ("fill", "type"):
            # Phiên 19 fix: node "⌨ Type" trên Flow Studio tạo action="type" (tên
            # thân thiện người dùng) nhưng engine chỉ có "fill" - 2 tên khác nhau
            # khiến MỌI node Type từ trước tới nay báo lỗi "Hành động không hỗ trợ".
            # Field cũng lệch: UI dùng "text", code cũ chỉ đọc "value". Giờ chấp
            # nhận CẢ 2 tên action và CẢ 2 tên field (ưu tiên "text" vì khớp UI).
            value = step.get("text", step.get("value", ""))
            await page.fill(sel, ctx.data.resolve(str(value)))
        elif action == "wait":
            # Phiên 19 fix: node "⏱ Wait" dùng field "duration_ms", code cũ chỉ đọc
            # "ms"/"value" - mọi node Wait từ UI trước đây luôn chờ 0ms (vô dụng).
            ms = step.get("duration_ms", step.get("ms", step.get("value", 0)))
            await page.wait_for_timeout(int(ms))
        elif action == "wait_for_selector":
            await page.wait_for_selector(sel)
        elif action == "wait_for_load_state":
            await page.wait_for_load_state(step.get("value", "load"))
        elif action in ("assert_selector", "assert"):
            # Phiên 19 fix: node "✔ Assert" tạo action="assert" - KHÔNG TỒN TẠI
            # trong engine trước đây (chỉ có assert_selector/assert_text tách
            # riêng, không action nào tên "assert" cả) - alias "assert" vào đây,
            # và đọc CẢ "selector" (kiểm tra tồn tại) LẪN "expected_text" (kiểm
            # tra nội dung trang) nếu cả 2 được điền trên node, khớp đúng 2 field
            # UI thật sự cho nhập (`_NODE_TEMPLATES.assert.fields`).
            if sel:
                try:
                    await page.wait_for_selector(sel, timeout=int(step.get("timeout", 5000)))
                except Exception as exc:
                    raise StepFailed(f"assert thất bại: không thấy selector {sel}") from exc
            expected = step.get("expected_text", step.get("value"))
            if expected:
                if str(expected) not in await page.inner_text("body"):
                    raise StepFailed(f"assert thất bại: không thấy text {expected!r}")
            if not sel and not expected:
                raise StepFailed("assert: cần ít nhất 1 trong 2 field 'selector' hoặc 'expected_text'")
        elif action == "assert_text":
            if str(step["value"]) not in await page.inner_text("body"):
                raise StepFailed(f"assert_text thất bại: không thấy {step['value']!r}")
        elif action == "loop":
            # Phiên 19 fix: node "🔄 Loop" KHÔNG TỒN TẠI trong engine trước đây -
            # mọi node Loop từ Flow Studio luôn báo "Hành động không hỗ trợ".
            # Field UI: count (số lần lặp), selector_wait (tùy chọn - nếu điền,
            # dừng sớm khi KHÔNG còn thấy selector này, hữu ích cho "lặp tới khi
            # hết trang/hết phần tử"). Thân vòng lặp đọc từ field "steps" (mảng
            # step con) - trên canvas, đây là NHÁNH DUY NHẤT đi ra từ node Loop
            # (xem _buildStepsFromGraph ở dashboard.py - giới hạn: mọi node sau
            # Loop trên cùng canvas đều nằm TRONG thân lặp, muốn chạy ngoài vòng
            # lặp phải tạo một chuỗi gốc độc lập khác trên canvas).
            count = int(step.get("count", 1))
            body = step.get("steps", [])
            for i in range(max(0, count)):
                if step.get("selector_wait"):
                    try:
                        await page.wait_for_selector(step["selector_wait"], timeout=2000)
                    except Exception:  # noqa: BLE001
                        LOGGER.debug("loop: dừng sớm ở vòng %d/%d - không còn thấy selector_wait", i + 1, count)
                        break
                await self._run_steps(page, body, ctx)
        elif action == "screenshot":
            name = safe_name(str(step.get("name", "shot")))
            shot_path = self.paths.screenshots / f"{name}.png"
            await page.screenshot(path=str(shot_path))
            ctx.last_screenshot = str(shot_path)
        elif action == "call_integration":
            await self._call_integration(str(step.get("name") or step.get("integration")),
                                         step.get("payload") or {}, page, ctx)
        elif action == "branch":
            branch = step.get("then", []) if await self._condition(page, step) else step.get("else", [])
            await self._run_steps(page, branch, ctx)
        # ── Phase 3: Phân hệ nâng cao ──────────────────────────────────────
        elif action == "widget_qa":
            from widget_media_qa import run_iframe_check
            result = await run_iframe_check(page, step.get("config") or {})
            ctx.meta["widget_qa"] = result
            LOGGER.info("widget_qa: %d iframe(s), %d redirect(s)",
                        result.get("iframe_count", 0), result.get("redirected_count", 0))
        elif action == "media_qa":
            from widget_media_qa import run_media_check
            result = await run_media_check(page, step.get("config") or {})
            ctx.meta["media_qa"] = result
            if not result.get("playback_ok"):
                LOGGER.warning("media_qa: playback KHÔNG ổn - %.1fs / %.1fs",
                               result.get("actual_play_s", 0), result.get("retention_window_s", 0))
        elif action == "trace_replay":
            from trace_replayer import run_trace_replay
            trace_path = step.get("trace_path") or step.get("path")
            if not trace_path:
                raise StepFailed("trace_replay: thiếu 'trace_path'")
            result = await run_trace_replay(page, trace_path, step.get("config") or {})
            ctx.meta["trace_replay"] = result
            if result.get("events_error", 0) > 0:
                LOGGER.warning("trace_replay: %d/%d sự kiện lỗi",
                               result["events_error"], result["events_total"])
        elif action == "trace_record":
            from trace_replayer import run_trace_record
            output = step.get("output_path") or step.get("output") or "recorded_trace.json"
            result = await run_trace_record(
                page, output,
                duration_s=step.get("duration_s", 30.0),
                record_keys=step.get("record_keys", True),
                record_input=step.get("record_input", True),
            )
            ctx.meta["trace_record"] = result
        elif action == "use_tunnel":
            from tunnel_manager import TunnelManager
            tunnel_name = step.get("tunnel") or step.get("name")
            config_path = step.get("config_path")
            binary = step.get("binary", "xray")
            if not tunnel_name:
                raise StepFailed("use_tunnel: thiếu 'tunnel' (tên tunnel)")
            if not hasattr(ctx, "_tunnel_manager"):
                ctx._tunnel_manager = TunnelManager(self.db)
            proxy_url = await ctx._tunnel_manager.start(
                tunnel_name, config_path=config_path, binary=binary)
            ctx.meta["tunnel_proxy_url"] = proxy_url
            LOGGER.info("use_tunnel: '%s' sẵn sàng → %s", tunnel_name, proxy_url)
        elif action == "js_probe":
            from js_sandbox_probe import probe_and_cache
            script = step.get("script") or step.get("js")
            if not script:
                raise StepFailed("js_probe: thiếu 'script' (mã JS cần chạy)")
            probe_key = step.get("probe_key") or f"step:{hash(script) & 0xFFFFFF:06x}"
            result = await probe_and_cache(
                self.db, probe_key, script,
                ttl_s=step.get("ttl_s", 3600),
                timeout_s=step.get("timeout_s", 15.0),
            )
            ctx.meta["js_probe"] = result
            LOGGER.info("js_probe '%s': cached=%s elapsed=%.0fms",
                        probe_key, result.get("cached"), result.get("elapsed_probe_ms"))
        # ── Phase 4: Cloud Browser ──────────────────────────────────────────
        elif action == "cloud_connect":
            from cloud_browser_adapter import CloudConfig, CloudBrowserAdapter
            cfg = CloudConfig.from_dict(step.get("cloud") or step.get("config") or {})
            adapter = CloudBrowserAdapter(self.db)
            # Lưu adapter vào ctx để _attempt_browser có thể dùng
            if not hasattr(ctx, "_cloud_adapter"):
                ctx._cloud_adapter = adapter
            ctx.meta["cloud_config"] = step.get("cloud") or step.get("config") or {}
            LOGGER.info("cloud_connect: provider=%s cấu hình đã lưu, sẽ dùng ở bước tiếp theo", cfg.provider)
        # ── Phase 4: Failure classification manual ───────────────────────
        elif action == "classify_failure":
            from diagnostics_alerter import FailureTaxonomyEngine
            engine_inst = FailureTaxonomyEngine(self.db)
            msg = step.get("message") or ctx.meta.get("last_error", "")
            http_st = step.get("http_status")
            ft = await engine_inst.classify_and_log(msg, scenario_id=ctx.sc.id,
                                                     http_status=http_st)
            ctx.meta["failure_type"] = ft
            LOGGER.info("classify_failure: '%s' → %s", ctx.sc.id, ft)
        # ── Phase 4: Smart cache pruning ──────────────────────────────────
        elif action == "prune_cache":
            from diagnostics_alerter import SmartCachePruner
            profiles_root = step.get("profiles_root") or str(self.settings.profiles_dir)
            pruner = SmartCachePruner(Path(profiles_root), dry_run=step.get("dry_run", False))
            profile_id = step.get("profile_id") or ctx.sc.profile_id or ""
            if profile_id:
                result = pruner.prune_profile(profile_id)
                ctx.meta["prune_result"] = {"bytes_freed": result.bytes_freed,
                                             "dirs_removed": result.dirs_removed}
                LOGGER.info("prune_cache: '%s' freed %.1fKB", profile_id,
                            result.bytes_freed / 1024)
        # ── Phase 5: Kinematic input ──────────────────────────────────────
        elif action == "human_click":
            from kinematic_input import KinematicSuite
            ks = KinematicSuite(page, seed=step.get("seed"))
            selector = step.get("selector")
            if selector:
                await ks.human_click(selector)
            elif step.get("x") is not None:
                await ks.mouse.click(float(step["x"]), float(step["y"]))
            else:
                raise StepFailed("human_click: cần 'selector' hoặc 'x'/'y'")
        elif action == "human_type":
            from kinematic_input import KinematicSuite
            ks = KinematicSuite(page, seed=step.get("seed"))
            await ks.human_type(step.get("selector","body"), step.get("text",""))
        elif action == "human_scroll":
            from kinematic_input import KinematicSuite
            ks = KinematicSuite(page, seed=step.get("seed"))
            await ks.scroll.scroll_gesture(float(step.get("delta_y", 500)))
        # ── Phase 5: Pre-flight audit ─────────────────────────────────────
        elif action == "preflight_audit":
            from preflight_audit import run_preflight
            report = await run_preflight(
                page=page, db=self.db,
                run_id=step.get("run_id") or ctx.sc.id,
                expected_timezone=step.get("expected_timezone"),
                expected_locale=step.get("expected_locale"),
                expected_webgl_vendor=step.get("expected_webgl_vendor"),
                exit_ip=step.get("exit_ip"),
                expected_ip_country=step.get("expected_ip_country"),
                block_on_fail=step.get("block_on_fail", True),
                skip_checks=step.get("skip_checks"),
            )
            ctx.meta["preflight"] = report.to_dict()
            if report.blocked:
                raise StepFailed(f"preflight_audit: campaign bị chặn — {report.to_dict()['summary']}")
        # ── Phase 5: Apply persona ────────────────────────────────────────
        elif action == "apply_persona":
            from persona_manager import PersonaManager
            pm = PersonaManager()
            persona_id = step.get("persona_id")
            persona = pm.get(persona_id) if persona_id else pm.pick_random(
                device_type=step.get("device_type"),
                os_filter=step.get("os"),
            )
            if persona:
                await pm.apply_to_context(
                    page.context, persona,
                    block_webrtc=step.get("block_webrtc", True),
                )
                ctx.meta["persona"] = persona.id
                LOGGER.info("apply_persona: áp '%s'", persona.id)
        # ── Phase 4: Action Synchronizer ─────────────────────────────────────
        elif action == "sync_start":
            from action_synchronizer import ActionSynchronizer, SlaveConfig
            slave_pages: list[Any] = step.get("slave_pages") or ctx.meta.get("slave_pages", [])
            if not slave_pages:
                LOGGER.warning("sync_start: không có slave pages, bỏ qua")
            else:
                slaves = [SlaveConfig(name=f"slave-{i}", page=pg,
                                      jitter_min_ms=step.get("jitter_min_ms", 50),
                                      jitter_max_ms=step.get("jitter_max_ms", 300))
                          for i, pg in enumerate(slave_pages)]
                syncer = ActionSynchronizer(page, slaves)
                await syncer.start()
                ctx.meta["_syncer"] = syncer
                LOGGER.info("sync_start: đang phát tới %d slave(s)", len(slaves))
        elif action == "sync_stop":
            syncer = ctx.meta.get("_syncer")
            if syncer:
                await syncer.stop()
                ctx.meta["sync_stats"] = syncer.stats
                del ctx.meta["_syncer"]
        # ── Phase 6: Self-Healing click/type ─────────────────────────────────
        elif action == "healing_click":
            from self_healing import ElementSnapshot, HealingLocator, SelectorHealer
            snap = ElementSnapshot.from_step(step)
            healer = SelectorHealer(
                ollama_url=step.get("ollama_url", "http://localhost:11434"),
                ollama_model=step.get("ollama_model", "llama3.2"),
            )
            loc_wrapper = HealingLocator(page, healer)
            loc = await loc_wrapper.locate(snap, timeout_ms=step.get("timeout_ms", 5000))
            await loc.click()
            # Ghi DB healing log nếu có heal
            healed_sel = loc_wrapper._cache.get(snap.selector)
            if healed_sel:
                await self._log_healing(snap.selector, healed_sel, ctx.sc.id)
                ctx.meta["last_healed_selector"] = healed_sel
        elif action == "healing_type":
            from self_healing import ElementSnapshot, HealingLocator
            snap = ElementSnapshot.from_step(step)
            loc_wrapper = HealingLocator(page)
            loc = await loc_wrapper.locate(snap, timeout_ms=step.get("timeout_ms", 5000))
            await loc.fill(step.get("text", ""))
        # ── Phase 7: Referrer Chain ───────────────────────────────────────────
        elif action == "referrer_goto":
            from referrer_orchestrator import ReferrerChain, ReferrerConfig
            cfg = ReferrerConfig.from_dict(step.get("referrer") or {})
            chain = ReferrerChain(page, cfg)
            url = step.get("url") or ctx.sc.url or ""
            result = await chain.navigate_to(url)
            ctx.meta["referrer_chain"] = result
            LOGGER.info("referrer_goto: %s → %s (via %s)",
                        result.get("referer_sent","direct")[:40],
                        url[:50], cfg.source)
        # ── Phase 7: Credential Vault ─────────────────────────────────────────
        elif action == "vault_load_cookies":
            from credential_vault import CredentialVault
            vault = CredentialVault(self.db)
            profile_id = step.get("profile_id") or ctx.sc.profile_id or ""
            domain = step.get("domain", "")
            if not domain:
                parsed = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(ctx.sc.url or "")
                domain = parsed.netloc
            cookies = await vault.aget_cookies_playwright(profile_id, domain)
            if cookies:
                await page.context.add_cookies(cookies)
                ctx.meta["vault_cookies_loaded"] = len(cookies)
                LOGGER.info("vault: injected %d cookies cho %s", len(cookies), domain)
        elif action == "vault_save_cookies":
            from credential_vault import CredentialVault
            vault = CredentialVault(self.db)
            profile_id = step.get("profile_id") or ctx.sc.profile_id or ""
            # Lấy cookies từ browser context hiện tại
            all_cookies = await page.context.cookies()
            domain = step.get("domain") or (urlparse(page.url).netloc if page.url else "")
            filtered = [c for c in all_cookies if domain in c.get("domain","")]
            if filtered:
                await vault.asave_cookies(profile_id, domain, filtered)
                ctx.meta["vault_cookies_saved"] = len(filtered)
        # ── Phase 7: Pre-task prime session ──────────────────────────────────
        elif action == "prime_session":
            from session_warmer import SessionWarmer
            warmer = SessionWarmer(self.settings.profiles_dir, self.db)
            profile_id = step.get("profile_id") or ctx.sc.profile_id or ""
            target = step.get("url") or ctx.sc.url or ""
            if profile_id and target:
                result = await warmer.prime_session(
                    profile_id, target,
                    dwell_s=step.get("dwell_s", 7.0),
                    headless=self.settings.headless,
                )
                ctx.meta["prime_result"] = result.__dict__
        # ── Phase 8: Hybrid Browser→HTTP Handoff ─────────────────────────────
        elif action == "hybrid_handoff":
            from engine_router import HybridHandoff
            handoff = HybridHandoff()
            await handoff.capture(page)
            urls = step.get("urls") or []
            if urls:
                results = await handoff.execute_requests(
                    urls,
                    method=step.get("method", "GET"),
                    timeout_s=step.get("timeout_s", 15.0),
                    proxy_url=step.get("proxy_url", ""),
                )
                ctx.meta["hybrid_handoff_results"] = results
                ok_count = sum(1 for r in results if r.get("status", 0) < 400)
                LOGGER.info("hybrid_handoff: %d/%d requests OK", ok_count, len(results))
            else:
                # Chỉ capture state, không gửi request ngay
                ctx.meta["hybrid_handoff"] = {
                    "cookies": len(handoff.cookies),
                    "user_agent": handoff.user_agent[:50],
                }
        # ── Phase 9: Redirect / Popup Blocker ────────────────────────────────
        elif action == "block_redirects":
            from campaign_controller import RedirectBlocker, BlockerConfig
            bcfg = BlockerConfig(
                allowed_domains=step.get("allowed_domains", []),
                block_popups=step.get("block_popups", True),
                block_new_tabs=step.get("block_new_tabs", True),
                log_blocked=step.get("log_blocked", True),
            )
            blocker = RedirectBlocker(page, bcfg)
            await blocker.attach()
            ctx.meta["_blocker"] = blocker
            LOGGER.info("block_redirects: active, allowed=%s", step.get("allowed_domains", []))
        elif action == "blocker_stats":
            blocker = ctx.meta.get("_blocker")
            if blocker:
                ctx.meta["blocker_stats"] = blocker.stats
        # ── Phase 9: Autopilot LLM rewrite ────────────────────────────────
        elif action == "autopilot_preview":
            from autopilot_rewriter import AutopilotRewriter
            rewriter = AutopilotRewriter(
                ollama_url=step.get("ollama_url", "http://localhost:11434"),
                model=step.get("model", "llama3.2"),
            )
            level = step.get("level", "light")
            mutated = await rewriter.preview(ctx.sc.__dict__.get("steps", []), level)
            ctx.meta["autopilot_preview"] = mutated
        # ── Phase 9: TLS session store probe ──────────────────────────────
        elif action == "tls_probe":
            from engine_router import TLSSessionStore
            from urllib.parse import urlsplit
            store = TLSSessionStore()
            url = step.get("url") or ctx.sc.url or ""
            host = urlsplit(url).netloc if url else ""
            if host:
                sess = await store.get_session(host, impersonate="chrome")
                try:
                    r = await sess.get(url, timeout=15)
                    ctx.meta["tls_probe"] = {
                        "host": host, "status": r.status_code,
                        "tls_resumed": True,  # curl_cffi handles internally
                    }
                except Exception as exc:
                    ctx.meta["tls_probe"] = {"host": host, "error": str(exc)[:100]}
                await store.close_all()
        # ── Phase 8: Resource check ───────────────────────────────────────────
        elif action == "resource_check":
            try:
                import psutil
                vm = psutil.virtual_memory()
                cpu = psutil.cpu_percent(interval=0.3)
                ctx.meta["system_metrics"] = {
                    "cpu_pct": round(cpu, 1),
                    "ram_pct": round(vm.percent, 1),
                    "ram_available_mb": round(vm.available / 1_048_576),
                }
                ram_limit = step.get("fail_if_ram_pct_above", 95.0)
                if vm.percent > ram_limit:
                    raise StepFailed(
                        f"resource_check: RAM {vm.percent:.0f}% > ngưỡng {ram_limit:.0f}%")
            except ImportError:
                LOGGER.debug("resource_check: psutil chưa cài")
        # ── Phase 12: Analytics Telemetry Verify (node palette #9) ─────────────
        elif action == "analytics_verify":
            # Checkpoint thủ công: Phase 10.5 đã tự động gắn listener + chốt
            # VERIFIED_SUCCESS ở cuối _attempt_browser, nhưng node này cho người
            # dùng CHỦ ĐỘNG kiểm tra NGAY tại một điểm giữa flow (vd. sau khi submit
            # form) và tùy chọn chặn flow lại (StepFailed) nếu bắt buộc phải thấy
            # pixel đã bắn trước khi đi tiếp.
            analytics_state = ctx.meta.get("_analytics_state", {})
            verified = bool(analytics_state.get("verified"))
            ctx.meta.setdefault("analytics_verify_checkpoints", []).append({
                "verified": verified, "hits": analytics_state.get("hits", 0),
                "at_step": step.get("_flow_id"),
            })
            if step.get("require", False) and not verified:
                raise StepFailed(
                    "analytics_verify: chưa thấy gói tin Analytics nào được xác nhận "
                    "(HTTP 200/204) tính đến thời điểm này trong flow."
                )
        # ── Phase 12: Local AI Form Filler (node palette #12) ───────────────────
        elif action == "ai_form_fill":
            await self._ai_form_fill(page, step, ctx)
        else:
            raise StepFailed(f"Hành động không hỗ trợ: {action!r}")

    # ── Phase 12: Node palette #12 - Local AI Form Filler ──────────────────────
    #: Khớp name/id/placeholder/aria-label của input (chữ thường) với "gợi ý"
    #: (hint) để TestDataGenerator sinh dữ liệu đúng ngữ cảnh (tên, email, điện
    #: thoại...). Khớp theo thứ tự - mẫu đầu tiên khớp thắng.
    _FORM_FIELD_HINTS: tuple[tuple[str, str], ...] = (
        ("email", "email"), ("e-mail", "email"),
        ("phone", "phone number"), ("tel", "phone number"), ("mobile", "phone number"),
        ("first", "first name"), ("last", "last name"), ("full", "full name"),
        ("name", "full name"),
        ("address", "street address"), ("city", "city name"),
        ("zip", "postal code"), ("postal", "postal code"),
        ("company", "company name"), ("message", "short message"),
        ("comment", "short comment"), ("subject", "email subject line"),
        ("age", "age as a number between 18 and 65"),
        ("country", "country name"),
    )

    def _infer_form_hint(self, attrs: dict[str, str]) -> str:
        text = " ".join(v for v in attrs.values() if v).lower()
        for keyword, hint in self._FORM_FIELD_HINTS:
            if keyword in text:
                return hint
        return "a short realistic piece of text for a web form field"

    async def _ai_form_fill(self, page: Any, step: dict[str, Any], ctx: "RunCtx") -> None:
        """Dò các input/textarea/select hiển thị trong `form` (hoặc toàn trang
        nếu không có `form` tag), suy luận ngữ cảnh mỗi field từ name/id/
        placeholder/aria-label, sinh dữ liệu tự nhiên qua `ctx.data.text()`
        (có thể gọi LLM nếu `settings.llm` được cấu hình, xem `test_data.py`),
        rồi điền vào. `step.submit=True` sẽ tự bấm nút submit sau khi điền xong."""
        scope_selector = step.get("form_selector", "form")
        try:
            fields = await page.eval_on_selector_all(
                f"{scope_selector} input:not([type=hidden]):not([type=submit]):not([type=button]), "
                f"{scope_selector} textarea, {scope_selector} select",
                """els => els.map((el, i) => ({
                    index: i, tag: el.tagName.toLowerCase(), type: el.type || '',
                    name: el.name || '', id: el.id || '',
                    placeholder: el.placeholder || '',
                    aria_label: el.getAttribute('aria-label') || '',
                    visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
                }))""",
            )
        except Exception as exc:  # noqa: BLE001
            raise StepFailed(f"ai_form_fill: không đọc được form ({exc})")

        filled = 0
        for f in fields:
            if not f.get("visible", True):
                continue
            attrs = {"name": f.get("name", ""), "id": f.get("id", ""),
                     "placeholder": f.get("placeholder", ""), "aria": f.get("aria_label", "")}
            selector = (f"{scope_selector} [name='{f['name']}']" if f.get("name")
                       else f"{scope_selector} #{f['id']}" if f.get("id") else None)
            if not selector:
                continue
            try:
                if f["tag"] == "select":
                    options = await page.eval_on_selector(selector, "el => [...el.options].map(o=>o.value).filter(v=>v)")
                    if options:
                        await page.select_option(selector, options[len(options) // 2])
                        filled += 1
                    continue
                if f.get("type") == "checkbox":
                    if step.get("check_checkboxes", False):
                        await page.check(selector)
                        filled += 1
                    continue
                hint = self._infer_form_hint(attrs)
                value = await ctx.data.text(hint)
                await page.fill(selector, str(value)[:200])
                filled += 1
            except Exception as exc:  # noqa: BLE001
                LOGGER.debug("ai_form_fill: bỏ qua field %r (%s)", attrs, exc)

        ctx.meta["ai_form_fill"] = {"fields_filled": filled, "fields_detected": len(fields)}
        if filled == 0:
            raise StepFailed(f"ai_form_fill: không điền được field nào trong '{scope_selector}'")

        if step.get("submit", False):
            submit_sel = step.get("submit_selector", f"{scope_selector} button[type=submit], {scope_selector} input[type=submit]")
            try:
                await page.click(submit_sel, timeout=5000)
            except Exception as exc:  # noqa: BLE001
                LOGGER.warning("ai_form_fill: điền xong nhưng bấm submit lỗi: %s", exc)

    async def _log_healing(self, old_sel: str, new_sel: str, scenario_id: str) -> None:
        """Ghi healing event vào DB."""
        try:
            from datetime import datetime, timezone
            self.db._write(
                """INSERT INTO healing_log (scenario_id, old_selector, new_selector,
                   strategy, confidence, healed_at) VALUES (?,?,?,?,?,?)""",
                (scenario_id, old_sel, new_sel, "auto",
                 0.8, datetime.now(timezone.utc).isoformat()),
            )
        except Exception:
            pass

    async def _call_integration(self, name: str, payload: dict[str, Any], page: Any, ctx: RunCtx) -> None:
        """Mục 4.3 - gọi một dịch vụ bên thứ ba đã cấu hình trên Web UI (tab Integrations)
        từ trong workflow, thường dùng trong `on_error_fallback`. Ba giao thức:
        - "webhook": POST JSON có Bearer token - giao thức chung (Slack/Discord/nội bộ).
        - "captcha_solver": giao thức kiểu 2Captcha (submit `in.php` -> poll `res.php`),
          rồi TỰ ĐIỀN token vào trang qua `payload.inject_selector` (mặc định
          `#g-recaptcha-response`). CHƯA xác minh với tài khoản 2Captcha thật (chỉ test
          bằng máy chủ giả lập đúng hình dạng API) - endpoint khác chuẩn 2Captcha (vd.
          Anti-Captcha dùng JSON-RPC, không phải in.php/res.php) sẽ KHÔNG hoạt động.
        - "cloud_storage": PUT ảnh chụp màn hình gần nhất (nếu có) lên `endpoint_url` kèm
          Bearer token. KHÔNG triển khai chữ ký AWS SigV4 chuẩn (phức tạp, cần tài khoản
          AWS thật để test) - chỉ hợp với presigned URL hoặc gateway nhận Bearer token
          (MinIO/R2 cấu hình phù hợp, hoặc backend tự viết), KHÔNG gọi thẳng được S3 dùng
          Access Key/Secret Key kiểu SigV4 truyền thống."""
        if not name:
            raise StepFailed("call_integration: thiếu 'name'")
        row = await self.db.aget_integration(name)
        if row is None:
            raise StepFailed(f"call_integration: không có tích hợp tên '{name}'")
        api_key = None
        if row["api_key_enc"]:
            try:
                api_key = self.secrets.decrypt(row["api_key_enc"])
            except Exception as exc:  # noqa: BLE001
                raise StepFailed(f"call_integration: không giải mã được api_key đã lưu ({exc})") from exc

        if row["service_type"] == "webhook":
            await self._integration_webhook(name, row["endpoint_url"], api_key, payload)
        elif row["service_type"] == "captcha_solver":
            await self._integration_captcha_solver(name, row["endpoint_url"], api_key, payload, page)
        elif row["service_type"] == "cloud_storage":
            await self._integration_cloud_storage(name, row["endpoint_url"], api_key, payload, ctx)
        else:
            raise StepFailed(f"call_integration: service_type='{row['service_type']}' không xác định")

    @staticmethod
    async def _integration_webhook(name: str, endpoint_url: Optional[str], api_key: Optional[str],
                                   payload: dict[str, Any]) -> None:
        import httpx

        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(endpoint_url, json=payload, headers=headers)
            if resp.status_code >= 400:
                raise StepFailed(f"call_integration '{name}': endpoint trả HTTP {resp.status_code}")
        except httpx.HTTPError as exc:
            raise StepFailed(f"call_integration '{name}': lỗi kết nối ({exc})") from exc

    @staticmethod
    async def _integration_captcha_solver(name: str, endpoint_url: Optional[str], api_key: Optional[str],
                                          payload: dict[str, Any], page: Any) -> None:
        import httpx

        if not api_key:
            raise StepFailed(f"call_integration '{name}': captcha_solver cần api_key")
        base = (endpoint_url or "http://2captcha.com").rstrip("/")
        sitekey = payload.get("sitekey")
        if not sitekey:
            raise StepFailed(f"call_integration '{name}': payload cần 'sitekey' (site key của reCAPTCHA/hCaptcha)")
        method = payload.get("method", "userrecaptcha")
        page_url = payload.get("page_url", page.url)
        poll_interval_s = float(payload.get("poll_interval_s", 5))
        max_wait_s = float(payload.get("max_wait_s", 120))

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                submit = await client.get(f"{base}/in.php", params={
                    "key": api_key, "method": method, "googlekey": sitekey,
                    "pageurl": page_url, "json": 1})
                sdata = submit.json()
                if sdata.get("status") != 1:
                    raise StepFailed(f"call_integration '{name}': gửi captcha thất bại - {sdata.get('request')}")
                captcha_id = sdata["request"]

                elapsed = 0.0
                token = None
                while elapsed < max_wait_s:
                    await asyncio.sleep(poll_interval_s)
                    elapsed += poll_interval_s
                    poll = await client.get(f"{base}/res.php", params={
                        "key": api_key, "action": "get", "id": captcha_id, "json": 1})
                    pdata = poll.json()
                    if pdata.get("status") == 1:
                        token = pdata["request"]
                        break
                    if pdata.get("request") not in ("CAPCHA_NOT_READY",):
                        raise StepFailed(f"call_integration '{name}': giải captcha lỗi - {pdata.get('request')}")
                if token is None:
                    raise StepFailed(f"call_integration '{name}': hết thời gian chờ ({max_wait_s}s)")
        except httpx.HTTPError as exc:
            raise StepFailed(f"call_integration '{name}': lỗi kết nối tới dịch vụ giải captcha ({exc})") from exc

        selector = payload.get("inject_selector", "#g-recaptcha-response")
        try:
            await page.evaluate(
                "([sel, tok]) => { const el = document.querySelector(sel); "
                "if (el) { el.innerHTML = tok; el.value = tok; } "
                "if (window.___grecaptcha_cfg) { try { window.grecaptcha.getResponse = () => tok; } catch (e) {} } }",
                [selector, token])
        except Exception as exc:  # noqa: BLE001
            raise StepFailed(f"call_integration '{name}': giải captcha xong nhưng không điền được vào "
                             f"selector '{selector}' ({exc})") from exc

    @staticmethod
    async def _integration_cloud_storage(name: str, endpoint_url: Optional[str], api_key: Optional[str],
                                         payload: dict[str, Any], ctx: RunCtx) -> None:
        import httpx

        if not endpoint_url:
            raise StepFailed(f"call_integration '{name}': cloud_storage cần endpoint_url")
        source = payload.get("file") or ctx.last_screenshot
        if not source or not Path(source).is_file():
            raise StepFailed(f"call_integration '{name}': không có tệp để tải lên - cần một step "
                             f"\"screenshot\" trước đó trong cùng luồng, hoặc truyền 'payload.file'")
        data = Path(source).read_bytes()
        headers = {"Content-Type": "application/octet-stream"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                resp = await client.put(endpoint_url, content=data, headers=headers)
            if resp.status_code >= 400:
                raise StepFailed(f"call_integration '{name}': tải lên thất bại - HTTP {resp.status_code}")
        except httpx.HTTPError as exc:
            raise StepFailed(f"call_integration '{name}': lỗi kết nối khi tải lên ({exc})") from exc

    @staticmethod
    async def _condition(page: Any, step: dict[str, Any]) -> bool:
        if "if_selector" in step:
            return await page.locator(step["if_selector"]).count() > 0
        if "if_url_contains" in step:
            return str(step["if_url_contains"]) in page.url
        if "if_text" in step:
            return str(step["if_text"]) in await page.inner_text("body")
        if "probability_a" in step:
            # Phase 19 fix: "Weighted Split" (mục 2.1.C.10 đặc tả Phase 12) - trước
            # đây field `probability_a` được UI cho nhập nhưng KHÔNG CÓ dòng code
            # nào đọc nó ở đây, nên mọi "Weighted Split" node đều luôn đi theo
            # nhánh "else" (vì _condition() luôn trả False khi không khớp if_*).
            try:
                p = float(step["probability_a"])
            except (TypeError, ValueError):
                p = 0.5
            return random.random() < max(0.0, min(1.0, p))
        return False

    # ------------------------------------------------------------ trạng thái cho dashboard
    async def status(self) -> dict[str, Any]:
        host_prefs = await self.db.aall_host_preferences()
        gw_checks = await self.db.alatest_gateway_checks()
        xvfb_status = self.xvfb.status() if self.xvfb is not None else {"running": False}
        return {"gateways": self.pool.snapshot(), "breakers": self.breakers.snapshot(),
                "max_concurrency": self.settings.max_concurrency,
                "context_mode": self.settings.context_mode,
                "router_default_engine": self.router.default_engine.value,
                "host_preferences": host_prefs, "gateway_checks": gw_checks,
                "xvfb": xvfb_status}
