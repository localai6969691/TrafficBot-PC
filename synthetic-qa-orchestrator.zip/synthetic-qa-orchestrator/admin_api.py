"""API phục vụ bảng điều khiển "Configuration & Extension Manager" trên dashboard
(mục 4.1-4.4). Được `dashboard.py` import và gắn vào ứng dụng FastAPI chính qua
`create_admin_router()` - module này giả định `fastapi` đã sẵn sàng (dashboard.py kiểm
tra trước khi import module này, xem ghi chú trong `create_app`).

Mọi endpoint ở đây chỉ nên truy cập được từ localhost/máy nội bộ của người vận hành -
dashboard chạy trên `127.0.0.1` theo mặc định (`settings.dashboard_host`). KHÔNG có lớp
xác thực (đăng nhập) nào khác: nếu đổi `dashboard_host` thành `0.0.0.0` để truy cập từ xa,
BẤT KỲ ai vào được địa chỉ đó đều có thể đổi cấu hình trình duyệt, cài plugin (chạy mã tuỳ
ý), hoặc đọc gateway đã cấu hình - xem cảnh báo tương ứng trong PROJECT.md.
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Body, Depends, Header, HTTPException
from pydantic import BaseModel


class JsRunIn(BaseModel):
    script: str


# Phase 10/11: TẤT CẢ BaseModel request body phải định nghĩa ở MODULE LEVEL
# (không lồng trong create_admin_router()) - lồng trong hàm khiến FastAPI đọc
# nhầm "body" thành query param, luôn trả 422 "Field required" (đã gặp bug
# này với JsRunIn ở trên, lặp lại 6 lần nữa ở Phase 10/11 trước khi sửa).
class CustomEngineDownloadIn(BaseModel):
    repo: str = "daijro/camoufox"       # "owner/repo" GitHub, mặc định Camoufox
    asset_pattern: str = ""             # vd. "linux" / "win64" - để trống = tự đoán theo OS hiện tại
    tag: str = "latest"                 # "latest" hoặc tag cụ thể (vd. "v135.0-beta.24")


class HybridHandoffTestIn(BaseModel):
    priming_url: str
    follow_up_urls: list[str]
    priming_wait_s: float = 5.0


class JsProbeRunIn(BaseModel):
    filename: str
    persona: Optional[dict[str, Any]] = None


class VirtualDisplayIn(BaseModel):
    enabled: bool
    width: int = 1920
    height: int = 1080


class GatewayQualitySettingsIn(BaseModel):
    datacenter_filter_enabled: Optional[bool] = None
    header_check_enabled: Optional[bool] = None
    max_latency_ms: Optional[float] = None  # 0 hoặc None = không giới hạn


class TrafficConfigIn(BaseModel):
    device_mix: Optional[dict[str, float]] = None
    source_mix: Optional[dict[str, float]] = None


class NlToFlowIn(BaseModel):
    description: str
    ollama_url: str = "http://localhost:11434"


class RunNowIn(BaseModel):
    scenario_ids: Optional[list[str]] = None  # None = chạy TẤT CẢ scenario active
    iterations: int = 1

from config_loader import Paths, load_config, load_gateways
from database import Database
from events import EventBus
from plugin_manager import Manifest, PluginInstallError, PluginInstaller, reconcile_plugins
from secrets_store import SecretBox

LOGGER = logging.getLogger("qa.admin_api")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


# ============================================================================ payload models
class BrowserSettingsIn(BaseModel):
    executable_path: Optional[str] = None
    cdp_endpoint: Optional[str] = None
    http_client: Optional[str] = None   # "httpx" | "curl_cffi"
    preflight_gate_enabled: Optional[bool] = None          # Phase 10.5
    analytics_verification_enabled: Optional[bool] = None  # Phase 10.5


class CdpTestIn(BaseModel):
    endpoint: str


class PluginInstallIn(BaseModel):
    filename: str
    content_base64: str


class PluginEnabledIn(BaseModel):
    enabled: bool


class PluginConfigIn(BaseModel):
    config: dict[str, Any]


class IntegrationIn(BaseModel):
    name: str
    service_type: str = "webhook"       # webhook | captcha_solver | cloud_storage | custom
    endpoint_url: Optional[str] = None
    api_key: Optional[str] = None        # chữ rõ - sẽ bị mã hoá trước khi lưu; None = không đổi key cũ
    extra: dict[str, Any] = {}


class GatewayImportIn(BaseModel):
    text: str
    mode: str = "replace"   # replace | append


async def _require_admin_key(db: Database, x_admin_key: Optional[str]) -> None:
    expected = await db.aget_setting("admin_api_key", "")
    if expected and x_admin_key != expected:
        raise HTTPException(401, "Thiếu hoặc sai header X-Admin-Key (xem `main.py admin-key`)")


def create_admin_router(db: Database, paths: Paths, bus: EventBus) -> APIRouter:
    """Nếu `system_settings.admin_api_key` đã được đặt (qua `main.py admin-key
    --generate`), MỌI route bên dưới yêu cầu header `X-Admin-Key` khớp, nếu không trả
    401 (kiểm tra qua dependency `_auth`, áp dụng cho toàn router). Nếu chưa đặt khoá
    (mặc định, tương thích ngược), không yêu cầu gì - xem cảnh báo bảo mật ở đầu file."""

    async def _auth(x_admin_key: Optional[str] = Header(default=None)) -> None:
        await _require_admin_key(db, x_admin_key)

    router = APIRouter(dependencies=[Depends(_auth)])
    secrets = SecretBox(paths.secret_key)
    installer = PluginInstaller(paths.plugins)

    # ------------------------------------------------------------ 4.1 Browser Runtime Settings
    @router.get("/browser-settings")
    async def get_browser_settings() -> dict[str, Any]:
        return {
            "executable_path": await db.aget_setting("browser_executable_path", ""),
            "cdp_endpoint": await db.aget_setting("cdp_endpoint", ""),
            "http_client": await db.aget_setting("http_client", "httpx"),
            "http_client_options": _http_client_options(),
            "preflight_gate_enabled": await db.aget_setting("preflight_gate_enabled", True),
            "analytics_verification_enabled": await db.aget_setting("analytics_verification_enabled", True),
        }

    @router.post("/browser-settings")
    async def save_browser_settings(body: BrowserSettingsIn) -> dict[str, Any]:
        now = utc_now()
        if body.executable_path is not None:
            await db.aset_setting("browser_executable_path", body.executable_path.strip(), now)
        if body.cdp_endpoint is not None:
            await db.aset_setting("cdp_endpoint", body.cdp_endpoint.strip(), now)
        if body.http_client is not None:
            if body.http_client not in ("httpx", "curl_cffi"):
                raise HTTPException(400, "http_client phải là 'httpx' hoặc 'curl_cffi'")
            await db.aset_setting("http_client", body.http_client, now)
        if body.preflight_gate_enabled is not None:
            await db.aset_setting("preflight_gate_enabled", body.preflight_gate_enabled, now)
        if body.analytics_verification_enabled is not None:
            await db.aset_setting("analytics_verification_enabled", body.analytics_verification_enabled, now)
        return {"saved": True}

    @router.post("/browser-settings/test-cdp")
    async def test_cdp(body: CdpTestIn) -> dict[str, Any]:
        """Thử kết nối tới một trình duyệt Chromium đang chạy sẵn qua CDP rồi ngắt ngay -
        KHÔNG giữ kết nối này lại (lần chạy thật sẽ tự kết nối lại, xem engine.py)."""
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            raise HTTPException(500, "Chưa cài playwright trong môi trường này")
        try:
            async with async_playwright() as pw:
                browser = await asyncio.wait_for(pw.chromium.connect_over_cdp(body.endpoint), timeout=8)
                try:
                    version = browser.version
                    contexts = len(browser.contexts)
                finally:
                    await browser.close()
            return {"ok": True, "browser_version": version, "existing_contexts": contexts}
        except asyncio.TimeoutError:
            return {"ok": False, "error": "Hết thời gian chờ kết nối (8s)"}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    @router.get("/browser-files")
    async def browse_browser_files() -> dict[str, Any]:
        """Liệt kê tệp thực thi khả dĩ trong thư mục browsers/ (giới hạn phạm vi này để
        tránh lộ đường dẫn tuỳ ý trên máy - xem cảnh báo đầu file). Không phải File Picker
        gốc hệ điều hành thật (dashboard chạy trong trình duyệt, không có quyền đó)."""
        if not paths.browsers.is_dir():
            return {"files": []}
        exe_names = {"chrome", "chrome.exe", "chromium", "chromium.exe", "msedge.exe",
                    "firefox", "firefox.exe", "Chromium.app", "Firefox.app"}
        found = []
        for p in paths.browsers.rglob("*"):
            if p.is_file() and (p.name in exe_names or p.suffix == ".exe" or
                                (p.stat().st_mode & 0o111 and p.suffix == "")):
                found.append(str(p.relative_to(paths.browsers)))
        return {"files": sorted(found)[:200], "root": str(paths.browsers)}

    # ------------------------------------------------------------ 4.2 Plugin Manager
    @router.get("/plugins")
    async def list_plugins() -> dict[str, Any]:
        await reconcile_plugins(db, paths)   # đăng ký plugin mới phát hiện trên đĩa vào DB
        return {"plugins": await db.aall_plugin_configs()}

    @router.post("/plugins/install")
    async def install_plugin(body: PluginInstallIn) -> dict[str, Any]:
        try:
            raw = base64.b64decode(body.content_base64, validate=True)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(400, f"content_base64 không hợp lệ: {exc}")
        try:
            manifest = await asyncio.to_thread(installer.install_zip, raw)
        except PluginInstallError as exc:
            raise HTTPException(400, str(exc))
        now = utc_now()
        rows = {r["plugin_name"]: r for r in await db.aall_plugin_configs()}
        config = rows[manifest.name]["config"] if manifest.name in rows else manifest.default_config()
        await db.aupsert_plugin_config(manifest.name, True, config, manifest.as_dict(), now)
        LOGGER.info("Đã cài plugin qua Web UI: %s", manifest.name)
        return {"installed": manifest.name, "manifest": manifest.as_dict()}

    @router.post("/plugins/{name}/enabled")
    async def set_plugin_enabled(name: str, body: PluginEnabledIn) -> dict[str, Any]:
        await db.aset_plugin_enabled(name, body.enabled, utc_now())
        return {"name": name, "enabled": body.enabled}

    @router.post("/plugins/{name}/config")
    async def set_plugin_config(name: str, body: PluginConfigIn) -> dict[str, Any]:
        rows = {r["plugin_name"]: r for r in await db.aall_plugin_configs()}
        if name not in rows:
            raise HTTPException(404, f"Không có plugin '{name}'")
        row = rows[name]
        manifest = Manifest.from_dict(row["manifest"]) if row["manifest"] else None
        coerced = _coerce_config(body.config, manifest)
        await db.aupsert_plugin_config(name, bool(row["enabled"]), coerced, row["manifest"], utc_now())
        return {"name": name, "config": coerced}

    @router.delete("/plugins/{name}")
    async def delete_plugin(name: str) -> dict[str, Any]:
        try:
            installer.remove(name)
        except PluginInstallError as exc:
            raise HTTPException(400, str(exc))
        await db.adelete_plugin_config(name)
        return {"deleted": name}

    # ------------------------------------------------------------ 4.3 Integrations & APIs
    @router.get("/integrations")
    async def list_integrations() -> dict[str, Any]:
        rows = await db.aall_integrations()
        for r in rows:
            enc = r.pop("api_key_enc", None)
            r["api_key_masked"] = _masked_key(enc, secrets)
            r["has_api_key"] = bool(enc)
        return {"integrations": rows, "service_types": ["webhook", "captcha_solver", "cloud_storage", "custom"]}

    @router.post("/integrations")
    async def save_integration(body: IntegrationIn) -> dict[str, Any]:
        if not body.name.strip():
            raise HTTPException(400, "Thiếu tên tích hợp")
        enc = None
        if body.api_key:
            enc = secrets.encrypt(body.api_key)
        elif body.api_key is None:
            existing = await db.aget_integration(body.name)
            enc = existing["api_key_enc"] if existing else None
        await db.aupsert_integration(body.name, body.service_type, body.endpoint_url, enc,
                                     body.extra, False, utc_now())
        return {"saved": body.name, "verified": False}

    @router.post("/integrations/{name}/verify")
    async def verify_integration(name: str) -> dict[str, Any]:
        """"Verify & Save": với service_type=webhook, thử POST một payload kiểm tra tới
        endpoint_url thật. Với captcha_solver/cloud_storage (chưa có protocol riêng - xem
        PROJECT.md), chỉ kiểm tra endpoint_url có phản hồi HTTP, KHÔNG xác minh được API
        key có đúng với nhà cung cấp hay không - trả về thông báo rõ ràng việc này."""
        row = await db.aget_integration(name)
        if row is None:
            raise HTTPException(404, f"Không có tích hợp '{name}'")
        if not row["endpoint_url"]:
            raise HTTPException(400, "Thiếu endpoint_url để kiểm tra")
        import httpx

        headers: dict[str, str] = {}
        api_key = secrets.decrypt(row["api_key_enc"]) if row["api_key_enc"] else None
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        note = ""
        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                if row["service_type"] == "webhook":
                    resp = await client.post(row["endpoint_url"], json={"test": True, "source": "qa-orchestrator"},
                                             headers=headers)
                elif row["service_type"] == "captcha_solver":
                    # Gọi API kiểm tra số dư của 2Captcha - xác minh THẬT api_key với nhà cung cấp
                    # (chỉ đúng với endpoint tương thích 2Captcha: in.php/res.php - xem PROJECT.md).
                    base = (row["endpoint_url"] or "http://2captcha.com").rstrip("/")
                    resp = await client.get(f"{base}/res.php",
                                            params={"key": api_key, "action": "getbalance", "json": 1})
                    body = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
                    if resp.status_code < 400 and body.get("status") == 1:
                        note = f"Số dư tài khoản: {body.get('request')}"
                    else:
                        resp.status_code = 400  # ép coi là lỗi dù HTTP 200, vì 2Captcha báo lỗi trong body
                        note = f"Phản hồi: {body}"
                else:  # cloud_storage và các loại khác
                    resp = await client.get(row["endpoint_url"], headers=headers)
                    note = ("Chỉ kiểm tra endpoint có phản hồi HTTP (GET) - không PUT thử vì sẽ tạo dữ liệu "
                           "thật trên dịch vụ lưu trữ; 'Verify' cho cloud_storage không đảm bảo API key đúng.")
            ok = resp.status_code < 500
            await db.aupsert_integration(name, row["service_type"], row["endpoint_url"],
                                         row["api_key_enc"], row["extra"], ok, utc_now())
            return {"ok": ok, "http_status": resp.status_code, "note": note}
        except httpx.HTTPError as exc:
            await db.aupsert_integration(name, row["service_type"], row["endpoint_url"],
                                         row["api_key_enc"], row["extra"], False, utc_now())
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    @router.delete("/integrations/{name}")
    async def delete_integration(name: str) -> dict[str, Any]:
        await db.adelete_integration(name)
        return {"deleted": name}

    # ------------------------------------------------------------ 4.4 Visual Gateway Manager
    @router.get("/gateways")
    async def get_gateways() -> dict[str, Any]:
        text = paths.gateways.read_text(encoding="utf-8") if paths.gateways.is_file() else ""
        entries = load_gateways(paths.gateways)
        return {"raw_text": text, "parsed": [{"region": e.region, "masked": e.masked,
                "browser_compatible": e.browser_compatible} for e in entries]}

    @router.post("/gateways/import")
    async def import_gateways(body: GatewayImportIn) -> dict[str, Any]:
        existing = paths.gateways.read_text(encoding="utf-8") if paths.gateways.is_file() else ""
        new_text = (existing.rstrip("\n") + "\n" + body.text) if body.mode == "append" else body.text
        paths.gateways.parent.mkdir(parents=True, exist_ok=True)
        paths.gateways.write_text(new_text.strip() + "\n", encoding="utf-8")
        entries = load_gateways(paths.gateways)
        total_lines = len([ln for ln in body.text.splitlines() if ln.strip() and not ln.strip().startswith("#")])
        return {"parsed_count": len(entries), "input_lines": total_lines,
                "rejected": max(0, total_lines - len(entries)) if body.mode == "replace" else None}

    @router.post("/gateways/check")
    async def check_gateways() -> dict[str, Any]:
        """Chạy kiểm định hàng loạt nền (không chặn request này); tiến trình phát qua
        EventBus - dashboard đang mở sẽ thấy cập nhật realtime qua /events (sự kiện
        kind="gateway_check_progress"), đúng cơ chế SSE đã dùng cho nhật ký/kết quả chạy."""
        entries = load_gateways(paths.gateways)
        if not entries:
            raise HTTPException(400, "Không có gateway nào trong gateways.txt")
        job_id = utc_now()
        asyncio.create_task(_run_gateway_check(entries, job_id))
        return {"job_id": job_id, "total": len(entries), "status": "started"}

    async def _run_gateway_check(entries: list[Any], job_id: str) -> None:
        from gateway_validator import GatewayCheckConfig, GatewayValidator

        gv_settings = dict(load_config(paths).settings.gateway_validator)
        # Phase 11.2: toggle điều khiển qua Web UI (lưu trong system_settings DB) ghi
        # đè lên giá trị tĩnh trong scenarios.json, để bật/tắt ngay không cần sửa file.
        gv_settings["datacenter_only_filter"] = await db.aget_setting("gateway_datacenter_filter_enabled", False)
        gv_settings["header_check_enabled"] = await db.aget_setting("gateway_header_check_enabled", False)
        max_lat = await db.aget_setting("gateway_max_latency_ms", 0)
        gv_settings["max_latency_ms"] = float(max_lat) if max_lat else None
        cfg = GatewayCheckConfig(**{k: v for k, v in gv_settings.items()
                                    if k in GatewayCheckConfig.__dataclass_fields__})
        validator = GatewayValidator(cfg)
        total, done = len(entries), 0
        bus.publish("gateway_check_progress", job_id=job_id, done=0, total=total, result=None)
        sem = asyncio.Semaphore(cfg.concurrency)

        async def bound(entry: Any) -> None:
            nonlocal done
            async with sem:
                result = await validator.check_one(entry)
            done += 1
            await db.ainsert_gateway_check(**result.to_db_row(utc_now()))
            bus.publish("gateway_check_progress", job_id=job_id, done=done, total=total,
                       result={"gateway": result.gateway, "healthy": result.healthy,
                               "latency_ms": result.latency_ms, "country_code": result.country_code,
                               "timezone_id": result.timezone_id})

        await asyncio.gather(*(bound(e) for e in entries))
        bus.publish("gateway_check_progress", job_id=job_id, done=total, total=total, result=None, finished=True)

    @router.get("/gateways/checks")
    async def get_gateway_checks() -> dict[str, Any]:
        return {"checks": await db.alatest_gateway_checks()}

    # ── Phase 3: Capabilities API ─────────────────────────────────────────
    @router.get("/capabilities")
    async def get_capabilities() -> dict[str, Any]:
        """Phát hiện và trả về khả năng môi trường chạy hiện tại."""
        import importlib.util, shutil, subprocess, sqlite3
        result: dict[str, Any] = {}

        # curl_cffi
        spec = importlib.util.find_spec("curl_cffi")
        result["curl_cffi"] = spec is not None
        if spec:
            try:
                import curl_cffi  # type: ignore[import-not-found]
                result["curl_cffi_version"] = getattr(curl_cffi, "__version__", "?")
            except Exception:
                result["curl_cffi_version"] = "?"

        # Node.js
        node = shutil.which("node")
        result["nodejs"] = node is not None
        if node:
            try:
                v = subprocess.check_output(["node", "--version"], text=True, timeout=3).strip()
                result["nodejs_version"] = v
            except Exception:
                result["nodejs_version"] = "?"

        # PyMiniRacer
        result["miniracer"] = importlib.util.find_spec("py_mini_racer") is not None

        # httpx
        result["httpx"] = importlib.util.find_spec("httpx") is not None
        if result["httpx"]:
            try:
                import httpx
                result["httpx_version"] = httpx.__version__
            except Exception:
                result["httpx_version"] = "?"

        # SQLite
        result["sqlite"] = True
        result["sqlite_version"] = sqlite3.sqlite_version

        # Playwright + installed browsers (dùng subprocess để tránh blocking async loop)
        try:
            import asyncio, subprocess as _sp, sys as _sys
            # Kiểm tra playwright có import được không
            pw_spec = importlib.util.find_spec("playwright")
            result["playwright"] = pw_spec is not None
            if pw_spec:
                try:
                    import playwright
                    result["playwright_version"] = getattr(playwright, "__version__", "?")
                except Exception:
                    result["playwright_version"] = "?"
                # Dùng `playwright install --dry-run` để lấy danh sách browser đã cài
                # Cách nhanh hơn: check path các binary browser của Playwright
                try:
                    proc = await asyncio.create_subprocess_exec(
                        _sys.executable, "-m", "playwright", "install", "--dry-run",
                        stdout=_sp.PIPE, stderr=_sp.PIPE
                    )
                    stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
                    output = (stdout + stderr).decode(errors="replace")
                except Exception:
                    output = ""
                # Fallback: kiểm tra browser executable paths trực tiếp
                from pathlib import Path as _Path
                import os as _os
                pw_home = _Path(_os.environ.get("PLAYWRIGHT_BROWSERS_PATH",
                               _Path.home() / ".cache" / "ms-playwright"))
                for bname in ("chromium", "firefox", "webkit"):
                    # Tìm binary trong pw_home
                    found = False
                    if pw_home.exists():
                        for entry in pw_home.iterdir():
                            if bname in entry.name.lower() and entry.is_dir():
                                # Tìm binary bên trong
                                for ext in ("", ".exe"):
                                    for binname in (bname, "chrome", "firefox-bin", "minibrowser"):
                                        candidate = list(entry.rglob(binname + ext))
                                        if candidate:
                                            found = True
                                            break
                                    if found:
                                        break
                            if found:
                                break
                    result[bname] = found
                    if found:
                        result[f"{bname}_version"] = "installed"
        except Exception as exc:
            result["playwright_error"] = str(exc)[:100]
            for bname in ("chromium", "firefox", "webkit"):
                result.setdefault(bname, False)

        # PyWebView (1-Click Desktop Native Window)
        try:
            import webview as _wv  # noqa: F401
            result["pywebview"] = True
            result["pywebview_version"] = getattr(_wv, "__version__", "installed")
        except ImportError:
            result["pywebview"] = False

        # pystray (System Tray icon)
        try:
            import pystray as _pt  # noqa: F401
            result["pystray"] = True
        except (ImportError, Exception):
            result["pystray"] = False

        # aiofiles
        result["aiofiles"] = importlib.util.find_spec("aiofiles") is not None

        # Bundled static assets (Drawflow, Alpine.js)
        from pathlib import Path
        _static = Path(__file__).parent / "static_assets"
        result["static_assets_bundled"] = _static.exists()
        result["drawflow_bundled"] = (_static / "drawflow.min.js").exists()
        result["alpinejs_bundled"] = (_static / "alpine.min.js").exists()

        # Expose as grouped modules dict for dashboard JS
        result["modules"] = {
            "curl_cffi": result.get("curl_cffi", False),
            "httpx": result.get("httpx", False),
            "playwright": not result.get("playwright_error"),
            "chromium": result.get("chromium", False),
            "firefox": result.get("firefox", False),
            "webkit": result.get("webkit", False),
            "pywebview": result.get("pywebview", False),
            "pystray": result.get("pystray", False),
            "aiofiles": result.get("aiofiles", False),
            "nodejs": result.get("nodejs", False),
            "sqlite": True,
        }

        return result

    @router.get("/capabilities/curl-test")
    async def test_curl_cffi() -> dict[str, Any]:
        """Thực hiện request thật bằng curl_cffi để xác nhận hoạt động."""
        try:
            from curl_cffi.requests import AsyncSession  # type: ignore[import-not-found]
            import time
            t0 = time.perf_counter()
            async with AsyncSession() as s:
                resp = await s.get("https://pypi.org/pypi/pip/json",
                                   impersonate="chrome", timeout=10)
            elapsed = round((time.perf_counter() - t0) * 1000, 1)
            data = resp.json()
            return {
                "ok": True,
                "status": resp.status_code,
                "elapsed_ms": elapsed,
                "impersonate": "chrome",
                "target": "pypi.org",
                "pip_version": data.get("info", {}).get("version", "?"),
                "headers_sent": {k: v for k, v in resp.request.headers.items()
                                 if k.lower() in ("user-agent", "accept", "accept-language")},
            }
        except ImportError:
            return {"ok": False, "error": "curl_cffi chưa được cài"}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:300]}

    @router.post("/capabilities/js-run")
    async def run_js_probe(body: JsRunIn) -> dict[str, Any]:
        """Thực thi JS script qua js_sandbox_probe và trả về kết quả.

        Nếu script là biểu thức đơn giản (không chứa 'console.' hay ';'),
        tự động wrap thành console.log(...) để luôn trả về output.
        """
        from js_sandbox_probe import execute_js
        import time
        t0 = time.perf_counter()

        script = body.script.strip()
        # Auto-wrap biểu thức đơn thuần (không có statement) với console.log
        # để user không cần viết console.log thủ công khi test nhanh
        is_bare_expression = (
            "console." not in script
            and "process." not in script
            and "\n" not in script
            and not script.startswith("(function")
            and not script.startswith("function")
            and not script.startswith("var ")
            and not script.startswith("let ")
            and not script.startswith("const ")
        )
        if is_bare_expression:
            script = f"console.log(JSON.stringify(({script})))"

        try:
            output = await execute_js(script, timeout_s=15.0)
            return {
                "ok": True,
                "output": output[:2000],
                "script_wrapped": is_bare_expression,
                "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
            }
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc)[:500],
                "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
            }

    # -------------------------------------------------------------------
    # Network-dependent capability endpoints (network is now open)
    # -------------------------------------------------------------------

    @router.get("/capabilities/network-check")
    async def network_check() -> dict[str, Any]:
        """Kiểm tra kết nối mạng thực tế tới các host quan trọng.
        Dùng httpx (không phụ thuộc curl_cffi) để xác nhận DNS + TCP + HTTP.
        """
        import time
        targets = [
            ("pypi.org",        "https://pypi.org/pypi/pip/json"),
            ("npmjs.org",       "https://registry.npmjs.org/lodash/latest"),
            ("github.com",      "https://github.com"),
        ]
        results = []
        try:
            import httpx
            async with httpx.AsyncClient(timeout=8, follow_redirects=True) as c:
                for name, url in targets:
                    t0 = time.perf_counter()
                    try:
                        r = await c.get(url)
                        elapsed = round((time.perf_counter() - t0) * 1000, 1)
                        results.append({
                            "host": name,
                            "url": url,
                            "ok": True,
                            "status": r.status_code,
                            "elapsed_ms": elapsed,
                            "bytes": len(r.content),
                        })
                    except Exception as exc:
                        elapsed = round((time.perf_counter() - t0) * 1000, 1)
                        results.append({
                            "host": name,
                            "url": url,
                            "ok": False,
                            "error": str(exc)[:120],
                            "elapsed_ms": elapsed,
                        })
        except ImportError:
            return {"ok": False, "error": "httpx chưa cài", "results": []}

        ok_count = sum(1 for r in results if r.get("ok"))
        return {
            "ok": ok_count > 0,
            "reachable": ok_count,
            "total": len(results),
            "results": results,
        }

    @router.get("/capabilities/browser-live")
    async def browser_live_test() -> dict[str, Any]:
        """Chạy Playwright Chromium thật, truy cập pypi.org, đo thời gian tải."""
        import time
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            return {"ok": False, "error": "playwright chưa cài"}

        t0 = time.perf_counter()
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(
                    headless=True,
                    args=["--no-sandbox", "--disable-setuid-sandbox",
                          "--disable-dev-shm-usage"],
                )
                page = await browser.new_page()
                nav_t0 = time.perf_counter()
                resp = await page.goto("https://pypi.org/pypi/pip/json",
                                       wait_until="domcontentloaded", timeout=20000)
                nav_elapsed = round((time.perf_counter() - nav_t0) * 1000, 1)
                status = resp.status if resp else 0
                content_len = len(await page.content())
                title = await page.title()
                await browser.close()
            total_elapsed = round((time.perf_counter() - t0) * 1000, 1)
            return {
                "ok": True,
                "url": "https://pypi.org/pypi/pip/json",
                "http_status": status,
                "nav_elapsed_ms": nav_elapsed,
                "total_elapsed_ms": total_elapsed,
                "page_bytes": content_len,
                "page_title": title[:80],
                "browser": "chromium",
                "headless": True,
            }
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc)[:400],
                "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
            }

    @router.get("/capabilities/tls-fingerprint")
    async def tls_fingerprint_test() -> dict[str, Any]:
        """So sánh TLS fingerprint curl_cffi (Chrome) vs httpx (Python default)."""
        import time
        results: dict[str, Any] = {}

        # Test 1: httpx (Python TLS stack)
        try:
            import httpx
            t0 = time.perf_counter()
            async with httpx.AsyncClient(timeout=8) as c:
                r = await c.get("https://registry.npmjs.org/lodash/latest")
                results["httpx"] = {
                    "ok": True,
                    "status": r.status_code,
                    "elapsed_ms": round((time.perf_counter() - t0)*1000, 1),
                    "tls_library": "python ssl (OpenSSL)",
                    "note": "JA3: Python TLS fingerprint — dễ bị Cloudflare phát hiện",
                }
        except Exception as exc:
            results["httpx"] = {"ok": False, "error": str(exc)[:150]}

        # Test 2: curl_cffi (Chrome TLS fingerprint)
        try:
            from curl_cffi.requests import AsyncSession  # type: ignore[import-not-found]
            t0 = time.perf_counter()
            async with AsyncSession() as s:
                r = await s.get("https://registry.npmjs.org/lodash/latest",
                                impersonate="chrome", timeout=8)
                results["curl_cffi"] = {
                    "ok": True,
                    "status": r.status_code,
                    "elapsed_ms": round((time.perf_counter() - t0)*1000, 1),
                    "impersonate": "chrome",
                    "tls_library": "curl_cffi (libcurl + BoringSSL)",
                    "note": "JA3: Chrome TLS fingerprint — Cloudflare/Akamai không phân biệt được",
                }
        except ImportError:
            results["curl_cffi"] = {"ok": False, "error": "curl_cffi chưa cài"}
        except Exception as exc:
            results["curl_cffi"] = {"ok": False, "error": str(exc)[:150]}

        return {
            "ok": any(v.get("ok") for v in results.values()),
            "tests": results,
            "conclusion": (
                "curl_cffi hoạt động, TLS fingerprint cải tiến kích hoạt"
                if results.get("curl_cffi", {}).get("ok")
                else "curl_cffi lỗi — Engine 1 fallback về httpx"
            ),
        }

    @router.get("/capabilities/ua-refresh")
    async def refresh_user_agents() -> dict[str, Any]:
        """Tải danh sách User-Agent mới nhất từ nguồn công khai (npmjs)."""
        import time
        t0 = time.perf_counter()
        try:
            import httpx
            ua_list: list[str] = []
            # Lấy từ whatismybrowser thông qua npmjs meta
            async with httpx.AsyncClient(timeout=10, follow_redirects=True) as c:
                # Source 1: npm package whatsmyua (nếu có)
                try:
                    r = await c.get("https://registry.npmjs.org/user-agents/latest")
                    meta = r.json()
                    version = meta.get("version", "?")
                    dist_url = meta.get("dist", {}).get("tarball", "")
                    ua_list.append(f"user-agents@{version}")
                except Exception:
                    pass
                # Source 2: Chrome UA strings từ npm meta
                try:
                    r = await c.get("https://registry.npmjs.org/chromium-bidi/latest")
                    meta = r.json()
                    # Lấy version Chromium đang dùng bởi Playwright
                    chrom_ver = meta.get("version", "?")
                    ua_list.append(f"chromium-bidi@{chrom_ver}")
                except Exception:
                    pass

            # Cập nhật UARegistry trong tray_daemon
            try:
                from tray_daemon import UARegistry
                from pathlib import Path as _Path
                reg = UARegistry(_Path("data/ua_cache.json"))
                newly_added = await reg.refresh()
                ua_list_live = reg.list()
                return {
                    "ok": True,
                    "source": "real_network",
                    "ua_count": len(ua_list_live),    # total pool size
                    "newly_added": newly_added,         # delta this refresh
                    "count": len(ua_list_live),         # alias for dashboard JS
                    "cached": newly_added == 0,         # True nếu không có UA mới
                    "sample": ua_list_live[:3],
                    "npm_packages": ua_list,
                    "elapsed_ms": round((time.perf_counter() - t0)*1000, 1),
                }
            except Exception as exc:
                return {
                    "ok": True,
                    "source": "npm_meta_only",
                    "npm_packages": ua_list,
                    "note": str(exc)[:100],
                    "elapsed_ms": round((time.perf_counter() - t0)*1000, 1),
                }
        except Exception as exc:
            return {
                "ok": False,
                "error": str(exc)[:300],
                "elapsed_ms": round((time.perf_counter() - t0)*1000, 1),
            }

    @router.get("/capabilities/playwright-install")
    async def playwright_install_check() -> dict[str, Any]:
        """Kiểm tra trạng thái cài đặt Playwright browsers và hướng dẫn cài thêm."""
        import shutil
        import subprocess
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            return {"ok": False, "error": "playwright chưa cài: pip install playwright"}

        browsers_status: dict[str, Any] = {}
        async with async_playwright() as pw:
            for name in ("chromium", "firefox", "webkit"):
                try:
                    browser = await getattr(pw, name).launch(
                        headless=True,
                        args=["--no-sandbox", "--disable-dev-shm-usage"],
                        timeout=5000,
                    )
                    ver = browser.version
                    await browser.close()
                    browsers_status[name] = {"installed": True, "version": ver}
                except Exception as exc:
                    err_str = str(exc)
                    need_install = "Executable doesn't exist" in err_str or "not found" in err_str.lower()
                    browsers_status[name] = {
                        "installed": False,
                        "need_install": need_install,
                        "install_cmd": f"python -m playwright install {name}" if need_install else None,
                        "error": err_str[:120] if not need_install else None,
                    }

        installed = [n for n, s in browsers_status.items() if s.get("installed")]
        return {
            "ok": len(installed) > 0,
            "installed": installed,
            "missing": [n for n, s in browsers_status.items() if not s.get("installed")],
            "browsers": browsers_status,
            "note": "Chạy 'python main.py install-browsers' để cài tất cả browsers",
        }

    # ------------------------------------------------------------------
    # Phase 10.1: Zero-Cost Custom Engine Build Pipeline (tải từ GitHub Release)
    # ------------------------------------------------------------------

    @router.get("/engine/custom-build/status")
    async def custom_engine_status() -> dict[str, Any]:
        """Liệt kê các nhân trình duyệt tùy chỉnh đã tải về `runtime/browsers/`."""
        browsers_dir = paths.base / "runtime" / "browsers"
        items: list[dict[str, Any]] = []
        if browsers_dir.is_dir():
            for entry in sorted(browsers_dir.iterdir()):
                if entry.is_dir() or entry.suffix in (".zip", ".tar.gz", ".tgz"):
                    items.append({
                        "name": entry.name,
                        "size_mb": round(sum(f.stat().st_size for f in entry.rglob("*")
                                             if f.is_file()) / 1_048_576, 1) if entry.is_dir()
                                   else round(entry.stat().st_size / 1_048_576, 1),
                        "is_dir": entry.is_dir(),
                    })
        return {"browsers_dir": str(browsers_dir), "items": items}

    @router.post("/engine/custom-build/download")
    async def custom_engine_download(body: CustomEngineDownloadIn) -> dict[str, Any]:
        """Tải bản phát hành (Release) mới nhất của nhân trình duyệt mã nguồn mở
        (mặc định: Camoufox - bản Firefox vá sẵn chống dò dấu vân tay) từ GitHub
        Releases API, giải nén vào `runtime/browsers/`.

        Mục 2.1 (Phase 10) + Mục 2.4 (Phase 11): CHÍNH LÀ backend của cả 2 nút
        "Tải/Cập nhật Nhân Trình Duyệt Từ GitHub Release" (Phase 10) và "Tải
        Nhân Trình Duyệt Tối Ưu (Linux/Windows)" (Phase 11) - logic tải/giải
        nén/dò executable dùng chung qua module `engine_updater.py`.
        """
        from engine_updater import download_and_install

        browsers_dir = paths.base / "runtime" / "browsers"
        result = await download_and_install(
            repo=body.repo, runtime_browsers_dir=browsers_dir,
            tag=body.tag, asset_marker=body.asset_pattern.strip() or None,
        )
        if result["ok"] and result.get("executable_path"):
            await db.aset_setting("browser_executable_path", result["executable_path"], utc_now())
            result["executable_saved_to_settings"] = True
        else:
            result["executable_saved_to_settings"] = False
        return result

    # ------------------------------------------------------------------
    # Phase 10.2: Runtime Protocol Rotation - endpoint test rotate_protocol_profile()
    # ------------------------------------------------------------------

    @router.get("/protocol/rotate")
    async def protocol_rotate_test(browser: str = "chrome", os_name: str = "Windows",
                                   locale: str = "") -> dict[str, Any]:
        """Test nhanh `rotate_protocol_profile()` - trả về bộ ba tín hiệu đồng bộ
        (impersonate, http2_settings, headers, tcp_profile) cho browser đã chọn."""
        from engine_router import rotate_protocol_profile
        profile = rotate_protocol_profile(browser, os_name, locale=locale or None)
        return profile.to_dict()

    # ------------------------------------------------------------------
    # Phase 10.3: Hybrid Browser-to-HTTP Handoff - endpoint test trực tiếp
    # ------------------------------------------------------------------

    @router.post("/capabilities/hybrid-handoff-test")
    async def hybrid_handoff_test(body: HybridHandoffTestIn) -> dict[str, Any]:
        """Chạy thử `hybrid_browser_to_http_handoff()` với URL do người dùng cung cấp -
        mở trình duyệt ẩn, chờ JS challenge, đóng trình duyệt, chuyển cookie sang
        curl_cffi cho các follow_up_urls. Xem mục 2.3 đặc tả Phase 10."""
        try:
            from playwright.async_api import async_playwright
            from engine_router import hybrid_browser_to_http_handoff
        except ImportError as exc:
            raise HTTPException(500, f"Thiếu dependency: {exc}")
        async with async_playwright() as pw:
            result = await hybrid_browser_to_http_handoff(
                browser_type=pw.chromium,
                priming_url=body.priming_url,
                follow_up_urls=body.follow_up_urls[:10],
                priming_wait_s=min(max(body.priming_wait_s, 1.0), 15.0),
            )
        return result

    # ------------------------------------------------------------------
    # Phase 10.4: JS Sandbox Probes - liệt kê + chạy file từ plugins/js_probes/
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Phase 11.1: Virtual Display (Xvfb) + Font Provisioner
    # ------------------------------------------------------------------

    @router.get("/display/xvfb/status")
    async def xvfb_status() -> dict[str, Any]:
        """Trạng thái Xvfb của Engine đang chạy - đọc lại từ `Engine.status()`
        (đã có sẵn trường "xvfb" từ Phase 11.1), tránh phải thread thêm một
        tham chiếu Engine riêng xuống admin_api.py (vốn chỉ nhận db/paths/bus)."""
        # Router này chỉ nhận db/paths/bus (không có tham chiếu Engine trực tiếp) -
        # trả về trạng thái PLATFORM + setting đã lưu; trạng thái "running" thời
        # gian thực xem tại GET /api/status (trường "xvfb", xem Engine.status()).
        from linux_display_manager import is_linux
        return {
            "platform_supported": is_linux(),
            "note": "Xem GET /api/status (trường 'xvfb') để biết trạng thái Xvfb thời gian thực.",
            "enabled_setting": await db.aget_setting("virtual_display_enabled", False),
        }

    @router.post("/display/xvfb/settings")
    async def xvfb_settings(body: VirtualDisplayIn) -> dict[str, Any]:
        """Lưu công tắc Virtual Display Mode - áp dụng ở lần `Engine.start()`
        TIẾP THEO (khởi động lại ứng dụng), không bật/tắt Xvfb đang chạy ngay lập tức."""
        now = utc_now()
        await db.aset_setting("virtual_display_enabled", body.enabled, now)
        await db.aset_setting("virtual_display_width", body.width, now)
        await db.aset_setting("virtual_display_height", body.height, now)
        return {"saved": True, "note": "Áp dụng từ lần khởi động Engine tiếp theo."}

    @router.post("/display/fonts/provision")
    async def fonts_provision(force: bool = False) -> dict[str, Any]:
        """Nút "Chuẩn hóa Phông chữ Đa nền tảng" - tải Noto Sans + Liberation Sans
        vào thư mục cục bộ của ứng dụng (không đụng fontconfig hệ thống)."""
        from linux_display_manager import provision_cross_platform_fonts
        return await provision_cross_platform_fonts(paths.base / "data", force=force)

    # ------------------------------------------------------------------
    # Phase 11.2: Công tắc lọc chất lượng gateway (Datacenter filter / Header check / Max latency)
    # ------------------------------------------------------------------

    @router.get("/gateways/quality-settings")
    async def get_gateway_quality_settings() -> dict[str, Any]:
        return {
            "datacenter_filter_enabled": await db.aget_setting("gateway_datacenter_filter_enabled", False),
            "header_check_enabled": await db.aget_setting("gateway_header_check_enabled", False),
            "max_latency_ms": await db.aget_setting("gateway_max_latency_ms", 0),
        }

    @router.post("/gateways/quality-settings")
    async def save_gateway_quality_settings(body: GatewayQualitySettingsIn) -> dict[str, Any]:
        now = utc_now()
        if body.datacenter_filter_enabled is not None:
            await db.aset_setting("gateway_datacenter_filter_enabled", body.datacenter_filter_enabled, now)
        if body.header_check_enabled is not None:
            await db.aset_setting("gateway_header_check_enabled", body.header_check_enabled, now)
        if body.max_latency_ms is not None:
            await db.aset_setting("gateway_max_latency_ms", body.max_latency_ms, now)
        return {"saved": True}

    # ------------------------------------------------------------------
    # Phase 12 — Flow Studio: Recorder, Blueprint Templates, NL-to-Flow
    # ------------------------------------------------------------------

    @router.post("/flow/recorder/start")
    async def flow_recorder_start(body: dict = Body(...)) -> dict[str, Any]:
        from trace_replayer import start_recording_session

        # Recorder cần headless=False (người dùng phải THẤY và thao tác trực
        # tiếp) - trên Linux không màn hình, tự bật Xvfb tạm thời nếu chưa có
        # DISPLAY nào (đồng bộ với Phase 11.1 - không cần người dùng tự bật tay).
        from linux_display_manager import XvfbManager, is_linux
        if is_linux() and not os.environ.get("DISPLAY"):
            mgr = getattr(flow_recorder_start, "_temp_xvfb", None) or XvfbManager()
            try:
                await mgr.start(width=1280, height=720)
                flow_recorder_start._temp_xvfb = mgr
            except Exception as exc:  # noqa: BLE001
                return {"ok": False, "error": f"Không có DISPLAY và không tự bật được Xvfb: {exc}. "
                                              f"Cài 'apt-get install xvfb' hoặc bật thủ công ở tab Công cụ."}

        result = await start_recording_session(body.get("url", ""), headless=False)
        if not result.get("ok") and "Target" in str(result.get("error", "")):
            result["hint"] = ("Lỗi mở trình duyệt có giao diện - kiểm tra máy chủ có "
                              "DISPLAY/Xvfb hoạt động không (xem tab Công cụ → Virtual Display).")
        return result

    @router.get("/flow/recorder/status")
    async def flow_recorder_status() -> dict[str, Any]:
        from trace_replayer import get_recording_status
        return await get_recording_status()

    @router.post("/flow/recorder/stop")
    async def flow_recorder_stop() -> dict[str, Any]:
        from trace_replayer import stop_recording_session
        return await stop_recording_session()

    @router.get("/flow/templates")
    async def flow_templates_list() -> dict[str, Any]:
        """Mục 3.1.A.1 - Kho Mẫu Dựng Sẵn (1-Click Blueprints). Đọc
        `config/templates/*.json` - mỗi tệp là {"name","description","steps"}."""
        tdir = paths.base / "config" / "templates"
        templates = []
        if tdir.is_dir():
            for f in sorted(tdir.glob("*.json")):
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    templates.append({"id": f.stem, "name": data.get("name", f.stem),
                                      "description": data.get("description", ""),
                                      "steps": data.get("steps", [])})
                except Exception as exc:  # noqa: BLE001
                    LOGGER.warning("flow_templates: lỗi đọc %s: %s", f, exc)
        return {"templates": templates}

    @router.post("/flow/nl-to-flow")
    async def flow_nl_to_flow(body: NlToFlowIn) -> dict[str, Any]:
        """Mục 3.1.A.3 - Trợ Lý AI Vẽ Sơ Đồ. Dùng CÙNG cơ chế gọi Ollama với
        `autopilot_rewriter.py` (cổng 11434 mặc định), nhưng sinh step MỚI từ
        MÔ TẢ (không mutate step có sẵn)."""
        import httpx

        prompt = f"""Bạn là bộ chuyển đổi mô tả kịch bản kiểm thử web sang JSON step.
Mô tả của người dùng: "{body.description}"

Chuyển mô tả trên thành một mảng JSON các step, MỖI step là một object có khoá
"action" và các tham số tương ứng. Các action hợp lệ: goto (url), wait
(duration_ms), click (selector), type (selector, text), scroll (delta_y),
prime_session (warmup_url, duration_s), referrer_goto (target_url,
referrer_type: "search"|"social"|"direct").

CHỈ trả về JSON thuần (một mảng), không giải thích, không markdown fence.
Ví dụ output: [{{"action":"goto","url":"https://example.com"}},{{"action":"wait","duration_ms":5000}}]
"""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(f"{body.ollama_url}/api/generate", json={
                    "model": "llama3.2", "prompt": prompt, "stream": False,
                })
                r.raise_for_status()
                raw_text = r.json().get("response", "").strip()
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"Ollama không khả dụng: {type(exc).__name__}: {exc}",
                    "note": "Cần chạy 'ollama serve' cục bộ với model llama3.2 đã pull."}

        # Dọn markdown fence nếu LLM lỡ bọc ```json...```
        cleaned = raw_text
        if "```" in cleaned:
            cleaned = cleaned.split("```")[1]
            cleaned = cleaned[4:] if cleaned.startswith("json") else cleaned
        try:
            steps = json.loads(cleaned.strip())
            if not isinstance(steps, list):
                raise ValueError("Kết quả không phải JSON array")
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"LLM trả về JSON không hợp lệ: {exc}",
                    "raw_response": raw_text[:500]}
        return {"ok": True, "steps": steps}

    # ------------------------------------------------------------------
    # Phase 12 — Command Center: Run Now, Live Worker Grid, Live Snapshot
    # ------------------------------------------------------------------
    # LƯU Ý KIẾN TRÚC QUAN TRỌNG: `create_admin_router` chỉ nhận db/paths/bus,
    # không nhận Engine trực tiếp. `main.py::build_app()` gán `bus.engine = engine`
    # ngay sau khi tạo Engine (Phase 12 fix) - router đọc qua `getattr(bus,
    # "engine", None)`. Nếu chạy ở chế độ không có Engine thật (vd. dashboard-only
    # debug), các endpoint dưới đây trả lỗi rõ ràng thay vì crash.

    def _get_engine() -> Any:
        eng = getattr(bus, "engine", None)
        if eng is None:
            raise HTTPException(503, "Engine chưa sẵn sàng (chế độ dashboard-only, "
                                     "không có vòng lặp thực thi scenario nào đang chạy).")
        return eng

    @router.post("/run-now")
    async def run_now(body: RunNowIn) -> dict[str, Any]:
        """Nút "▶ Chạy ngay" (Command Center) - phát hiện qua Phase 12: trước đây
        KHÔNG CÓ cách nào trong Dashboard để chủ động kích hoạt một lượt chạy
        (chỉ có CLI `main.py run`/`schedule`, hoặc chờ cron) - đặc biệt nghiêm
        trọng với desktop launcher (`app_launcher.py`), vốn trước Phase 12 còn
        chưa từng khởi tạo Engine nào (xem PROJECT.md Mục 8-quater)."""
        eng = _get_engine()
        from engine import Task, LocalQueue

        scenarios = (
            [eng.scenarios[sid] for sid in body.scenario_ids if sid in eng.scenarios]
            if body.scenario_ids else
            [sc for sc in eng.scenarios.values() if sc.active]
        )
        if not scenarios:
            raise HTTPException(404, "Không tìm thấy scenario nào khớp (hoặc không có scenario active).")

        queue = LocalQueue()
        n_tasks = 0
        for _ in range(max(1, body.iterations)):
            for sc in scenarios:
                for url in sc.urls:
                    await queue.put(Task(scenario_id=sc.id, url=url))
                    n_tasks += 1

        # Chạy NGẦM (fire-and-forget) - HTTP response trả về ngay, người dùng
        # theo dõi tiến độ qua Live Worker Grid / SSE /events, không block request.
        asyncio.create_task(eng.run_tasks(queue, drain=True))
        return {"ok": True, "scenarios": [sc.id for sc in scenarios], "tasks_queued": n_tasks}

    @router.get("/workers/live")
    async def workers_live() -> dict[str, Any]:
        """Live Browser Workers Grid - danh sách worker đang chạy thời gian thực."""
        eng = _get_engine()
        workers = []
        for w in eng._workers.values():
            workers.append({k: v for k, v in w.items() if k != "page"})  # không serialize Page object
        return {"workers": workers, "count": len(workers)}

    @router.get("/workers/{task_id}/snapshot")
    async def worker_snapshot(task_id: str) -> dict[str, Any]:
        """Live Snapshot Preview - chụp khung hình HIỆN TẠI của worker đang chạy
        (hoạt động cả khi engine chạy trên Xvfb ảo không màn hình vật lý)."""
        eng = _get_engine()
        w = eng._workers.get(task_id)
        if w is None:
            raise HTTPException(404, f"Không có worker đang chạy với task_id={task_id!r}")
        page = w.get("page")
        if page is None:
            return {"ok": False, "error": "Worker chưa có trang nào mở (có thể đang ở bước khởi tạo)."}
        try:
            png_bytes = await page.screenshot(type="png", timeout=5000)
            b64 = base64.b64encode(png_bytes).decode()
            return {"ok": True, "image_base64": b64, "mime": "image/png"}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": f"Chụp màn hình lỗi: {type(exc).__name__}: {exc}"}

    @router.post("/workers/{task_id}/stop")
    async def worker_stop(task_id: str) -> dict[str, Any]:
        """Dừng riêng MỘT worker mà không ảnh hưởng các worker khác - đóng
        trực tiếp Page/Context của worker đó (worker sẽ tự dọn dẹp ở finally
        của `_attempt_browser` khi context.close() khiến mọi thao tác tiếp
        theo trên page raise lỗi, thoát vòng lặp step sớm)."""
        eng = _get_engine()
        w = eng._workers.get(task_id)
        if w is None:
            raise HTTPException(404, f"Không có worker đang chạy với task_id={task_id!r}")
        page = w.get("page")
        if page is None:
            return {"ok": False, "error": "Worker chưa có trang nào mở để dừng."}
        try:
            await page.context.close()
            return {"ok": True, "note": "Đã đóng context - worker sẽ dừng ở bước tiếp theo."}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)[:300]}

    @router.get("/js-probes/list")
    async def js_probes_list() -> dict[str, Any]:
        from js_sandbox_probe import list_js_probe_files
        return {"files": list_js_probe_files()}

    @router.post("/js-probes/run")
    async def js_probes_run(body: JsProbeRunIn) -> dict[str, Any]:
        from js_sandbox_probe import run_js_probe_file
        return await run_js_probe_file(body.filename, persona=body.persona)

    # Tunnel API - dùng singleton TunnelManager gắn vào app state
    @router.get("/tunnels")
    async def list_tunnels() -> dict[str, Any]:
        tm = getattr(list_tunnels, "_tm", None)
        if tm is None:
            return {"tunnels": []}
        tunnels = []
        for info in tm.list_running():
            healthy = await tm.health_check(info.name)
            tunnels.append({
                "name": info.name, "proxy_url": info.proxy_url,
                "pid": info.pid, "age_s": round(info.age_s, 0),
                "config_path": info.config_path, "healthy": healthy,
            })
        return {"tunnels": tunnels}

    class TunnelStartIn(BaseModel):
        name: str
        binary: str = "xray"
        config_path: Optional[str] = None

    @router.post("/tunnels")
    async def start_tunnel(body: TunnelStartIn) -> dict[str, Any]:
        from tunnel_manager import TunnelManager
        if not hasattr(start_tunnel, "_tm"):
            start_tunnel._tm = TunnelManager(db)
            # Chia sẻ instance với list/delete
            list_tunnels._tm = start_tunnel._tm
            delete_tunnel._tm = start_tunnel._tm
            delete_all_tunnels._tm = start_tunnel._tm
        tm: "TunnelManager" = start_tunnel._tm
        proxy_url = await tm.start(body.name, config_path=body.config_path, binary=body.binary)
        return {"ok": True, "proxy_url": proxy_url, "name": body.name}

    @router.delete("/tunnels/{name}")
    async def delete_tunnel(name: str) -> dict[str, Any]:
        tm = getattr(delete_tunnel, "_tm", None)
        if tm:
            await tm.stop(name)
        return {"ok": True, "stopped": name}

    @router.delete("/tunnels")
    async def delete_all_tunnels() -> dict[str, Any]:
        tm = getattr(delete_all_tunnels, "_tm", None)
        if tm:
            await tm.stop_all()
        return {"ok": True}

    # ── Phase 6: Visual Picker ─────────────────────────────────────────────
    class PickerStartIn(BaseModel):
        url: str
        timeout_s: float = 90.0

    @router.post("/picker/start")
    async def picker_start(body: PickerStartIn) -> dict[str, Any]:
        from visual_picker import start_picker
        return await start_picker(body.url, body.timeout_s)

    @router.get("/picker/result")
    async def picker_result() -> dict[str, Any]:
        from visual_picker import get_picker_result
        return await get_picker_result() or {"status": "no_session"}

    @router.post("/picker/stop")
    async def picker_stop() -> dict[str, Any]:
        from visual_picker import stop_picker
        return await stop_picker()

    # ── Phase 6: Profile Warmth & Personas ────────────────────────────────
    @router.get("/profiles/warmth")
    async def get_profiles_warmth() -> dict[str, Any]:
        profiles = db.all_profile_warmth()
        return {"profiles": profiles}

    class PrimeIn(BaseModel):
        profile_id: str
        target_url: Optional[str] = None
        dwell_s: float = 7.0

    @router.post("/profiles/prime")
    async def prime_profile(body: PrimeIn) -> dict[str, Any]:
        from session_warmer import SessionWarmer
        from config_loader import get_base_dir
        profiles_root = paths.profiles
        warmer = SessionWarmer(profiles_root, db)
        result = await warmer.prime_session(
            body.profile_id,
            body.target_url or "https://www.google.com",
            dwell_s=body.dwell_s,
        )
        return {"ok": result.errors == 0, "result": result.__dict__}

    class WarmCampaignIn(BaseModel):
        profile_ids: list[str]
        days: int = 3
        urls_per_day: int = 5
        target_url: Optional[str] = None
        max_concurrency: int = 2

    @router.post("/profiles/warm")
    async def warm_profiles(body: WarmCampaignIn) -> dict[str, Any]:
        from session_warmer import SessionWarmer, WarmingConfig
        warmer = SessionWarmer(paths.profiles, db)
        cfg = WarmingConfig(
            profile_ids=body.profile_ids,
            days=body.days,
            urls_per_day=body.urls_per_day,
            target_url=body.target_url,
            max_concurrency=body.max_concurrency,
        )
        # Chạy nền để không block request
        import asyncio
        asyncio.create_task(warmer.run_campaign(cfg))
        return {"ok": True, "message": f"Warming {len(body.profile_ids)} profiles đã bắt đầu (nền)"}

    @router.get("/personas")
    async def get_personas() -> dict[str, Any]:
        from persona_manager import PersonaManager
        pm = PersonaManager()
        return {"personas": pm.list_personas()}

    # ── Phase 6: Schedule slots ────────────────────────────────────────────
    @router.get("/schedule/slots")
    async def get_schedule_slots() -> dict[str, Any]:
        """Trả về danh sách các slot lịch trình (day_of_week 1-7, hour 0-22)."""
        rows = db._read(
            "SELECT scenario_id, cron, active FROM schedules WHERE active=1 LIMIT 100"
        ) if hasattr(db, '_read') else []
        slots: list[dict[str, Any]] = []
        for r in rows:
            # Parse cron đơn giản: "0 10 * * 1" → thứ 2 lúc 10h
            cron = str(r.get("cron", ""))
            parts = cron.split()
            if len(parts) >= 5:
                try:
                    hour = int(parts[1]) if parts[1] != "*" else 0
                    dow = int(parts[4]) if parts[4] != "*" else 1
                    slots.append({"scenario_id": r["scenario_id"],
                                  "day_of_week": dow or 7, "hour": hour})
                except (ValueError, IndexError):
                    pass
        return {"slots": slots}

    # ── Phase 6: MCP status ────────────────────────────────────────────────
    @router.get("/mcp/status")
    async def get_mcp_status() -> dict[str, Any]:
        """Trạng thái Local MCP Server."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=2) as c:
                r = await c.get("http://localhost:3000/health")
                running = r.status_code == 200
                data = r.json() if running else {}
        except Exception:
            running = False
            data = {}
        return {
            "running": running,
            "tools": data.get("tools", []),
            "requests_today": data.get("requests_today"),
            "uptime_human": data.get("uptime_human", "–"),
        }

    # ── Phase 6: Healing log ───────────────────────────────────────────────
    @router.get("/healing/log")
    async def get_healing_log() -> dict[str, Any]:
        rows = db._read(
            """SELECT scenario_id, old_selector, new_selector, strategy,
               confidence, healed_at FROM healing_log ORDER BY healed_at DESC LIMIT 100"""
        ) if hasattr(db, '_read') else []
        return {"entries": [dict(r) for r in rows]}

    # ── Phase 7: Cloud Usage Dashboard ────────────────────────────────────
    @router.get("/cloud/usage")
    async def get_cloud_usage(hours: float = 24.0) -> dict[str, Any]:
        summary = await db.acloud_usage_summary(hours)
        # Thêm danh sách sessions gần nhất
        rows = db._read(
            """SELECT provider, started_at, duration_s, cost_usd, status, error
               FROM cloud_usage_logs ORDER BY started_at DESC LIMIT 50""")
        return {"summary": summary, "recent": [dict(r) for r in rows]}

    @router.get("/cloud/hybrid/status")
    async def get_hybrid_status() -> dict[str, Any]:
        return {"message": "Hybrid scheduler trạng thái xem trong engine runtime"}

    # ── Phase 7: Alerts ────────────────────────────────────────────────────
    @router.get("/alerts/history")
    async def get_alert_history() -> dict[str, Any]:
        rows = db._read(
            """SELECT channel, scenario_id, message, sent_at, status, error
               FROM alert_history ORDER BY sent_at DESC LIMIT 100""")
        return {"alerts": [dict(r) for r in rows]}

    class AlertTestIn(BaseModel):
        channel: str = "telegram"
        message: str = "🧪 Test alert từ QA Orchestrator"

    @router.post("/alerts/test")
    async def test_alert(body: AlertTestIn) -> dict[str, Any]:
        from diagnostics_alerter import AlertConfig, AlertDispatcher
        cfg = AlertConfig.from_env(body.channel)
        dispatcher = AlertDispatcher(db, [cfg])
        ok, err = await dispatcher._send(cfg, body.message)
        await db.alog_alert(channel=body.channel, message=body.message,
                             status="ok" if ok else "failed", error=err)
        return {"ok": ok, "error": err or None}

    @router.get("/alerts/failure-rates")
    async def get_failure_rates() -> dict[str, Any]:
        rows = db._read(
            """SELECT scenario_id, failure_type, COUNT(*) n, MAX(occurred_at) last
               FROM failure_events GROUP BY scenario_id, failure_type
               ORDER BY n DESC LIMIT 50""")
        return {"rates": [dict(r) for r in rows]}

    # ── Phase 7: Credential Vault ──────────────────────────────────────────
    class AccountIn(BaseModel):
        name: str
        username: str
        password: str
        email: str = ""
        profile_id: str = ""
        tags: list[str] = []
        notes: str = ""

    @router.get("/vault/accounts")
    async def list_vault_accounts() -> dict[str, Any]:
        from credential_vault import CredentialVault
        v = CredentialVault(db)
        return {"accounts": v.list_accounts()}

    @router.post("/vault/accounts")
    async def save_vault_account(body: AccountIn) -> dict[str, Any]:
        from credential_vault import CredentialVault, TestAccount
        v = CredentialVault(db)
        acc = TestAccount(**body.model_dump())
        await v.asave_account(acc)
        return {"ok": True, "name": body.name}

    @router.delete("/vault/accounts/{name}")
    async def delete_vault_account(name: str) -> dict[str, Any]:
        from credential_vault import CredentialVault
        v = CredentialVault(db)
        ok = v.delete_account(name)
        return {"ok": ok}

    class CookieImportIn(BaseModel):
        profile_id: str
        cookies_json: str  # raw JSON string từ EditThisCookie

    @router.post("/vault/cookies/import")
    async def import_vault_cookies(body: CookieImportIn) -> dict[str, Any]:
        from credential_vault import CredentialVault
        v = CredentialVault(db)
        n = v.import_cookies_json(body.profile_id, body.cookies_json)
        return {"ok": True, "imported": n}

    @router.get("/vault/cookies")
    async def list_vault_cookies() -> dict[str, Any]:
        from credential_vault import CredentialVault
        v = CredentialVault(db)
        return {"cookies": v.list_cookies()}

    @router.get("/vault/captcha")
    async def list_captcha_services() -> dict[str, Any]:
        from credential_vault import CredentialVault
        v = CredentialVault(db)
        return {"services": v.list_captcha_services()}

    class CaptchaKeyIn(BaseModel):
        name: str   # 2captcha | capsolver | anticaptcha
        api_key: str

    @router.post("/vault/captcha")
    async def save_captcha_key(body: CaptchaKeyIn) -> dict[str, Any]:
        from credential_vault import CredentialVault, CaptchaService
        v = CredentialVault(db)
        v.save_captcha_key(CaptchaService(name=body.name, api_key=body.api_key))
        return {"ok": True}

    # ── Phase 7: Referrer Chain ────────────────────────────────────────────
    class ReferrerPreviewIn(BaseModel):
        source: str = "google"
        target_url: str = "https://example.com"
        search_query: str = ""
        utm_source: str = ""
        utm_medium: str = ""
        utm_campaign: str = ""

    @router.post("/referrer/preview")
    async def preview_referrer(body: ReferrerPreviewIn) -> dict[str, Any]:
        from referrer_orchestrator import ReferrerConfig
        cfg = ReferrerConfig(
            source=body.source,
            search_query=body.search_query,
            utm_source=body.utm_source,
            utm_medium=body.utm_medium,
            utm_campaign=body.utm_campaign,
        )
        return {
            "final_url": cfg.build_target_url(body.target_url),
            "source": body.source,
            "step_json": {
                "action": "referrer_goto",
                "url": body.target_url,
                "referrer": {
                    "source": body.source,
                    "search_query": body.search_query,
                    "utm_source": body.utm_source,
                    "utm_medium": body.utm_medium,
                    "utm_campaign": body.utm_campaign,
                },
            },
        }

    @router.get("/referrer/traffic-config")
    async def get_traffic_config() -> dict[str, Any]:
        from referrer_orchestrator import TrafficConfig
        saved = await db.aget_setting("referrer_traffic_config", None)
        tc = TrafficConfig.from_dict(saved) if saved else TrafficConfig()
        return tc.to_dict()

    @router.post("/referrer/traffic-config")
    async def save_traffic_config(body: TrafficConfigIn) -> dict[str, Any]:
        """Phase 11.3 - Lưu Device Mix (Mobile/Desktop slider) + source_mix vào
        system_settings, để `/referrer/preview` và engine dùng ngay lần sau mà
        không cần sửa file cấu hình tĩnh."""
        from referrer_orchestrator import TrafficConfig
        existing = await db.aget_setting("referrer_traffic_config", None)
        tc = TrafficConfig.from_dict(existing) if existing else TrafficConfig()
        if body.device_mix is not None:
            total = sum(body.device_mix.values())
            if total <= 0:
                raise HTTPException(400, "device_mix phải có tổng > 0")
            tc.device_mix = {k: v / total for k, v in body.device_mix.items()}  # tự chuẩn hóa về tổng=1.0
        if body.source_mix is not None:
            tc.source_mix = body.source_mix
        await db.aset_setting("referrer_traffic_config", tc.to_dict(), utc_now())
        return tc.to_dict()

    # ── Phase 7: Remote DB sync ────────────────────────────────────────────
    @router.post("/remote-db/sync")
    async def trigger_remote_sync() -> dict[str, Any]:
        from remote_db_adapter import sync_to_remote
        result = await sync_to_remote(db_path=paths.db)
        return {"ok": True, "result": result}

    @router.get("/remote-db/status")
    async def get_remote_db_status() -> dict[str, Any]:
        mongo = bool(os.environ.get("MONGODB_URI"))
        supa = bool(os.environ.get("SUPABASE_URL") and os.environ.get("SUPABASE_KEY"))
        try:
            rows = db._read("SELECT table_name, last_synced_at FROM sync_state ORDER BY last_synced_at DESC")
        except Exception:
            rows = []
        return {"mongodb_configured": mongo, "supabase_configured": supa,
                "last_syncs": [dict(r) for r in rows]}

    # ── Phase 8: Resource Governor ─────────────────────────────────────────
    @router.get("/system/metrics")
    async def get_system_metrics() -> dict[str, Any]:
        try:
            import psutil
            vm = psutil.virtual_memory()
            cpu = psutil.cpu_percent(interval=0.5)
            disk = psutil.disk_usage("/")
            return {
                "cpu_pct": round(cpu, 1),
                "ram_pct": round(vm.percent, 1),
                "ram_available_mb": round(vm.available / 1_048_576),
                "ram_total_mb": round(vm.total / 1_048_576),
                "disk_free_gb": round(disk.free / 1_073_741_824, 1),
                "disk_pct": round(disk.percent, 1),
            }
        except ImportError:
            return {"error": "psutil chưa cài — pip install psutil"}
        except Exception as exc:
            return {"error": str(exc)}

    @router.get("/system/metrics/history")
    async def get_metrics_history() -> dict[str, Any]:
        # Trả về history nếu governor đang chạy
        gov = getattr(get_metrics_history, "_governor", None)
        if gov:
            return {"history": gov.metrics_history(30)}
        # Fallback: đo tức thì
        snap = await get_system_metrics()
        return {"history": [snap]}

    # ── Phase 8: UA Registry ───────────────────────────────────────────────
    @router.get("/ua/list")
    async def list_uas(os_filter: str = "", browser_filter: str = "") -> dict[str, Any]:
        from tray_daemon import UARegistry
        reg = UARegistry(cache_path=paths.base / "data" / "ua_cache.json")
        uas = reg.get_all(
            os_filter=os_filter or None,
            browser_filter=browser_filter or None,
        )
        return {"uas": uas, "summary": reg.to_summary()}

    @router.post("/ua/refresh")
    async def refresh_uas() -> dict[str, Any]:
        from tray_daemon import UARegistry
        reg = UARegistry(cache_path=paths.base / "data" / "ua_cache.json")
        added = await reg.refresh()
        return {"ok": True, "added": added, "summary": reg.to_summary()}

    # ── Phase 8: Proxy Parser ──────────────────────────────────────────────
    class ProxyParseIn(BaseModel):
        raw_text: str
        default_protocol: str = "http"
        output_format: str = "url"   # url | ip:port | ip:port:user:pass

    @router.post("/proxy/parse")
    async def parse_proxies(body: ProxyParseIn) -> dict[str, Any]:
        from tray_daemon import ProxyParser
        parser = ProxyParser()
        proxies = parser.parse(body.raw_text, body.default_protocol)
        return {
            "proxies": [p.to_dict() for p in proxies],
            "output_text": parser.to_text(proxies, body.output_format),
            "stats": parser.stats(proxies),
        }

    # ── Phase 8: AutoStart ─────────────────────────────────────────────────
    @router.get("/system/autostart")
    async def get_autostart_status() -> dict[str, Any]:
        from tray_daemon import AutoStartManager
        mgr = AutoStartManager()
        return {"enabled": mgr.is_enabled(), "platform": __import__("platform").system()}

    class AutoStartIn(BaseModel):
        enabled: bool

    @router.post("/system/autostart")
    async def set_autostart(body: AutoStartIn) -> dict[str, Any]:
        from tray_daemon import AutoStartManager
        mgr = AutoStartManager()
        ok = mgr.enable() if body.enabled else mgr.disable()
        return {"ok": ok, "enabled": body.enabled}

    # ── Phase 8: Hybrid Handoff status (info only) ─────────────────────────
    @router.get("/hybrid/info")
    async def get_hybrid_info() -> dict[str, Any]:
        return {
            "description": "Browser-to-HTTP Cookie Handoff",
            "usage": {
                "step_json": {
                    "action": "hybrid_handoff",
                    "urls": ["https://api.example.com/data"],
                    "method": "GET",
                },
            },
            "how_it_works": (
                "1. Browser mở trang đầu → giải JS challenge\n"
                "2. HybridHandoff.capture(page) trích cookies + UA\n"
                "3. curl_cffi AsyncSession inject cookies → gửi N requests song song\n"
                "4. Browser đóng → tiết kiệm RAM/CPU cho phase follow-up"
            ),
        }

    # ── Phase 9: Resource Governor status ──────────────────────────────────
    @router.get("/governor/status")
    async def get_governor_status() -> dict[str, Any]:
        gov = getattr(get_governor_status, "_engine_governor", None)
        if gov:
            return gov.status()
        return {"message": "Governor chưa gắn vào API (xem engine runtime)"}

    # ── Phase 9: TLS Session Store ──────────────────────────────────────────
    @router.get("/tls/profiles")
    async def get_tcp_os_profiles() -> dict[str, Any]:
        from engine_router import _TCP_OS_PROFILES
        return {"profiles": _TCP_OS_PROFILES}

    class TlsProbeIn(BaseModel):
        url: str
        os_name: str = "Windows"

    @router.post("/tls/probe")
    async def tls_probe(body: TlsProbeIn) -> dict[str, Any]:
        from engine_router import TLSSessionStore, get_tcp_profile
        from urllib.parse import urlsplit
        store = TLSSessionStore()
        host = urlsplit(body.url).netloc
        tcp_profile = get_tcp_profile(body.os_name)
        try:
            sess = await store.get_session(host, impersonate="chrome")
            import time as _t
            t0 = _t.perf_counter()
            r = await sess.get(body.url, timeout=15)
            elapsed = round((_t.perf_counter() - t0) * 1000, 1)
            result = {"ok": True, "status": r.status_code, "elapsed_ms": elapsed,
                      "host": host, "tcp_profile": tcp_profile}
        except Exception as exc:
            result = {"ok": False, "error": str(exc)[:200], "host": host}
        finally:
            await store.close_all()
        return result

    # ── Phase 9: Autopilot Rewriter ──────────────────────────────────────────
    class AutopilotPreviewIn(BaseModel):
        steps: list[dict[str, Any]]
        level: str = "light"
        use_llm: bool = True
        model: str = "llama3.2"

    @router.post("/autopilot/preview")
    async def autopilot_preview(body: AutopilotPreviewIn) -> dict[str, Any]:
        from autopilot_rewriter import AutopilotRewriter, mutate_offline
        if body.use_llm:
            rewriter = AutopilotRewriter(model=body.model)
            sc = {"steps": body.steps, "autopilot": {"enabled": True,
                  "mutation_level": body.level, "model": body.model}}
            result = await rewriter.rewrite(sc)
            return {"steps": result["steps"], "used_llm": await rewriter._check_ollama()}
        else:
            mutated = mutate_offline(body.steps, body.level)
            return {"steps": mutated, "used_llm": False}

    @router.get("/autopilot/ollama-status")
    async def check_ollama_status() -> dict[str, Any]:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get("http://localhost:11434/api/tags")
                if r.status_code == 200:
                    models = r.json().get("models", [])
                    return {"running": True, "models": [m.get("name") for m in models]}
        except Exception:
            pass
        return {"running": False, "models": []}

    class SpintaxIn(BaseModel):
        text: str

    @router.post("/autopilot/spintax")
    async def expand_spintax_preview(body: SpintaxIn) -> dict[str, Any]:
        from autopilot_rewriter import expand_spintax
        return {"original": body.text, "expanded": expand_spintax(body.text)}

    # ── Phase 9: Storm Mode ──────────────────────────────────────────────────
    class StormConfigIn(BaseModel):
        warmup_s: float = 60.0
        storm_s: float = 300.0
        cooldown_s: float = 60.0
        max_concurrency: int = 10
        min_concurrency: int = 1
        ramp_curve: str = "linear"

    @router.post("/storm/preview")
    async def storm_preview(body: StormConfigIn) -> dict[str, Any]:
        from campaign_controller import StormConfig, _ramp_factor
        cfg = StormConfig(**body.model_dump())
        # Tính curve preview (20 điểm)
        points = []
        n = 40
        for i in range(n + 1):
            t = cfg.total_s * i / n
            factor = _ramp_factor(t, cfg)
            concurrency = cfg.min_concurrency + (cfg.max_concurrency - cfg.min_concurrency) * factor
            points.append({"t": round(t, 1), "concurrency": round(concurrency, 1)})
        return {"config": body.model_dump(), "curve": points, "total_s": cfg.total_s}

    @router.get("/storm/history")
    async def get_storm_history() -> dict[str, Any]:
        runs = await db.arecent_storm_runs(20)
        return {"runs": runs}

    # ── Phase 9: Workspaces ──────────────────────────────────────────────────
    class WorkspaceIn(BaseModel):
        id: str
        name: str
        description: str = ""
        color: str = "#1f6f5c"

    # -------------------------------------------------------------------
    # Scenarios (dùng bởi Flow Studio dropdown "Load Scenario")
    # -------------------------------------------------------------------

    @router.get("/scenarios")
    async def list_scenarios() -> dict[str, Any]:
        """Trả danh sách scenario đã lưu trong DB — Flow Studio load vào dropdown."""
        rows = await db.fetch_all(
            "SELECT id, name, urls, profile_id, timeout_ms, active, config, updated_at "
            "FROM scenarios ORDER BY updated_at DESC"
        )
        scenarios = []
        for row in rows:
            import json as _json
            try:
                cfg = _json.loads(row["config"] or "{}")
            except Exception:
                cfg = {}
            scenarios.append({
                "id": row["id"],
                "name": row["name"] or row["id"],
                "urls": _json.loads(row["urls"] or "[]") if isinstance(row["urls"], str) else (row["urls"] or []),
                "profile_id": row["profile_id"],
                "timeout_ms": row["timeout_ms"],
                "active": bool(row["active"]),
                "config": cfg,
                "updated_at": row["updated_at"],
                # Trả số bước để hiển thị badge trong dropdown
                "step_count": len(cfg.get("steps", [])),
            })
        return {"scenarios": scenarios, "total": len(scenarios)}

    @router.get("/scenarios/{scenario_id}")
    async def get_scenario(scenario_id: str) -> dict[str, Any]:
        """Trả chi tiết 1 scenario — Flow Studio dùng để restore canvas Drawflow."""
        import json as _json
        row = await db.fetch_one(
            "SELECT id, name, urls, profile_id, timeout_ms, active, config, updated_at "
            "FROM scenarios WHERE id = ?",
            (scenario_id,),
        )
        if row is None:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail=f"Scenario '{scenario_id}' không tồn tại")
        try:
            cfg = _json.loads(row["config"] or "{}")
        except Exception:
            cfg = {}
        return {
            "id": row["id"],
            "name": row["name"] or row["id"],
            "urls": _json.loads(row["urls"] or "[]") if isinstance(row["urls"], str) else (row["urls"] or []),
            "profile_id": row["profile_id"],
            "timeout_ms": row["timeout_ms"],
            "active": bool(row["active"]),
            "config": cfg,
            "updated_at": row["updated_at"],
            # drawflow_data: nếu config lưu sẵn Drawflow export thì trả về luôn
            "drawflow_data": cfg.get("drawflow_data"),
            "steps": cfg.get("steps", []),
        }

    @router.get("/workspaces")
    async def list_workspaces() -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        return {"workspaces": wm.list_workspaces()}

    @router.post("/workspaces")
    async def create_workspace(body: WorkspaceIn) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        wm.create_workspace(body.id, body.name, body.description, body.color)
        return {"ok": True, "id": body.id}

    @router.delete("/workspaces/{ws_id}")
    async def delete_workspace(ws_id: str) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        wm.delete_workspace(ws_id)
        return {"ok": True}

    class WorkspaceItemIn(BaseModel):
        item_type: str
        item_id: str

    @router.post("/workspaces/{ws_id}/items")
    async def add_workspace_item(ws_id: str, body: WorkspaceItemIn) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        wm.add_item(ws_id, body.item_type, body.item_id)
        return {"ok": True}

    @router.get("/workspaces/{ws_id}/items")
    async def get_workspace_items(ws_id: str) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        return {"items": wm.get_items(ws_id)}

    @router.post("/workspaces/{ws_id}/export")
    async def export_workspace_bundle(ws_id: str) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        out_dir = Path(paths.reports) / "bundles"
        out_dir.mkdir(parents=True, exist_ok=True)
        bundle_path = wm.export_bundle(ws_id, out_dir / f"{ws_id}.qa-bundle")
        return {"ok": True, "path": str(bundle_path), "size_kb": round(bundle_path.stat().st_size / 1024, 1)}

    class BundleImportIn(BaseModel):
        bundle_path: str
        merge: bool = True

    @router.post("/workspaces/import")
    async def import_workspace_bundle(body: BundleImportIn) -> dict[str, Any]:
        from campaign_controller import WorkspaceManager
        wm = WorkspaceManager(db, paths)
        result = wm.import_bundle(Path(body.bundle_path), body.merge)
        return {"ok": True, "result": result}

    return router


# ============================================================================ tiện ích
def _http_client_options() -> list[dict[str, Any]]:
    import importlib.util

    return [{"value": "httpx", "label": "httpx (mặc định, luôn sẵn có)", "available": True},
            {"value": "curl_cffi", "label": "curl_cffi (giả chữ ký TLS/JA3 + HTTP/2 ALPN thật - đã xác nhận Phase 3)",
             "available": bool(importlib.util.find_spec("curl_cffi"))}]


def _masked_key(enc: Optional[str], secrets: SecretBox) -> Optional[str]:
    if not enc:
        return None
    try:
        return SecretBox.mask(secrets.decrypt(enc))
    except Exception:  # noqa: BLE001 - khoá hỏng/đổi secret.key: không chặn hiển thị danh sách
        return "***"


def _coerce_config(config: dict[str, Any], manifest: Optional[Manifest]) -> dict[str, Any]:
    if manifest is None:
        return config
    types = {i.key: i.type for i in manifest.inputs}
    out: dict[str, Any] = {}
    for k, v in config.items():
        t = types.get(k)
        try:
            if t == "number" and v is not None and v != "":
                out[k] = float(v) if "." in str(v) else int(v)
            elif t == "boolean":
                out[k] = bool(v) if not isinstance(v, str) else v.lower() in ("1", "true", "on", "yes")
            else:
                out[k] = v
        except (TypeError, ValueError):
            out[k] = v
    return out
