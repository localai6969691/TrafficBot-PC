"""Phase 11.1 — Trình Quản Lý Màn Hình Ảo & Môi Trường Linux Tự Động.

Hai trách nhiệm độc lập, dùng chung module cho gọn:

1. `XvfbManager` — tự khởi tạo/quản lý vòng đời tiến trình `Xvfb` khi người
   dùng bật "Virtual Display Mode" trên Web UI. Mục đích: một số trang web
   kiểm tra `window.screen`/kích thước màn hình thật qua CSS media query
   hoặc Canvas rendering theo cách khác nhau giữa headless thật và có màn
   hình ảo (dù Playwright headless mới đã khá tốt, một số site/anti-bot vẫn
   phân biệt được qua các API như `getDisplayMedia`/WebGL renderer string).
   Chỉ hoạt động trên Linux - không có khái niệm Xvfb trên Windows/macOS.

2. `provision_cross_platform_fonts()` — tải/dàn xếp một bộ phông chữ chuẩn
   (Noto Sans, Liberation...) vào thư mục cấu hình phông cục bộ của ứng dụng
   (không đụng vào fontconfig hệ thống gốc của VPS), để chữ hiển thị trên
   các bản chụp màn hình / phép đo layout nhất quán giữa các máy chủ khác
   nhau (vd. 1 VPS Ubuntu tối giản không có font nào ngoài DejaVu mặc định).

GIỚI HẠN ĐÃ BIẾT:
* `XvfbManager` gọi `subprocess` trực tiếp tới binary `Xvfb` — cần cài sẵn
  qua `apt install xvfb` trên máy chủ (không tự cài gói hệ thống, chỉ tự
  KHỞI CHẠY tiến trình nếu binary đã có sẵn).
* `provision_cross_platform_fonts()` tải từ Google Fonts GitHub repo (mã
  nguồn mở, miễn phí) - cần Internet. Nếu máy chủ không có Internet, hàm trả
  lỗi rõ ràng thay vì âm thầm bỏ qua.
"""
from __future__ import annotations

import asyncio
import logging
import os
import platform
import shutil
import signal
import socket
import subprocess
import time
from contextlib import closing
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.display")


def is_linux() -> bool:
    return platform.system() == "Linux"


def _find_free_display_num(start: int = 99, tries: int = 50) -> int:
    """Dò một số hiệu DISPLAY (:NN) chưa bị chiếm bằng cách kiểm tra file lock
    X11 chuẩn (`/tmp/.X{N}-lock`) - cách dò nhẹ, không cần quyền root."""
    for n in range(start, start + tries):
        if not Path(f"/tmp/.X{n}-lock").exists():
            return n
    raise RuntimeError("Không tìm được số hiệu DISPLAY trống sau %d lần thử" % tries)


@dataclass
class XvfbHandle:
    display: str                 # vd. ":99"
    process: Any                 # subprocess.Popen
    width: int
    height: int
    depth: int
    started_at: float = field(default_factory=time.time)

    def is_alive(self) -> bool:
        return self.process.poll() is None

    def to_dict(self) -> dict[str, Any]:
        return {
            "display": self.display, "pid": self.process.pid,
            "width": self.width, "height": self.height, "depth": self.depth,
            "alive": self.is_alive(),
            "uptime_s": round(time.time() - self.started_at, 1),
        }


class XvfbManager:
    """Quản lý một tiến trình `Xvfb` duy nhất cho toàn bộ Engine (singleton
    theo instance - `engine.py` giữ MỘT XvfbManager suốt vòng đời ứng dụng,
    không tạo mới cho mỗi scenario, để tránh tốn RAM mở nhiều framebuffer ảo
    cùng lúc không cần thiết).

    Cách dùng:
        mgr = XvfbManager()
        handle = await mgr.start(width=1920, height=1080)
        os.environ["DISPLAY"] = handle.display   # hoặc truyền env= vào subprocess launch trình duyệt
        ...
        await mgr.stop()   # giải phóng khi tắt ứng dụng / đổi chế độ

    "Headless=false" (Virtual Display Mode) nghĩa là: trình duyệt khởi chạy
    với `headless=False` (chế độ có cửa sổ GUI thật), nhưng cửa sổ đó vẽ ra
    một framebuffer ẢO (Xvfb) chứ không cần màn hình vật lý/VNC - máy chủ
    Linux không màn hình vẫn chạy được chế độ "có giao diện" đầy đủ.
    """

    def __init__(self) -> None:
        self._handle: Optional[XvfbHandle] = None
        self._lock = asyncio.Lock()

    @property
    def handle(self) -> Optional[XvfbHandle]:
        return self._handle

    def status(self) -> dict[str, Any]:
        if self._handle is None:
            return {"running": False, "platform_supported": is_linux()}
        d = self._handle.to_dict()
        d["running"] = d.pop("alive")
        d["platform_supported"] = True
        return d

    async def start(self, width: int = 1920, height: int = 1080, depth: int = 24) -> XvfbHandle:
        """Khởi tạo `Xvfb :NN -screen 0 WxHxD` nếu chưa chạy. Idempotent: gọi
        lại khi đã chạy sẵn sẽ trả về handle hiện tại (không mở tiến trình mới)."""
        if not is_linux():
            raise RuntimeError(
                "Virtual Display Mode (Xvfb) chỉ hỗ trợ trên Linux. "
                f"Hệ điều hành hiện tại: {platform.system()}."
            )
        xvfb_bin = shutil.which("Xvfb")
        if not xvfb_bin:
            raise RuntimeError(
                "Không tìm thấy binary 'Xvfb'. Cài đặt bằng: "
                "sudo apt-get install -y xvfb  (Ubuntu/Debian)."
            )
        async with self._lock:
            if self._handle is not None and self._handle.is_alive():
                LOGGER.debug("Xvfb đã chạy sẵn ở %s - bỏ qua khởi tạo lại", self._handle.display)
                return self._handle

            display_num = _find_free_display_num()
            display = f":{display_num}"
            args = [xvfb_bin, display, "-screen", "0", f"{width}x{height}x{depth}", "-nolisten", "tcp"]
            LOGGER.info("Khởi chạy Xvfb: %s", " ".join(args))
            proc = subprocess.Popen(
                args, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                start_new_session=True,  # để kill cả process group lúc stop()
            )
            # Chờ lock file xuất hiện (dấu hiệu Xvfb đã bind thành công) - tối đa 3s.
            lock_path = Path(f"/tmp/.X{display_num}-lock")
            for _ in range(30):
                if lock_path.exists() or proc.poll() is not None:
                    break
                await asyncio.sleep(0.1)
            if proc.poll() is not None:
                _, err = proc.communicate(timeout=2)
                raise RuntimeError(f"Xvfb thoát ngay lập tức (exit {proc.returncode}): "
                                   f"{err.decode(errors='replace')[:300]}")

            self._handle = XvfbHandle(display=display, process=proc,
                                      width=width, height=height, depth=depth)
            # Gán DISPLAY cho CHÍNH tiến trình Python hiện tại - để mọi subprocess
            # con (trình duyệt Playwright) kế thừa biến môi trường này mặc định.
            os.environ["DISPLAY"] = display
            LOGGER.info("Xvfb sẵn sàng tại DISPLAY=%s (pid=%d)", display, proc.pid)
            return self._handle

    async def stop(self) -> None:
        """Dừng Xvfb và giải phóng bộ nhớ framebuffer ảo. An toàn khi gọi
        nhiều lần / khi chưa từng start()."""
        async with self._lock:
            if self._handle is None:
                return
            proc = self._handle.process
            display = self._handle.display
            if proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except (ProcessLookupError, PermissionError):
                    proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        proc.kill()
            if os.environ.get("DISPLAY") == display:
                os.environ.pop("DISPLAY", None)
            LOGGER.info("Đã dừng Xvfb tại %s", display)
            self._handle = None


# ---------------------------------------------------------------------------
# Cross-Platform Font Provisioner
# ---------------------------------------------------------------------------

#: Danh sách phông chữ chuẩn - CHỈ gồm URL đã xác minh tải được thật (HTTP 200,
#: kiểm tra bằng curl trực tiếp trước khi đưa vào code, không đoán đường dẫn).
#: Phủ: Latin phổ biến (Noto Sans - Google Fonts repo chính thức) + tương thích
#: layout với Arial (Liberation Sans, mirror từ repo nlplab/brat - vì repo gốc
#: liberationfonts/liberation-fonts chỉ lưu mã nguồn .sfd cần `make` để build ra
#: .ttf, KHÔNG có file .ttf build sẵn trong nhánh chính).
#:
#: GIỚI HẠN ĐÃ BIẾT: Liberation Serif (~ Times New Roman) và Liberation Mono
#: (~ Courier New) chưa tìm được mirror .ttf build-sẵn ổn định nào qua
#: raw.githubusercontent.com tại thời điểm viết code này - CHỦ ĐỘNG bỏ khỏi
#: danh sách thay vì để URL 404 âm thầm. Nếu cần đủ bộ 3, build từ mã nguồn
#: repo gốc (`git clone` + `make`) hoặc cài qua `apt-get install fonts-liberation`
#: trên máy chủ (yêu cầu quyền root - nằm ngoài phạm vi "không đổi cấu hình gốc
#: VPS" của tính năng này).
_FONT_PACKAGES: dict[str, str] = {
    "NotoSans-Regular.ttf":
        "https://raw.githubusercontent.com/google/fonts/main/ofl/notosans/NotoSans%5Bwdth%2Cwght%5D.ttf",
    "LiberationSans-Regular.ttf":
        "https://raw.githubusercontent.com/nlplab/brat/master/static/fonts/Liberation_Sans-Regular.ttf",
}


def local_fontconfig_dir(app_data_dir: Path) -> Path:
    """Thư mục phông cục bộ CỦA RIÊNG ỨNG DỤNG - không phải thư mục font hệ
    thống. Dùng làm giá trị biến môi trường `FONTCONFIG_PATH` khi khởi chạy
    trình duyệt, để không cần quyền root / không đụng tới cấu hình font gốc
    của VPS (mục 2.1: "không làm thay đổi cấu hình hệ thống gốc của VPS")."""
    d = app_data_dir / "fonts_local"
    d.mkdir(parents=True, exist_ok=True)
    return d


async def provision_cross_platform_fonts(app_data_dir: Path, force: bool = False) -> dict[str, Any]:
    """Tải bộ phông chuẩn đa nền tảng vào `local_fontconfig_dir()` + sinh tệp
    `fonts.conf` tối thiểu để fontconfig nhận diện thư mục này khi
    `FONTCONFIG_PATH` trỏ vào đây.

    Trả về: {"ok": bool, "downloaded": [...], "skipped": [...], "failed": [...],
             "fontconfig_path": str}
    """
    try:
        import httpx
    except ImportError:
        return {"ok": False, "error": "Cần cài httpx: pip install httpx"}

    font_dir = local_fontconfig_dir(app_data_dir)
    downloaded, skipped, failed = [], [], []

    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        for filename, url in _FONT_PACKAGES.items():
            dest = font_dir / filename
            if dest.is_file() and not force:
                skipped.append(filename)
                continue
            try:
                r = await client.get(url)
                if r.status_code != 200 or len(r.content) < 1024:
                    failed.append({"file": filename, "error": f"HTTP {r.status_code} hoặc nội dung quá nhỏ"})
                    continue
                dest.write_bytes(r.content)
                downloaded.append(filename)
            except Exception as exc:  # noqa: BLE001
                failed.append({"file": filename, "error": f"{type(exc).__name__}: {exc}"})

    # fonts.conf tối thiểu: chỉ khai báo thư mục này, KHÔNG include
    # <dir>/usr/share/fonts</dir> hay bất kỳ đường dẫn hệ thống nào khác -
    # giữ đúng tinh thần "cục bộ, không đổi cấu hình gốc".
    conf_path = font_dir / "fonts.conf"
    conf_path.write_text(
        '<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "fonts.dtd">\n'
        f'<fontconfig>\n  <dir>{font_dir}</dir>\n  <cachedir>{font_dir / "cache"}</cachedir>\n'
        '</fontconfig>\n',
        encoding="utf-8",
    )
    (font_dir / "cache").mkdir(exist_ok=True)

    return {
        "ok": len(failed) == 0 or len(downloaded) + len(skipped) > 0,
        "downloaded": downloaded, "skipped": skipped, "failed": failed,
        "fontconfig_path": str(font_dir),
    }


def fontconfig_env(app_data_dir: Path) -> dict[str, str]:
    """Biến môi trường để gán cho subprocess trình duyệt nếu muốn dùng bộ
    phông cục bộ đã provision. Dùng: `env={**os.environ, **fontconfig_env(...)}`."""
    font_dir = local_fontconfig_dir(app_data_dir)
    if not (font_dir / "fonts.conf").is_file():
        return {}
    return {"FONTCONFIG_PATH": str(font_dir)}
