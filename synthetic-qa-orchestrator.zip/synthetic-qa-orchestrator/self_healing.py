"""Cơ Chế Tự Phục Hồi Kịch Bản Thích Ứng (Adaptive Selector Self-Healing).

Khi selector chính không tìm thấy phần tử → tự động thử các chiến lược fallback:
  1. Multi-attribute heuristic: role + text, aria-label, placeholder, name, type
  2. Fuzzy text match: tìm phần tử có text gần giống (Levenshtein-like)
  3. Structural fallback: nth-of-type tương đối trong container
  4. Ollama Local LLM: gửi DOM rút gọn sang mô hình AI cục bộ để suy luận selector

ElementSnapshot (lưu khi ghi scenario):
  {
    "selector": "#submit-btn",
    "inner_text": "Submit",
    "aria_label": "Submit form",
    "role": "button",
    "placeholder": "",
    "name": "submit",
    "element_type": "submit",
    "xpath": "//button[@id='submit-btn']",
    "tag": "button"
  }

GIỚI HẠN ĐÃ BIẾT:
  - Ollama fallback yêu cầu `ollama` chạy cục bộ trên http://localhost:11434.
    Nếu không có → bỏ qua strategy này, không báo lỗi, thử chiến lược khác.
  - Fuzzy match dùng Levenshtein đơn giản (không diacritics-aware).
    Với ngôn ngữ có nhiều dấu (tiếng Việt), nên kết hợp normalized comparison.
  - Self-healing chỉ sửa tạm thời trong memory của run hiện tại.
    Để cập nhật vĩnh viễn vào scenarios.json: gọi patch_scenario_selector().
  - Không tự phục hồi được với dynamic components (React re-render, SPA routing)
    nếu phần tử chưa mount vào DOM khi selector được tìm. Thêm wait_for_selector
    với timeout đủ dài vào step trước.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.healer")


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class ElementSnapshot:
    """Ảnh chụp đa thuộc tính của phần tử tại thời điểm ghi scenario."""
    selector: str
    inner_text: str = ""
    aria_label: str = ""
    role: str = ""
    placeholder: str = ""
    name: str = ""
    element_type: str = ""
    xpath: str = ""
    tag: str = "div"

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ElementSnapshot":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})

    @classmethod
    def from_step(cls, step: dict[str, Any]) -> "ElementSnapshot":
        """Tạo snapshot từ step JSON (đọc _picker_meta nếu có)."""
        selector = step.get("selector", "")
        meta = step.get("_picker_meta", {})
        return cls(
            selector=selector,
            inner_text=step.get("text") or meta.get("inner_text", ""),
            aria_label=meta.get("aria_label", ""),
            role=meta.get("role", ""),
            tag=meta.get("tag", "div"),
            xpath=meta.get("xpath", ""),
        )


@dataclass
class HealResult:
    original_selector: str
    healed_selector: str
    strategy: str           # original|aria|text|fuzzy|structural|ollama
    confidence: float       # 0.0 – 1.0
    healed: bool = False
    error: str = ""


# ---------------------------------------------------------------------------
# JS helpers chạy trong browser
# ---------------------------------------------------------------------------

def _build_find_js(snapshot: ElementSnapshot) -> str:
    """Tạo JS tìm kiếm multi-attribute, trả về {found, selector, strategy}."""
    text_norm = _normalize(snapshot.inner_text)
    aria = json.dumps(snapshot.aria_label)
    ph = json.dumps(snapshot.placeholder)
    nm = json.dumps(snapshot.name)
    role = json.dumps(snapshot.role or snapshot.tag)
    text_q = json.dumps(text_norm[:50])
    tag = snapshot.tag or "*"

    return f"""
() => {{
  const norm = s => s.toLowerCase().replace(/[\\s\\u00a0]+/g,' ').trim();
  const matchText = (el, q) => norm(el.innerText||el.textContent||'').includes(q);

  // Strategy 1: aria-label
  if ({aria} !== '') {{
    const el = document.querySelector('[aria-label={aria}]');
    if (el) return {{found:true, selector:'[aria-label={aria}]', strategy:'aria'}};
  }}
  // Strategy 2: placeholder
  if ({ph} !== '') {{
    const el = document.querySelector('[placeholder={ph}]');
    if (el) return {{found:true, selector:'[placeholder={ph}]', strategy:'placeholder'}};
  }}
  // Strategy 3: name attribute
  if ({nm} !== '') {{
    const el = document.querySelector('[name={nm}]');
    if (el) return {{found:true, selector:'[name={nm}]', strategy:'name'}};
  }}
  // Strategy 4: role + text
  const q = {text_q};
  if (q !== '') {{
    const els = [...document.querySelectorAll('{tag},[role={role}]')];
    const match = els.find(el => matchText(el, q));
    if (match) {{
      const id = match.id ? '#'+match.id : null;
      const sel = id || (match.getAttribute('aria-label') ?
        '[aria-label="' + match.getAttribute('aria-label') + '"]' :
        match.tagName.toLowerCase() + ':has-text("' + q.slice(0,20) + '")');
      return {{found:true, selector:sel, strategy:'text_role'}};
    }}
    // Strategy 5: fuzzy (tìm el gần nhất về text)
    const scored = [...document.querySelectorAll('{tag}')]
      .map(el => {{
        const t = norm(el.innerText||el.textContent||'');
        let s = 0;
        for (let i=0;i<Math.min(q.length,t.length);i++) if(q[i]===t[i]) s++;
        return {{el, score: s/Math.max(q.length,t.length,1)}};
      }})
      .filter(x => x.score > 0.6)
      .sort((a,b) => b.score - a.score);
    if (scored.length) {{
      const best = scored[0].el;
      const sel = best.id ? '#'+best.id : best.tagName.toLowerCase();
      return {{found:true, selector:sel, strategy:'fuzzy', score:scored[0].score}};
    }}
  }}
  return {{found:false}};
}}
"""


def _normalize(s: str) -> str:
    """Chuẩn hóa text: lowercase, bỏ diacritics nhẹ, collapse spaces."""
    if not s:
        return ""
    # Normalize unicode để so sánh dễ hơn
    try:
        s = unicodedata.normalize("NFC", s)
    except Exception:
        pass
    return re.sub(r"\s+", " ", s.lower().strip())


# ---------------------------------------------------------------------------
# SelectorHealer
# ---------------------------------------------------------------------------

class SelectorHealer:
    """Thử các chiến lược fallback để tìm lại phần tử khi selector gốc thất bại."""

    def __init__(
        self,
        ollama_url: str = "http://localhost:11434",
        ollama_model: str = "llama3.2",
        max_dom_chars: int = 4000,
    ) -> None:
        self.ollama_url = ollama_url
        self.ollama_model = ollama_model
        self.max_dom_chars = max_dom_chars

    async def heal(
        self,
        page: Any,
        snapshot: ElementSnapshot,
    ) -> HealResult:
        """Thử tất cả chiến lược, trả về HealResult tốt nhất tìm được."""
        orig = snapshot.selector

        # 0. Thử lại selector gốc (đôi khi trang load chậm)
        try:
            el = await page.locator(orig).first.element_handle(timeout=2000)
            if el:
                return HealResult(orig, orig, "original", 1.0, healed=False)
        except Exception:
            pass

        # 1. Multi-attribute JS search
        try:
            js = _build_find_js(snapshot)
            result: dict[str, Any] = await page.evaluate(js)
            if result.get("found"):
                sel = result["selector"]
                strategy = result.get("strategy", "heuristic")
                score = result.get("score", 0.85)
                # Xác minh selector thật sự tìm được element
                try:
                    el = await page.locator(sel).first.element_handle(timeout=1500)
                    if el:
                        LOGGER.info("healer: '%s' → '%s' (strategy=%s)",
                                    orig[:50], sel[:60], strategy)
                        return HealResult(orig, sel, strategy,
                                          float(score), healed=True)
                except Exception:
                    pass
        except Exception as exc:
            LOGGER.debug("healer JS search lỗi: %s", exc)

        # 2. Ollama LLM fallback
        ollama_result = await self._ollama_fallback(page, snapshot)
        if ollama_result:
            return ollama_result

        # 3. Thất bại hoàn toàn
        return HealResult(orig, orig, "failed", 0.0, healed=False,
                          error="Không tìm được phần tử với bất kỳ chiến lược nào")

    async def _ollama_fallback(
        self,
        page: Any,
        snapshot: ElementSnapshot,
    ) -> Optional[HealResult]:
        """Gửi DOM rút gọn sang Ollama để xin selector mới."""
        try:
            import httpx
        except ImportError:
            return None

        # Kiểm tra Ollama có chạy không
        try:
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get(f"{self.ollama_url}/api/tags")
                if r.status_code != 200:
                    return None
        except Exception:
            return None

        # Lấy DOM rút gọn (loại bỏ script/style/svg)
        try:
            dom_html: str = await page.evaluate("""
            () => {
              const clone = document.body.cloneNode(true);
              clone.querySelectorAll('script,style,svg,img,link,meta').forEach(e=>e.remove());
              // Giữ chỉ tag, id, class, aria-*, role, placeholder, name, type, innerText ngắn
              clone.querySelectorAll('*').forEach(el => {
                [...el.attributes].forEach(a => {
                  if (!['id','class','role','aria-label','placeholder','name','type','href'].includes(a.name))
                    el.removeAttribute(a.name);
                });
                if (el.children.length === 0 && el.textContent.length > 60)
                  el.textContent = el.textContent.slice(0,60) + '…';
              });
              return clone.innerHTML.slice(0, 6000);
            }""")
        except Exception:
            return None

        dom_trimmed = dom_html[:self.max_dom_chars]
        prompt = (
            f"Tôi cần tìm phần tử HTML này:\n"
            f"- Tag: {snapshot.tag}\n"
            f"- Text: {snapshot.inner_text[:60]}\n"
            f"- ARIA label: {snapshot.aria_label}\n"
            f"- Placeholder: {snapshot.placeholder}\n"
            f"- Selector cũ (không còn hoạt động): {snapshot.selector}\n\n"
            f"DOM hiện tại (rút gọn):\n{dom_trimmed}\n\n"
            f"Hãy trả về CHỈ một CSS selector ngắn gọn, bắt đầu bằng #, ., [ hoặc tag. "
            f"Không giải thích, không markdown."
        )

        try:
            async with httpx.AsyncClient(timeout=30) as c:
                r = await c.post(
                    f"{self.ollama_url}/api/generate",
                    json={"model": self.ollama_model, "prompt": prompt,
                          "stream": False, "options": {"temperature": 0.1}},
                )
            resp = r.json()
            new_sel = resp.get("response", "").strip().split("\n")[0].strip()
            # Validate: phải có ký tự selector hợp lệ
            if not new_sel or not re.match(r'^[#.\[\*a-zA-Z]', new_sel):
                return None
            # Xác minh selector
            try:
                el = await page.locator(new_sel).first.element_handle(timeout=2000)
                if el:
                    LOGGER.info("healer: Ollama gợi ý '%s' → '%s' ✅", snapshot.selector[:50], new_sel)
                    return HealResult(snapshot.selector, new_sel, "ollama", 0.7, healed=True)
            except Exception:
                return None
        except Exception as exc:
            LOGGER.debug("healer: Ollama lỗi: %s", exc)
            return None


# ---------------------------------------------------------------------------
# Auto-heal wrapper cho engine steps
# ---------------------------------------------------------------------------

class HealingLocator:
    """Wrap Playwright locator với self-healing fallback."""

    def __init__(self, page: Any, healer: Optional[SelectorHealer] = None) -> None:
        self.page = page
        self.healer = healer or SelectorHealer()
        self._cache: dict[str, str] = {}  # original → healed selector

    async def locate(self, snapshot: ElementSnapshot, timeout_ms: int = 5000) -> Any:
        """Trả về Playwright locator, tự heal nếu cần."""
        orig = snapshot.selector

        # Kiểm tra cache heal
        if orig in self._cache:
            cached = self._cache[orig]
            try:
                loc = self.page.locator(cached).first
                await loc.element_handle(timeout=1500)
                return loc
            except Exception:
                del self._cache[orig]

        # Thử selector gốc
        try:
            loc = self.page.locator(orig).first
            await loc.element_handle(timeout=timeout_ms)
            return loc
        except Exception:
            pass

        # Self-heal
        LOGGER.info("healer: '%s' không tìm thấy → kích hoạt healing", orig[:60])
        result = await self.healer.heal(self.page, snapshot)
        if result.healed:
            self._cache[orig] = result.healed_selector
            LOGGER.info("healer: đã cache '%s' → '%s'", orig[:40], result.healed_selector[:50])
            return self.page.locator(result.healed_selector).first

        raise Exception(f"self_healing: không thể tìm phần tử '{orig}' "
                        f"với bất kỳ chiến lược nào")


# ---------------------------------------------------------------------------
# patch_scenario_selector: cập nhật vĩnh viễn vào scenarios.json
# ---------------------------------------------------------------------------

async def patch_scenario_selector(
    scenarios_path: Path,
    scenario_id: str,
    old_selector: str,
    new_selector: str,
) -> bool:
    """Cập nhật selector trong scenarios.json sau khi heal thành công.

    Returns True nếu tìm và sửa được ít nhất 1 selector.
    """
    if not scenarios_path.exists():
        return False
    try:
        data = json.loads(scenarios_path.read_text())
        changed = 0
        for sc in data.get("scenarios", []):
            if sc.get("id") != scenario_id:
                continue
            for step in sc.get("steps", []):
                if step.get("selector") == old_selector:
                    step["selector"] = new_selector
                    step.setdefault("_healed", []).append({
                        "from": old_selector, "to": new_selector,
                        "healed_at": __import__("datetime").datetime.utcnow().isoformat(),
                    })
                    changed += 1
        if changed:
            scenarios_path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
            LOGGER.info("healer: đã cập nhật %d selector trong '%s'", changed, scenario_id)
        return changed > 0
    except Exception as exc:
        LOGGER.error("patch_scenario_selector lỗi: %s", exc)
        return False
