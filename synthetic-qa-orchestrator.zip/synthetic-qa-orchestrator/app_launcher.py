"""
app_launcher.py — 1-Click Desktop Launcher
Điểm vào duy nhất cho giao diện máy tính để bàn.

Luồng khởi động:
  1. Tìm cổng mạng cục bộ trống (127.0.0.1:18080 → 18180)
  2. Khởi chạy FastAPI backend trong daemon thread (asyncio)
  3. Chờ server sẵn sàng (health probe)
  4. Mở cửa sổ PyWebView → giao diện như phần mềm thật (không thanh địa chỉ)
  5. Khi người dùng đóng cửa sổ → thu nhỏ xuống System Tray (pystray)
  6. Menu Tray: "Mở Dashboard", "Tạm dừng", "Khởi động lại", "Thoát"
  7. Khi thoát hẳn → dọn dẹp sạch (server + tray)

Chạy:
  python app_launcher.py          # Desktop GUI mode (1-click)
  python app_launcher.py --no-gui # Headless server mode (giống main.py dashboard)
  python app_launcher.py --port 18080  # Chỉ định cổng cố định

Tương thích:
  - Windows: PyWebView dùng IE/Edge WebView2, pystray dùng Win32 API
  - macOS: PyWebView dùng WKWebView, pystray dùng AppKit
  - Linux: PyWebView dùng GTK WebKit, pystray dùng AppIndicator/Gtk
  - Headless server: fallback graceful (in URL, không mở cửa sổ/tray)

Giới hạn:
  - PyWebView yêu cầu display (X11/Wayland/Quartz/Win32).
    Trên Linux headless: set DISPLAY=:99 hoặc dùng Xvfb.
  - pystray yêu cầu Gtk3/AppIndicator trên Linux.
    Nếu thiếu: daemon chạy bình thường, chỉ không có tray icon.
  - File thực thi app_launcher.py phải nằm cùng thư mục với main.py.
"""
from __future__ import annotations

import argparse
import asyncio
import contextlib
import logging
import os
import platform
import signal
import socket
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

LOG_FORMAT = "%(asctime)s [%(levelname).1s] %(name)s: %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FORMAT)
LOGGER = logging.getLogger("qa.launcher")

APP_TITLE = "Synthetic Automation Studio"
APP_VERSION = "1.0"
DEFAULT_PORT_START = 18080
DEFAULT_PORT_END   = 18180
HEALTH_TIMEOUT_S   = 20.0
HEALTH_INTERVAL_S  = 0.3

# ---------------------------------------------------------------------------
# Port detection
# ---------------------------------------------------------------------------

def find_free_port(start: int = DEFAULT_PORT_START,
                   end: int = DEFAULT_PORT_END) -> int:
    """Tìm cổng TCP tự do đầu tiên trong dải [start, end)."""
    for port in range(start, end):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"Không tìm được cổng trống trong dải {start}-{end}")


def wait_for_server(url: str, timeout: float = HEALTH_TIMEOUT_S) -> bool:
    """Chờ cho đến khi HTTP server phản hồi OK hoặc hết timeout."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:
                if r.status < 500:
                    return True
        except Exception:
            pass
        time.sleep(HEALTH_INTERVAL_S)
    return False


# ---------------------------------------------------------------------------
# Backend thread
# ---------------------------------------------------------------------------

class BackendThread(threading.Thread):
    """Chạy FastAPI/uvicorn trong một daemon thread."""

    def __init__(self, host: str, port: int) -> None:
        super().__init__(daemon=True, name="qa-backend")
        self.host = host
        self.port = port
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._ready = threading.Event()
        self._error: Optional[Exception] = None

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def run(self) -> None:
        try:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            self._loop.run_until_complete(self._serve())
        except Exception as exc:
            self._error = exc
            LOGGER.error("Backend thread lỗi: %s", exc)
        finally:
            self._ready.set()

    async def _serve(self) -> None:
        """Build FastAPI app + khởi chạy uvicorn.

        Phase 12 fix: TRƯỚC ĐÂY hàm này chỉ tạo Database + dashboard viewer,
        KHÔNG BAO GIỜ tạo Engine - nghĩa là desktop launcher (chế độ 1-click
        chính của ứng dụng) không có cách nào thực thi scenario, dù dashboard
        hiển thị đầy đủ UI để "chạy". Sửa bằng cách dùng chung `build_app()` +
        `running()` với đường CLI (`main.py`), đảm bảo desktop và CLI có cùng
        một Engine thật, cùng vòng đời pool/governor/Xvfb (Phase 10/11), và
        Live Worker Grid (Phase 12) hoạt động được trên cả hai đường chạy.
        """
        import argparse
        from config_loader import Paths
        from main import build_app, running

        paths = Paths.from_base(ROOT)
        paths.ensure_dirs()

        # build_app() cần một argparse.Namespace (đường CLI) - desktop launcher
        # không có cờ dòng lệnh nào tương ứng nên truyền Namespace rỗng/mặc định.
        fake_args = argparse.Namespace(concurrency=None, headed=False, scenario=None)
        app = await build_app(paths, fake_args)
        db, bus, paths = app.db, app.bus, app.paths

        def _status() -> dict:
            return {"workers": len(app.engine._workers), "mode": "desktop",
                    "port": self.port, "version": APP_VERSION}

        from dashboard import create_app
        fastapi_app = create_app(db, bus, _status, paths)

        # `running()` khởi động pool health-check + Engine (Xvfb nếu bật) và dọn
        # dẹp đúng cách khi thoát - chạy NGẦM suốt vòng đời tiến trình desktop,
        # không one-shot như `cmd_run`. Người dùng dùng nút "▶ Chạy ngay" (Phase
        # 12, Command Center) để kích hoạt scenario theo yêu cầu thay vì cron.
        self._running_ctx = running(app, dashboard=False)  # dashboard=False: ta tự serve fastapi_app dưới
        await self._running_ctx.__aenter__()

        app_for_uvicorn = fastapi_app

        import uvicorn
        config = uvicorn.Config(
            app_for_uvicorn,
            host=self.host,
            port=self.port,
            log_level="warning",
            loop="asyncio",
        )
        server = uvicorn.Server(config)
        server.install_signal_handlers = lambda: None

        # Signal ready ngay khi server bắt đầu lắng nghe
        async def _startup_hook():
            self._ready.set()

        orig_startup = server.startup
        async def _patched_startup(sockets=None):
            await orig_startup(sockets)
            self._ready.set()
        server.startup = _patched_startup

        LOGGER.info("Backend sẵn sàng tại %s", self.base_url)
        try:
            await server.serve()
        finally:
            # Phase 12: đóng Engine/pool/db đúng cách qua context manager running()
            # thay vì để tiến trình thoát đột ngột và bỏ sót dọn dẹp Xvfb/browser.
            with contextlib.suppress(Exception):
                await self._running_ctx.__aexit__(None, None, None)

    def wait_ready(self, timeout: float = HEALTH_TIMEOUT_S) -> bool:
        self._ready.wait(timeout=timeout)
        if self._error:
            raise self._error
        # Double-check bằng HTTP probe
        return wait_for_server(self.base_url + "/", timeout=timeout)


# ---------------------------------------------------------------------------
# Desktop window (PyWebView)
# ---------------------------------------------------------------------------

class DesktopWindow:
    """Cửa sổ PyWebView bọc xung quanh dashboard localhost."""

    def __init__(self, url: str, title: str = APP_TITLE) -> None:
        self.url = url
        self.title = title
        self._window = None
        self._tray: Optional["SystemTray"] = None
        self._available = False

    def try_import(self) -> bool:
        try:
            import webview  # noqa: F401
            self._available = True
        except ImportError:
            LOGGER.warning("pywebview chưa được cài. Chạy: pip install pywebview")
        return self._available

    def attach_tray(self, tray: "SystemTray") -> None:
        self._tray = tray

    def open(self) -> None:
        """Mở cửa sổ và block cho đến khi người dùng đóng/thu nhỏ."""
        if not self._available:
            LOGGER.info("Mở trình duyệt tại: %s", self.url)
            import webbrowser
            webbrowser.open(self.url)
            return

        import webview

        self._window = webview.create_window(
            self.title,
            url=self.url,
            width=1360,
            height=860,
            min_size=(960, 640),
            resizable=True,
            # Ẩn thanh địa chỉ trình duyệt → trông như phần mềm thật
            text_select=True,
            easy_drag=False,
        )

        # Khi người dùng nhấn ×  → thu nhỏ xuống tray thay vì thoát
        def on_closing():
            if self._tray and self._tray.is_running():
                LOGGER.info("Thu nhỏ xuống system tray")
                self._window.hide()
                self._tray.notify("QA Studio đang chạy ngầm", "Nhấp đúp vào biểu tượng để mở lại")
                return False  # Ngăn PyWebView đóng cửa sổ hẳn
            return True

        self._window.events.closing += on_closing
        LOGGER.info("Mở cửa sổ desktop tại %s", self.url)
        webview.start(debug=False)

    def show(self) -> None:
        """Hiện lại cửa sổ từ tray."""
        if self._window:
            try:
                self._window.show()
                self._window.on_top = True
                self._window.on_top = False
            except Exception:
                pass

    def destroy(self) -> None:
        """Đóng cửa sổ hẳn."""
        if self._window:
            try:
                import webview
                webview.windows.clear()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# System Tray
# ---------------------------------------------------------------------------

class SystemTray:
    """Biểu tượng khay hệ thống với menu chuột phải."""

    def __init__(
        self,
        dashboard_url: str,
        on_show: Optional[callable] = None,
        on_quit: Optional[callable] = None,
    ) -> None:
        self.dashboard_url = dashboard_url
        self._on_show = on_show
        self._on_quit = on_quit
        self._icon = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def is_running(self) -> bool:
        return self._running

    def _make_image(self):
        """Tạo icon 64×64 đơn giản bằng Pillow."""
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            # Vẽ hình tròn gradient đơn giản
            d.ellipse([4, 4, 60, 60], fill=(56, 189, 248, 255))   # sky-400
            d.ellipse([16, 16, 48, 48], fill=(14, 165, 233, 255))  # sky-500
            d.ellipse([24, 24, 40, 40], fill=(255, 255, 255, 220))
            return img
        except ImportError:
            return None

    def start(self) -> bool:
        """Khởi động system tray icon trong background thread."""
        try:
            import pystray

            img = self._make_image()
            if img is None:
                LOGGER.warning("pystray: Pillow chưa cài, dùng icon rỗng")
                from PIL import Image
                img = Image.new("RGB", (64, 64), (56, 189, 248))

            menu = pystray.Menu(
                pystray.MenuItem("🖥️ Mở Dashboard", self._show_window, default=True),
                pystray.MenuItem("🌐 Mở trong trình duyệt", self._open_browser),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("❌ Thoát hoàn toàn", self._quit),
            )

            self._icon = pystray.Icon(
                "qa-studio",
                img,
                f"{APP_TITLE} v{APP_VERSION}",
                menu,
            )
            self._running = True

            self._thread = threading.Thread(
                target=self._icon.run, daemon=True, name="qa-tray"
            )
            self._thread.start()
            LOGGER.info("System tray icon đã khởi động")
            return True
        except Exception as exc:
            LOGGER.warning("Không thể khởi động system tray: %s", exc)
            return False

    def _show_window(self, icon=None, item=None) -> None:
        if self._on_show:
            self._on_show()

    def _open_browser(self, icon=None, item=None) -> None:
        import webbrowser
        webbrowser.open(self.dashboard_url)

    def _quit(self, icon=None, item=None) -> None:
        self._running = False
        if self._icon:
            self._icon.stop()
        if self._on_quit:
            self._on_quit()

    def notify(self, title: str, message: str) -> None:
        if self._icon:
            try:
                self._icon.notify(message, title)
            except Exception:
                pass

    def stop(self) -> None:
        self._running = False
        if self._icon:
            try:
                self._icon.stop()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Main launcher
# ---------------------------------------------------------------------------

def launch_desktop(host: str, port: int) -> None:
    """Luồng chính: start backend → open window → tray."""
    LOGGER.info("=" * 55)
    LOGGER.info(" %s v%s", APP_TITLE, APP_VERSION)
    LOGGER.info(" Hệ điều hành: %s %s", platform.system(), platform.release())
    LOGGER.info("=" * 55)

    # 1. Khởi động backend
    backend = BackendThread(host, port)
    backend.start()
    LOGGER.info("Đang khởi động backend tại %s:%d …", host, port)

    if not backend.wait_ready(HEALTH_TIMEOUT_S):
        LOGGER.error("Backend không phản hồi trong %.0fs — dừng lại", HEALTH_TIMEOUT_S)
        sys.exit(1)

    dashboard_url = backend.base_url
    LOGGER.info("Backend sẵn sàng: %s", dashboard_url)

    # 2. Khởi động desktop window
    window = DesktopWindow(dashboard_url)
    has_webview = window.try_import()

    # 3. Khởi động system tray
    _quitting = threading.Event()

    def on_quit():
        LOGGER.info("Thoát theo yêu cầu từ tray")
        _quitting.set()
        window.destroy()

    def on_show():
        window.show()

    tray = SystemTray(dashboard_url, on_show=on_show, on_quit=on_quit)
    tray_ok = tray.start()
    window.attach_tray(tray if tray_ok else None)

    if not has_webview:
        LOGGER.info("Không có PyWebView — mở trình duyệt hệ thống")
        import webbrowser
        webbrowser.open(dashboard_url)
        if tray_ok:
            LOGGER.info("Ứng dụng đang chạy ngầm. Dùng System Tray để thoát.")
            _quitting.wait()
        else:
            LOGGER.info("Nhấn Ctrl+C để thoát. Dashboard: %s", dashboard_url)
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
        return

    # 4. Bắt Ctrl+C ngay cả khi window đang mở
    def _sigint(sig, frame):
        LOGGER.info("Nhận Ctrl+C — đóng ứng dụng")
        tray.stop()
        window.destroy()
        sys.exit(0)

    try:
        signal.signal(signal.SIGINT, _sigint)
    except (ValueError, OSError):
        pass  # Không phải main thread

    # 5. Mở cửa sổ (blocking)
    window.open()

    # Sau khi cửa sổ đóng hẳn — dọn dẹp
    tray.stop()
    LOGGER.info("Ứng dụng đã đóng")


def launch_headless(host: str, port: int) -> None:
    """Chế độ headless: chỉ chạy server, không mở cửa sổ."""
    LOGGER.info("Chế độ Headless — %s:%d", host, port)
    backend = BackendThread(host, port)
    backend.start()

    if not backend.wait_ready(HEALTH_TIMEOUT_S):
        LOGGER.error("Backend không khởi động được")
        sys.exit(1)

    LOGGER.info("Dashboard: http://%s:%d", host, port)
    LOGGER.info("Nhấn Ctrl+C để dừng")
    try:
        backend.join()
    except KeyboardInterrupt:
        LOGGER.info("Dừng server")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description=f"{APP_TITLE} — Khởi động ứng dụng máy tính để bàn"
    )
    parser.add_argument(
        "--no-gui", action="store_true",
        help="Chạy headless (không mở cửa sổ PyWebView)",
    )
    parser.add_argument(
        "--port", type=int, default=0,
        help=f"Cổng cố định (mặc định: tự tìm trong dải {DEFAULT_PORT_START}-{DEFAULT_PORT_END})",
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
        help="Địa chỉ bind (mặc định: 127.0.0.1)",
    )
    args = parser.parse_args()

    port = args.port if args.port > 0 else find_free_port()
    LOGGER.info("Cổng được chọn: %d", port)

    if args.no_gui:
        launch_headless(args.host, port)
    else:
        launch_desktop(args.host, port)


if __name__ == "__main__":
    main()
