"""Plugin mẫu. Hook là hàm thường hoặc async; tham số scenario/run là tùy chọn.
Đổi tên tệp bắt đầu bằng "_" để tắt plugin."""
import logging

LOGGER = logging.getLogger("qa.plugin.dom_check")


async def on_page_loaded(page, scenario=None):
    title = await page.title()
    missing_alt = await page.evaluate("() => document.querySelectorAll('img:not([alt])').length")
    sid = scenario.id if scenario else "-"
    if not title.strip():
        LOGGER.warning("[%s] Trang không có <title>: %s", sid, page.url)
    if missing_alt:
        LOGGER.warning("[%s] %d ảnh thiếu alt: %s", sid, missing_alt, page.url)


async def on_run_finished(run, scenario=None):
    if run["status"] != "ok":
        LOGGER.warning("Lượt chạy lỗi: %s -> %s", run["url"], run["error_message"])
