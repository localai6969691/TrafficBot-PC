// Chạy trước mọi script của trang (context.add_init_script).
// Ví dụ: đánh dấu môi trường kiểm thử để frontend có thể bật/tắt tính năng.
window.__QA_ENV__ = { runner: 'synthetic-qa-orchestrator', ts: Date.now() };
