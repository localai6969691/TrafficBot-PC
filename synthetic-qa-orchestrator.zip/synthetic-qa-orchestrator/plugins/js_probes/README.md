# `plugins/js_probes/` — Kho Script JS Tính Toán Token (Phase 10.4)

Thư mục này chứa các tệp `.js` độc lập dùng để tính toán các giá trị phía
client (Proof-of-Work, chữ ký session, token xác thực...) **mà không cần
khởi động toàn bộ trình duyệt Playwright** — tiết kiệm RAM/CPU đáng kể khi
chỉ cần giải một phép tính đơn giản trước khi gửi request HTTP.

## Cách dùng

1. Lấy đoạn JS cần chạy từ trang web mục tiêu (DevTools → Sources, hoặc từ
   response JS bundle) và lưu thành tệp `.js` riêng trong thư mục này.
2. Gọi từ Python:

   ```python
   from js_sandbox_probe import run_js_probe_file

   result = await run_js_probe_file(
       "ten_file.js",
       persona={"user_agent": "...", "platform": "Win32", "language": "vi-VN"},
   )
   print(result["output"])
   ```

3. Hoặc qua API: `POST /api/admin/js-probes/run` với body
   `{"filename": "ten_file.js", "persona": {...}}` — xem tab **Khả năng**
   trong Dashboard (mục "Chạy JS Probe từ thư mục plugins/js_probes/").

## Bề mặt API có sẵn trong script (Minimal Browser Surface Shim)

Script của bạn chạy bên trong Node.js `vm` context đã được nạp sẵn:

| Đối tượng | Thuộc tính/phương thức có sẵn |
|---|---|
| `navigator` | `userAgent`, `platform`, `language`, `languages`, `hardwareConcurrency`, `deviceMemory`, `webdriver` (luôn `false`) |
| `screen` | `width`, `height`, `availWidth`, `availHeight`, `colorDepth`, `pixelDepth` |
| `performance` | `now()`, `timeOrigin` |
| `crypto` | `getRandomValues(typedArray)`, `subtle.digest(algo, data)` |
| `document` | `createElement()`, `querySelector()`, `cookie`, `readyState`, `location` (bản tối giản, không có layout thật) |
| `window` | tham chiếu tới tất cả object trên + `localStorage`/`sessionStorage` (in-memory), `btoa`/`atob` |
| `require(...)` | **CÓ SẴN** — dùng được các module Node chuẩn (`crypto`, `buffer`...) |

Các giá trị `navigator.*`/`screen.*` được đồng bộ theo tham số `persona` bạn
truyền vào (khớp với Persona/Environment đang chạy kịch bản), để kết quả tính
toán nhất quán với "danh tính trình duyệt" đang dùng ở các tầng khác
(xem `engine_router.rotate_protocol_profile()`).

## Giới hạn đã biết

- **Không có layout/CSSOM thật** — `document.createElement()` trả về object
  giả lập rất tối giản, không render được gì. Nếu script cần đọc kích thước
  phần tử DOM thật (`getBoundingClientRect`...), dùng Playwright thật thay vì
  probe này.
- **Không có `fetch`/network** — đây là chủ đích (cô lập hoàn toàn, không cho
  script gọi mạng ra ngoài trong lúc tính toán). Nếu script cố `fetch(...)`,
  sẽ gặp `ReferenceError`.
- **`crypto.subtle.digest` chỉ hỗ trợ SHA-256/1/384/512** qua Node `crypto`
  built-in (không hỗ trợ các thuật toán WebCrypto khác như AES-GCM).
- Giá trị trả về nên là `console.log(JSON.stringify(...))` ở cuối script để
  `run_js_probe_file()` parse được kết quả.
- Tên tệp không được chứa `..` hoặc đường dẫn tuyệt đối (chặn path traversal).

## Ví dụ có sẵn

`example_token.js` — tính một token SHA-256 mẫu từ `navigator.userAgent` +
giá trị ngẫu nhiên từ `crypto.getRandomValues()`. Dùng làm khung sườn để viết
probe thật.
