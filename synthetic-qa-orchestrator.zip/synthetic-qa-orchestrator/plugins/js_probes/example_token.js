// Ví dụ probe: tính một "session token" giả lập dựa trên navigator.userAgent
// + một giá trị random từ crypto.getRandomValues (khớp bề mặt API DOM shim
// ở Phase 10.4). Dùng làm mẫu để viết probe thật lấy từ trang web mục tiêu.
(function () {
  const rand = new Uint8Array(8);
  crypto.getRandomValues(rand);
  const randHex = Array.from(rand).map(b => b.toString(16).padStart(2, '0')).join('');
  const crypto2 = require('crypto');
  const token = crypto2.createHash('sha256')
    .update(navigator.userAgent + randHex + performance.now())
    .digest('hex');
  console.log(JSON.stringify({ token, platform: navigator.platform, lang: navigator.language }));
})();
