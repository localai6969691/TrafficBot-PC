"""Kiểm định cổng mạng (gateway) hàng loạt: độ trễ, Exit IP, quốc gia/ISP/ASN,
và tự động khớp timezone_id/locale cho BrowserContext theo vị trí thực của gateway.

GIỚI HẠN ĐÃ BIẾT (xem PROJECT.md):
* Không có cơ sở dữ liệu GeoIP offline đi kèm (MaxMind GeoLite2 cần đăng ký giấy phép
  riêng và nặng vài chục MB, không phù hợp để bundle vào bản portable). Module tra cứu
  qua dịch vụ công khai `ip-api.com` (miễn phí, giới hạn ~45 request/phút, KHÔNG dùng
  cho mục đích thương mại theo điều khoản của họ) - nghĩa là việc này cần Internet và
  có giới hạn tốc độ riêng, tách biệt với gateway đang được kiểm thử. Muốn dùng offline
  thật, cần tự tải GeoLite2-City.mmdb và đổi `_geo_lookup` sang đọc bằng thư viện
  `geoip2` - CHƯA triển khai.
* "ASN/ISP" lấy từ trường `isp`/`as` của ip-api.com - là tên ISP tự khai báo của dịch vụ
  này, có thể không khớp 100% với ASN đăng ký chính thức (RDAP/WHOIS) trong mọi trường hợp.
* Ánh xạ quốc gia -> locale mặc định (`_COUNTRY_LOCALE`) chỉ phủ các quốc gia phổ biến;
  quốc gia không có trong bảng sẽ dùng "en-US".
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from config_loader import Environment, GatewayEntry

LOGGER = logging.getLogger("qa.gwvalidator")

_COUNTRY_LOCALE = {
    "VN": "vi-VN", "US": "en-US", "GB": "en-GB", "JP": "ja-JP", "KR": "ko-KR",
    "CN": "zh-CN", "TW": "zh-TW", "DE": "de-DE", "FR": "fr-FR", "ES": "es-ES",
    "IT": "it-IT", "BR": "pt-BR", "PT": "pt-PT", "RU": "ru-RU", "IN": "en-IN",
    "TH": "th-TH", "SG": "en-SG", "ID": "id-ID", "MY": "ms-MY", "PH": "en-PH",
    "AU": "en-AU", "CA": "en-CA", "NL": "nl-NL", "SE": "sv-SE", "PL": "pl-PL",
    "TR": "tr-TR", "MX": "es-MX", "AR": "es-AR", "SA": "ar-SA", "AE": "ar-AE",
}


@dataclass
class GatewayCheckConfig:
    concurrency: int = 25
    timeout_s: float = 5.0
    exit_ip_url: str = "https://api.ipify.org?format=json"
    geoip_enabled: bool = True
    geoip_url_template: str = "http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,city,isp,as,timezone"
    geoip_timeout_s: float = 5.0
    # Phase 11.2: Bộ Lọc Chất Lượng Cổng Kết Nối Đa Tầng
    header_check_enabled: bool = False
    # httpbin.org/headers phản hồi JSON {"headers": {...}} - echo nguyên văn mọi
    # header mà gateway (hoặc máy chủ trung gian) CHÈN THÊM vào request, giúp
    # phát hiện proxy "transparent"/"anonymous" (so với "elite" không chèn gì).
    header_check_url: str = "https://httpbin.org/headers"
    datacenter_only_filter: bool = False   # True = loại bỏ mọi gateway infra_class="datacenter"
    max_latency_ms: Optional[float] = None  # None = không giới hạn (thanh trượt độ trễ trên UI)


@dataclass
class GatewayCheckResult:
    gateway: str
    region: str
    healthy: bool
    latency_ms: Optional[float] = None
    exit_ip: Optional[str] = None
    country: Optional[str] = None
    country_code: Optional[str] = None
    city: Optional[str] = None
    isp: Optional[str] = None
    asn: Optional[str] = None
    timezone_id: Optional[str] = None
    locale: Optional[str] = None
    error: Optional[str] = None
    # Phase 11.2
    infra_class: Optional[str] = None       # "isp_residential" | "mobile" | "datacenter" | None (chưa phân loại)
    anonymity_level: Optional[str] = None   # "elite" | "anonymous" | "transparent" | None (chưa kiểm tra)
    leak_headers: list = field(default_factory=list)  # tên các header lộ IP gốc (nếu có)
    passes_quality_filter: bool = True      # False = bị loại bởi datacenter_only_filter/max_latency_ms

    def to_db_row(self, checked_at: str) -> dict[str, Any]:
        return dict(gateway=self.gateway, region=self.region, checked_at=checked_at,
                    healthy=int(self.healthy), latency_ms=self.latency_ms, exit_ip=self.exit_ip,
                    country=self.country, city=self.city, isp=self.isp, asn=self.asn,
                    timezone_id=self.timezone_id, locale=self.locale, error=self.error,
                    infra_class=self.infra_class, anonymity_level=self.anonymity_level)

    def localized_environment(self, base: Environment) -> Environment:
        """Trả về bản sao Environment với timezone_id/locale theo vị trí thực của gateway
        (Geo-Matched Localization). Giữ nguyên các trường khác của base."""
        import dataclasses

        overrides: dict[str, Any] = {}
        if self.timezone_id:
            overrides["timezone_id"] = self.timezone_id
        if self.locale:
            overrides["locale"] = self.locale
        return dataclasses.replace(base, **overrides) if overrides else base


class GatewayValidator:
    def __init__(self, cfg: GatewayCheckConfig) -> None:
        self.cfg = cfg

    async def check_all(self, entries: list[GatewayEntry]) -> list[GatewayCheckResult]:
        sem = asyncio.Semaphore(max(1, self.cfg.concurrency))

        async def bound(entry: GatewayEntry) -> GatewayCheckResult:
            async with sem:
                return await self.check_one(entry)

        return list(await asyncio.gather(*(bound(e) for e in entries)))

    async def check_one(self, entry: GatewayEntry) -> GatewayCheckResult:
        if not entry.browser_compatible:
            LOGGER.debug("Gateway %s dùng SOCKS5 có xác thực - vẫn kiểm tra được qua httpx", entry.masked)
        try:
            import httpx
        except ImportError:
            return GatewayCheckResult(entry.masked, entry.region, False, error="Chưa cài httpx")

        t0 = time.perf_counter()
        try:
            async with httpx.AsyncClient(proxy=entry.url, timeout=self.cfg.timeout_s) as client:
                resp = await client.get(self.cfg.exit_ip_url)
                resp.raise_for_status()
                exit_ip = resp.json().get("ip")
        except Exception as exc:  # noqa: BLE001
            return GatewayCheckResult(entry.masked, entry.region, False,
                                      error=f"{type(exc).__name__}: {exc}")
        latency_ms = round((time.perf_counter() - t0) * 1000, 1)
        result = GatewayCheckResult(entry.masked, entry.region, True, latency_ms=latency_ms, exit_ip=exit_ip)

        if self.cfg.geoip_enabled and exit_ip:
            await self._enrich_geoip(result, exit_ip)
            result.infra_class = classify_infrastructure(result.isp, result.asn)

        if self.cfg.header_check_enabled:
            await self._check_header_transparency(result, entry)

        # Mục 2.2: bộ lọc chất lượng - đánh dấu passes_quality_filter=False thay
        # vì loại thẳng khỏi kết quả, để UI vẫn hiển thị LÝ DO bị loại cho người
        # dùng thấy (thay vì biến mất không giải thích).
        reasons: list[str] = []
        if self.cfg.datacenter_only_filter and result.infra_class == "datacenter":
            reasons.append("infra_class=datacenter (đã bật lọc chỉ-ISP/residential)")
        if (self.cfg.max_latency_ms is not None and result.latency_ms is not None
                and result.latency_ms > self.cfg.max_latency_ms):
            reasons.append(f"latency {result.latency_ms:.0f}ms > giới hạn {self.cfg.max_latency_ms:.0f}ms")
        if self.cfg.header_check_enabled and result.anonymity_level == "transparent":
            reasons.append(f"lộ header gốc: {', '.join(result.leak_headers)}")
        if reasons:
            result.passes_quality_filter = False
            LOGGER.info("Gateway %s KHÔNG đạt chuẩn: %s", entry.masked, "; ".join(reasons))
        return result

    async def _check_header_transparency(self, result: GatewayCheckResult, entry: GatewayEntry) -> None:
        """Mục 2.2 - Header Transparency Audit: gửi request QUA gateway tới một
        dịch vụ echo header (mặc định httpbin.org/headers) và kiểm tra server
        đích thực sự nhận được những header nào - phát hiện proxy "transparent"
        (tự chèn X-Forwarded-For/Via/...) khác với "elite" (không chèn gì)."""
        try:
            import httpx

            async with httpx.AsyncClient(proxy=entry.url, timeout=self.cfg.timeout_s) as client:
                resp = await client.get(self.cfg.header_check_url)
                resp.raise_for_status()
                echoed = resp.json().get("headers", {})
            result.anonymity_level, result.leak_headers = classify_anonymity(echoed)
        except Exception as exc:  # noqa: BLE001 - không được làm hỏng kiểm tra chính
            LOGGER.debug("Header transparency check lỗi cho %s: %s", entry.masked, exc)

    async def _enrich_geoip(self, result: GatewayCheckResult, ip: str) -> None:
        """Tra cứu quốc gia/thành phố/ISP/timezone qua ip-api.com - KHÔNG đi qua gateway
        (tra cứu bằng kết nối Internet trực tiếp của máy chạy runner)."""
        try:
            import httpx

            async with httpx.AsyncClient(timeout=self.cfg.geoip_timeout_s) as client:
                resp = await client.get(self.cfg.geoip_url_template.format(ip=ip))
                data = resp.json()
            if data.get("status") != "success":
                LOGGER.debug("GeoIP tra cứu %s thất bại: %s", ip, data.get("message"))
                return
            result.country, result.country_code = data.get("country"), data.get("countryCode")
            result.city, result.isp, result.asn = data.get("city"), data.get("isp"), data.get("as")
            result.timezone_id = data.get("timezone")
            result.locale = _COUNTRY_LOCALE.get(result.country_code or "", "en-US")
        except Exception as exc:  # noqa: BLE001 - GeoIP là phần bổ sung, không được làm hỏng kiểm tra chính
            LOGGER.debug("GeoIP lỗi cho %s: %s", ip, exc)


# ---------------------------------------------------------------------------
# Phase 11.2: Phân loại hạ tầng mạng (ASN & Infrastructure Classification)
# ---------------------------------------------------------------------------
# Heuristic dựa trên chuỗi "isp"/"as" trả về từ ip-api.com (KHÔNG phải tra cứu
# ASN chính thức qua RDAP/WHOIS - xem giới hạn đã ghi ở đầu file). Đủ dùng cho
# mục đích lọc "tránh né Datacenter ASN rõ ràng" thực tế hàng ngày.
_DATACENTER_KEYWORDS = (
    "amazon", "aws", "ec2", "google cloud", "google llc", "gcp", "digitalocean",
    "hetzner", "ovh", "linode", "akamai", "cloudflare", "microsoft azure",
    "azure", "vultr", "scaleway", "contabo", "oracle cloud", "alibaba cloud",
    "tencent cloud", "choopa", "leaseweb", "online s.a.s", "m247", "datacamp",
    "server", "hosting", "colocation", "data center", "datacenter",
)
_MOBILE_KEYWORDS = (
    "mobile", "wireless", "cellular", "lte", "3g", "4g", "5g", "gsm",
    "viettel mobile", "vinaphone", "mobifone", "t-mobile", "verizon wireless",
    "at&t mobility", "vodafone", "telstra mobile",
)


def classify_infrastructure(isp: Optional[str], asn: Optional[str]) -> str:
    """Phân loại hạ tầng mạng thành 3 nhóm dựa trên tên ISP/ASN (chữ thường,
    khớp từ khóa - best-effort, xem giới hạn module). Trả về:
    "datacenter" | "mobile" | "isp_residential" (mặc định khi không khớp gì)."""
    text = f"{isp or ''} {asn or ''}".lower()
    if any(kw in text for kw in _DATACENTER_KEYWORDS):
        return "datacenter"
    if any(kw in text for kw in _MOBILE_KEYWORDS):
        return "mobile"
    return "isp_residential"


# Các tên header (chữ thường) làm lộ thông tin máy khách/gốc thật qua proxy.
_LEAK_HEADER_NAMES = ("x-forwarded-for", "via", "forwarded", "client-ip",
                      "x-real-ip", "x-proxy-id", "proxy-connection")


def classify_anonymity(echoed_headers: dict[str, str]) -> tuple[str, list[str]]:
    """Phân loại độ ẩn danh dựa trên header mà server đích THỰC SỰ NHẬN ĐƯỢC
    (qua dịch vụ echo như httpbin.org/headers) - nếu proxy tự chèn thêm bất kỳ
    header nào trong `_LEAK_HEADER_NAMES`, coi là "transparent" (lộ gốc).
    Không chèn gì thêm khả nghi -> "elite". Có header nhưng không phải nhóm
    leak rõ ràng (vd. thêm "X-Cache") -> "anonymous" (ẩn danh nhưng để lại dấu
    vết là có qua proxy, dù không lộ IP/host gốc)."""
    lower_keys = {k.lower() for k in echoed_headers.keys()}
    leaked = [k for k in _LEAK_HEADER_NAMES if k in lower_keys]
    if leaked:
        return "transparent", leaked
    # Header tiêu chuẩn mà client luôn gửi (không tính là dấu hiệu proxy)
    standard = {"host", "accept", "accept-encoding", "accept-language",
                "user-agent", "connection", "x-amzn-trace-id"}
    extra = lower_keys - standard
    return ("anonymous" if extra else "elite"), []


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")
