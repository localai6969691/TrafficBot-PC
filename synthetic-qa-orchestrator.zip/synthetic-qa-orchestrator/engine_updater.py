"""Phase 11.4 — Trình Tích Hợp Nhân Trình Duyệt Mã Nguồn Mở Sẵn Có.

Thay thế quy trình biên dịch mã nguồn phức tạp (Phase 10.1 -
`build_custom_engine.yml`, tốn hàng giờ CI) bằng cơ chế ĐƠN GIẢN HƠN: tự động
tải bản phát hành NHỊ PHÂN đã build sẵn từ GitHub Releases API của các dự án
trình duyệt mã nguồn mở hỗ trợ kiểm thử tự động (mặc định: Camoufox), giải nén
đúng theo hệ điều hành máy chủ hiện tại, và cập nhật `executable_path` vào DB.

Đây là phần lõi dùng chung bởi:
- Nút "Tải/Cập nhật Nhân Trình Duyệt Từ GitHub Release" (Phase 10, tab Quản trị
  → Plugins & Extensions).
- Nút "Tải Nhân Trình Duyệt Tối Ưu (Linux/Windows)" (Phase 11, tab Extensions).

Cả 2 nút gọi CÙNG một hàm `download_and_install()` ở đây - tránh trùng lặp
logic tải/giải nén/dò executable giữa `admin_api.py` Phase 10 và Phase 11.
"""
from __future__ import annotations

import io
import logging
import os
import platform
import tarfile
import zipfile
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.engine_updater")

#: Thực thi được công nhận là "trình duyệt" sau khi giải nén (không phân biệt
#: hoa/thường khi so khớp tên tệp).
_EXECUTABLE_NAMES = (
    "firefox", "camoufox", "chrome", "chromium", "chromium-browser",
    "firefox.exe", "camoufox.exe", "chrome.exe", "chromium.exe",
)

#: Từ khóa trong tên asset GitHub Release ứng với mỗi hệ điều hành.
_OS_ASSET_MARKERS: dict[str, list[str]] = {
    "Linux": ["linux"],
    "Windows": ["win64", "win32", "windows"],
    "Darwin": ["macos", "osx", "mac"],
}


def current_os_markers() -> list[str]:
    return _OS_ASSET_MARKERS.get(platform.system(), ["linux"])


def pick_asset(assets: list[dict[str, Any]], marker_override: Optional[str] = None) -> Optional[dict[str, Any]]:
    """Chọn asset khớp hệ điều hành hiện tại (hoặc `marker_override` nếu người
    dùng tự chỉ định chuỗi khớp tên tệp, vd. "linux" / "win64" / "aarch64")."""
    markers = [marker_override.lower()] if marker_override else current_os_markers()
    for a in assets:
        name = a.get("name", "").lower()
        if any(m in name for m in markers):
            return a
    return None


def extract_archive(raw: bytes, asset_name: str, dest_dir: Path) -> Path:
    """Giải nén `raw` (nội dung tải về) vào `dest_dir/<tên không đuôi>`.
    Hỗ trợ .zip và .tar.gz/.tgz - rơi vào ghi file trần nếu không nhận diện
    được định dạng (một số release phát hành binary đơn lẻ không nén)."""
    stem = asset_name
    for suffix in (".tar.gz", ".tgz", ".zip"):
        if stem.lower().endswith(suffix):
            stem = stem[: -len(suffix)]
            break
    extract_to = dest_dir / stem
    lname = asset_name.lower()
    if lname.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            zf.extractall(extract_to)
    elif lname.endswith((".tar.gz", ".tgz")):
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tf:
            tf.extractall(extract_to)
    else:
        extract_to.mkdir(parents=True, exist_ok=True)
        (extract_to / asset_name).write_bytes(raw)
        # Binary trần tải về thường cần quyền thực thi trên Linux/macOS.
        try:
            os.chmod(extract_to / asset_name, 0o755)
        except OSError:
            pass
    return extract_to


def find_executable(extracted_dir: Path) -> Optional[Path]:
    """Dò tìm tệp thực thi trình duyệt bên trong thư mục vừa giải nén
    (best-effort - khớp theo TÊN TỆP, không đọc nội dung binary)."""
    for p in extracted_dir.rglob("*"):
        if p.is_file() and p.name.lower() in _EXECUTABLE_NAMES:
            return p
    return None


async def fetch_release_metadata(repo: str, tag: str = "latest") -> dict[str, Any]:
    """Gọi GitHub Releases API, trả về JSON release (gồm trường "assets")."""
    import httpx

    api_url = (f"https://api.github.com/repos/{repo}/releases/latest" if tag == "latest"
               else f"https://api.github.com/repos/{repo}/releases/tags/{tag}")
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        r = await client.get(api_url, headers={"Accept": "application/vnd.github+json"})
        r.raise_for_status()
        return r.json()


async def download_and_install(
    repo: str,
    runtime_browsers_dir: Path,
    tag: str = "latest",
    asset_marker: Optional[str] = None,
) -> dict[str, Any]:
    """Quy trình đầy đủ 1-click: metadata -> chọn asset theo OS -> tải -> giải
    nén vào `runtime_browsers_dir` -> dò executable_path.

    Returns:
        dict: {
          "ok": bool, "repo": str, "tag": str, "asset": str, "size_mb": float,
          "extracted_to": str, "executable_path": str | None,
          "error": str | None, "available_assets": [str] (chỉ khi lỗi chọn asset),
        }

    KHÔNG tự ghi vào Database - caller (admin_api.py) chịu trách nhiệm gọi
    `db.aset_setting("browser_executable_path", result["executable_path"], ...)`
    nếu muốn áp dụng ngay, để module này không phụ thuộc vào `database.py`
    (giữ engine_updater.py độc lập, dễ test/tái sử dụng).
    """
    import httpx

    runtime_browsers_dir.mkdir(parents=True, exist_ok=True)
    try:
        release = await fetch_release_metadata(repo, tag)
    except httpx.HTTPStatusError as exc:
        return {"ok": False, "error": f"GitHub Releases API lỗi HTTP {exc.response.status_code}"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    assets = release.get("assets", [])
    if not assets:
        return {"ok": False, "error": f"Release '{release.get('tag_name', '?')}' không có asset nào"}

    chosen = pick_asset(assets, asset_marker)
    if not chosen:
        return {
            "ok": False,
            "error": f"Không tìm thấy asset khớp hệ điều hành {platform.system()}",
            "available_assets": [a["name"] for a in assets][:20],
        }

    try:
        async with httpx.AsyncClient(timeout=120, follow_redirects=True) as client:
            dl = await client.get(chosen["browser_download_url"], headers={"Accept": "application/octet-stream"})
            dl.raise_for_status()
            raw = dl.content
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"Tải asset thất bại: {type(exc).__name__}: {exc}"}

    try:
        extracted_to = extract_archive(raw, chosen["name"], runtime_browsers_dir)
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"Giải nén thất bại: {type(exc).__name__}: {exc}"}

    exe = find_executable(extracted_to)
    LOGGER.info("engine_updater: đã cài %s từ %s vào %s (executable=%s)",
               chosen["name"], repo, extracted_to, exe)
    return {
        "ok": True, "repo": repo, "tag": release.get("tag_name"),
        "asset": chosen["name"], "size_mb": round(len(raw) / 1_048_576, 1),
        "extracted_to": str(extracted_to),
        "executable_path": str(exe) if exe else None,
        "error": None,
    }
