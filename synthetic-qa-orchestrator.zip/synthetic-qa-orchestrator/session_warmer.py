"""Quy Trình Nuôi Dưỡng Trạng Thái Phiên (Automated Session Warming Lifecycle).

Hai chế độ:
  1. Multi-Day Warming Campaign — điều hướng profile qua nhiều trang trong N ngày,
     xây dựng lịch sử cookie/cache tự nhiên, nâng Trust Score.
  2. Pre-Task Session Priming  — visit nhanh trang chủ target 5-10s trước khi
     thực thi kịch bản chính để khởi tạo session cookie hợp lệ.

Trust Score (0–100):
  Dựa trên: số domain đã thăm, số cookie tích lũy, số ngày hoạt động, referrer history.
  Lưu vào bảng `profile_warmth` trong SQLite.

GIỚI HẠN ĐÃ BIẾT:
  - Cookie/Storage được lưu qua Playwright storage_state → chỉ lưu được HTTP cookies
    và LocalStorage. IndexedDB và SessionStorage KHÔNG persist (giới hạn Playwright API).
  - Trust Score là chỉ số nội bộ, không phản ánh score của website mục tiêu.
    Đây là ước tính heuristic từ metadata phiên.
  - Warming campaign dùng Chromium headless, không có GPU rendering — một số site
    dùng GPU fingerprint để phân biệt. Kết hợp với persona_manager để tốt hơn.
  - Warm URLs mặc định là danh sách tĩnh; bổ sung bằng cách thêm vào warm_url_pool.
  - Không warm song song cùng 1 profile (data race trên storage file).
"""
from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.warmer")

# ---------------------------------------------------------------------------
# Default warm URL pool (chia theo domain phổ biến)
# ---------------------------------------------------------------------------
_DEFAULT_WARM_POOL: list[dict[str, Any]] = [
    # Tin tức
    {"url": "https://news.ycombinator.com",        "dwell_s": (8, 20),  "scroll": True,  "category": "news"},
    {"url": "https://www.reddit.com/r/technology",  "dwell_s": (10, 25), "scroll": True,  "category": "social"},
    {"url": "https://techcrunch.com",               "dwell_s": (5, 15),  "scroll": True,  "category": "news"},
    # Tìm kiếm (không thực hiện search, chỉ visit trang chủ)
    {"url": "https://www.google.com",               "dwell_s": (3, 8),   "scroll": False, "category": "search"},
    {"url": "https://www.bing.com",                 "dwell_s": (3, 7),   "scroll": False, "category": "search"},
    # Developer
    {"url": "https://github.com/explore",           "dwell_s": (8, 20),  "scroll": True,  "category": "tech"},
    {"url": "https://stackoverflow.com",            "dwell_s": (5, 15),  "scroll": True,  "category": "tech"},
    {"url": "https://dev.to",                       "dwell_s": (5, 12),  "scroll": True,  "category": "tech"},
    # Shopping / General
    {"url": "https://www.amazon.com",               "dwell_s": (5, 12),  "scroll": True,  "category": "shop"},
    {"url": "https://www.wikipedia.org",            "dwell_s": (8, 20),  "scroll": True,  "category": "info"},
    # VN-specific
    {"url": "https://vnexpress.net",                "dwell_s": (5, 15),  "scroll": True,  "category": "news_vi"},
    {"url": "https://dantri.com.vn",                "dwell_s": (5, 12),  "scroll": True,  "category": "news_vi"},
]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class WarmResult:
    profile_id: str
    urls_visited: int = 0
    cookies_gained: int = 0
    errors: int = 0
    duration_s: float = 0.0
    trust_score_delta: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class WarmingConfig:
    """Cấu hình một chiến dịch warming."""
    profile_ids: list[str]
    days: int = 3                           # số ngày chạy
    urls_per_day: int = 5                   # số URL mỗi ngày
    warm_pool: list[dict[str, Any]] = field(default_factory=lambda: list(_DEFAULT_WARM_POOL))
    target_url: Optional[str] = None       # thêm vào pool nếu muốn warm trang mục tiêu
    headless: bool = True
    max_concurrency: int = 2                # tối đa 2 profile song song
    pre_task_dwell_s: float = 7.0          # dwell cho pre-task priming

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "WarmingConfig":
        cfg = cls(profile_ids=d.get("profile_ids", []))
        for k in ("days", "urls_per_day", "headless", "max_concurrency",
                  "pre_task_dwell_s", "target_url"):
            if k in d:
                setattr(cfg, k, d[k])
        if d.get("extra_urls"):
            cfg.warm_pool = cfg.warm_pool + [
                {"url": u, "dwell_s": (5, 15), "scroll": True, "category": "custom"}
                for u in d["extra_urls"]
            ]
        return cfg


# ---------------------------------------------------------------------------
# Session Trust Scorer
# ---------------------------------------------------------------------------

def compute_trust_score(
    domains_visited: int,
    cookies_count: int,
    days_active: int,
    has_referrer_history: bool,
) -> float:
    """Tính Trust Score (0-100) dựa trên metadata phiên."""
    score = 0.0
    # Domains (max 30 pts)
    score += min(30, domains_visited * 3)
    # Cookies (max 25 pts)
    score += min(25, cookies_count * 0.5)
    # Days (max 30 pts)
    score += min(30, days_active * 10)
    # Referrer history (15 pts bonus)
    if has_referrer_history:
        score += 15
    return round(min(100.0, score), 1)


# ---------------------------------------------------------------------------
# SessionWarmer
# ---------------------------------------------------------------------------

class SessionWarmer:
    """Nuôi dưỡng cookie/storage cho các profile theo lịch."""

    def __init__(self, profiles_root: Path, db: Optional[Database] = None) -> None:
        self.profiles_root = profiles_root
        self.db = db
        self._running: set[str] = set()     # profile IDs đang warm

    # ------------------------------------------------------------------
    # Pre-task priming (nhanh, chạy trước mỗi task)
    # ------------------------------------------------------------------

    async def prime_session(
        self,
        profile_id: str,
        target_url: str,
        dwell_s: float = 7.0,
        headless: bool = True,
    ) -> WarmResult:
        """Visit target_url trong vài giây để khởi tạo session cookie."""
        result = WarmResult(profile_id=profile_id)
        storage_path = self.profiles_root / profile_id / "storage_state.json"

        try:
            from playwright.async_api import async_playwright
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(
                    headless=headless,
                    args=["--disable-blink-features=AutomationControlled",
                          "--no-first-run"],
                )
                ctx_opts: dict[str, Any] = {}
                if storage_path.exists():
                    ctx_opts["storage_state"] = str(storage_path)

                context = await browser.new_context(**ctx_opts)
                page = await context.new_page()

                t0 = time.perf_counter()
                await page.goto(target_url, wait_until="domcontentloaded", timeout=20_000)

                # Dwell + scroll nhẹ
                await asyncio.sleep(dwell_s * 0.4)
                await page.evaluate("window.scrollBy(0, Math.random()*300+100)")
                await asyncio.sleep(dwell_s * 0.6)

                # Lưu storage
                storage_path.parent.mkdir(parents=True, exist_ok=True)
                await context.storage_state(path=str(storage_path))
                state = json.loads(storage_path.read_text())
                result.cookies_gained = len(state.get("cookies", []))
                result.urls_visited = 1
                result.duration_s = round(time.perf_counter() - t0, 1)

                await browser.close()
                LOGGER.info("prime '%s': %s cookies, %.1fs",
                            profile_id, result.cookies_gained, result.duration_s)
        except Exception as exc:
            result.errors += 1
            LOGGER.warning("prime '%s' lỗi: %s", profile_id, exc)
        return result

    # ------------------------------------------------------------------
    # Multi-day warming campaign
    # ------------------------------------------------------------------

    async def run_campaign(self, cfg: WarmingConfig) -> list[WarmResult]:
        """Chạy warming campaign. Mỗi profile N ngày × M URL."""
        semaphore = asyncio.Semaphore(cfg.max_concurrency)
        tasks = [
            self._warm_profile(pid, cfg, semaphore)
            for pid in cfg.profile_ids
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        out: list[WarmResult] = []
        for pid, r in zip(cfg.profile_ids, results):
            if isinstance(r, Exception):
                LOGGER.error("campaign '%s' lỗi: %s", pid, r)
                out.append(WarmResult(profile_id=pid, errors=1))
            else:
                out.append(r)
        return out

    async def _warm_profile(
        self,
        profile_id: str,
        cfg: WarmingConfig,
        semaphore: asyncio.Semaphore,
    ) -> WarmResult:
        async with semaphore:
            if profile_id in self._running:
                LOGGER.warning("warmer: '%s' đang chạy, bỏ qua", profile_id)
                return WarmResult(profile_id=profile_id)

            self._running.add(profile_id)
            result = WarmResult(profile_id=profile_id)
            storage_path = self.profiles_root / profile_id / "storage_state.json"
            storage_path.parent.mkdir(parents=True, exist_ok=True)

            try:
                from playwright.async_api import async_playwright

                # Chọn URL pool cho campaign
                pool = list(cfg.warm_pool)
                if cfg.target_url:
                    pool.append({"url": cfg.target_url, "dwell_s": (8, 15),
                                 "scroll": True, "category": "target"})

                total_urls = cfg.days * cfg.urls_per_day
                selected = random.choices(pool, k=min(total_urls, len(pool) * 3))
                random.shuffle(selected)

                async with async_playwright() as pw:
                    browser = await pw.chromium.launch(
                        headless=cfg.headless,
                        args=["--disable-blink-features=AutomationControlled",
                              "--no-first-run"],
                    )
                    ctx_opts: dict[str, Any] = {}
                    if storage_path.exists():
                        ctx_opts["storage_state"] = str(storage_path)

                    context = await browser.new_context(**ctx_opts)
                    page = await context.new_page()
                    t0 = time.perf_counter()

                    for entry in selected:
                        url = entry["url"]
                        dwell_range = entry.get("dwell_s", (5, 15))
                        do_scroll = entry.get("scroll", True)
                        try:
                            await page.goto(url, wait_until="domcontentloaded",
                                            timeout=15_000)
                            dwell = random.uniform(*dwell_range)
                            # Chia dwell thành đọc + cuộn + đọc tiếp
                            await asyncio.sleep(dwell * 0.3)
                            if do_scroll:
                                # Cuộn từ từ theo nhiều bước
                                for _ in range(random.randint(2, 4)):
                                    delta = random.randint(150, 400)
                                    await page.mouse.wheel(0, delta)
                                    await asyncio.sleep(random.uniform(0.5, 1.5))
                            await asyncio.sleep(dwell * 0.4)
                            result.urls_visited += 1
                        except Exception as exc:
                            result.errors += 1
                            LOGGER.debug("warmer '%s' lỗi %s: %s", profile_id, url, exc)
                        # Nghỉ giữa các URL (mô phỏng user thật)
                        await asyncio.sleep(random.uniform(2, 6))

                    # Lưu storage
                    await context.storage_state(path=str(storage_path))
                    state = json.loads(storage_path.read_text())
                    result.cookies_gained = len(state.get("cookies", []))
                    result.duration_s = round(time.perf_counter() - t0, 1)

                    # Tính trust score
                    domains = len(set(e["url"].split("/")[2] for e in selected))
                    result.trust_score_delta = compute_trust_score(
                        domains_visited=domains,
                        cookies_count=result.cookies_gained,
                        days_active=cfg.days,
                        has_referrer_history=True,
                    )

                    await browser.close()

                # Ghi DB
                if self.db:
                    await self.db.aset_profile_warmth(
                        profile_id=profile_id,
                        trust_score=result.trust_score_delta,
                        urls_visited=result.urls_visited,
                        cookies=result.cookies_gained,
                        warmed_at=result.timestamp,
                    )
                LOGGER.info("warmer '%s': %d URLs, %d cookies, score=%.1f (%.0fs)",
                            profile_id, result.urls_visited, result.cookies_gained,
                            result.trust_score_delta, result.duration_s)
            except Exception as exc:
                result.errors += 1
                LOGGER.error("warmer '%s' thất bại: %s", profile_id, exc)
            finally:
                self._running.discard(profile_id)

            return result

    async def get_warmth(self, profile_id: str) -> Optional[dict[str, Any]]:
        """Lấy thông tin warmth của profile từ DB."""
        if self.db:
            return await self.db.aget_profile_warmth(profile_id)
        return None

    def is_warming(self, profile_id: str) -> bool:
        return profile_id in self._running
