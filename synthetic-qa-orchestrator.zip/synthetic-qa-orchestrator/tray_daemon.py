r"""Chế Độ Hoạt Động Nền & Khay Hệ Thống (System Tray Daemon Mode).

Bốn thành phần:
  1. TrayDaemon      - biểu tượng khay hệ thống (pystray), menu chuột phải
  2. AutoStartManager - đăng ký/huỷ autostart Windows registry / macOS LaunchAgent
  3. UARegistry      - cập nhật danh sách User-Agent mới nhất từ nguồn công khai
  4. ProxyParser     - chuẩn hoá nhiều định dạng proxy, dedup, export

GIỚI HẠN:
  - pystray yêu cầu display (X11/Wayland/Quartz/Win32). Trên Linux headless server:
    cài Xvfb và set DISPLAY=:99 hoặc dùng pystray với backend 'dummy'.
    TrayDaemon.start() tự phát hiện nếu không có display và fallback về daemon-only mode
    (không có icon, chỉ chạy server).
  - Windows autostart: ghi vào HKCU\Software\Microsoft\Windows\CurrentVersion\Run.
    Yêu cầu Python chạy với quyền user thường (không cần admin).
  - macOS autostart: tạo ~/Library/LaunchAgents/com.qa-orchestrator.plist.
  - Linux autostart: tạo ~/.config/autostart/qa-orchestrator.desktop.
  - UARegistry cần mạng. Dùng nguồn whatismybrowser API và user-agents.net fallback.
  - ProxyParser hoàn toàn offline, không verify proxy.
"""
from __future__ import annotations

import asyncio
import logging
import os
import platform
import re
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

LOGGER = logging.getLogger("qa.tray")

# ---------------------------------------------------------------------------
# 1. System Tray Daemon
# ---------------------------------------------------------------------------

class TrayDaemon:
    """System tray icon với menu chuột phải để quản lý nhanh orchestrator."""

    def __init__(
        self,
        dashboard_url: str = "http://localhost:8880",
        icon_path: Optional[Path] = None,
        on_pause: Optional[Callable] = None,
        on_resume: Optional[Callable] = None,
        on_restart: Optional[Callable] = None,
        on_quit: Optional[Callable] = None,
    ) -> None:
        self.dashboard_url = dashboard_url
        self.icon_path = icon_path
        self._on_pause = on_pause
        self._on_resume = on_resume
        self._on_restart = on_restart
        self._on_quit = on_quit
        self._icon: Any = None
        self._paused = False
        self._thread: Optional[threading.Thread] = None

    def _make_image(self) -> Any:
        """Tạo icon 64×64 đơn giản nếu không có file icon."""
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (64, 64), color=(31, 111, 92))  # QA green
            draw = ImageDraw.Draw(img)
            draw.ellipse([8, 8, 56, 56], fill=(255, 255, 255))
            draw.text((22, 18), "QA", fill=(31, 111, 92))
            return img
        except ImportError:
            return None

    def _open_dashboard(self, icon: Any = None, item: Any = None) -> None:
        import webbrowser
        webbrowser.open(self.dashboard_url)

    def _toggle_pause(self, icon: Any = None, item: Any = None) -> None:
        self._paused = not self._paused
        label = "▶ Resume" if self._paused else "⏸ Pause all"
        LOGGER.info("tray: %s", "paused" if self._paused else "resumed")
        if self._paused and self._on_pause:
            self._on_pause()
        elif not self._paused and self._on_resume:
            self._on_resume()

    def _restart_workers(self, icon: Any = None, item: Any = None) -> None:
        LOGGER.info("tray: restart workers")
        if self._on_restart:
            self._on_restart()

    def _quit(self, icon: Any = None, item: Any = None) -> None:
        LOGGER.info("tray: quit")
        if self._icon:
            self._icon.stop()
        if self._on_quit:
            self._on_quit()
        else:
            os._exit(0)

    def start(self) -> bool:
        """Khởi động tray icon trong thread riêng. Trả False nếu không có display."""
        try:
            import pystray
            from pystray import MenuItem as Item, Menu
        except ImportError:
            LOGGER.warning("tray: pystray chưa cài — pip install pystray pillow")
            return False

        img = self._make_image()
        if img is None:
            LOGGER.warning("tray: Pillow chưa cài — không tạo được icon")
            return False

        try:
            menu = Menu(
                Item("🖥 Mở Dashboard", self._open_dashboard, default=True),
                Menu.SEPARATOR,
                Item("⏸ Tạm dừng tất cả", self._toggle_pause),
                Item("🔄 Khởi động lại Worker", self._restart_workers),
                Menu.SEPARATOR,
                Item("❌ Thoát an toàn", self._quit),
            )
            self._icon = pystray.Icon(
                "qa-orchestrator", img,
                "QA Orchestrator", menu)

            self._thread = threading.Thread(
                target=self._icon.run, daemon=True, name="tray-thread")
            self._thread.start()
            LOGGER.info("tray: đã khởi động tại %s", self.dashboard_url)
            return True
        except Exception as exc:
            LOGGER.warning("tray: không khởi động được (%s) — headless mode", exc)
            return False

    def stop(self) -> None:
        if self._icon:
            try:
                self._icon.stop()
            except Exception:
                pass

    def show_notification(self, title: str, message: str) -> None:
        """Hiển thị balloon notification (Windows/macOS)."""
        if self._icon:
            try:
                self._icon.notify(message, title)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# 2. AutoStart Manager
# ---------------------------------------------------------------------------

class AutoStartManager:
    """Đăng ký / huỷ autostart theo OS."""

    _APP_NAME = "QA-Orchestrator"
    _APP_KEY = "qa-orchestrator"

    def __init__(self, executable_path: Optional[Path] = None) -> None:
        self.exe = executable_path or Path(sys.executable)
        self._script = Path(sys.argv[0]) if sys.argv else Path("main.py")

    def _cmd_string(self) -> str:
        if getattr(sys, "frozen", False):  # Nuitka compiled
            return f'"{self.exe}"'
        return f'"{self.exe}" "{self._script}" serve'

    def enable(self) -> bool:
        """Đăng ký autostart. Trả True nếu thành công."""
        sys_name = platform.system()
        try:
            if sys_name == "Windows":
                return self._enable_windows()
            elif sys_name == "Darwin":
                return self._enable_macos()
            elif sys_name == "Linux":
                return self._enable_linux()
            else:
                LOGGER.warning("autostart: OS %s không được hỗ trợ", sys_name)
                return False
        except Exception as exc:
            LOGGER.error("autostart enable lỗi: %s", exc)
            return False

    def disable(self) -> bool:
        """Huỷ đăng ký autostart."""
        sys_name = platform.system()
        try:
            if sys_name == "Windows":
                return self._disable_windows()
            elif sys_name == "Darwin":
                return self._disable_macos()
            elif sys_name == "Linux":
                return self._disable_linux()
            return False
        except Exception as exc:
            LOGGER.error("autostart disable lỗi: %s", exc)
            return False

    def is_enabled(self) -> bool:
        sys_name = platform.system()
        try:
            if sys_name == "Windows":
                import winreg
                key = winreg.OpenKey(
                    winreg.HKEY_CURRENT_USER,
                    r"Software\Microsoft\Windows\CurrentVersion\Run")
                winreg.QueryValueEx(key, self._APP_NAME)
                winreg.CloseKey(key)
                return True
            elif sys_name == "Darwin":
                return self._plist_path().exists()
            elif sys_name == "Linux":
                return self._desktop_path().exists()
        except Exception:
            pass
        return False

    # Windows
    def _enable_windows(self) -> bool:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, self._APP_NAME, 0, winreg.REG_SZ, self._cmd_string())
        winreg.CloseKey(key)
        LOGGER.info("autostart: đã đăng ký Windows registry")
        return True

    def _disable_windows(self) -> bool:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE)
        try:
            winreg.DeleteValue(key, self._APP_NAME)
        except FileNotFoundError:
            pass
        winreg.CloseKey(key)
        return True

    # macOS
    def _plist_path(self) -> Path:
        return Path.home() / "Library/LaunchAgents" / f"com.{self._APP_KEY}.plist"

    def _enable_macos(self) -> bool:
        plist = self._plist_path()
        plist.parent.mkdir(parents=True, exist_ok=True)
        cmd_parts = self._cmd_string().replace('"', '').split()
        args_xml = "".join(f"<string>{a}</string>" for a in cmd_parts)
        plist.write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.{self._APP_KEY}</string>
  <key>ProgramArguments</key><array>{args_xml}</array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><false/>
</dict></plist>""")
        LOGGER.info("autostart: đã tạo macOS LaunchAgent %s", plist)
        return True

    def _disable_macos(self) -> bool:
        p = self._plist_path()
        if p.exists():
            p.unlink()
        return True

    # Linux
    def _desktop_path(self) -> Path:
        return Path.home() / ".config/autostart" / f"{self._APP_KEY}.desktop"

    def _enable_linux(self) -> bool:
        dp = self._desktop_path()
        dp.parent.mkdir(parents=True, exist_ok=True)
        dp.write_text(f"""[Desktop Entry]
Type=Application
Name=QA Orchestrator
Exec={self._cmd_string()}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
""")
        LOGGER.info("autostart: đã tạo Linux desktop entry %s", dp)
        return True

    def _disable_linux(self) -> bool:
        dp = self._desktop_path()
        if dp.exists():
            dp.unlink()
        return True


# ---------------------------------------------------------------------------
# 3. UA Registry
# ---------------------------------------------------------------------------

# UA templates tĩnh — dùng khi không có mạng
_STATIC_UA_POOL: list[dict[str, str]] = [
    {"os": "Windows", "browser": "Chrome",  "version": "131",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"},
    {"os": "Windows", "browser": "Edge",    "version": "131",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"},
    {"os": "Windows", "browser": "Firefox", "version": "132",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0"},
    {"os": "macOS",   "browser": "Chrome",  "version": "131",
     "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"},
    {"os": "macOS",   "browser": "Safari",  "version": "17",
     "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15"},
    {"os": "Linux",   "browser": "Chrome",  "version": "131",
     "ua": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"},
    {"os": "Android", "browser": "Chrome",  "version": "131",
     "ua": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Mobile Safari/537.36"},
    {"os": "iOS",     "browser": "Safari",  "version": "17",
     "ua": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1"},
    {"os": "Windows", "browser": "Chrome",  "version": "130",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"},
    {"os": "macOS",   "browser": "Firefox", "version": "131",
     "ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.1; rv:131.0) Gecko/20100101 Firefox/131.0"},
]


class UARegistry:
    """Quản lý và cập nhật danh sách User-Agent."""

    def __init__(self, cache_path: Optional[Path] = None) -> None:
        self._pool: list[dict[str, str]] = list(_STATIC_UA_POOL)
        self._cache_path = cache_path
        self._last_updated: Optional[float] = None
        if cache_path and cache_path.exists():
            self._load_cache()

    def _load_cache(self) -> None:
        try:
            import json
            data = json.loads(self._cache_path.read_text())
            if isinstance(data, list) and data:
                self._pool = data
                LOGGER.debug("ua_registry: loaded %d UAs from cache", len(self._pool))
        except Exception:
            pass

    def _save_cache(self) -> None:
        if self._cache_path:
            import json
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            self._cache_path.write_text(json.dumps(self._pool, indent=2))

    async def refresh(self) -> int:
        """Cập nhật danh sách UA từ nguồn công khai. Trả về số UA mới."""
        new_uas = await self._fetch_from_web()
        if new_uas:
            # Merge: giữ UA cũ + thêm UA mới chưa có
            existing = {u["ua"] for u in self._pool}
            added = [u for u in new_uas if u["ua"] not in existing]
            self._pool.extend(added)
            self._last_updated = time.time()
            self._save_cache()
            LOGGER.info("ua_registry: đã thêm %d UA mới (tổng %d)", len(added), len(self._pool))
            return len(added)
        return 0

    async def _fetch_from_web(self) -> list[dict[str, str]]:
        """Lấy UA mới từ nguồn công khai. Ưu tiên các nguồn đã xác nhận reachable:
        - registry.npmjs.org/user-agents (metadata chứa danh sách UA thực tế)
        - registry.npmjs.org/chromium-bidi (version Chromium mới nhất)
        - Fallback: jnrbsn.github.io/user-agents (nếu raw.githubusercontent reachable)
        """
        results: list[dict[str, str]] = []
        try:
            import httpx, json as _json, tarfile, io as _io

            # Danh sách UA mẫu được nhúng sẵn — không cần mạng để có baseline
            _BUILTIN_UAS: list[str] = [
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
            ]
            for ua_str in _BUILTIN_UAS:
                parsed = _parse_ua_string(ua_str)
                if parsed:
                    results.append(parsed)

            async with httpx.AsyncClient(timeout=12, follow_redirects=True) as c:
                # Nguồn 1: npm user-agents package — tải tarball, đọc JSON bên trong
                try:
                    meta_r = await c.get("https://registry.npmjs.org/user-agents/latest")
                    if meta_r.status_code == 200:
                        tarball_url = meta_r.json().get("dist", {}).get("tarball", "")
                        if tarball_url:
                            tgz_r = await c.get(tarball_url)
                            with tarfile.open(fileobj=_io.BytesIO(tgz_r.content), mode="r:gz") as tf:
                                for member in tf.getmembers():
                                    if member.name.endswith(".json") and "index" in member.name:
                                        raw = tf.extractfile(member)
                                        if raw:
                                            data = _json.loads(raw.read())
                                            entries = data if isinstance(data, list) else []
                                            for entry in entries[:80]:
                                                ua_str = entry.get("userAgent", "") if isinstance(entry, dict) else str(entry)
                                                parsed = _parse_ua_string(ua_str)
                                                if parsed:
                                                    results.append(parsed)
                                            break
                    LOGGER.debug("ua_registry: nguồn npm user-agents OK")
                except Exception as exc:
                    LOGGER.debug("ua_registry npm user-agents: %s", exc)

                # Nguồn 2: Chromium version từ Playwright npm meta → build UA string
                try:
                    r2 = await c.get("https://registry.npmjs.org/playwright/latest")
                    if r2.status_code == 200:
                        pdata = r2.json()
                        chromium_rev = pdata.get("playwright", {}).get("chromium_revision", "")
                        chrom_ver = pdata.get("dependencies", {}).get("@playwright/test", "")
                        if not chrom_ver:
                            # Extract version from browser metadata
                            browsers = pdata.get("playwright", {}).get("browsers", [])
                            for b in browsers:
                                if b.get("name") == "chromium":
                                    chrom_ver = b.get("chromiumVersion", "")
                                    break
                        if chrom_ver and chrom_ver.strip("^~"):
                            ua_chromium = (
                                f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                f"AppleWebKit/537.36 (KHTML, like Gecko) "
                                f"Chrome/{chrom_ver.strip('^~')} Safari/537.36"
                            )
                            parsed = _parse_ua_string(ua_chromium)
                            if parsed:
                                results.append(parsed)
                except Exception as exc:
                    LOGGER.debug("ua_registry playwright meta: %s", exc)

                # Nguồn 3: Fallback github raw (nếu có thể truy cập)
                try:
                    r3 = await c.get(
                        "https://jnrbsn.github.io/user-agents/user-agents.json",
                        timeout=6,
                    )
                    if r3.status_code == 200:
                        data = r3.json()
                        if isinstance(data, list):
                            for ua_str in data[:60]:
                                parsed = _parse_ua_string(ua_str)
                                if parsed:
                                    results.append(parsed)
                except Exception:
                    pass  # Nguồn này không always reachable

        except ImportError:
            pass

        # Deduplicate by UA string
        seen: set[str] = set()
        unique: list[dict[str, str]] = []
        for item in results:
            key = item.get("ua", "")
            if key and key not in seen:
                seen.add(key)
                unique.append(item)
        return unique

    def list(self) -> list[str]:
        """Trả về danh sách UA string (dùng cho /capabilities/ua-refresh)."""
        return [u.get("ua", "") for u in self._pool if u.get("ua")]

    def get_all(self, os_filter: Optional[str] = None,
                browser_filter: Optional[str] = None) -> list[dict[str, str]]:
        result = self._pool
        if os_filter:
            result = [u for u in result if u.get("os", "").lower() == os_filter.lower()]
        if browser_filter:
            result = [u for u in result if u.get("browser", "").lower() == browser_filter.lower()]
        return result

    def pick_random(self, **filters: str) -> Optional[dict[str, str]]:
        import random
        pool = self.get_all(**{k: v for k, v in filters.items()
                               if k in ("os_filter", "browser_filter")})
        return random.choice(pool) if pool else None

    def to_summary(self) -> dict[str, Any]:
        from collections import Counter
        os_counts = Counter(u.get("os", "?") for u in self._pool)
        br_counts = Counter(u.get("browser", "?") for u in self._pool)
        return {
            "total": len(self._pool),
            "by_os": dict(os_counts),
            "by_browser": dict(br_counts),
            "last_updated": self._last_updated,
        }


def _parse_ua_string(ua: str) -> Optional[dict[str, str]]:
    """Phân tích UA string → dict {os, browser, version, ua}."""
    if not ua or len(ua) < 20:
        return None
    os_name = "Unknown"
    browser = "Unknown"
    version = ""
    if "Android" in ua:
        os_name = "Android"
    elif "iPhone" in ua or "iPad" in ua:
        os_name = "iOS"
    elif "Macintosh" in ua or "Mac OS X" in ua:
        os_name = "macOS"
    elif "Windows" in ua:
        os_name = "Windows"
    elif "Linux" in ua:
        os_name = "Linux"
    if "Edg/" in ua:
        browser = "Edge"
        m = re.search(r"Edg/(\d+)", ua)
        version = m.group(1) if m else ""
    elif "Firefox/" in ua:
        browser = "Firefox"
        m = re.search(r"Firefox/(\d+)", ua)
        version = m.group(1) if m else ""
    elif "Chrome/" in ua:
        browser = "Chrome"
        m = re.search(r"Chrome/(\d+)", ua)
        version = m.group(1) if m else ""
    elif "Safari/" in ua and "Version/" in ua:
        browser = "Safari"
        m = re.search(r"Version/(\d+)", ua)
        version = m.group(1) if m else ""
    return {"os": os_name, "browser": browser, "version": version, "ua": ua}


# ---------------------------------------------------------------------------
# 4. Proxy Parser & Deduplicator
# ---------------------------------------------------------------------------

@dataclass
class ParsedProxy:
    protocol: str           # http | https | socks4 | socks5
    host: str
    port: int
    username: str = ""
    password: str = ""

    @property
    def url(self) -> str:
        if self.username:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"

    @property
    def key(self) -> str:
        return f"{self.host}:{self.port}"

    def to_dict(self) -> dict[str, Any]:
        return {"protocol": self.protocol, "host": self.host, "port": self.port,
                "username": self.username, "url": self.url}


_PROTO_MAP = {
    "http": "http", "https": "https",
    "socks4": "socks4", "socks5": "socks5",
    "socks4a": "socks4", "socks5h": "socks5",
}


def parse_proxy_line(line: str) -> Optional[ParsedProxy]:
    """Parse một dòng proxy theo bất kỳ định dạng phổ biến nào.

    Hỗ trợ:
      ip:port
      ip:port:user:pass
      protocol://ip:port
      protocol://user:pass@ip:port
      user:pass@ip:port
    """
    line = line.strip()
    if not line or line.startswith("#"):
        return None

    proto = "http"
    # Phát hiện protocol prefix
    m = re.match(r"^(https?|socks[45][ah]?)://(.+)$", line, re.I)
    if m:
        proto = _PROTO_MAP.get(m.group(1).lower(), "http")
        line = m.group(2)
    elif line.lower().startswith("socks5h://") or line.lower().startswith("socks5://"):
        proto = "socks5"
        line = re.sub(r"^socks5h?://", "", line, flags=re.I)

    # user:pass@host:port
    if "@" in line:
        creds, hostpart = line.rsplit("@", 1)
        parts = creds.split(":", 1)
        username, password = parts[0], parts[1] if len(parts) > 1 else ""
    else:
        username, password = "", ""
        hostpart = line

    # host:port[:user:pass] (không có @)
    parts = hostpart.split(":")
    if len(parts) == 4 and not username:
        host, port_s, username, password = parts
    elif len(parts) == 2:
        host, port_s = parts
    elif len(parts) == 1:
        return None  # không có port
    else:
        host, port_s = parts[0], parts[1]

    try:
        port = int(port_s)
    except ValueError:
        return None

    if not (1 <= port <= 65535):
        return None
    if not host or not re.match(r"^[\w.\-]+$", host):
        return None

    return ParsedProxy(protocol=proto, host=host, port=port,
                       username=username, password=password)


class ProxyParser:
    """Parse, dedup và chuẩn hoá danh sách proxy từ text đa định dạng."""

    def parse(self, raw_text: str,
              default_protocol: str = "http") -> list[ParsedProxy]:
        """Parse text nhiều dòng, trả về list đã dedup."""
        seen: set[str] = set()
        result: list[ParsedProxy] = []
        for line in raw_text.splitlines():
            p = parse_proxy_line(line)
            if p is None:
                continue
            if p.protocol == "http" and default_protocol != "http":
                p.protocol = default_protocol
            key = p.key
            if key not in seen:
                seen.add(key)
                result.append(p)
        return result

    def to_text(self, proxies: list[ParsedProxy],
                fmt: str = "url") -> str:
        """Xuất ra text. fmt: url | ip:port | ip:port:user:pass"""
        lines: list[str] = []
        for p in proxies:
            if fmt == "url":
                lines.append(p.url)
            elif fmt == "ip:port":
                lines.append(f"{p.host}:{p.port}")
            elif fmt == "ip:port:user:pass" and p.username:
                lines.append(f"{p.host}:{p.port}:{p.username}:{p.password}")
            else:
                lines.append(p.url)
        return "\n".join(lines)

    def stats(self, proxies: list[ParsedProxy]) -> dict[str, Any]:
        from collections import Counter
        protos = Counter(p.protocol for p in proxies)
        with_auth = sum(1 for p in proxies if p.username)
        return {
            "total": len(proxies),
            "by_protocol": dict(protos),
            "with_auth": with_auth,
            "without_auth": len(proxies) - with_auth,
        }
