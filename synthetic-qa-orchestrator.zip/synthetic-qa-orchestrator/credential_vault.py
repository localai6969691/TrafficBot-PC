"""Kho Lưu Trữ Thông Tin Xác Thực Mã Hóa (Encrypted Credential & Cookie Vault).

Lưu an toàn vào SQLite (mã hóa Fernet/AES-128-CBC):
  - Tài khoản kiểm thử (username/password)
  - Cookie JSON nhập từ bên ngoài (EditThisCookie, browser extension export)
  - API key của dịch vụ giải captcha (2Captcha, CapSolver, Anti-Captcha)
  - Storage state Playwright (cookie + localStorage đã warm)

Session Watchdog:
  Giám sát thời hạn cookie định danh; nếu sắp hết hạn → đưa vào hàng đợi warm.

GIỚI HẠN:
  - Fernet dùng khóa 32-byte URL-safe base64. Khóa tạo từ QA_SECRET_KEY trong .env.
    Nếu mất khóa → mất toàn bộ dữ liệu vault. Backup file .env riêng.
  - Cookies lưu dưới dạng JSON blob mã hóa; không parse được nếu chỉ có DB.
  - Watchdog chỉ kiểm tra 'expires' field của cookie (Unix timestamp).
    Session-only cookies (expires=-1) không được theo dõi.
  - Captcha API keys lưu plaintext trong memory sau khi decrypt; không persist
    sau khi process thoát.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.vault")

# ---------------------------------------------------------------------------
# Encryption helpers (Fernet-compatible, không cần cryptography package)
# ---------------------------------------------------------------------------

def _derive_key(secret: str) -> bytes:
    """Derive 32-byte key từ secret string bằng SHA256."""
    return hashlib.sha256(secret.encode()).digest()


def _fernet_encrypt(data: bytes, key: bytes) -> str:
    """Mã hóa Fernet-like: base64(iv + AES-CBC(data) + HMAC). Fallback XOR nếu
    không có cryptography package."""
    try:
        from cryptography.fernet import Fernet
        import base64 as b64
        fernet_key = b64.urlsafe_b64encode(key)
        f = Fernet(fernet_key)
        return f.encrypt(data).decode()
    except ImportError:
        # Fallback: simple XOR obfuscation + base64 (không phải mã hóa thật)
        # Đủ để tránh plaintext trong DB, nhưng KHÔNG bảo mật như AES
        xored = bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
        return "xor:" + base64.urlsafe_b64encode(xored).decode()


def _fernet_decrypt(token: str, key: bytes) -> bytes:
    """Giải mã token."""
    try:
        from cryptography.fernet import Fernet
        import base64 as b64
        fernet_key = b64.urlsafe_b64encode(key)
        f = Fernet(fernet_key)
        return f.decrypt(token.encode())
    except ImportError:
        if token.startswith("xor:"):
            xored = base64.urlsafe_b64decode(token[4:])
            return bytes(b ^ key[i % len(key)] for i, b in enumerate(xored))
        raise ValueError("Không thể giải mã: cryptography package chưa cài")


# ---------------------------------------------------------------------------
# Credential types
# ---------------------------------------------------------------------------

@dataclass
class TestAccount:
    name: str               # định danh (vd: "user_vn_01")
    username: str
    password: str
    email: str = ""
    profile_id: str = ""    # profile liên kết
    tags: list[str] = field(default_factory=list)
    notes: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class CaptchaService:
    name: str               # 2captcha | capsolver | anticaptcha
    api_key: str
    balance: Optional[float] = None
    last_checked: str = ""


@dataclass
class CookieEntry:
    profile_id: str
    domain: str
    cookies_json: str       # JSON array của cookies
    imported_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    expires_at: Optional[float] = None  # earliest expiry Unix timestamp


# ---------------------------------------------------------------------------
# CredentialVault
# ---------------------------------------------------------------------------

class CredentialVault:
    """Kho lưu trữ mã hóa trong SQLite."""

    def __init__(self, db: Database, secret: str = "") -> None:
        self.db = db
        self._key = _derive_key(secret or os.environ.get("QA_SECRET_KEY", "default-dev-key"))
        self._ensure_tables()

    def _ensure_tables(self) -> None:
        self.db._write("""
            CREATE TABLE IF NOT EXISTS credential_vault (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                type      TEXT NOT NULL,  -- account|cookie|captcha
                name      TEXT NOT NULL,  -- unique name/identifier
                payload   TEXT NOT NULL,  -- encrypted JSON
                tags      TEXT DEFAULT '',
                created_at TEXT,
                updated_at TEXT,
                UNIQUE(type, name)
            )""")
        self.db._write("""
            CREATE INDEX IF NOT EXISTS idx_vault_type ON credential_vault(type)
        """)

    # ------------------------------------------------------------------
    # Store / retrieve helpers
    # ------------------------------------------------------------------

    def _store(self, type_: str, name: str, data: dict[str, Any],
               tags: list[str] = []) -> None:
        payload = _fernet_encrypt(json.dumps(data).encode(), self._key)
        now = datetime.now(timezone.utc).isoformat()
        self.db._write("""
            INSERT INTO credential_vault (type, name, payload, tags, created_at, updated_at)
            VALUES (?,?,?,?,?,?)
            ON CONFLICT(type,name) DO UPDATE SET
              payload=excluded.payload, tags=excluded.tags, updated_at=excluded.updated_at
        """, (type_, name, payload, ",".join(tags), now, now))

    def _load(self, type_: str, name: str) -> Optional[dict[str, Any]]:
        rows = self.db._read(
            "SELECT payload FROM credential_vault WHERE type=? AND name=?", (type_, name))
        if not rows:
            return None
        return json.loads(_fernet_decrypt(rows[0]["payload"], self._key))

    def _list_names(self, type_: str) -> list[dict[str, Any]]:
        rows = self.db._read(
            "SELECT name, tags, created_at, updated_at FROM credential_vault WHERE type=? ORDER BY name",
            (type_,))
        return [dict(r) for r in rows]

    def _delete(self, type_: str, name: str) -> bool:
        rows = self.db._read("SELECT id FROM credential_vault WHERE type=? AND name=?", (type_, name))
        if not rows:
            return False
        self.db._write("DELETE FROM credential_vault WHERE type=? AND name=?", (type_, name))
        return True

    # ------------------------------------------------------------------
    # Test Accounts
    # ------------------------------------------------------------------

    def save_account(self, account: TestAccount) -> None:
        self._store("account", account.name, account.__dict__, account.tags)
        LOGGER.debug("vault: saved account '%s'", account.name)

    def get_account(self, name: str) -> Optional[TestAccount]:
        d = self._load("account", name)
        if not d:
            return None
        return TestAccount(**{k: v for k, v in d.items()
                               if k in TestAccount.__dataclass_fields__})

    def list_accounts(self) -> list[dict[str, Any]]:
        """Trả về danh sách tên + tags (không decrypt password)."""
        return self._list_names("account")

    def delete_account(self, name: str) -> bool:
        return self._delete("account", name)

    # ------------------------------------------------------------------
    # Cookies
    # ------------------------------------------------------------------

    def save_cookies(self, profile_id: str, domain: str,
                     cookies: list[dict[str, Any]]) -> None:
        """Lưu cookie array (từ EditThisCookie / browser export)."""
        # Tìm earliest expiry
        expires_list = [c.get("expirationDate") or c.get("expires", -1)
                        for c in cookies if isinstance(c.get("expirationDate") or c.get("expires"), (int, float))]
        earliest = min((e for e in expires_list if e > 0), default=None)

        entry = CookieEntry(
            profile_id=profile_id, domain=domain,
            cookies_json=json.dumps(cookies),
            expires_at=earliest,
        )
        self._store("cookie", f"{profile_id}::{domain}", entry.__dict__)
        LOGGER.info("vault: saved %d cookies for %s / %s", len(cookies), profile_id, domain)

    def get_cookies(self, profile_id: str, domain: str) -> Optional[list[dict[str, Any]]]:
        d = self._load("cookie", f"{profile_id}::{domain}")
        if not d:
            return None
        return json.loads(d.get("cookies_json", "[]"))

    def list_cookies(self) -> list[dict[str, Any]]:
        return self._list_names("cookie")

    def cookies_to_playwright(self, profile_id: str, domain: str) -> list[dict[str, Any]]:
        """Convert cookies sang format Playwright BrowserContext.add_cookies()."""
        raw = self.get_cookies(profile_id, domain) or []
        pw_cookies = []
        for c in raw:
            pw_c: dict[str, Any] = {
                "name": c.get("name", ""),
                "value": c.get("value", ""),
                "domain": c.get("domain", domain),
                "path": c.get("path", "/"),
                "secure": c.get("secure", False),
                "httpOnly": c.get("httpOnly", False),
            }
            exp = c.get("expirationDate") or c.get("expires")
            if exp and exp > 0:
                pw_c["expires"] = int(exp)
            same_site = c.get("sameSite", "Lax")
            if same_site in ("Strict", "Lax", "None"):
                pw_c["sameSite"] = same_site
            pw_cookies.append(pw_c)
        return pw_cookies

    def import_cookies_json(self, profile_id: str, json_str: str) -> int:
        """Import từ chuỗi JSON (EditThisCookie, Chrome export...). Trả về số cookie."""
        try:
            data = json.loads(json_str)
            cookies = data if isinstance(data, list) else data.get("cookies", [])
            # Group by domain
            by_domain: dict[str, list[dict]] = {}
            for c in cookies:
                d = c.get("domain", "").lstrip(".")
                by_domain.setdefault(d, []).append(c)
            for domain, cks in by_domain.items():
                self.save_cookies(profile_id, domain, cks)
            return len(cookies)
        except Exception as exc:
            LOGGER.error("vault: import cookies lỗi: %s", exc)
            return 0

    # ------------------------------------------------------------------
    # Captcha services
    # ------------------------------------------------------------------

    def save_captcha_key(self, service: CaptchaService) -> None:
        self._store("captcha", service.name, service.__dict__)
        LOGGER.info("vault: saved captcha key for %s", service.name)

    def get_captcha_key(self, name: str) -> Optional[str]:
        d = self._load("captcha", name)
        return d.get("api_key") if d else None

    def list_captcha_services(self) -> list[dict[str, Any]]:
        return self._list_names("captcha")

    # ------------------------------------------------------------------
    # Async wrappers
    # ------------------------------------------------------------------

    async def asave_account(self, account: TestAccount) -> None:
        await asyncio.to_thread(self.save_account, account)

    async def aget_account(self, name: str) -> Optional[TestAccount]:
        return await asyncio.to_thread(self.get_account, name)

    async def asave_cookies(self, profile_id: str, domain: str,
                             cookies: list[dict[str, Any]]) -> None:
        await asyncio.to_thread(self.save_cookies, profile_id, domain, cookies)

    async def aget_cookies_playwright(self, profile_id: str,
                                       domain: str) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.cookies_to_playwright, profile_id, domain)


# ---------------------------------------------------------------------------
# Session Watchdog
# ---------------------------------------------------------------------------

class SessionWatchdog:
    """Giám sát expiry của cookies; re-queue profile vào warmer khi sắp hết hạn.

    Chạy dưới dạng asyncio background task.
    """

    def __init__(
        self,
        vault: CredentialVault,
        db: Database,
        warn_before_s: float = 24 * 3600,  # cảnh báo trước 24h
        check_interval_s: float = 3600,     # kiểm tra mỗi 1h
    ) -> None:
        self.vault = vault
        self.db = db
        self.warn_before_s = warn_before_s
        self.check_interval_s = check_interval_s
        self._task: Optional[asyncio.Task] = None
        self._expiring: list[str] = []  # profile IDs sắp hết hạn

    async def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="session-watchdog")
        LOGGER.info("watchdog: bắt đầu (kiểm tra mỗi %.0fh)", self.check_interval_s / 3600)

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _loop(self) -> None:
        while True:
            try:
                await self._check_all()
            except Exception as exc:
                LOGGER.error("watchdog lỗi: %s", exc)
            await asyncio.sleep(self.check_interval_s)

    async def _check_all(self) -> None:
        now = time.time()
        deadline = now + self.warn_before_s
        rows = self.vault.db._read(
            "SELECT name FROM credential_vault WHERE type='cookie'")
        self._expiring = []
        for row in rows:
            parts = row["name"].split("::")
            if len(parts) < 2:
                continue
            profile_id, domain = parts[0], parts[1]
            d = self.vault._load("cookie", row["name"])
            if not d:
                continue
            expires_at = d.get("expires_at")
            if expires_at and 0 < expires_at < deadline:
                age_h = (expires_at - now) / 3600
                LOGGER.warning(
                    "watchdog: profile '%s' domain '%s' hết hạn trong %.1fh → queue warm",
                    profile_id, domain, max(0, age_h))
                self._expiring.append(profile_id)
                # Cập nhật trạng thái warmth về 'new' để trigger re-warm
                await self.db.aset_profile_warmth(
                    profile_id=profile_id,
                    trust_score=0.0, urls_visited=0, cookies=0,
                    warmed_at=datetime.now(timezone.utc).isoformat(),
                )

    @property
    def expiring_profiles(self) -> list[str]:
        return list(self._expiring)
