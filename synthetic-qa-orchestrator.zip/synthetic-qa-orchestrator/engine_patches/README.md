# `engine_patches/` — Bản Vá Tùy Chỉnh Cho Nhân Trình Duyệt (Phase 10.1)

Thư mục này chứa các tệp `.patch` được `build_custom_engine.yml` tự động áp
dụng (qua `git apply`) lên mã nguồn/bản phát hành của nhân trình duyệt mã
nguồn mở (mặc định: [Camoufox](https://github.com/daijro/camoufox) — bản
Firefox đã patch sẵn chống dò dấu vân tay) trước khi đóng gói lại.

## Quy ước đặt tên & áp dụng

- Mỗi bản vá là một tệp `.patch` chuẩn `git diff` / `diff -u`.
- Workflow áp patch với `git apply --directory=engine_build`, nghĩa là
  đường dẫn trong patch phải là đường dẫn **tương đối bên trong thư mục giải
  nén** của bản phát hành gốc (vd. nếu release giải nén ra
  `engine_build/camoufox-linux/...`, patch phải ghi đường dẫn bắt đầu bằng
  `camoufox-linux/...`).
- Đặt số thứ tự ở đầu tên tệp để kiểm soát thứ tự áp dụng khi nhiều patch phụ
  thuộc nhau: `01-canvas-seed.patch`, `02-disable-telemetry.patch`...
- Nếu một patch áp dụng thất bại (vd. bản release mới đã đổi cấu trúc), workflow
  chỉ in cảnh báo (`::warning::`) và **tiếp tục** với các patch còn lại — không
  làm hỏng toàn bộ build.

## Các nhóm bản vá được khuyến nghị (theo mục 2.1 đặc tả Phase 10)

1. **Canvas/WebGL/Audio deterministic seed** — khoá cứng seed nhiễu fingerprint
   (nếu bản gốc dùng seed ngẫu nhiên mỗi lần khởi chạy) để các lượt kiểm thử
   lặp lại cho ra cùng giá trị fingerprint, giúp so sánh kết quả qua các lần
   chạy khác nhau.
2. **Tắt dịch vụ telemetry/crash-reporting nền** — loại các request nền tự
   động gửi về nhà cung cấp gốc (Mozilla/Google) mà kịch bản kiểm thử không
   chủ động gọi, tránh nhiễu số liệu băng thông đo được.
3. **`--remote-debugging-pipe`** — đã được workflow tự ghi vào
   `qa_engine_launch_defaults.json` ở bước đóng gói (không cần patch riêng),
   để `engine_router.py` ưu tiên kết nối qua pipe thay vì cổng TCP CDP lộ ra
   ngoài khi khởi chạy nhân trình duyệt này.

## Ví dụ khung sườn một patch

```diff
--- a/camoufox-linux/defaults/pref.js
+++ b/camoufox-linux/defaults/pref.js
@@ -120,6 +120,8 @@
 pref("toolkit.telemetry.enabled", false);
 pref("datareporting.healthreport.uploadEnabled", false);
+pref("privacy.resistFingerprinting.canvas.seed", 1234567890);
+pref("media.navigator.enabled", false);
```

*(Đường dẫn và tên pref trên chỉ mang tính minh họa — kiểm tra cấu trúc thật
của bản release Camoufox bạn đang dùng trước khi viết patch.)*

## Không có patch nào?

Hoàn toàn hợp lệ — để thư mục này trống (chỉ còn `README.md`) thì
`build_custom_engine.yml` sẽ đóng gói nguyên bản gốc không chỉnh sửa gì thêm.
