"""Quản Trị Chiến Dịch Vi Mô & Chống Nhiễu Dữ Liệu (Granular Campaign & Noise Filtering).

Ba thành phần:
  1. StormController   - Ramp-up / Storm Peak / Cool-down load curve
  2. RedirectBlocker   - chặn popup và navigate ngoài allowed_domains
  3. WorkspaceManager  - nhóm kịch bản theo project, export/import .qa-bundle

GIỚI HẠN:
  - StormController điều tiết số task được SUBMIT vào queue; không kill task đang chạy.
    Cool-down chỉ ngừng submit mới, task inflight vẫn chạy đến xong.
  - RedirectBlocker dùng page.on("popup") và page.on("framenavigated"). Cross-origin
    iframe navigation không bị chặn (giới hạn Playwright).
  - .qa-bundle là file zip chứa JSON config; không bao gồm profiles_data (cookies/storage).
    Dữ liệu nhạy cảm trong credential_vault được BỎ QUA khi export (không thể serialize AES).
  - workspace không có phân quyền user thật — chỉ là tag phân loại. Multi-user auth
    cần thêm lớp auth riêng (ngoài scope module này).
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import math
import os
import time
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Optional

from database import Database

LOGGER = logging.getLogger("qa.campaign")


# ---------------------------------------------------------------------------
# 1. Storm Controller — Ramp-up / Storm / Cool-down
# ---------------------------------------------------------------------------

@dataclass
class StormConfig:
    """Đồ thị tải theo 3 giai đoạn."""
    warmup_s: float = 60.0        # thời gian khởi động (tăng từ 0 lên max)
    storm_s: float = 300.0        # thời gian giữ tải đỉnh
    cooldown_s: float = 60.0      # thời gian giảm về 0
    max_concurrency: int = 10     # số task đồng thời tối đa ở đỉnh
    min_concurrency: int = 1      # số task tối thiểu khi khởi động/kết thúc
    ramp_curve: str = "linear"    # linear | sine | exponential

    @property
    def total_s(self) -> float:
        return self.warmup_s + self.storm_s + self.cooldown_s

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "StormConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


def _ramp_factor(elapsed: float, cfg: StormConfig) -> float:
    """Trả về factor 0.0–1.0 tại thời điểm elapsed (giây từ khi bắt đầu)."""
    if elapsed < cfg.warmup_s:
        t = elapsed / cfg.warmup_s
        if cfg.ramp_curve == "sine":
            return math.sin(t * math.pi / 2)
        elif cfg.ramp_curve == "exponential":
            return t ** 2
        return t  # linear
    elif elapsed < cfg.warmup_s + cfg.storm_s:
        return 1.0  # đỉnh
    else:
        remaining = cfg.total_s - elapsed
        if remaining <= 0:
            return 0.0
        t = remaining / cfg.cooldown_s
        return max(0.0, min(1.0, t))


class StormController:
    """Điều tiết số task submit theo đồ thị tải."""

    def __init__(self, cfg: StormConfig) -> None:
        self.cfg = cfg
        self._started_at: Optional[float] = None
        self._stopped = False
        self._total_submitted = 0

    def start(self) -> None:
        self._started_at = time.monotonic()
        self._stopped = False
        LOGGER.info("storm: bắt đầu — warmup=%.0fs storm=%.0fs cooldown=%.0fs max=%d",
                    self.cfg.warmup_s, self.cfg.storm_s, self.cfg.cooldown_s,
                    self.cfg.max_concurrency)

    def stop(self) -> None:
        self._stopped = True

    @property
    def is_running(self) -> bool:
        if self._stopped or self._started_at is None:
            return False
        return self._elapsed < self.cfg.total_s

    @property
    def _elapsed(self) -> float:
        return time.monotonic() - (self._started_at or time.monotonic())

    @property
    def current_concurrency(self) -> int:
        if not self.is_running:
            return 0
        factor = _ramp_factor(self._elapsed, self.cfg)
        spread = self.cfg.max_concurrency - self.cfg.min_concurrency
        return max(self.cfg.min_concurrency,
                   int(self.cfg.min_concurrency + spread * factor))

    @property
    def phase(self) -> str:
        if not self.is_running:
            return "idle"
        e = self._elapsed
        if e < self.cfg.warmup_s:
            return "warmup"
        if e < self.cfg.warmup_s + self.cfg.storm_s:
            return "storm"
        return "cooldown"

    def status(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "elapsed_s": round(self._elapsed, 1) if self._started_at else 0,
            "total_s": self.cfg.total_s,
            "current_concurrency": self.current_concurrency,
            "max_concurrency": self.cfg.max_concurrency,
            "is_running": self.is_running,
            "total_submitted": self._total_submitted,
        }

    async def run_campaign(
        self,
        task_factory: Any,       # async callable() → task object
        submit_fn: Any,          # async callable(task)
        poll_interval_s: float = 1.0,
    ) -> dict[str, Any]:
        """Chạy campaign theo đồ thị tải. task_factory tạo task mới, submit_fn gửi vào queue."""
        self.start()
        inflight = 0
        t0 = time.time()
        while self.is_running:
            target = self.current_concurrency
            while inflight < target:
                task = await task_factory()
                if task is None:
                    break
                await submit_fn(task)
                inflight += 1
                self._total_submitted += 1
            await asyncio.sleep(poll_interval_s)
            # Giảm inflight counter khi tasks xong (đơn giản hóa: không track chính xác)
            inflight = max(0, inflight - max(1, int(inflight * 0.1)))
        self.stop()
        return {
            "total_submitted": self._total_submitted,
            "duration_s": round(time.time() - t0, 1),
            "peak_concurrency": self.cfg.max_concurrency,
        }


# ---------------------------------------------------------------------------
# 2. Redirect / Popup Blocker
# ---------------------------------------------------------------------------

@dataclass
class BlockerConfig:
    allowed_domains: list[str] = field(default_factory=list)
    block_popups: bool = True
    block_new_tabs: bool = True
    log_blocked: bool = True


class RedirectBlocker:
    """Gắn vào Playwright page để chặn popup và navigate ngoài allowed_domains."""

    def __init__(self, page: Any, cfg: BlockerConfig) -> None:
        self.page = page
        self.cfg = cfg
        self._blocked_count = 0
        self._blocked_urls: list[str] = []

    def _is_allowed(self, url: str) -> bool:
        if not self.cfg.allowed_domains:
            return True  # không có whitelist → cho qua hết
        from urllib.parse import urlparse
        host = urlparse(url).netloc.lower()
        return any(
            host == d.lower() or host.endswith("." + d.lower())
            for d in self.cfg.allowed_domains
        )

    async def attach(self) -> None:
        """Gắn event listeners vào page."""
        if self.cfg.block_popups:
            self.page.on("popup", self._on_popup)
        self.page.on("framenavigated", self._on_navigate)
        LOGGER.debug("blocker: attached (allowed=%s)", self.cfg.allowed_domains)

    async def detach(self) -> None:
        try:
            self.page.remove_listener("popup", self._on_popup)
            self.page.remove_listener("framenavigated", self._on_navigate)
        except Exception:
            pass

    def _on_popup(self, popup: Any) -> None:
        """Đóng popup ngay khi mở."""
        if not self.cfg.block_popups:
            return
        url = ""
        try:
            url = popup.url
        except Exception:
            pass
        if not self._is_allowed(url):
            self._blocked_count += 1
            self._blocked_urls.append(url[:100])
            asyncio.create_task(self._close_popup(popup))
            if self.cfg.log_blocked:
                LOGGER.warning("blocker: popup blocked → %s", url[:80])

    async def _close_popup(self, popup: Any) -> None:
        try:
            await popup.close()
        except Exception:
            pass

    def _on_navigate(self, frame: Any) -> None:
        """Phát hiện navigate sang domain ngoài whitelist."""
        try:
            if frame != self.page.main_frame:
                return
            url = frame.url
            if url in ("about:blank", "about:#", "") or not url.startswith("http"):
                return
            if not self._is_allowed(url):
                self._blocked_count += 1
                self._blocked_urls.append(url[:100])
                if self.cfg.log_blocked:
                    LOGGER.warning("blocker: redirect blocked → %s", url[:80])
                asyncio.create_task(self._go_back())
        except Exception:
            pass

    async def _go_back(self) -> None:
        try:
            await self.page.go_back(timeout=5000)
        except Exception:
            pass

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "blocked_count": self._blocked_count,
            "blocked_urls": list(self._blocked_urls[-10:]),
        }


# ---------------------------------------------------------------------------
# 3. Workspace Manager & .qa-bundle
# ---------------------------------------------------------------------------

class WorkspaceManager:
    """Phân nhóm kịch bản/profiles/gateways theo workspace, export/import .qa-bundle."""

    def __init__(self, db: Database, paths: Any) -> None:
        self.db = db
        self.paths = paths
        self._ensure_tables()

    def _ensure_tables(self) -> None:
        self.db._write("""
            CREATE TABLE IF NOT EXISTS workspaces (
                id          TEXT PRIMARY KEY,
                name        TEXT NOT NULL,
                description TEXT DEFAULT '',
                color       TEXT DEFAULT '#1f6f5c',
                created_at  TEXT,
                updated_at  TEXT
            )""")
        self.db._write("""
            CREATE TABLE IF NOT EXISTS workspace_items (
                workspace_id TEXT NOT NULL,
                item_type    TEXT NOT NULL,  -- scenario|profile|gateway|persona
                item_id      TEXT NOT NULL,
                PRIMARY KEY (workspace_id, item_type, item_id)
            )""")

    # ── Workspace CRUD ──────────────────────────────────────────────────

    def create_workspace(self, ws_id: str, name: str,
                          description: str = "", color: str = "#1f6f5c") -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.db._write(
            """INSERT INTO workspaces(id,name,description,color,created_at,updated_at)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET name=excluded.name,
                 description=excluded.description, color=excluded.color,
                 updated_at=excluded.updated_at""",
            (ws_id, name, description, color, now, now))

    def list_workspaces(self) -> list[dict[str, Any]]:
        rows = self.db._read("SELECT * FROM workspaces ORDER BY name")
        return [dict(r) for r in rows]

    def delete_workspace(self, ws_id: str) -> None:
        self.db._write("DELETE FROM workspaces WHERE id=?", (ws_id,))
        self.db._write("DELETE FROM workspace_items WHERE workspace_id=?", (ws_id,))

    def add_item(self, ws_id: str, item_type: str, item_id: str) -> None:
        self.db._write(
            "INSERT OR IGNORE INTO workspace_items(workspace_id,item_type,item_id) VALUES(?,?,?)",
            (ws_id, item_type, item_id))

    def remove_item(self, ws_id: str, item_type: str, item_id: str) -> None:
        self.db._write(
            "DELETE FROM workspace_items WHERE workspace_id=? AND item_type=? AND item_id=?",
            (ws_id, item_type, item_id))

    def get_items(self, ws_id: str, item_type: Optional[str] = None) -> list[dict[str, Any]]:
        if item_type:
            rows = self.db._read(
                "SELECT * FROM workspace_items WHERE workspace_id=? AND item_type=? ORDER BY item_id",
                (ws_id, item_type))
        else:
            rows = self.db._read(
                "SELECT * FROM workspace_items WHERE workspace_id=? ORDER BY item_type,item_id",
                (ws_id,))
        return [dict(r) for r in rows]

    # ── Export .qa-bundle ───────────────────────────────────────────────

    def export_bundle(self, ws_id: str, out_path: Optional[Path] = None) -> Path:
        """Xuất workspace thành file .qa-bundle (zip) chứa JSON config.

        Bundle structure:
          manifest.json        — metadata
          scenarios.json       — kịch bản thuộc workspace
          environments.json    — environments
          gateways.txt         — proxy list
          personas.json        — device personas
          plugins/             — plugin configs
        """
        ws = self.db._read("SELECT * FROM workspaces WHERE id=?", (ws_id,))
        if not ws:
            raise ValueError(f"Workspace '{ws_id}' không tồn tại")
        ws_info = dict(ws[0])

        items = self.get_items(ws_id)
        scenario_ids = {r["item_id"] for r in items if r["item_type"] == "scenario"}
        profile_ids = {r["item_id"] for r in items if r["item_type"] == "profile"}
        gateway_ids = {r["item_id"] for r in items if r["item_type"] == "gateway"}

        # Đọc config files
        scenarios_all: list[dict] = []
        try:
            data = json.loads(Path(self.paths.scenarios).read_text())
            scenarios_all = [s for s in data.get("scenarios", [])
                             if not scenario_ids or s["id"] in scenario_ids]
        except Exception:
            pass

        gateways_text = ""
        try:
            gw_path = Path(self.paths.gateways)
            if gw_path.exists():
                gateways_text = gw_path.read_text()
        except Exception:
            pass

        env_data: dict = {}
        try:
            env_data = json.loads(Path(self.paths.environments).read_text())
        except Exception:
            pass

        # Tạo bundle zip trong memory
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            manifest = {
                "bundle_version": "1",
                "workspace_id": ws_id,
                "workspace_name": ws_info["name"],
                "exported_at": datetime.now(timezone.utc).isoformat(),
                "scenario_count": len(scenarios_all),
                "included_profiles": list(profile_ids),
                "included_gateways": list(gateway_ids),
            }
            zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))
            zf.writestr("scenarios.json",
                        json.dumps({"scenarios": scenarios_all}, indent=2, ensure_ascii=False))
            if gateways_text:
                zf.writestr("gateways.txt", gateways_text)
            if env_data:
                zf.writestr("environments.json",
                            json.dumps(env_data, indent=2, ensure_ascii=False))

        if out_path is None:
            out_path = Path(f"{ws_id}_{int(time.time())}.qa-bundle")
        out_path.write_bytes(buf.getvalue())
        LOGGER.info("bundle: xuất workspace '%s' → %s (%.1fKB)",
                    ws_id, out_path.name, out_path.stat().st_size / 1024)
        return out_path

    def import_bundle(self, bundle_path: Path, merge: bool = True) -> dict[str, Any]:
        """Nhập .qa-bundle. merge=True: giữ kịch bản hiện có, chỉ thêm mới.
        merge=False: ghi đè toàn bộ.
        """
        if not bundle_path.exists():
            raise FileNotFoundError(f"Bundle không tồn tại: {bundle_path}")

        result: dict[str, Any] = {"scenarios_added": 0, "workspace_created": False}

        with zipfile.ZipFile(bundle_path, "r") as zf:
            names = zf.namelist()
            manifest: dict = {}
            if "manifest.json" in names:
                manifest = json.loads(zf.read("manifest.json"))

            ws_id = manifest.get("workspace_id", bundle_path.stem)
            ws_name = manifest.get("workspace_name", ws_id)
            self.create_workspace(ws_id, ws_name)
            result["workspace_created"] = True
            result["workspace_id"] = ws_id

            # Import scenarios
            if "scenarios.json" in names:
                new_data = json.loads(zf.read("scenarios.json"))
                new_scenarios = new_data.get("scenarios", [])
                try:
                    existing_data = json.loads(Path(self.paths.scenarios).read_text())
                except Exception:
                    existing_data = {"scenarios": []}
                existing_ids = {s["id"] for s in existing_data.get("scenarios", [])}
                added = 0
                for sc in new_scenarios:
                    if merge and sc["id"] in existing_ids:
                        continue
                    existing_data.setdefault("scenarios", []).append(sc)
                    self.add_item(ws_id, "scenario", sc["id"])
                    added += 1
                Path(self.paths.scenarios).write_text(
                    json.dumps(existing_data, indent=2, ensure_ascii=False))
                result["scenarios_added"] = added

            # Import gateways (append)
            if "gateways.txt" in names:
                new_gw = zf.read("gateways.txt").decode()
                try:
                    gw_path = Path(self.paths.gateways)
                    existing = gw_path.read_text() if gw_path.exists() else ""
                    combined = existing.rstrip() + "\n" + new_gw if existing else new_gw
                    gw_path.write_text(combined)
                    result["gateways_imported"] = True
                except Exception:
                    pass

        LOGGER.info("bundle: nhập từ %s → ws='%s' +%d scenarios",
                    bundle_path.name, ws_id, result["scenarios_added"])
        return result
