"""Bộ Kết Nối Hạ Tầng Trình Duyệt Đám Mây (Cloud Browser Infrastructure Adapter).

Kết nối tới các nhà cung cấp Cloud Browser thương mại thông qua giao thức WebSocket CDP,
quản lý quota/chi phí phiên, và hỗ trợ chế độ Hybrid (cục bộ + cloud).

Nhà cung cấp được hỗ trợ (tất cả dùng giao thức CDP tiêu chuẩn):
  - Browserless   : wss://chrome.browserless.io?token=TOKEN
  - BrowserStack  : wss://cdp.browserstack.com/playwright?caps=...
  - Browser Use   : wss://api.browser-use.com/playwright?apiKey=TOKEN
  - Anchor Browser: wss://connect.anchorbrowser.io?apiKey=TOKEN
  - Bright Data   : wss://brd-customer-...@brd.superproxy.io:9222
  - Tùy chỉnh     : bất kỳ endpoint WebSocket CDP nào

Cách dùng trong scenarios.json:
  "cloud": {
    "provider": "browserless",
    "endpoint": "wss://chrome.browserless.io",
    "token_env": "BROWSERLESS_TOKEN",   // tên biến môi trường chứa API key
    "timeout_ms": 60000
  }

Hoặc Hybrid Mode (chia tải):
  "settings": {
    "cloud_hybrid": {
      "cloud_ratio": 0.7,         // 70% chạy cloud, 30% local
      "provider": "browserless",
      "endpoint": "wss://...",
      "token_env": "BL_TOKEN"
    }
  }

GIỚI HẠN ĐÃ BIẾT:
  - Phụ thuộc hoàn toàn vào tính sẵn sàng của nhà cung cấp - khi cloud down, fallback
    về local nếu bật `fallback_local: true` (mặc định True).
  - BrowserStack cần encode capabilities vào URL phức tạp - xem helper `browserstack_url()`.
  - Thời gian session được tính từ lúc connect đến close, không phải thời gian thực thi
    thực tế - đây là cách tính phổ biến của các provider.
  - Cost tracking chỉ là ƯỚC TÍNH dựa trên duration × rate_per_second; giá thật tính
    theo hóa đơn của provider, không phải số trong DB này.
  - Mỗi phiên cloud tạo một kết nối WebSocket riêng - không share session giữa tasks.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from urllib.parse import quote, urlencode

from database import Database

LOGGER = logging.getLogger("qa.cloud")

# Giá tham khảo (USD/phút) - chỉ dùng để ước tính; con số thật tùy plan
_PROVIDER_RATES: dict[str, float] = {
    "browserless": 0.004,
    "browserstack": 0.01,
    "browser_use": 0.005,
    "anchor": 0.006,
    "bright_data": 0.008,
    "custom": 0.005,
}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class CloudSession:
    provider: str
    endpoint: str
    browser_type: str = "chromium"
    connected_at: float = field(default_factory=time.time)
    closed_at: Optional[float] = None
    session_id: Optional[str] = None      # ID do provider cấp (nếu có)
    db_log_id: Optional[int] = None       # ID trong bảng cloud_usage_logs

    @property
    def duration_s(self) -> float:
        end = self.closed_at or time.time()
        return end - self.connected_at

    @property
    def estimated_cost_usd(self) -> float:
        rate = _PROVIDER_RATES.get(self.provider, 0.005)
        return self.duration_s / 60.0 * rate


@dataclass
class CloudConfig:
    provider: str                          # browserless | browserstack | browser_use | anchor | custom
    endpoint: str                          # wss://...
    token: str = ""                        # API key / token (đọc từ env hoặc truyền trực tiếp)
    browser_type: str = "chromium"
    timeout_ms: int = 60_000
    fallback_local: bool = True            # nếu connect thất bại thì dùng local browser
    extra_params: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "CloudConfig":
        token = d.get("token", "")
        if not token and d.get("token_env"):
            token = os.environ.get(d["token_env"], "")
        return cls(
            provider=d.get("provider", "custom"),
            endpoint=d.get("endpoint", ""),
            token=token,
            browser_type=d.get("browser_type", "chromium"),
            timeout_ms=d.get("timeout_ms", 60_000),
            fallback_local=d.get("fallback_local", True),
            extra_params=d.get("extra_params", {}),
        )

    def build_ws_url(self) -> str:
        """Xây dựng WebSocket URL đúng định dạng cho từng provider."""
        ep = self.endpoint.rstrip("/")

        if self.provider == "browserless":
            sep = "&" if "?" in ep else "?"
            return f"{ep}{sep}token={self.token}"

        elif self.provider == "browserstack":
            return browserstack_url(ep, self.token, self.extra_params)

        elif self.provider in ("browser_use", "anchor"):
            sep = "&" if "?" in ep else "?"
            return f"{ep}{sep}apiKey={self.token}"

        elif self.provider == "bright_data":
            # format: wss://USER:PASS@host:port
            if self.token and "@" not in ep:
                proto, rest = ep.split("://", 1)
                return f"{proto}://{self.token}@{rest}"
            return ep

        else:  # custom
            if self.token:
                sep = "&" if "?" in ep else "?"
                return f"{ep}{sep}token={self.token}"
            return ep


def browserstack_url(base: str, credentials: str, caps: dict[str, Any]) -> str:
    """Tạo URL CDP cho BrowserStack với capabilities được encode.

    credentials: "user:key" hoặc chỉ "key" (nếu user nằm trong extra_params).
    caps: dict capabilities theo format BrowserStack.
    """
    default_caps = {
        "browser": "chrome",
        "browser_version": "latest",
        "os": "Windows",
        "os_version": "11",
        "name": "QA-Orchestrator",
        "build": "phase4",
    }
    default_caps.update(caps)
    caps_json = quote(json.dumps(default_caps))
    sep = "&" if "?" in base else "?"
    return f"{base}{sep}caps={caps_json}&key={credentials}"


# ---------------------------------------------------------------------------
# Cloud Adapter
# ---------------------------------------------------------------------------

class CloudBrowserAdapter:
    """Quản lý kết nối CDP tới Cloud Browser providers."""

    def __init__(self, db: Database) -> None:
        self.db = db
        self._active: dict[str, CloudSession] = {}  # task_id → CloudSession

    async def connect(
        self,
        cfg: CloudConfig,
        playwright: Any,
        task_id: str = "",
    ) -> tuple[Any, CloudSession]:
        """Kết nối tới cloud browser, trả về (browser, session).

        Thử kết nối WebSocket CDP. Nếu thất bại VÀ fallback_local=True,
        trả về None cho browser để caller biết dùng local.

        Args:
            playwright: instance của Playwright (đã có sẵn trong engine loop).
            task_id: định danh task để map với session.

        Returns:
            (browser_object, CloudSession) — browser=None nếu fallback local.
        """
        ws_url = cfg.build_ws_url()
        LOGGER.info("cloud: kết nối %s → %s…", cfg.provider, ws_url[:60] + "…")

        session = CloudSession(provider=cfg.provider, endpoint=ws_url,
                               browser_type=cfg.browser_type)

        # Ghi vào DB (trạng thái connecting)
        log_id = await self.db.alog_cloud_session_start(
            provider=cfg.provider, endpoint=ws_url[:200],
            browser_type=cfg.browser_type,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        session.db_log_id = log_id

        try:
            pw_browser_type = getattr(playwright, cfg.browser_type, playwright.chromium)
            browser = await asyncio.wait_for(
                pw_browser_type.connect_over_cdp(
                    ws_url,
                    timeout=cfg.timeout_ms,
                    slow_mo=0,
                ),
                timeout=cfg.timeout_ms / 1000 + 5,
            )
            LOGGER.info("cloud: ✅ kết nối thành công tới %s", cfg.provider)

            if task_id:
                self._active[task_id] = session
            return browser, session

        except Exception as exc:
            LOGGER.warning("cloud: ❌ kết nối %s thất bại: %s", cfg.provider, exc)
            await self.db.alog_cloud_session_end(
                log_id, duration_s=0, status="connect_failed", error=str(exc)[:300])

            if cfg.fallback_local:
                LOGGER.info("cloud: fallback về local browser")
                return None, session
            raise

    async def close_session(self, session: CloudSession, browser: Any) -> None:
        """Đóng browser và ghi thời gian sử dụng vào DB."""
        try:
            if browser:
                await browser.close()
        except Exception:
            pass
        finally:
            session.closed_at = time.time()
            if session.db_log_id:
                await self.db.alog_cloud_session_end(
                    session.db_log_id,
                    duration_s=round(session.duration_s, 2),
                    cost_usd=round(session.estimated_cost_usd, 6),
                    status="ok",
                )
            LOGGER.info(
                "cloud: phiên %s kết thúc — %.1fs (~$%.4f)",
                session.provider, session.duration_s, session.estimated_cost_usd,
            )

    def get_active(self, task_id: str) -> Optional[CloudSession]:
        return self._active.get(task_id)

    async def usage_summary(self, since_hours: float = 24.0) -> dict[str, Any]:
        """Tóm tắt chi phí và thời gian sử dụng cloud trong `since_hours` giờ gần nhất."""
        return await self.db.acloud_usage_summary(since_hours)


# ---------------------------------------------------------------------------
# Hybrid Execution Scheduler
# ---------------------------------------------------------------------------

class HybridScheduler:
    """Phân bổ tasks giữa local và cloud dựa trên tỷ lệ cấu hình.

    cloud_ratio=0.7 nghĩa là 70% tasks được đẩy lên cloud,
    30% chạy local. Quyết định được đưa ra ngẫu nhiên có trọng số,
    không phải round-robin cứng (để tránh burst pattern có thể phát hiện được).

    GIỚI HẠN: khi cloud không khả dụng và fallback_local=True, tất cả tasks
    tự động chạy local bất kể tỷ lệ. Quota cloud không được phân bổ lại.
    """

    def __init__(self, cloud_ratio: float, cloud_cfg: CloudConfig) -> None:
        self.cloud_ratio = max(0.0, min(1.0, cloud_ratio))
        self.cloud_cfg = cloud_cfg
        self._cloud_down = False      # flag khi provider liên tục lỗi
        self._fail_streak = 0
        self._MAX_FAIL = 3            # sau 3 lỗi liên tiếp → đánh dấu cloud down

    def should_use_cloud(self) -> bool:
        """Trả về True nếu task này nên chạy cloud."""
        if self._cloud_down:
            return False
        return random.random() < self.cloud_ratio

    def record_outcome(self, success: bool) -> None:
        """Ghi nhận kết quả để tự động tắt cloud khi quá nhiều lỗi."""
        if success:
            self._fail_streak = 0
            self._cloud_down = False
        else:
            self._fail_streak += 1
            if self._fail_streak >= self._MAX_FAIL:
                LOGGER.warning(
                    "hybrid: cloud liên tục lỗi %d lần → tắt tạm, dùng local",
                    self._fail_streak,
                )
                self._cloud_down = True

    def reset_cloud(self) -> None:
        """Khôi phục lại trạng thái cloud sau khi admin kiểm tra xong."""
        self._cloud_down = False
        self._fail_streak = 0
        LOGGER.info("hybrid: đã reset trạng thái cloud")
