"""Nạp động plugin.

Hai dạng plugin, nạp cùng lúc:
1. **Plugin kiểu cũ (Phase 1)**: một tệp `plugins/<ten>.py` độc lập, không có manifest,
   luôn bật, không có biểu mẫu cấu hình trên Web UI (chỉ dùng cho người tự thêm mã thủ công).
2. **Plugin đóng gói (Phase 2, mục 4.2)**: một thư mục `plugins/<ten>/` chứa `main.py` +
   `manifest.json`, cài qua Web UI bằng cách kéo-thả tệp `.zip`. `manifest.json` khai báo
   các biến cấu hình để Web UI tự vẽ biểu mẫu (xem `PluginInstaller.install_zip`). Cấu hình
   do người dùng điền được lưu ở bảng `plugin_configs` trong SQLite, KHÔNG bao giờ phải mở
   file code - và được truyền vào plugin qua tham số `config` của mỗi hook, nếu hook đó có
   khai báo tham số này (cùng cơ chế lọc tham số tùy chọn đã dùng cho `scenario`/`run`).

Hook (hàm thường hoặc async): on_context_created(context, scenario, config),
on_page_loaded(page, scenario, config), on_run_finished(run, scenario, config).
Mọi tham số hook đều tùy chọn - chỉ cần khai báo tên tham số mà plugin muốn nhận.

CẢNH BÁO AN TOÀN: plugin là mã Python tùy ý, chạy với toàn quyền của tiến trình runner.
Cài plugin qua Web UI tương đương chạy mã do người dùng cung cấp - chỉ cài plugin bạn
tin tưởng. Bộ cài có kiểm tra "zip-slip" (chặn đường dẫn thoát ra ngoài thư mục đích) và
giới hạn dung lượng, nhưng KHÔNG quét virus hay phân tích tĩnh nội dung mã nguồn.
"""
from __future__ import annotations

import importlib.util
import inspect
import json
import logging
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Optional

HOOKS = ("on_context_created", "on_page_loaded", "on_run_finished")
LOGGER = logging.getLogger("qa.plugins")

MAX_ZIP_BYTES = 10 * 1024 * 1024          # 10 MB - đủ cho một plugin Python thông thường
MAX_UNCOMPRESSED_BYTES = 50 * 1024 * 1024  # chặn zip-bomb
_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]{1,64}$")


class PluginInstallError(Exception):
    """Lỗi có thể hiểu được, hiển thị trực tiếp cho người dùng trên Web UI."""


@dataclass
class ManifestInput:
    key: str
    label: str
    type: str = "text"       # text | number | boolean | password
    default: Any = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ManifestInput":
        if not d.get("key"):
            raise PluginInstallError("manifest.json: mỗi input cần có 'key'")
        return cls(key=str(d["key"]), label=str(d.get("label", d["key"])),
                  type=str(d.get("type", "text")), default=d.get("default"))


@dataclass
class Manifest:
    name: str
    description: str = ""
    version: str = "1.0"
    inputs: list[ManifestInput] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Manifest":
        if not d.get("name") or not _NAME_RE.match(d["name"]):
            raise PluginInstallError("manifest.json: 'name' bắt buộc, chỉ gồm chữ/số/_/-  (tối đa 64 ký tự)")
        return cls(name=d["name"], description=str(d.get("description", "")),
                  version=str(d.get("version", "1.0")),
                  inputs=[ManifestInput.from_dict(i) for i in d.get("inputs", [])])

    def default_config(self) -> dict[str, Any]:
        return {i.key: i.default for i in self.inputs}

    def as_dict(self) -> dict[str, Any]:
        return {"name": self.name, "description": self.description, "version": self.version,
                "inputs": [vars(i) for i in self.inputs]}


class PluginInstaller:
    """Giải nén và kiểm tra một gói plugin .zip (mục 4.2 - Drag-and-Drop Plugin Manager)."""

    def __init__(self, plugins_dir: Path) -> None:
        self.plugins_dir = Path(plugins_dir)

    def install_zip(self, zip_bytes: bytes) -> Manifest:
        if len(zip_bytes) > MAX_ZIP_BYTES:
            raise PluginInstallError(f"Tệp .zip vượt quá {MAX_ZIP_BYTES // 1024 // 1024} MB")
        import io

        try:
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
        except zipfile.BadZipFile as exc:
            raise PluginInstallError("Không phải tệp .zip hợp lệ") from exc

        total_uncompressed = sum(i.file_size for i in zf.infolist())
        if total_uncompressed > MAX_UNCOMPRESSED_BYTES:
            raise PluginInstallError("Nội dung giải nén vượt quá giới hạn cho phép (nghi zip-bomb)")
        names = [i.filename for i in zf.infolist() if not i.is_dir()]
        for n in names:
            if n.startswith("/") or ".." in Path(n).parts:
                raise PluginInstallError(f"Đường dẫn không an toàn trong zip: {n!r} (chặn zip-slip)")

        # Chuẩn hoá: nếu mọi tệp nằm trong một thư mục gốc chung (vd. "my-plugin/main.py"),
        # bỏ tiền tố đó đi để lấy đúng main.py/manifest.json ở gốc.
        common_prefix = ""
        parts0 = names[0].split("/") if names else []
        if len(parts0) > 1 and all(n.startswith(parts0[0] + "/") for n in names):
            common_prefix = parts0[0] + "/"
        rel = {n[len(common_prefix):]: n for n in names}

        if "manifest.json" not in rel or "main.py" not in rel:
            raise PluginInstallError("Gói plugin cần có 'manifest.json' và 'main.py' ở thư mục gốc")
        try:
            manifest = Manifest.from_dict(json.loads(zf.read(rel["manifest.json"]).decode("utf-8")))
        except json.JSONDecodeError as exc:
            raise PluginInstallError(f"manifest.json không phải JSON hợp lệ: {exc}") from exc

        dest = self.plugins_dir / manifest.name
        tmp_dest = self.plugins_dir / f".{manifest.name}.installing"
        shutil.rmtree(tmp_dest, ignore_errors=True)
        tmp_dest.mkdir(parents=True)
        try:
            for rel_name, zip_name in rel.items():
                target = tmp_dest / rel_name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(zf.read(zip_name))
            shutil.rmtree(dest, ignore_errors=True)
            tmp_dest.rename(dest)
        finally:
            shutil.rmtree(tmp_dest, ignore_errors=True)
        LOGGER.info("Đã cài plugin '%s' (phiên bản %s) vào %s", manifest.name, manifest.version, dest)
        return manifest

    def remove(self, name: str) -> None:
        if not _NAME_RE.match(name):
            raise PluginInstallError("Tên plugin không hợp lệ")
        shutil.rmtree(self.plugins_dir / name, ignore_errors=True)

    def discover_manifests(self) -> dict[str, Manifest]:
        """Quét plugins/<ten>/manifest.json cho các plugin đã cài qua Web UI."""
        found: dict[str, Manifest] = {}
        if not self.plugins_dir.is_dir():
            return found
        for sub in self.plugins_dir.iterdir():
            manifest_path = sub / "manifest.json"
            if sub.is_dir() and manifest_path.is_file():
                try:
                    found[sub.name] = Manifest.from_dict(json.loads(manifest_path.read_text(encoding="utf-8")))
                except (json.JSONDecodeError, PluginInstallError) as exc:
                    LOGGER.warning("Bỏ qua manifest lỗi ở %s: %s", sub, exc)
        return found


class PluginManager:
    def __init__(self, plugins_dir: Path, init_scripts_dir: Path) -> None:
        self.plugins_dir, self.init_dir = Path(plugins_dir), Path(init_scripts_dir)
        self._modules: dict[str, ModuleType] = {}
        self._configs: dict[str, dict[str, Any]] = {}
        self._scripts: list[tuple[str, str]] = []

    def load(self, enabled: Optional[dict[str, bool]] = None,
             configs: Optional[dict[str, dict[str, Any]]] = None) -> None:
        """enabled: {tên_plugin: bật/tắt} từ bảng plugin_configs (mặc định bật nếu không có
        trong dict). configs: {tên_plugin: {key: value}} - cấu hình người dùng điền trên Web UI."""
        enabled, configs = enabled or {}, configs or {}
        self._modules.clear()
        self._configs.clear()
        self._scripts.clear()

        if self.plugins_dir.is_dir():
            # (1) Plugin kiểu cũ: tệp .py rời ở gốc plugins/ - luôn bật.
            for path in sorted(self.plugins_dir.glob("*.py")):
                if path.name.startswith("_"):
                    continue
                module = self._import(path.stem, path)
                if module and any(callable(getattr(module, h, None)) for h in HOOKS):
                    self._modules[path.stem] = module
                    self._configs[path.stem] = {}
                    LOGGER.info("Đã nạp plugin: %s", path.name)
            # (2) Plugin đóng gói: thư mục con có manifest.json + main.py.
            for sub in sorted(self.plugins_dir.iterdir()):
                main_py = sub / "main.py"
                if not (sub.is_dir() and main_py.is_file() and (sub / "manifest.json").is_file()):
                    continue
                if not enabled.get(sub.name, True):
                    LOGGER.info("Plugin '%s' đang TẮT - bỏ qua", sub.name)
                    continue
                module = self._import(sub.name, main_py)
                if module:
                    self._modules[sub.name] = module
                    self._configs[sub.name] = configs.get(sub.name, {})
                    LOGGER.info("Đã nạp plugin đóng gói: %s", sub.name)

        if self.init_dir.is_dir():
            for path in sorted(self.init_dir.glob("*.js")):
                self._scripts.append((path.name, path.read_text(encoding="utf-8")))
                LOGGER.info("Đã nạp init script: %s", path.name)

    @staticmethod
    def _import(stem: str, path: Path) -> "ModuleType | None":
        name = f"qa_plugin_{stem}"
        try:
            spec = importlib.util.spec_from_file_location(name, path)
            if spec is None or spec.loader is None:
                raise ImportError(str(path))
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            return module
        except Exception:  # noqa: BLE001
            sys.modules.pop(name, None)
            LOGGER.exception("Không nạp được plugin %s", path)
            return None

    @property
    def init_scripts(self) -> list[tuple[str, str]]:
        return list(self._scripts)

    async def run(self, hook: str, *args: Any, **context: Any) -> None:
        for name, module in self._modules.items():
            fn = getattr(module, hook, None)
            if not callable(fn):
                continue
            try:
                ctx = {**context, "config": self._configs.get(name, {})}
                result = fn(*args, **self._kwargs(fn, ctx))
                if inspect.isawaitable(result):
                    await result
            except Exception:  # noqa: BLE001 - plugin lỗi không được làm sập engine
                LOGGER.exception("Plugin '%s' lỗi ở hook %s", name, hook)

    @staticmethod
    def _kwargs(fn: Callable[..., Any], ctx: dict[str, Any]) -> dict[str, Any]:
        try:
            params = inspect.signature(fn).parameters
        except (TypeError, ValueError):
            return {}
        if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()):
            return dict(ctx)
        return {k: v for k, v in ctx.items() if k in params}


async def reconcile_plugins(db: Any, paths: Any) -> tuple[dict[str, bool], dict[str, dict[str, Any]]]:
    """Quét plugins/<tên>/manifest.json, đăng ký plugin mới phát hiện vào bảng
    plugin_configs (bật mặc định, cấu hình = giá trị default của manifest), rồi trả về
    (enabled, configs) để truyền thẳng vào `PluginManager.load()`. Gọi lại an toàn mỗi
    chu kỳ chạy - không ghi đè cấu hình người dùng đã lưu cho plugin đã biết."""
    from datetime import datetime, timezone

    installer = PluginInstaller(paths.plugins)
    manifests = installer.discover_manifests()
    existing = {r["plugin_name"] for r in await db.aall_plugin_configs()}
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    for name, manifest in manifests.items():
        if name not in existing:
            await db.aupsert_plugin_config(name, True, manifest.default_config(), manifest.as_dict(), now)
    rows = await db.aall_plugin_configs()
    return ({r["plugin_name"]: bool(r["enabled"]) for r in rows},
            {r["plugin_name"]: r["config"] for r in rows})
