"""Bộ Tự Động Tái Cấu Trúc Kịch Bản Bằng AI Cục Bộ (Local LLM Autopilot Rewriter).

Kết nối tới Ollama (http://localhost:11434) để:
  1. Sinh biến thể kịch bản: sắp xếp lại bước phụ, thêm dwell/scroll ngẫu nhiên,
     thay đổi từ khóa tìm kiếm theo spintax — giữ nguyên assertions và target endpoints.
  2. Spintax expander: {từ_này|hay_từ_kia|hoặc_từ_khác} → chọn 1 ngẫu nhiên.
  3. Fallback offline: nếu Ollama không chạy → áp lightweight mutation cứng (shuffle
     bước phụ, random dwell, spintax expand) hoàn toàn không cần LLM.

Cấu hình trong scenarios.json:
  "autopilot": {
    "enabled": true,
    "model": "llama3.2",           // model Ollama
    "mutation_level": "light",      // light | medium | heavy
    "preserve_assertions": true,    // không đảo assertions/goto
    "max_tokens": 1500
  }

GIỚI HẠN:
  - Ollama phải chạy cục bộ: ollama serve (cổng 11434 mặc định).
  - LLM có thể sinh JSON không hợp lệ → luôn validate + fallback về kịch bản gốc.
  - mutation_level="heavy" có thể xóa bước phụ làm kịch bản ngắn hơn — dự phòng.
  - Không gửi thông tin nhạy cảm (password, API key trong steps) sang LLM.
    AutopilotRewriter.sanitize_scenario() strip các trường nhạy cảm trước khi gửi.
"""
from __future__ import annotations

import json
import logging
import random
import re
import time
from copy import deepcopy
from typing import Any, Optional

LOGGER = logging.getLogger("qa.autopilot")

# Bước "cốt lõi" — không được đảo thứ tự, thêm/xóa
_CORE_ACTIONS = frozenset({
    "goto", "assert_selector", "assert_text", "assert_url", "assert_title",
    "fill", "click", "submit", "wait_for_selector", "navigate",
    "referrer_goto", "vault_load_cookies", "js_probe", "preflight_audit",
    "hybrid_handoff",
})
# Bước "phụ" — có thể đảo thứ tự, nhân đôi, bỏ bớt
_SECONDARY_ACTIONS = frozenset({
    "scroll", "wait", "mouse_move", "hover", "screenshot",
    "human_scroll", "human_click", "widget_qa", "media_qa",
    "dwell", "move_to",
})
# Bước chờ ngẫu nhiên để thêm vào giữa các bước chính
_DWELL_TEMPLATES = [
    {"action": "wait", "duration_ms": 0},          # thời gian sẽ được random
    {"action": "human_scroll", "delta_y": 0},
    {"action": "screenshot", "name": "auto_snap"},
]

# ---------------------------------------------------------------------------
# Spintax expander
# ---------------------------------------------------------------------------

def expand_spintax(text: str) -> str:
    """Mở rộng {option1|option2|option3} → chọn 1 ngẫu nhiên.
    Hỗ trợ nested: {outer{inner1|inner2}|plain}.
    """
    max_iter = 20
    for _ in range(max_iter):
        # Tìm innermost {} không chứa {}
        m = re.search(r'\{([^{}]+)\}', text)
        if not m:
            break
        options = m.group(1).split("|")
        chosen = random.choice(options).strip()
        text = text[:m.start()] + chosen + text[m.end():]
    return text


def expand_spintax_in_step(step: dict[str, Any]) -> dict[str, Any]:
    """Áp spintax lên mọi giá trị string trong step."""
    result = {}
    for k, v in step.items():
        if isinstance(v, str):
            result[k] = expand_spintax(v)
        elif isinstance(v, dict):
            result[k] = expand_spintax_in_step(v)
        else:
            result[k] = v
    return result


# ---------------------------------------------------------------------------
# Offline lightweight mutator (không cần LLM)
# ---------------------------------------------------------------------------

def _add_random_dwell(steps: list[dict], count: int = 1) -> list[dict]:
    """Chèn bước dwell/scroll ngẫu nhiên vào giữa các bước."""
    result = list(steps)
    positions = sorted(random.sample(range(1, max(2, len(result))), min(count, len(result) - 1)))
    for offset, pos in enumerate(positions):
        tmpl = deepcopy(random.choice(_DWELL_TEMPLATES))
        if tmpl["action"] == "wait":
            tmpl["duration_ms"] = random.randint(500, 3000)
        elif tmpl["action"] == "human_scroll":
            tmpl["delta_y"] = random.randint(100, 500) * random.choice([1, -1])
        result.insert(pos + offset, tmpl)
    return result


def mutate_offline(
    steps: list[dict[str, Any]],
    level: str = "light",
    preserve_assertions: bool = True,
) -> list[dict[str, Any]]:
    """Áp mutation không cần LLM.

    light:  thêm 1-2 dwell, expand spintax.
    medium: shuffle bước phụ liền kề, thêm 2-3 dwell, expand spintax.
    heavy:  shuffle tất cả bước phụ toàn kịch bản, thêm 3-5 dwell, có thể bỏ 1 bước phụ.
    """
    result = [expand_spintax_in_step(deepcopy(s)) for s in steps]

    core_indices = [i for i, s in enumerate(result)
                    if s.get("action", "") in _CORE_ACTIONS or
                    (preserve_assertions and "assert" in s.get("action", ""))]
    secondary_indices = [i for i, s in enumerate(result)
                         if i not in core_indices]

    if level == "light":
        result = _add_random_dwell(result, count=random.randint(1, 2))

    elif level == "medium":
        # Shuffle từng cụm bước phụ liên tiếp
        if secondary_indices:
            groups: list[list[int]] = []
            g: list[int] = []
            for idx in secondary_indices:
                if g and idx != g[-1] + 1:
                    groups.append(g)
                    g = []
                g.append(idx)
            if g:
                groups.append(g)
            for group in groups:
                if len(group) > 1:
                    vals = [result[i] for i in group]
                    random.shuffle(vals)
                    for i, v in zip(group, vals):
                        result[i] = v
        result = _add_random_dwell(result, count=random.randint(2, 3))

    elif level == "heavy":
        if secondary_indices:
            vals = [result[i] for i in secondary_indices]
            random.shuffle(vals)
            # Optionally drop 1 secondary step
            if len(vals) > 2 and random.random() < 0.3:
                vals.pop(random.randrange(len(vals)))
            # Re-insert (may be fewer now)
            for i, v in zip(secondary_indices[:len(vals)], vals):
                result[i] = v
        result = _add_random_dwell(result, count=random.randint(3, 5))

    return result


# ---------------------------------------------------------------------------
# Ollama LLM mutator
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """You are a QA scenario optimizer. You receive a JSON list of test steps.
Your job: return a MUTATED version that:
1. PRESERVES all steps with actions: {core_actions}
2. May reorder, duplicate, or remove steps with actions: {secondary_actions}
3. Adds 1-3 natural dwell/scroll steps between main steps
4. Expands {{option1|option2}} spintax randomly (pick one option)
5. Changes numeric values slightly (±20%) where appropriate
6. MUST return valid JSON array of steps ONLY — no explanation, no markdown
Return ONLY the JSON array."""


async def mutate_with_llm(
    steps: list[dict[str, Any]],
    model: str = "llama3.2",
    ollama_url: str = "http://localhost:11434",
    max_tokens: int = 1500,
    timeout_s: float = 30.0,
    level: str = "medium",
    preserve_assertions: bool = True,
) -> Optional[list[dict[str, Any]]]:
    """Gửi steps tới Ollama LLM để sinh biến thể. Trả None nếu thất bại."""
    try:
        import httpx
    except ImportError:
        return None

    # Sanitize: loại bỏ trường nhạy cảm trước khi gửi
    safe_steps = _sanitize_steps(steps)

    prompt = _SYSTEM_PROMPT.format(
        core_actions=", ".join(sorted(_CORE_ACTIONS)),
        secondary_actions=", ".join(sorted(_SECONDARY_ACTIONS)),
    )
    user_msg = (
        f"Mutation level: {level}. Preserve assertions: {preserve_assertions}.\n"
        f"Steps to mutate:\n{json.dumps(safe_steps, ensure_ascii=False, indent=2)}"
    )

    try:
        async with httpx.AsyncClient(timeout=timeout_s) as c:
            r = await c.post(f"{ollama_url}/api/generate", json={
                "model": model,
                "prompt": user_msg,
                "system": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.7,
                    "num_predict": max_tokens,
                },
            })
        if r.status_code != 200:
            LOGGER.debug("autopilot LLM HTTP %d", r.status_code)
            return None

        raw = r.json().get("response", "")
        # Extract JSON array từ response (có thể có text thừa)
        m = re.search(r'\[.*\]', raw, re.DOTALL)
        if not m:
            LOGGER.debug("autopilot: LLM không trả về JSON array")
            return None

        mutated = json.loads(m.group(0))
        if not isinstance(mutated, list):
            return None

        # Validate: mọi core step từ gốc phải có trong kết quả
        if preserve_assertions:
            core_orig = [s for s in steps if s.get("action") in _CORE_ACTIONS]
            core_mut = [s for s in mutated if s.get("action") in _CORE_ACTIONS]
            if len(core_mut) < len(core_orig):
                LOGGER.warning("autopilot: LLM xóa core step → reject, dùng offline fallback")
                return None

        LOGGER.info("autopilot: LLM sinh %d steps (gốc %d)", len(mutated), len(steps))
        return mutated

    except Exception as exc:
        LOGGER.debug("autopilot LLM lỗi: %s", exc)
        return None


def _sanitize_steps(steps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Strip trường nhạy cảm trước khi gửi LLM."""
    _SENSITIVE = {"password", "api_key", "token", "secret", "credentials"}
    result = []
    for step in steps:
        clean = {}
        for k, v in step.items():
            if k.lower() in _SENSITIVE:
                clean[k] = "***"
            elif isinstance(v, str) and len(v) > 200:
                clean[k] = v[:100] + "...[truncated]"
            else:
                clean[k] = v
        result.append(clean)
    return result


# ---------------------------------------------------------------------------
# AutopilotRewriter — public interface
# ---------------------------------------------------------------------------

class AutopilotRewriter:
    """Sinh biến thể kịch bản: thử LLM trước, fallback offline nếu không có."""

    def __init__(
        self,
        ollama_url: str = "http://localhost:11434",
        model: str = "llama3.2",
        max_tokens: int = 1500,
        timeout_s: float = 30.0,
    ) -> None:
        self.ollama_url = ollama_url
        self.model = model
        self.max_tokens = max_tokens
        self.timeout_s = timeout_s
        self._ollama_available: Optional[bool] = None  # cache

    async def _check_ollama(self) -> bool:
        if self._ollama_available is not None:
            return self._ollama_available
        try:
            import httpx
            async with httpx.AsyncClient(timeout=3) as c:
                r = await c.get(f"{self.ollama_url}/api/tags")
                self._ollama_available = r.status_code == 200
        except Exception:
            self._ollama_available = False
        return self._ollama_available

    async def rewrite(
        self,
        scenario: dict[str, Any],
        cfg: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Sinh biến thể kịch bản. Trả về scenario mới (gốc không bị sửa)."""
        cfg = cfg or scenario.get("autopilot") or {}
        if not cfg.get("enabled", False):
            return scenario

        level = cfg.get("mutation_level", "light")
        preserve = cfg.get("preserve_assertions", True)
        model = cfg.get("model", self.model)

        original_steps = scenario.get("steps", [])
        if not original_steps:
            return scenario

        t0 = time.perf_counter()
        mutated_steps: Optional[list[dict]] = None

        # Thử LLM nếu Ollama available
        if await self._check_ollama():
            mutated_steps = await mutate_with_llm(
                original_steps,
                model=model,
                ollama_url=self.ollama_url,
                max_tokens=cfg.get("max_tokens", self.max_tokens),
                timeout_s=self.timeout_s,
                level=level,
                preserve_assertions=preserve,
            )

        # Fallback offline
        if mutated_steps is None:
            LOGGER.info("autopilot: dùng offline mutation (level=%s)", level)
            mutated_steps = mutate_offline(original_steps, level, preserve)

        elapsed = round((time.perf_counter() - t0) * 1000)
        LOGGER.info("autopilot: %d→%d steps (%dms, llm=%s)",
                    len(original_steps), len(mutated_steps),
                    elapsed, mutated_steps is not None and not any(
                        s.get("_offline") for s in mutated_steps))

        new_scenario = deepcopy(scenario)
        new_scenario["steps"] = mutated_steps
        new_scenario["_autopilot_mutated"] = True
        new_scenario["_mutation_level"] = level
        return new_scenario

    async def preview(self, steps: list[dict[str, Any]],
                      level: str = "light") -> list[dict[str, Any]]:
        """Preview mutation không lưu — dùng cho dashboard."""
        return mutate_offline(steps, level, preserve_assertions=True)
