"""Event bus trong tiến trình: đẩy log/sự kiện tới dashboard (SSE)."""
from __future__ import annotations

import asyncio
import logging
from collections import deque
from datetime import datetime, timezone
from typing import Any


class EventBus:
    def __init__(self, history: int = 500) -> None:
        self._subs: set[asyncio.Queue[dict[str, Any]]] = set()
        self._history: deque[dict[str, Any]] = deque(maxlen=history)

    def publish(self, kind: str, **fields: Any) -> None:
        event = {"ts": datetime.now(timezone.utc).strftime("%H:%M:%S"), "kind": kind, **fields}
        self._history.append(event)
        for q in list(self._subs):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass  # người xem chậm: bỏ qua sự kiện

    def history(self) -> list[dict[str, Any]]:
        return list(self._history)

    def subscribe(self) -> "asyncio.Queue[dict[str, Any]]":
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: "asyncio.Queue[dict[str, Any]]") -> None:
        self._subs.discard(q)


class BusLogHandler(logging.Handler):
    """Chuyển mọi log của logger 'qa.*' lên event bus (kèm mã luồng `task`)."""

    def __init__(self, bus: EventBus) -> None:
        super().__init__(level=logging.INFO)
        self._bus = bus

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self._bus.publish("log", level=record.levelname, logger=record.name,
                              task=getattr(record, "task", None), message=record.getMessage())
        except Exception:  # noqa: BLE001
            pass
