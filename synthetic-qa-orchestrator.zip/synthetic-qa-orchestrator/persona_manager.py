"""Bộ Đồng Bộ Hóa Hồ Sơ Phần Cứng Nhất Quán (Deterministic Persona & Hardware Coherence).

Nạp các bộ hồ sơ thiết bị thực tế từ device_personas.json và áp đồng nhất
một bộ thông số cố định lên tất cả các tầng của phiên Playwright:
  - Tầng định danh: User-Agent, Client Hints, navigator.*, platform
  - Tầng phần cứng: hardwareConcurrency, deviceMemory, devicePixelRatio
  - Tầng đồ họa: WebGL vendor/renderer, Canvas noise seed
  - Tầng âm thanh: AudioContext noise seed
  - Tầng worker: Web Workers nhận cùng thông số với Main Thread

GIỚI HẠN ĐÃ BIẾT:
  - Playwright chưa hỗ trợ native WebGL spoofing → dùng JS injection qua
    `add_init_script`. Trình duyệt có thể phát hiện nếu dùng Object.defineProperty
    sau khi context đã khởi tạo. Inject vào `add_init_script` chạy TRƯỚC mọi script
    của trang → an toàn hơn nhiều.
  - Canvas fingerprint noise: áp một hàm nhiễu Gaussian vi mô lên pixel data
    của toDataURL/getImageData. Không giống native GPU rendering nhưng đủ để
    phá vỡ các fingerprinting thư viện thông dụng (FingerprintJS, Cloudflare).
  - device_personas.json được cung cấp sẵn 10 persona mẫu. Thêm persona thật
    từ thiết bị vật lý của bạn để có độ chân thực cao hơn.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.persona")

# ---------------------------------------------------------------------------
# Default device_personas.json (10 persona thực tế)
# ---------------------------------------------------------------------------

DEFAULT_PERSONAS: list[dict[str, Any]] = [
    {
        "id": "win11-chrome-desktop-en",
        "os": "Windows", "os_version": "11",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "platform": "Win32",
        "hardware_concurrency": 8,
        "device_memory": 8,
        "device_pixel_ratio": 1.0,
        "screen": {"width": 1920, "height": 1080},
        "webgl": {"vendor": "Google Inc. (Intel)", "renderer": "ANGLE (Intel, Intel(R) UHD Graphics 770 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
        "client_hints": {"platform": "Windows", "platform_version": "15.0.0", "mobile": False, "architecture": "x86", "bitness": "64"},
        "locale": "en-US", "timezone": "America/New_York",
        "accept_language": "en-US,en;q=0.9",
        "webgpu_adapter": {"vendor": "intel", "architecture": "gen-12lp",
                            "device": "Intel(R) UHD Graphics 770",
                            "description": "Intel(R) UHD Graphics 770", "backend": "D3D12"},
        "media_devices": {"videoinput": 1, "audioinput": 1, "audiooutput": 1},
    },
    {
        "id": "win11-chrome-desktop-vi",
        "os": "Windows", "os_version": "11",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "platform": "Win32",
        "hardware_concurrency": 4,
        "device_memory": 4,
        "device_pixel_ratio": 1.0,
        "screen": {"width": 1366, "height": 768},
        "webgl": {"vendor": "Google Inc. (NVIDIA)", "renderer": "ANGLE (NVIDIA, NVIDIA GeForce GTX 1650 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
        "client_hints": {"platform": "Windows", "platform_version": "15.0.0", "mobile": False, "architecture": "x86", "bitness": "64"},
        "locale": "vi-VN", "timezone": "Asia/Ho_Chi_Minh",
        "accept_language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
    },
    {
        "id": "macos-chrome-desktop",
        "os": "macOS", "os_version": "14",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "platform": "MacIntel",
        "hardware_concurrency": 10,
        "device_memory": 16,
        "device_pixel_ratio": 2.0,
        "screen": {"width": 2560, "height": 1664},
        "webgl": {"vendor": "Apple Inc.", "renderer": "Apple M2"},
        "client_hints": {"platform": "macOS", "platform_version": "14.0.0", "mobile": False, "architecture": "arm", "bitness": "64"},
        "locale": "en-US", "timezone": "America/Los_Angeles",
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "id": "android-chrome-mobile",
        "os": "Android", "os_version": "14",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "mobile",
        "user_agent": "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Mobile Safari/537.36",
        "platform": "Linux armv81",
        "hardware_concurrency": 8,
        "device_memory": 8,
        "device_pixel_ratio": 2.625,
        "screen": {"width": 412, "height": 892},
        "webgl": {"vendor": "ARM", "renderer": "Mali-G715"},
        "client_hints": {"platform": "Android", "platform_version": "14.0.0", "mobile": True, "architecture": "arm", "bitness": "64"},
        "locale": "en-US", "timezone": "America/New_York",
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "id": "iphone-safari-mobile",
        "os": "iOS", "os_version": "17",
        "browser": "Safari", "browser_version": "17",
        "device_type": "mobile",
        "user_agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
        "platform": "iPhone",
        "hardware_concurrency": 6,
        "device_memory": 6,
        "device_pixel_ratio": 3.0,
        "screen": {"width": 390, "height": 844},
        "webgl": {"vendor": "Apple Inc.", "renderer": "Apple GPU"},
        "client_hints": {},
        "locale": "en-US", "timezone": "America/Chicago",
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "id": "win10-firefox-desktop",
        "os": "Windows", "os_version": "10",
        "browser": "Firefox", "browser_version": "121",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "platform": "Win32",
        "hardware_concurrency": 4,
        "device_memory": 8,
        "device_pixel_ratio": 1.0,
        "screen": {"width": 1920, "height": 1080},
        "webgl": {"vendor": "Google Inc. (Intel)", "renderer": "ANGLE (Intel, Intel(R) HD Graphics 620 Direct3D11 vs_5_0 ps_5_0)"},
        "client_hints": {},
        "locale": "en-US", "timezone": "Europe/London",
        "accept_language": "en-US,en;q=0.5",
    },
    {
        "id": "ubuntu-chrome-desktop",
        "os": "Linux", "os_version": "22.04",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "platform": "Linux x86_64",
        "hardware_concurrency": 16,
        "device_memory": 32,
        "device_pixel_ratio": 1.0,
        "screen": {"width": 2560, "height": 1440},
        "webgl": {"vendor": "Google Inc. (NVIDIA)", "renderer": "ANGLE (NVIDIA, NVIDIA RTX 4070 Ti, OpenGL 4.6)"},
        "client_hints": {"platform": "Linux", "platform_version": "", "mobile": False, "architecture": "x86", "bitness": "64"},
        "locale": "en-US", "timezone": "Europe/Berlin",
        "accept_language": "en-US,en;q=0.9,de;q=0.8",
    },
    {
        "id": "android-samsung-mobile",
        "os": "Android", "os_version": "13",
        "browser": "Chrome", "browser_version": "130",
        "device_type": "mobile",
        "user_agent": "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.102 Mobile Safari/537.36",
        "platform": "Linux armv81",
        "hardware_concurrency": 8,
        "device_memory": 8,
        "device_pixel_ratio": 3.0,
        "screen": {"width": 360, "height": 780},
        "webgl": {"vendor": "ARM", "renderer": "Mali-G715-MC10"},
        "client_hints": {"platform": "Android", "platform_version": "13.0.0", "mobile": True, "architecture": "arm", "bitness": "64"},
        "locale": "ko-KR", "timezone": "Asia/Seoul",
        "accept_language": "ko-KR,ko;q=0.9,en-US;q=0.8",
    },
    {
        "id": "win11-edge-desktop",
        "os": "Windows", "os_version": "11",
        "browser": "Edge", "browser_version": "131",
        "device_type": "desktop",
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0",
        "platform": "Win32",
        "hardware_concurrency": 12,
        "device_memory": 16,
        "device_pixel_ratio": 1.25,
        "screen": {"width": 2560, "height": 1440},
        "webgl": {"vendor": "Google Inc. (NVIDIA)", "renderer": "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)"},
        "client_hints": {"platform": "Windows", "platform_version": "15.0.0", "mobile": False, "architecture": "x86", "bitness": "64"},
        "locale": "en-US", "timezone": "America/New_York",
        "accept_language": "en-US,en;q=0.9",
    },
    {
        "id": "tablet-android-chrome",
        "os": "Android", "os_version": "13",
        "browser": "Chrome", "browser_version": "131",
        "device_type": "tablet",
        "user_agent": "Mozilla/5.0 (Linux; Android 13; SM-X900) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.135 Safari/537.36",
        "platform": "Linux armv81",
        "hardware_concurrency": 8,
        "device_memory": 8,
        "device_pixel_ratio": 2.0,
        "screen": {"width": 1600, "height": 2560},
        "webgl": {"vendor": "ARM", "renderer": "Mali-G710"},
        "client_hints": {"platform": "Android", "platform_version": "13.0.0", "mobile": False, "architecture": "arm", "bitness": "64"},
        "locale": "zh-CN", "timezone": "Asia/Shanghai",
        "accept_language": "zh-CN,zh;q=0.9,en;q=0.8",
    },
]


# ---------------------------------------------------------------------------
# JS injection scripts
# ---------------------------------------------------------------------------

def _build_navigator_script(persona: dict[str, Any]) -> str:
    """Tạo script JS ghi đè navigator.* và Client Hints."""
    ua = json.dumps(persona["user_agent"])
    platform = json.dumps(persona["platform"])
    hc = persona["hardware_concurrency"]
    dm = persona["device_memory"]
    dpr = persona["device_pixel_ratio"]
    ch = persona.get("client_hints", {})

    return f"""
(function() {{
  // Navigator overrides
  const def = (obj, prop, val) => {{
    try {{
      Object.defineProperty(obj, prop, {{get: () => val, configurable: true}});
    }} catch(e) {{}}
  }};
  def(navigator, 'userAgent', {ua});
  def(navigator, 'platform', {platform});
  def(navigator, 'hardwareConcurrency', {hc});
  def(navigator, 'deviceMemory', {dm});
  def(window, 'devicePixelRatio', {dpr});

  // userAgentData (Client Hints)
  if ({json.dumps(bool(ch))}) {{
    const hints = {json.dumps(ch)};
    def(navigator, 'userAgentData', {{
      brands: [
        {{brand: 'Google Chrome', version: '131'}},
        {{brand: 'Chromium', version: '131'}},
        {{brand: 'Not_A Brand', version: '24'}},
      ],
      mobile: hints.mobile || false,
      platform: hints.platform || '',
      getHighEntropyValues: async (keys) => {{
        const map = {{
          platform: hints.platform || '',
          platformVersion: hints.platform_version || '',
          architecture: hints.architecture || 'x86',
          bitness: hints.bitness || '64',
          model: '',
          uaFullVersion: '131.0.0.0',
        }};
        const r = {{}};
        keys.forEach(k => {{ if(map[k] !== undefined) r[k] = map[k]; }});
        return r;
      }}
    }});
  }}

  // Worker propagation: ghi đè navigator trong ServiceWorker/SharedWorker context
  if (typeof WorkerNavigator !== 'undefined') {{
    def(WorkerNavigator.prototype, 'hardwareConcurrency', {hc});
  }}
}})();
"""


def _build_webgl_script(vendor: str, renderer: str, noise_seed: int = 42) -> str:
    """Tạo script JS ghi đè WebGL vendor/renderer và thêm noise vi mô vào Canvas."""
    return f"""
(function() {{
  const seed = {noise_seed};
  // LCG mini RNG từ seed để noise nhất quán
  let _s = seed;
  const rng = () => {{ _s = (_s * 1664525 + 1013904223) & 0xFFFFFFFF; return (_s >>> 0) / 4294967296; }};

  // WebGL vendor/renderer
  const getParamOrig = WebGLRenderingContext.prototype.getParameter;
  WebGLRenderingContext.prototype.getParameter = function(param) {{
    if (param === 37445) return {json.dumps(vendor)};   // UNMASKED_VENDOR_WEBGL
    if (param === 37446) return {json.dumps(renderer)}; // UNMASKED_RENDERER_WEBGL
    if (param === 7937)  return {json.dumps(vendor)};   // VENDOR
    if (param === 7936)  return {json.dumps(renderer)}; // RENDERER
    return getParamOrig.call(this, param);
  }};
  if (typeof WebGL2RenderingContext !== 'undefined') {{
    const getParam2 = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function(param) {{
      if (param === 37445) return {json.dumps(vendor)};
      if (param === 37446) return {json.dumps(renderer)};
      return getParam2.call(this, param);
    }};
  }}

  // Canvas noise vi mô (±1 LSB trên kênh alpha)
  const toDataURLOrig = HTMLCanvasElement.prototype.toDataURL;
  HTMLCanvasElement.prototype.toDataURL = function(...args) {{
    const ctx = this.getContext('2d');
    if (ctx) {{
      const img = ctx.getImageData(0, 0, this.width, this.height);
      for (let i = 3; i < img.data.length; i += 4) {{
        img.data[i] = Math.min(255, Math.max(0, img.data[i] + (rng() < 0.5 ? 1 : -1)));
      }}
      ctx.putImageData(img, 0, 0);
    }}
    return toDataURLOrig.apply(this, args);
  }};

  // AudioContext noise
  const getChannelDataOrig = AudioBuffer.prototype.getChannelData;
  AudioBuffer.prototype.getChannelData = function(ch) {{
    const data = getChannelDataOrig.call(this, ch);
    for (let i = 0; i < data.length; i += 100) {{
      data[i] += (rng() - 0.5) * 1e-7;
    }}
    return data;
  }};
}})();
"""


# Phase 7: OS-specific font whitelists
_OS_FONTS: dict[str, list[str]] = {
    "Windows": [
        "Arial", "Calibri", "Cambria", "Comic Sans MS", "Consolas",
        "Courier New", "Georgia", "Impact", "Lucida Console", "Segoe UI",
        "Tahoma", "Times New Roman", "Trebuchet MS", "Verdana",
        "Palatino Linotype", "Franklin Gothic Medium", "Microsoft Sans Serif",
    ],
    "macOS": [
        "Arial", "Courier New", "Georgia", "Helvetica", "Helvetica Neue",
        "Menlo", "Monaco", "San Francisco", "Optima", "Palatino",
        "Times New Roman", "Trebuchet MS", "Verdana", "Gill Sans",
        "Futura", "American Typewriter",
    ],
    "Android": [
        "Droid Sans", "Droid Serif", "Droid Sans Mono", "Roboto",
        "Roboto Condensed", "Roboto Mono", "Noto Sans", "Noto Serif",
    ],
    "iOS": [
        "Arial", "Courier New", "Georgia", "Helvetica", "Helvetica Neue",
        "Times New Roman", "Trebuchet MS", "Verdana", "Gill Sans",
        "San Francisco",
    ],
    "Linux": [
        "DejaVu Sans", "DejaVu Serif", "DejaVu Sans Mono",
        "Liberation Sans", "Liberation Serif", "Liberation Mono",
        "Ubuntu", "Noto Sans", "FreeSans", "FreeSerif",
    ],
}


def _build_font_whitelist_script(os_name: str) -> str:
    """Script JS giả lập font list theo OS, chặn enumerate font thật."""
    fonts = _OS_FONTS.get(os_name, _OS_FONTS["Windows"])
    fonts_json = json.dumps(fonts)
    return f"""
(function() {{
  // Override FontFaceSet.check() để trả về true chỉ cho font trong whitelist
  const allowed = new Set({fonts_json});
  const origCheck = FontFace.prototype ? undefined : null;
  if (document.fonts && document.fonts.check) {{
    const origFontsCheck = document.fonts.check.bind(document.fonts);
    document.fonts.check = function(font, text) {{
      // Extract font family name từ CSS font string
      const m = font.match(/['"]?([^'"]+)['"]?/);
      const name = m ? m[1].trim() : font.trim();
      return allowed.has(name);
    }};
  }}
  // Block font enumeration qua queryLocalFonts API (Chrome 103+)
  if (window.queryLocalFonts) {{
    window.queryLocalFonts = async () => {fonts_json}.map(f => ({{family:f, fullName:f, postscriptName:f, style:'Regular'}}));
  }}
}})();
"""


def _build_domrect_script(device_pixel_ratio: float, viewport_w: int, viewport_h: int) -> str:
    """Script JS hiệu chỉnh DOMRect precision theo viewport và devicePixelRatio.

    Thêm micro-noise (±0.1px) để tránh exact-integer detection, đồng thời đảm
    bảo các giá trị getBoundingClientRect() nhất quán với viewport đã cấu hình.
    """
    return f"""
(function() {{
  const dpr = {device_pixel_ratio};
  const vw = {viewport_w}, vh = {viewport_h};
  // Micro-noise seed từ DPR để consistent trong cùng session
  let _ns = Math.round(dpr * 1000) % 97;
  const noise = () => {{ _ns = (_ns * 1103515245 + 12345) & 0x7fffffff; return (_ns % 100 - 50) * 0.001; }};

  const origGetBCR = Element.prototype.getBoundingClientRect;
  Element.prototype.getBoundingClientRect = function() {{
    const r = origGetBCR.call(this);
    // Clamp trong viewport + noise vi mô
    const n = noise();
    return {{
      x: Math.max(0, Math.min(r.x + n, vw)),
      y: Math.max(0, Math.min(r.y + n, vh)),
      width: Math.max(0, r.width + noise()),
      height: Math.max(0, r.height + noise()),
      top: r.top + n, left: r.left + n,
      right: r.right + n, bottom: r.bottom + n,
      toJSON: () => ({{}})
    }};
  }};
  // Range.getClientRects consistency
  const origGCR = Range.prototype.getClientRects;
  Range.prototype.getClientRects = function() {{
    const rects = origGCR.call(this);
    return rects;
  }};
}})();
"""


def _build_webgpu_script(gpu_data: dict[str, Any]) -> str:
    """Spoof WebGPU adapter info để khớp với GPU của persona."""
    if not gpu_data:
        return "(function(){})()"
    vendor = json.dumps(gpu_data.get("vendor", "Google Inc."))
    architecture = json.dumps(gpu_data.get("architecture", ""))
    device = json.dumps(gpu_data.get("device", ""))
    description = json.dumps(gpu_data.get("description", ""))
    backend = json.dumps(gpu_data.get("backend", "WebGPU"))
    return f"""
(function() {{
  if (!navigator.gpu) return;
  const origRequestAdapter = navigator.gpu.requestAdapter.bind(navigator.gpu);
  navigator.gpu.requestAdapter = async function(opts) {{
    const adapter = await origRequestAdapter(opts);
    if (!adapter) return null;
    // Override AdapterInfo
    const origGetInfo = adapter.requestAdapterInfo?.bind(adapter);
    if (origGetInfo) {{
      adapter.requestAdapterInfo = async () => {{
        const info = await origGetInfo();
        const spoofed = Object.create(info);
        Object.defineProperties(spoofed, {{
          vendor:       {{ get: () => {vendor},       configurable: true }},
          architecture: {{ get: () => {architecture}, configurable: true }},
          device:       {{ get: () => {device},       configurable: true }},
          description:  {{ get: () => {description},  configurable: true }},
        }});
        return spoofed;
      }};
    }}
    // Also spoof adapter.info (Chrome 121+)
    try {{
      Object.defineProperty(adapter, 'info', {{
        get: () => ({{ vendor: {vendor}, architecture: {architecture},
                       device: {device}, description: {description} }}),
        configurable: true,
      }});
    }} catch(e) {{}}
    return adapter;
  }};
}})();
"""


def _build_media_devices_script(virtual_devices: bool = True,
                                  device_count: dict[str, int] | None = None) -> str:
    """Mô phỏng danh sách thiết bị media (camera/mic) như máy vật lý thật.

    Khi virtual_devices=True: trả về danh sách devices giả lập gồm 1 camera + 1 mic.
    device_count: {"videoinput": 1, "audioinput": 1, "audiooutput": 1}
    """
    counts = device_count or {"videoinput": 1, "audioinput": 1, "audiooutput": 1}
    devices: list[dict[str, str]] = []
    for i in range(counts.get("audioinput", 1)):
        devices.append({"kind": "audioinput",
                         "label": f"Default Microphone (device {i+1})",
                         "deviceId": f"audioinput_{i}",
                         "groupId": f"group_{i}"})
    for i in range(counts.get("videoinput", 1)):
        devices.append({"kind": "videoinput",
                         "label": f"Integrated Camera (device {i+1})",
                         "deviceId": f"videoinput_{i}",
                         "groupId": f"group_{i}"})
    for i in range(counts.get("audiooutput", 1)):
        devices.append({"kind": "audiooutput",
                         "label": f"Default Speaker (device {i+1})",
                         "deviceId": f"audiooutput_{i}",
                         "groupId": f"group_{i}"})
    devices_json = json.dumps(devices)
    return f"""
(function() {{
  if (!navigator.mediaDevices) return;
  const fakeDevices = {devices_json};
  const makeDeviceInfo = d => ({{
    deviceId: d.deviceId, kind: d.kind,
    label: d.label, groupId: d.groupId,
    toJSON: () => d,
  }});
  const origEnum = navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);
  navigator.mediaDevices.enumerateDevices = async function() {{
    // Trả về danh sách ảo thay vì danh sách thật của server
    return fakeDevices.map(makeDeviceInfo);
  }};
  // getSupportedConstraints: trả về full set như trình duyệt thật
  const origGSC = navigator.mediaDevices.getSupportedConstraints.bind(navigator.mediaDevices);
  navigator.mediaDevices.getSupportedConstraints = function() {{
    return {{
      width: true, height: true, aspectRatio: true, frameRate: true,
      facingMode: true, resizeMode: true, sampleRate: true, sampleSize: true,
      echoCancellation: true, autoGainControl: true, noiseSuppression: true,
      latency: true, channelCount: true, deviceId: true, groupId: true,
    }};
  }};
}})();
"""


def _build_webrtc_policy_script() -> str:
    """Chặn WebRTC rò rỉ IP qua disable_non_proxied_udp policy."""
    return """
(function() {
  // Override RTCPeerConnection để ẩn local ICE candidates
  const OrigRTC = window.RTCPeerConnection;
  if (!OrigRTC) return;
  window.RTCPeerConnection = function(config, ...args) {
    if (config && config.iceServers) {
      // Xóa STUN servers để ngăn IP leak
      config.iceServers = config.iceServers.filter(s =>
        !JSON.stringify(s).includes('stun:'));
    }
    const pc = new OrigRTC(config, ...args);
    // Chặn local candidates
    const origAddListener = pc.addEventListener.bind(pc);
    origAddListener('icecandidate', (e) => {
      if (e.candidate && e.candidate.candidate &&
          e.candidate.candidate.includes('host')) {
        return; // drop host candidates (local IP leak)
      }
    });
    return pc;
  };
  Object.assign(window.RTCPeerConnection, OrigRTC);
})();
"""


# ---------------------------------------------------------------------------
# PersonaManager
# ---------------------------------------------------------------------------

@dataclass
class Persona:
    id: str
    data: dict[str, Any]
    noise_seed: int = 0

    @property
    def user_agent(self) -> str:
        return self.data.get("user_agent", "")

    @property
    def locale(self) -> str:
        return self.data.get("locale", "en-US")

    @property
    def timezone(self) -> str:
        return self.data.get("timezone", "UTC")

    @property
    def screen(self) -> dict[str, int]:
        return self.data.get("screen", {"width": 1920, "height": 1080})

    @property
    def device_pixel_ratio(self) -> float:
        return float(self.data.get("device_pixel_ratio", 1.0))

    @property
    def accept_language(self) -> str:
        return self.data.get("accept_language", "en-US,en;q=0.9")

    @property
    def webgpu(self) -> dict[str, Any]:
        return self.data.get("webgpu", {})

    @property
    def media_devices(self) -> dict[str, Any]:
        return self.data.get("media_devices", {})


class PersonaManager:
    """Quản lý thư viện device personas và inject thông số vào Playwright context."""

    def __init__(self, personas_path: Optional[Path] = None) -> None:
        self._personas: dict[str, Persona] = {}
        self._load_defaults()
        if personas_path and personas_path.exists():
            self._load_file(personas_path)

    def _load_defaults(self) -> None:
        for p in DEFAULT_PERSONAS:
            seed = int(hashlib.md5(p["id"].encode()).hexdigest()[:8], 16)
            self._personas[p["id"]] = Persona(id=p["id"], data=p, noise_seed=seed)
        LOGGER.debug("persona: nạp %d persona mặc định", len(self._personas))

    def _load_file(self, path: Path) -> None:
        with path.open() as f:
            custom = json.load(f)
        for p in (custom if isinstance(custom, list) else custom.get("personas", [])):
            seed = int(hashlib.md5(p["id"].encode()).hexdigest()[:8], 16)
            self._personas[p["id"]] = Persona(id=p["id"], data=p, noise_seed=seed)
        LOGGER.info("persona: nạp thêm từ %s, tổng %d personas", path.name, len(self._personas))

    def get(self, persona_id: str) -> Optional[Persona]:
        return self._personas.get(persona_id)

    def pick_random(self, device_type: Optional[str] = None,
                    os_filter: Optional[str] = None) -> Persona:
        """Chọn ngẫu nhiên một persona, lọc theo device_type hoặc os."""
        candidates = list(self._personas.values())
        if device_type:
            candidates = [p for p in candidates if p.data.get("device_type") == device_type]
        if os_filter:
            candidates = [p for p in candidates if p.data.get("os", "").lower() == os_filter.lower()]
        if not candidates:
            candidates = list(self._personas.values())
        return random.choice(candidates)

    def list_personas(self) -> list[dict[str, str]]:
        return [{"id": p.id, "os": p.data.get("os",""), "browser": p.data.get("browser",""),
                 "device_type": p.data.get("device_type","")} for p in self._personas.values()]

    async def apply_to_context(
        self,
        context: Any,          # Playwright BrowserContext
        persona: Persona,
        block_webrtc: bool = True,
    ) -> None:
        """Inject toàn bộ thông số persona vào BrowserContext."""
        webgl = persona.data.get("webgl", {})
        vendor = webgl.get("vendor", "Google Inc.")
        renderer = webgl.get("renderer", "ANGLE")

        # 1. Navigator + Client Hints
        await context.add_init_script(_build_navigator_script(persona.data))
        # 2. WebGL + Canvas noise + AudioContext
        await context.add_init_script(_build_webgl_script(vendor, renderer, persona.noise_seed))
        # 3. WebRTC leak prevention
        if block_webrtc:
            await context.add_init_script(_build_webrtc_policy_script())
        # 4. Phase 7: OS font whitelist
        os_name = persona.data.get("os", "Windows")
        await context.add_init_script(_build_font_whitelist_script(os_name))
        # 5. Phase 7: DOMRect precision calibration
        # 6. Phase 8: WebGPU adapter spoof
        webgpu_data = persona.data.get("webgpu_adapter", persona.data.get("webgpu", {}))
        if webgpu_data:
            await context.add_init_script(_build_webgpu_script(webgpu_data))
        # 7. Phase 8: Virtual mediaDevices (camera/mic enumeration)
        md = persona.data.get("media_devices", {})
        if md or True:  # luôn inject để ẩn thiết bị server thật
            await context.add_init_script(_build_media_devices_script(
                virtual_devices=True,
                device_count=md if md else {"videoinput": 1, "audioinput": 1, "audiooutput": 1},
            ))
        await context.add_init_script(_build_domrect_script(
            persona.device_pixel_ratio,
            persona.screen.get("width", 1920),
            persona.screen.get("height", 1080),
        ))

        LOGGER.debug("persona: áp '%s' (seed=%d, UA=%s…)",
                     persona.id, persona.noise_seed, persona.user_agent[:50])

    def build_context_options(self, persona: Persona) -> dict[str, Any]:
        """Tạo dict kwargs cho browser.new_context() từ persona."""
        return {
            "user_agent": persona.user_agent,
            "locale": persona.locale,
            "timezone_id": persona.timezone,
            "viewport": {"width": persona.screen["width"], "height": persona.screen["height"]},
            "device_scale_factor": persona.device_pixel_ratio,
            "is_mobile": persona.data.get("device_type") == "mobile",
            "has_touch": persona.data.get("device_type") in ("mobile", "tablet"),
            "extra_http_headers": {"Accept-Language": persona.accept_language},
        }
