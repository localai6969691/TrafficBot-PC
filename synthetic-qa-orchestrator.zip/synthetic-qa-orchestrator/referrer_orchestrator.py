"""Bộ Mô Phỏng Chuỗi Điều Hướng & Nguồn Truy Cập (Referrer Chain & Multi-Channel Flow).

Ba thành phần:
  1. ReferrerChain     - tạo chuỗi điều hướng đa bước với Referer header thật
  2. TrafficDistributor - phân bổ theo Device Mix và Weekday Weights
  3. SearchFlowEngine  - mô phỏng user tìm kiếm → click kết quả → vào trang đích

Referrer sources được hỗ trợ:
  direct      : truy cập thẳng (không có Referer)
  google      : google.com/search?q=... → click organic result
  bing        : bing.com/search → click
  facebook    : facebook.com → click shared link
  twitter     : t.co redirect → trang đích
  email       : mô phỏng user mở link từ email (Referer = mail.google.com)
  news        : trang tin tức → click link trong bài
  youtube     : youtube.com description link
  reddit      : reddit.com/r/... → click external link
  custom      : bất kỳ URL nào tùy chỉnh

GIỚI HẠN:
  - Google/Bing search: không gõ từ khóa thật vào search box (dễ bị captcha),
    thay vào đó dùng URL search trực tiếp rồi scroll + click link.
  - Referer header: Playwright tự gán khi navigate từ trang A → B trong cùng page.
    Với cross-origin referer: dùng extra_http_headers.
  - UTM parameters: append vào URL đích; không inject vào trang trung gian.
  - Weekday weights áp dụng tại thời điểm task được schedule, không phải runtime.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from urllib.parse import quote_plus, urlencode, urlparse

LOGGER = logging.getLogger("qa.referrer")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

# Source → (referer_base, is_search_engine)
_SOURCES: dict[str, dict[str, Any]] = {
    "direct":   {"referer": "", "is_search": False, "dwell_s": (0, 0)},
    "google":   {"referer": "https://www.google.com/", "is_search": True,
                 "search_url": "https://www.google.com/search?q={query}&hl={lang}",
                 "dwell_s": (5, 15)},
    "bing":     {"referer": "https://www.bing.com/", "is_search": True,
                 "search_url": "https://www.bing.com/search?q={query}&setlang={lang}",
                 "dwell_s": (4, 12)},
    "facebook": {"referer": "https://www.facebook.com/", "is_search": False,
                 "dwell_s": (3, 8)},
    "twitter":  {"referer": "https://t.co/", "is_search": False, "dwell_s": (2, 6)},
    "email":    {"referer": "https://mail.google.com/", "is_search": False, "dwell_s": (1, 3)},
    "youtube":  {"referer": "https://www.youtube.com/", "is_search": False, "dwell_s": (2, 5)},
    "reddit":   {"referer": "https://www.reddit.com/", "is_search": False, "dwell_s": (5, 15)},
    "news":     {"referer": "https://news.ycombinator.com/", "is_search": False, "dwell_s": (8, 20)},
}

# Weekday weights (Mon=0 .. Sun=6), mặc định thấp cuối tuần
_DEFAULT_WEEKDAY_WEIGHTS = [1.0, 1.0, 1.0, 1.0, 0.9, 0.5, 0.4]  # Mon-Sun

# Device type distribution
# Phase 11.3: khuyến nghị mặc định của đặc tả - 75% Mobile / 25% Desktop,
# tối ưu độ ổn định khi chạy trên máy chủ tài nguyên giới hạn (profile mobile
# nhẹ RAM/CPU hơn desktop đáng kể do viewport nhỏ hơn + ít tab/extension mô phỏng).
_DEFAULT_DEVICE_MIX = {"mobile": 0.75, "desktop": 0.25}


@dataclass
class ReferrerConfig:
    source: str = "direct"            # tên source (xem _SOURCES)
    custom_referer: str = ""          # nếu source="custom"
    search_query: str = ""            # cho Google/Bing
    search_lang: str = "vi"
    utm_source: str = ""
    utm_medium: str = ""
    utm_campaign: str = ""
    utm_content: str = ""
    intermediate_dwell_s: tuple[float, float] = (3.0, 10.0)

    def build_target_url(self, base_url: str) -> str:
        """Thêm UTM parameters vào URL đích nếu có cấu hình."""
        utm: dict[str, str] = {}
        if self.utm_source:
            utm["utm_source"] = self.utm_source
        if self.utm_medium:
            utm["utm_medium"] = self.utm_medium
        if self.utm_campaign:
            utm["utm_campaign"] = self.utm_campaign
        if self.utm_content:
            utm["utm_content"] = self.utm_content
        if not utm:
            return base_url
        sep = "&" if "?" in base_url else "?"
        return base_url + sep + urlencode(utm)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ReferrerConfig":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# ReferrerChain — điều hướng đa bước
# ---------------------------------------------------------------------------

class ReferrerChain:
    """Thực thi chuỗi điều hướng để truyền Referer header thật tới trang đích."""

    def __init__(self, page: Any, cfg: ReferrerConfig) -> None:
        self.page = page
        self.cfg = cfg
        self._rng = random.Random()

    async def navigate_to(self, target_url: str) -> dict[str, Any]:
        """Điều hướng qua chain, trả về {final_url, referer_sent, steps}."""
        final_url = self.cfg.build_target_url(target_url)
        source_info = _SOURCES.get(self.cfg.source, _SOURCES["direct"])
        steps: list[str] = []

        if self.cfg.source == "direct" or not source_info.get("referer"):
            # Truy cập thẳng
            await self.page.goto(final_url, wait_until="domcontentloaded")
            steps.append(f"direct → {final_url}")
            return {"final_url": final_url, "referer_sent": "", "steps": steps}

        if source_info.get("is_search") and self.cfg.search_query:
            return await self._via_search_engine(final_url, source_info, steps)

        return await self._via_referrer_page(final_url, source_info, steps)

    async def _via_search_engine(
        self, target_url: str, source_info: dict, steps: list[str]
    ) -> dict[str, Any]:
        """Mô phỏng: truy cập search → scroll → navigate sang target."""
        lang = self.cfg.search_lang
        search_url = source_info["search_url"].format(
            query=quote_plus(self.cfg.search_query), lang=lang)

        # Bước 1: Mở trang search
        await self.page.goto(search_url, wait_until="domcontentloaded")
        steps.append(f"search: {search_url[:60]}")

        # Dwell trên trang search (đọc kết quả)
        dwell = self._rng.uniform(*source_info["dwell_s"])
        await asyncio.sleep(dwell * 0.4)
        # Scroll nhẹ
        await self.page.mouse.wheel(0, self._rng.randint(100, 300))
        await asyncio.sleep(dwell * 0.6)

        # Bước 2: Navigate sang target (Playwright tự gán Referer = search URL)
        await self.page.goto(target_url, wait_until="domcontentloaded")
        steps.append(f"→ {target_url[:60]}")
        return {"final_url": target_url, "referer_sent": search_url, "steps": steps}

    async def _via_referrer_page(
        self, target_url: str, source_info: dict, steps: list[str]
    ) -> dict[str, Any]:
        """Ghé thăm trang trung gian rồi navigate sang target."""
        referer_base = self.cfg.custom_referer or source_info["referer"]

        # Bước 1: visit intermediate page
        try:
            await self.page.goto(referer_base, wait_until="domcontentloaded", timeout=10_000)
            steps.append(f"via: {referer_base[:60]}")
            dwell = self._rng.uniform(*self.cfg.intermediate_dwell_s)
            await asyncio.sleep(dwell)
        except Exception:
            steps.append(f"via: {referer_base[:60]} (failed, skip)")

        # Bước 2: navigate sang target — Playwright sẽ gán Referer tự động
        # Dùng extra_http_headers để ép Referer header ngay cả khi intermediate page lỗi
        try:
            await self.page.set_extra_http_headers({"Referer": referer_base})
        except Exception:
            pass
        try:
            await self.page.goto(target_url, wait_until="domcontentloaded", timeout=20_000)
        except Exception as exc:
            LOGGER.debug("referrer_goto lỗi, thử lại: %s", exc)
            # Fallback: set header trực tiếp và navigate
            await self.page.goto(target_url, wait_until="commit", timeout=15_000)
        steps.append(f"→ {target_url[:60]}")
        return {"final_url": target_url, "referer_sent": referer_base, "steps": steps}


# ---------------------------------------------------------------------------
# TrafficDistributor — phân bổ device mix + weekday weights
# ---------------------------------------------------------------------------

@dataclass
class TrafficConfig:
    """Cấu hình phân bổ lưu lượng cho campaign."""
    device_mix: dict[str, float] = field(
        default_factory=lambda: dict(_DEFAULT_DEVICE_MIX))
    weekday_weights: list[float] = field(
        default_factory=lambda: list(_DEFAULT_WEEKDAY_WEIGHTS))
    source_mix: dict[str, float] = field(default_factory=lambda: {
        "direct": 0.30, "google": 0.40, "facebook": 0.15,
        "email": 0.05, "reddit": 0.05, "news": 0.05,
    })
    # Giờ cao điểm (0-23), weight tương ứng
    hourly_weights: Optional[list[float]] = None  # None = phân bổ đều

    def effective_weight_now(self) -> float:
        """Trả về weight tại thời điểm hiện tại (weekday × hourly)."""
        now = datetime.now(timezone.utc)
        dow = now.weekday()  # 0=Mon
        w = self.weekday_weights[dow % 7]
        if self.hourly_weights:
            h = now.hour % 24
            w *= self.hourly_weights[h]
        return w

    def should_run_now(self, base_probability: float = 1.0) -> bool:
        """Quyết định có nên chạy task ở thời điểm này không."""
        w = self.effective_weight_now()
        return random.random() < base_probability * w

    def pick_device_type(self) -> str:
        """Chọn loại thiết bị theo phân phối mix."""
        types = list(self.device_mix.keys())
        weights = list(self.device_mix.values())
        return random.choices(types, weights=weights, k=1)[0]

    def pick_source(self) -> str:
        """Chọn nguồn lưu lượng theo phân phối."""
        sources = list(self.source_mix.keys())
        weights = list(self.source_mix.values())
        return random.choices(sources, weights=weights, k=1)[0]

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TrafficConfig":
        cfg = cls()
        if "device_mix" in d:
            cfg.device_mix = d["device_mix"]
        if "weekday_weights" in d:
            cfg.weekday_weights = d["weekday_weights"][:7]
        if "source_mix" in d:
            cfg.source_mix = d["source_mix"]
        if "hourly_weights" in d:
            cfg.hourly_weights = d["hourly_weights"][:24]
        return cfg

    def to_dict(self) -> dict[str, Any]:
        return {
            "device_mix": self.device_mix,
            "weekday_weights": self.weekday_weights,
            "source_mix": self.source_mix,
            "effective_weight_now": round(self.effective_weight_now(), 3),
        }


# ---------------------------------------------------------------------------
# SearchFlowEngine — mô phỏng toàn bộ luồng tìm kiếm
# ---------------------------------------------------------------------------

class SearchFlowEngine:
    """Mô phỏng user: gõ từ khóa → chờ kết quả → click link → vào trang đích.

    Dùng khi muốn Referer = search result page URL (chi tiết hơn ReferrerChain).
    """

    def __init__(self, page: Any, engine: str = "google") -> None:
        self.page = page
        self.engine = engine
        self._rng = random.Random()

    async def search_and_navigate(
        self,
        query: str,
        target_domain: str,
        lang: str = "vi",
        result_position: int = 0,  # 0 = click kết quả đầu tiên khớp domain
    ) -> dict[str, Any]:
        """Tìm kiếm và click vào kết quả của target_domain."""
        source = _SOURCES.get(self.engine, _SOURCES["google"])
        search_url = source.get("search_url", "https://www.google.com/search?q={query}").format(
            query=quote_plus(query), lang=lang)

        await self.page.goto(search_url, wait_until="domcontentloaded")
        await asyncio.sleep(self._rng.uniform(2, 5))

        # Scroll đọc kết quả
        await self.page.mouse.wheel(0, self._rng.randint(200, 500))
        await asyncio.sleep(self._rng.uniform(1, 3))

        # Tìm link khớp target_domain trong kết quả
        clicked_url = ""
        try:
            links = await self.page.query_selector_all("a[href]")
            candidates = []
            for link in links:
                href = await link.get_attribute("href") or ""
                if target_domain in href and "google.com" not in href:
                    candidates.append((link, href))
            if candidates:
                idx = min(result_position, len(candidates) - 1)
                link_el, href = candidates[idx]
                clicked_url = href
                # Di chuyển chuột đến link trước khi click (tự nhiên hơn)
                box = await link_el.bounding_box()
                if box:
                    await self.page.mouse.move(
                        box["x"] + box["width"] / 2 + self._rng.gauss(0, 3),
                        box["y"] + box["height"] / 2 + self._rng.gauss(0, 2),
                    )
                    await asyncio.sleep(self._rng.uniform(0.3, 0.8))
                await link_el.click()
                await self.page.wait_for_load_state("domcontentloaded", timeout=15_000)
        except Exception as exc:
            LOGGER.debug("search_flow: click kết quả lỗi: %s", exc)
            # Fallback: navigate trực tiếp với referer
            await self.page.goto(f"https://{target_domain}", wait_until="domcontentloaded")

        return {
            "search_url": search_url,
            "clicked_url": clicked_url or f"https://{target_domain}",
            "current_url": self.page.url,
        }
