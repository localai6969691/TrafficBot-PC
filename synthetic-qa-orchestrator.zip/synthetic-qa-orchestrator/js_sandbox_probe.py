"""Phân hệ thực thi kịch bản JavaScript nhẹ, không giao diện (Lightweight JS Probe).

Dùng để:
  * Chạy các hàm tính toán phía client (Proof-of-Work, token signing, challenge solver)
    trước khi khởi chạy trình duyệt đầy đủ - tiết kiệm tài nguyên đáng kể.
  * Giải quyết session token / cookie đơn giản bằng JS thuần để tái dùng cho
    các luồng HTTP/2 (curl_cffi hoặc httpx) tiếp theo.

Thứ tự ưu tiên backend thực thi JS:
  1. `PyMiniRacer` (nếu đã cài) - V8 thật, nhẹ nhất, cô lập tốt nhất.
  2. `Node.js` subprocess - sẵn trên hầu hết hệ thống, chạy trong chế độ
     stdin/stdout đơn, không giữ tiến trình nền.
  3. Fallback `eval` Python-builtins - CỰC KỲ HẠN CHẾ: chỉ dùng được với
     JS không cần DOM/window/crypto (tính toán thuần số học). Ghi cảnh báo rõ.

GIỚI HẠN ĐÃ BIẾT:
  - Không có DOM, window, fetch, setTimeout trong môi trường PyMiniRacer / Node
    subprocess (trừ khi script tự polyfill).
  - Script không được phép thực hiện kết nối mạng ra ngoài trong chế độ
    PyMiniRacer (cô lập hoàn toàn - đây là ưu điểm bảo mật, không phải lỗi).
  - Node.js subprocess có thể thực hiện I/O nếu script JS gọi `require(...)`.
    Dùng cẩn thận với script không tin cậy.
  - Giá trị cookie/header lưu vào SQLite KHÔNG được mã hoá (chỉ lưu plaintext).
    Đừng lưu thông tin nhạy cảm vĩnh viễn - kết quả probe chỉ nên tồn tại ngắn.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.js_probe")

# Thời gian sống mặc định của session cache (giây) - sau đó bị coi là lỗi thời.
_DEFAULT_TTL_S = 3600  # 1 giờ


# ---------------------------------------------------------------------------
# Backend phát hiện & thực thi
# ---------------------------------------------------------------------------

def _node_available() -> bool:
    return shutil.which("node") is not None


def _miniRacer_available() -> bool:
    try:
        import py_mini_racer  # type: ignore[import-not-found]  # noqa: F401
        return True
    except ImportError:
        return False


def _run_js_node(script: str, timeout_s: float = 10.0) -> str:
    """Chạy `script` qua `node -e` subprocess, trả về stdout (string)."""
    result = subprocess.run(
        ["node", "-e", script],
        capture_output=True, text=True, timeout=timeout_s,
    )
    if result.returncode != 0:
        raise RuntimeError(f"node exit {result.returncode}: {result.stderr.strip()[:400]}")
    return result.stdout


def _run_js_miniracer(script: str, timeout_s: float = 10.0) -> Any:
    """Chạy script qua PyMiniRacer, trả về giá trị JavaScript cuối cùng."""
    import py_mini_racer  # type: ignore[import-not-found]
    ctx = py_mini_racer.MiniRacer()
    return ctx.eval(script)


async def execute_js(script: str, timeout_s: float = 10.0) -> str:
    """Thực thi `script` JS, trả về chuỗi kết quả (stdout hoặc giá trị .toString()).

    Thứ tự thử: PyMiniRacer → Node.js → python-eval fallback.
    Luôn chạy async (sử dụng executor để không chặn event loop).
    """
    loop = asyncio.get_event_loop()

    if _miniRacer_available():
        LOGGER.debug("js_probe: dùng PyMiniRacer")
        raw = await loop.run_in_executor(None, _run_js_miniracer, script, timeout_s)
        return str(raw)

    if _node_available():
        LOGGER.debug("js_probe: dùng Node.js subprocess")
        out = await loop.run_in_executor(None, _run_js_node, script, timeout_s)
        return out.strip()

    # Fallback cực kỳ hạn chế - chỉ JS không cần host API
    LOGGER.warning("js_probe: không có PyMiniRacer lẫn node - dùng python eval (rất hạn chế)")
    # Thêm polyfill tối thiểu rồi dùng execjs-style qua compile
    try:
        import js2py  # type: ignore[import-not-found]
        return str(js2py.eval_js(script))
    except ImportError:
        raise RuntimeError(
            "js_probe: không tìm thấy backend JS nào (cần py_mini_racer hoặc node). "
            "Cài bằng: pip install py-mini-racer  hoặc cài Node.js."
        )


# ---------------------------------------------------------------------------
# Các helper script chuẩn
# ---------------------------------------------------------------------------

SCRIPT_PROOF_OF_WORK = """\
// Proof-of-Work đơn giản: tìm nonce sao cho SHA256(prefix + nonce) bắt đầu bằng difficulty số 0
// Dùng khi trang yêu cầu PoW challenge trước khi cấp token.
// Input: JSON.parse(input) với { prefix, difficulty }
// Output: JSON.stringify({ nonce, hash, elapsed_ms })
(function(){
  var args = JSON.parse(process.argv[2] || '{"prefix":"test","difficulty":4}');
  var prefix = args.prefix, diff = args.difficulty || 4;
  var target = Array(diff+1).join('0');
  var crypto = require('crypto');
  var t0 = Date.now(), nonce = 0;
  while(true){
    var h = crypto.createHash('sha256').update(prefix+nonce).digest('hex');
    if(h.startsWith(target)){ process.stdout.write(JSON.stringify({nonce,hash:h,elapsed_ms:Date.now()-t0})); break; }
    nonce++;
  }
})();
"""


def make_pow_script(prefix: str, difficulty: int = 4) -> str:
    """Tạo script PoW với tham số cụ thể (inlined, không cần process.argv)."""
    return f"""\
(function(){{
  var prefix={json.dumps(prefix)}, diff={difficulty};
  var target=Array(diff+1).join('0');
  var crypto=require('crypto');
  var t0=Date.now(),nonce=0;
  while(true){{
    var h=crypto.createHash('sha256').update(prefix+nonce).digest('hex');
    if(h.startsWith(target)){{console.log(JSON.stringify({{nonce,hash:h,elapsed_ms:Date.now()-t0}}));break;}}
    nonce++;
  }}
}})();
"""


def make_hmac_script(message: str, secret: str, algorithm: str = "sha256") -> str:
    """Tạo script tính HMAC (message, secret) và trả JSON {signature}."""
    return f"""\
(function(){{
  var crypto=require('crypto');
  var sig=crypto.createHmac({json.dumps(algorithm)},{json.dumps(secret)})
                .update({json.dumps(message)}).digest('hex');
  console.log(JSON.stringify({{signature:sig}}));
}})();
"""


# ---------------------------------------------------------------------------
# Session Pre-Cache: lưu kết quả vào SQLite
# ---------------------------------------------------------------------------

async def probe_and_cache(
    db: Database,
    probe_key: str,
    js_script: str,
    extract_fn: "Optional[Any]" = None,
    ttl_s: float = _DEFAULT_TTL_S,
    timeout_s: float = 15.0,
) -> dict[str, Any]:
    """Chạy JS probe và cache kết quả vào bảng `sessions` trong SQLite.

    Args:
        db: instance Database của orchestrator.
        probe_key: khoá định danh probe (vd. "pow:example.com:4"), dùng để tra cache.
        js_script: mã JS cần chạy.
        extract_fn: hàm Python nhận (raw_output: str) -> dict[cookies, headers, ...].
                    Nếu None, lưu raw output vào trường 'raw'.
        ttl_s: thời gian cache hợp lệ (giây).
        timeout_s: timeout cho thực thi JS.

    Returns:
        dict với ít nhất {"raw": ..., "cached": bool, "age_s": float}
        Thêm các trường do extract_fn trả về (vd. "cookies", "headers", "token").
    """
    # 1. Kiểm tra cache còn hợp lệ không
    cached = await db.aget_session_cache(probe_key)
    if cached:
        age_s = time.time() - cached["created_at_ts"]
        if age_s < ttl_s:
            LOGGER.debug("js_probe cache HIT: %s (%.0fs cũ)", probe_key, age_s)
            payload = json.loads(cached["payload"])
            payload["cached"] = True
            payload["age_s"] = round(age_s, 1)
            return payload

    # 2. Chạy probe thật
    LOGGER.info("js_probe: chạy probe '%s'", probe_key)
    t0 = time.perf_counter()
    raw = await execute_js(js_script, timeout_s=timeout_s)
    elapsed = round((time.perf_counter() - t0) * 1000, 1)
    LOGGER.info("js_probe: '%s' xong trong %.0fms", probe_key, elapsed)

    # 3. Trích xuất kết quả
    result: dict[str, Any] = {"raw": raw, "elapsed_probe_ms": elapsed, "cached": False, "age_s": 0.0}
    if extract_fn is not None:
        try:
            extracted = extract_fn(raw)
            result.update(extracted)
        except Exception as exc:
            LOGGER.warning("js_probe: extract_fn lỗi: %s", exc)
            result["extract_error"] = str(exc)

    # 4. Lưu cache
    payload_str = json.dumps(result)
    await db.aset_session_cache(probe_key, payload_str)
    return result


async def get_cached_cookies(db: Database, probe_key: str) -> Optional[list[dict[str, str]]]:
    """Lấy cookies đã cache cho probe_key (None nếu không có hoặc hết hạn cache-miss)."""
    cached = await db.aget_session_cache(probe_key)
    if not cached:
        return None
    try:
        payload = json.loads(cached["payload"])
        return payload.get("cookies")
    except (json.JSONDecodeError, KeyError):
        return None


async def invalidate_cache(db: Database, probe_key: str) -> None:
    """Xoá cache cho probe_key (ép chạy lại probe ở lần tiếp theo)."""
    await db.adelete_session_cache(probe_key)
    LOGGER.debug("js_probe: đã xoá cache '%s'", probe_key)


# ---------------------------------------------------------------------------
# Tiện ích: hash script để dùng làm probe_key tự động
# ---------------------------------------------------------------------------

def script_key(prefix: str, script: str) -> str:
    """Tạo probe_key từ prefix + hash nội dung script (dùng khi không muốn đặt tên thủ công)."""
    h = hashlib.sha256(script.encode()).hexdigest()[:12]
    return f"{prefix}:{h}"


# ---------------------------------------------------------------------------
# Phase 10.4: Môi trường Node.js `vm` với bề mặt DOM tối thiểu (Minimal Browser
# Surface Shim) - cô lập hoàn toàn khỏi global scope của Node, nạp sẵn các đối
# tượng window/document/navigator/crypto/performance khớp Persona hiện tại.
#
# Dùng `vm.createContext()` thay vì `node -e` thuần: script chạy TRONG MỘT
# CONTEXT RIÊNG (không đụng tới global process/require thật của host, trừ khi
# shim tự expose), khớp đúng tinh thần "Sandboxed V8 Runtime Probe" của đặc tả.
# ---------------------------------------------------------------------------

#: Thư mục chứa các script JS người dùng có thể nạp qua `run_js_probe_file()`.
JS_PROBES_DIR = Path("plugins") / "js_probes"


def _persona_to_shim_values(persona: Optional[dict[str, Any]]) -> dict[str, Any]:
    """Chuyển Persona config (nếu có) thành các giá trị cụ thể để bơm vào shim.

    `persona` có thể là dict tuỳ ý (từ `Environment`/`persona_manager.py`); các
    khoá được nhận biết: user_agent, platform, language, languages, hardware_concurrency,
    device_memory, screen_width, screen_height, timezone_offset_min.
    Khoá không có mặt -> dùng giá trị mặc định hợp lý (giống Chrome/Windows phổ biến).
    """
    p = persona or {}
    return {
        "user_agent": p.get("user_agent") or (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
        "platform": p.get("platform", "Win32"),
        "language": p.get("language", "en-US"),
        "languages": p.get("languages", ["en-US", "en"]),
        "hardware_concurrency": p.get("hardware_concurrency", 8),
        "device_memory": p.get("device_memory", 8),
        "screen_width": p.get("screen_width", 1920),
        "screen_height": p.get("screen_height", 1080),
        "timezone_offset_min": p.get("timezone_offset_min", 0),
    }


def _build_dom_shim_prelude(persona: Optional[dict[str, Any]] = None) -> str:
    """Sinh đoạn JS "prelude" định nghĩa window/document/navigator/crypto/performance
    tối thiểu bên trong `vm` context, TRƯỚC khi script thật của người dùng chạy.

    Không phải polyfill đầy đủ DOM (không có layout/CSSOM) - chỉ đủ bề mặt API
    để các hàm tính toán token/PoW/challenge-solver phía client không bị lỗi
    ReferenceError khi đọc navigator.*/window.*/crypto.getRandomValues(...).
    """
    v = _persona_to_shim_values(persona)
    return f"""\
// ── Minimal Browser Surface Shim (Phase 10.4) ───────────────────────────
const __nodeCrypto = require('crypto');
const navigator = {{
  userAgent: {json.dumps(v["user_agent"])},
  platform: {json.dumps(v["platform"])},
  language: {json.dumps(v["language"])},
  languages: {json.dumps(v["languages"])},
  hardwareConcurrency: {v["hardware_concurrency"]},
  deviceMemory: {v["device_memory"]},
  webdriver: false,
}};
const screen = {{
  width: {v["screen_width"]}, height: {v["screen_height"]},
  availWidth: {v["screen_width"]}, availHeight: {v["screen_height"]},
  colorDepth: 24, pixelDepth: 24,
}};
const performance = {{
  _origin: Date.now(),
  now() {{ return Date.now() - this._origin; }},
  timeOrigin: Date.now(),
}};
const crypto = {{
  getRandomValues(typedArray) {{
    const buf = __nodeCrypto.randomBytes(typedArray.length *
      (typedArray.BYTES_PER_ELEMENT || 1));
    for (let i = 0; i < typedArray.length; i++) {{
      typedArray[i] = buf[i % buf.length];
    }}
    return typedArray;
  }},
  subtle: {{
    digest: async (algo, data) => {{
      const map = {{'SHA-256':'sha256','SHA-1':'sha1','SHA-384':'sha384','SHA-512':'sha512'}};
      const h = __nodeCrypto.createHash(map[algo] || 'sha256');
      h.update(Buffer.from(data));
      return h.digest().buffer;
    }},
  }},
}};
// document tối giản: đủ để code gọi createElement/querySelector không throw ngay lập tức.
function __mkEl() {{
  const attrs = {{}};
  return {{
    style: {{}}, attrs,
    setAttribute(k, v) {{ attrs[k] = v; }},
    getAttribute(k) {{ return attrs[k]; }},
    appendChild() {{}}, removeChild() {{}},
    getContext() {{ return null; }},  // không giả lập Canvas/WebGL ở đây
    addEventListener() {{}}, removeEventListener() {{}},
  }};
}}
const document = {{
  createElement: () => __mkEl(),
  querySelector: () => null, querySelectorAll: () => [],
  getElementById: () => null,
  cookie: '',
  readyState: 'complete',
  addEventListener() {{}}, removeEventListener() {{}},
  location: {{ href: 'about:blank', hostname: '', protocol: 'https:' }},
}};
const window = {{
  navigator, screen, performance, crypto, document,
  location: document.location,
  localStorage: {{ _s: {{}}, getItem(k) {{ return this._s[k] ?? null; }},
                   setItem(k, v) {{ this._s[k] = String(v); }}, removeItem(k) {{ delete this._s[k]; }} }},
  sessionStorage: {{ _s: {{}}, getItem(k) {{ return this._s[k] ?? null; }},
                     setItem(k, v) {{ this._s[k] = String(v); }}, removeItem(k) {{ delete this._s[k]; }} }},
  setTimeout, clearTimeout, setInterval, clearInterval,
  addEventListener() {{}}, removeEventListener() {{}},
  btoa: (s) => Buffer.from(s, 'binary').toString('base64'),
  atob: (s) => Buffer.from(s, 'base64').toString('binary'),
}};
// ── Hết phần shim - script người dùng bắt đầu từ đây ────────────────────
"""


def _run_js_node_vm(script: str, persona: Optional[dict[str, Any]] = None,
                    timeout_s: float = 10.0) -> str:
    """Build full script (shim + user script) và chạy qua `node -e`.

    LƯU Ý: dùng `vm.createContext` BÊN TRONG script được sinh ra (không phải
    gọi `vm` từ Python) - đây là cách Node tạo một global scope cô lập, đúng
    với "Node.js vm module" trong đặc tả. Toàn bộ shim + script người dùng
    chạy trong context đó, tách biệt khỏi global thật của tiến trình node.
    """
    shim = _build_dom_shim_prelude(persona)
    # Escape script người dùng để nhúng an toàn vào chuỗi JS bên trong vm context.
    full_script = f"""\
const vm = require('vm');
const __shimSrc = {json.dumps(shim)};
const __userSrc = {json.dumps(script)};
const sandbox = {{ require, console, process, Buffer, module, exports,
                   setTimeout, clearTimeout, setInterval, clearInterval }};
vm.createContext(sandbox);
vm.runInContext(__shimSrc, sandbox, {{ timeout: {int(timeout_s * 1000)} }});
vm.runInContext(__userSrc, sandbox, {{ timeout: {int(timeout_s * 1000)} }});
"""
    result = subprocess.run(
        ["node", "-e", full_script],
        capture_output=True, text=True, timeout=timeout_s + 2.0,
    )
    if result.returncode != 0:
        raise RuntimeError(f"node vm exit {result.returncode}: {result.stderr.strip()[:500]}")
    return result.stdout


async def execute_js_with_dom_shim(
    script: str,
    persona: Optional[dict[str, Any]] = None,
    timeout_s: float = 10.0,
) -> str:
    """Thực thi `script` trong Node `vm` context có sẵn window/document/navigator/
    crypto/performance (xem `_build_dom_shim_prelude`), khớp `persona` nếu truyền vào.

    Đây là đường thực thi được khuyến nghị cho các script cần đọc
    navigator.userAgent / crypto.getRandomValues / performance.now() trước khi
    tính toán token - KHÁC với `execute_js()` (PyMiniRacer/node -e thuần, không
    có DOM) vốn chỉ phù hợp cho script tính toán số học/HMAC/PoW thuần không
    đụng tới bề mặt trình duyệt.

    Yêu cầu: Node.js phải có sẵn (không hỗ trợ PyMiniRacer cho đường này vì
    PyMiniRacer không có `require('vm')`/`require('crypto')` built-in).
    """
    if not _node_available():
        raise RuntimeError(
            "execute_js_with_dom_shim: cần Node.js (không hỗ trợ PyMiniRacer cho "
            "chế độ có DOM shim). Cài Node.js để dùng tính năng này."
        )
    loop = asyncio.get_event_loop()
    out = await loop.run_in_executor(None, _run_js_node_vm, script, persona, timeout_s)
    return out.strip()


async def run_js_probe_file(
    filename: str,
    persona: Optional[dict[str, Any]] = None,
    probes_dir: Optional[Path] = None,
    timeout_s: float = 10.0,
) -> dict[str, Any]:
    """Nạp một tệp `.js` từ `plugins/js_probes/` (hoặc `probes_dir` tuỳ chỉnh),
    thực thi trong Node vm context có DOM shim, trả về kết quả + metadata.

    Dùng cho các thuật toán tính toán mã xác thực phiên / Proof-of-Work phía
    client lấy trực tiếp từ trang web mục tiêu (lưu thành file .js riêng, không
    cần sửa code Python) - đúng tinh thần mục 2.4: "Cho phép nạp một tệp .js
    bất kỳ từ thư mục plugins/js_probes/".

    Returns:
        dict: {"ok": bool, "output": str, "elapsed_ms": float, "file": str,
               "error": str | None}
    """
    base = probes_dir or JS_PROBES_DIR
    path = (base / filename).resolve()
    # Chặn path traversal ra ngoài thư mục probes (an toàn tối thiểu).
    try:
        path.relative_to(base.resolve())
    except ValueError:
        return {"ok": False, "output": "", "elapsed_ms": 0.0, "file": filename,
                "error": "Đường dẫn không hợp lệ (ngoài thư mục plugins/js_probes/)"}
    if not path.is_file():
        return {"ok": False, "output": "", "elapsed_ms": 0.0, "file": filename,
                "error": f"Không tìm thấy tệp: {path}"}

    script = path.read_text(encoding="utf-8")
    t0 = time.perf_counter()
    try:
        output = await execute_js_with_dom_shim(script, persona=persona, timeout_s=timeout_s)
        return {"ok": True, "output": output[:4000],
                "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                "file": filename, "error": None}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "output": "",
                "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                "file": filename, "error": str(exc)[:500]}


def list_js_probe_files(probes_dir: Optional[Path] = None) -> list[str]:
    """Liệt kê các tệp `.js` có sẵn trong thư mục probes (cho dropdown UI)."""
    base = probes_dir or JS_PROBES_DIR
    if not base.is_dir():
        return []
    return sorted(p.name for p in base.glob("*.js") if p.is_file())
