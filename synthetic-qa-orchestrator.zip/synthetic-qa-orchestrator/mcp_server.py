"""Local MCP Server qua stdio: cho Claude Desktop / Cursor / VS Code điều khiển runner.

GIỚI HẠN ĐÃ BIẾT (xem PROJECT.md):
* Gói `mcp` chính thức của Python KHÔNG cài được trong môi trường phát triển hiện tại
  (không có Internet để pip install lúc viết module này). Vì vậy đây là một triển khai
  JSON-RPC 2.0 thủ công, tự viết theo đúng hình dạng thông điệp của MCP (newline-delimited
  JSON qua stdio: `initialize`, `tools/list`, `tools/call`), KHÔNG dùng SDK chính thức.
  Đã kiểm thử bằng cách tự gửi các dòng JSON-RPC qua subprocess và so khớp phản hồi với
  đặc tả MCP, NHƯNG CHƯA được xác minh với một MCP client thật (Claude Desktop/Cursor) -
  có thể cần chỉnh field nếu client thật khó tính hơn giả lập của chúng tôi.
* `trigger_execution` chạy đồng bộ tới khi xong rồi mới trả kết quả qua `tools/call` (không
  có cơ chế thông báo tiến độ dạng streaming của MCP) - với chiến dịch dài, lệnh gọi MCP sẽ
  treo tới khi hoàn tất. Dùng `async_mode: true` để chạy nền và lấy `job_id`, sau đó gọi lại
  `trigger_execution` với `job_id` để lấy trạng thái/kết quả.
* `create_test_scenario` chỉ làm được NLU thật khi có cấu hình LLM (Ollama/OpenAI) trong
  settings.llm; nếu không, dùng suy luận đơn giản theo mẫu (rút URL bằng regex, mặc định
  phần còn lại) - không phải hiểu ngôn ngữ tự nhiên đầy đủ.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import sys
import uuid
from dataclasses import asdict
from typing import Any, Optional

from config_loader import Paths, get_base_dir, load_config
from database import Database
from engine import Engine, LocalQueue, Task, utc_now
from events import EventBus
from network_manager import GatewayPool, HttpProbe
from plugin_manager import PluginManager, reconcile_plugins
from reporting import build_report

LOGGER = logging.getLogger("qa.mcp")
PROTOCOL_VERSION = "2024-11-05"

TOOLS = [
    {
        "name": "create_test_scenario",
        "description": "Tạo hoặc cập nhật một kịch bản kiểm thử trong config/scenarios.json "
                       "từ mô tả ngắn gọn (URL là bắt buộc; các trường khác suy ra theo mẫu "
                       "hoặc qua LLM nếu đã cấu hình settings.llm).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "description": {"type": "string", "description": "Mô tả tự nhiên, ví dụ: "
                                 "'kiểm tra trang https://a.com trên điện thoại ở Mỹ'"},
                "id": {"type": "string"}, "name": {"type": "string"},
                "url": {"type": "string"}, "environment": {"type": "string"},
                "active": {"type": "boolean"},
            },
            "required": ["description"],
        },
    },
    {
        "name": "trigger_execution",
        "description": "Khởi chạy một chiến dịch kiểm thử (một hoặc nhiều kịch bản) và trả về "
                       "báo cáo. Dùng async_mode=true để chạy nền rồi hỏi lại bằng job_id.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "scenario_ids": {"type": "array", "items": {"type": "string"}},
                "iterations": {"type": "integer"}, "async_mode": {"type": "boolean"},
                "job_id": {"type": "string", "description": "Truyền vào để hỏi trạng thái một "
                           "lần chạy nền đã khởi tạo trước đó"},
            },
        },
    },
    {
        "name": "get_diagnostic_report",
        "description": "Truy vấn SQLite để tổng hợp các lượt chạy thất bại gần đây: phân loại "
                       "theo loại lỗi (timeout, gateway, HTTP 4xx/5xx, bị chặn domain, circuit "
                       "breaker) kèm gợi ý khắc phục, cộng p50/p95/p99 hiệu năng.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "since": {"type": "string", "description": "ISO-8601, mặc định 24 giờ gần nhất"},
                "scenario_id": {"type": "string"}, "limit": {"type": "integer"},
            },
        },
    },
]


class JobRegistry:
    """Theo dõi các lượt chạy nền (async_mode=true) trong vòng đời tiến trình MCP server."""

    def __init__(self) -> None:
        self._jobs: dict[str, dict[str, Any]] = {}

    def create(self) -> str:
        job_id = uuid.uuid4().hex[:10]
        self._jobs[job_id] = {"status": "running", "report": None, "error": None}
        return job_id

    def finish(self, job_id: str, report: Optional[dict[str, Any]], error: Optional[str]) -> None:
        self._jobs[job_id] = {"status": "failed" if error else "done", "report": report, "error": error}

    def get(self, job_id: str) -> Optional[dict[str, Any]]:
        return self._jobs.get(job_id)


class ToolError(Exception):
    """Lỗi có thể hiểu được, trả về cho client dưới dạng nội dung lỗi của tool (không phải lỗi giao thức)."""


def _guess_scenario_from_description(text: str, fields: dict[str, Any]) -> dict[str, Any]:
    """Suy luận đơn giản theo mẫu (không dùng LLM): rút URL, đoán environment theo từ khoá."""
    url = fields.get("url")
    if not url:
        m = re.search(r"https?://[^\s'\"]+", text)
        if not m:
            raise ToolError("Không tìm thấy URL trong mô tả; hãy truyền thêm trường 'url'.")
        url = m.group(0)
    low = text.lower()
    environment = fields.get("environment")
    if not environment:
        mobile = any(k in low for k in ("điện thoại", "mobile", "phone", "di động"))
        environment = "mobile-us" if mobile else "desktop-vn"
    sid = fields.get("id") or re.sub(r"[^a-z0-9]+", "-", url.lower()).strip("-")[:40] or uuid.uuid4().hex[:8]
    return {
        "id": sid, "name": fields.get("name") or f"Kịch bản: {url}",
        "active": fields.get("active", True), "profile_id": f"profile-{sid}",
        "environment": environment, "urls": [url], "timeout_ms": 30000,
        "interaction": {"dwell_time_range": [1.0, 3.0], "scroll": True, "cursor": True},
        "steps": [{"action": "goto", "url": "{url}"}, {"action": "interact"}],
    }


async def _llm_assisted_scenario(text: str, fields: dict[str, Any], llm_cfg: dict[str, Any]) -> dict[str, Any]:
    """Nếu có cấu hình LLM, nhờ nó trích JSON có cấu trúc từ mô tả; lỗi -> rơi về suy luận mẫu."""
    base = _guess_scenario_from_description(text, fields)
    if llm_cfg.get("provider", "none") == "none":
        return base
    try:
        from test_data import TestDataGenerator

        gen = TestDataGenerator(llm_cfg, max_llm_calls_per_run=1)
        prompt = (f"Mô tả: {text!r}. Trả về DUY NHẤT một JSON object với các khoá: "
                  f"name (string), environment (một trong 'desktop-vn','mobile-us'), "
                  f"dwell_seconds_max (số). Không giải thích gì thêm.")
        raw = await gen._ask_llm(prompt)  # noqa: SLF001 - dùng trực tiếp lớp nội bộ đã có
        if raw:
            extra = json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
            base["name"] = extra.get("name", base["name"])
            base["environment"] = extra.get("environment", base["environment"])
            if "dwell_seconds_max" in extra:
                base["interaction"]["dwell_time_range"][1] = float(extra["dwell_seconds_max"])
    except Exception as exc:  # noqa: BLE001 - LLM là trợ giúp tuỳ chọn, lỗi thì dùng bản suy luận mẫu
        LOGGER.warning("LLM hỗ trợ tạo kịch bản thất bại, dùng suy luận theo mẫu: %s", exc)
    return base


class McpServer:
    def __init__(self, paths: Paths) -> None:
        self.paths = paths
        self.jobs = JobRegistry()

    # ------------------------------------------------------------ tools
    async def create_test_scenario(self, args: dict[str, Any]) -> dict[str, Any]:
        cfg = load_config(self.paths)
        text = str(args.get("description", ""))
        scenario = await _llm_assisted_scenario(text, args, cfg.settings.llm)
        raw = json.loads(self.paths.scenarios.read_text(encoding="utf-8"))
        container = raw if isinstance(raw, dict) else {"scenarios": raw}
        container.setdefault("scenarios", [])
        existing = next((s for s in container["scenarios"] if s.get("id") == scenario["id"]), None)
        if existing:
            existing.update(scenario)
            action = "updated"
        else:
            container["scenarios"].append(scenario)
            action = "created"
        self.paths.scenarios.write_text(json.dumps(container, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"action": action, "scenario": scenario}

    async def trigger_execution(self, args: dict[str, Any]) -> dict[str, Any]:
        job_id = args.get("job_id")
        if job_id:
            job = self.jobs.get(job_id)
            if job is None:
                raise ToolError(f"Không có job_id {job_id!r}")
            return {"job_id": job_id, **job}

        cfg = load_config(self.paths)
        only = set(args.get("scenario_ids") or [])
        if only:
            cfg.scenarios = [s for s in cfg.scenarios if s.id in only]
        if not cfg.scenarios:
            raise ToolError("Không có kịch bản nào khớp scenario_ids")
        iterations = int(args.get("iterations") or cfg.settings.iterations)

        async def run_once() -> dict[str, Any]:
            db = Database(self.paths.db)
            db.open()
            try:
                now = utc_now()
                for sc in cfg.scenarios:
                    await db.aupsert_scenario(sc, now)
                bus = EventBus()
                plugins = PluginManager(self.paths.plugins, self.paths.init_scripts)
                p_enabled, p_configs = await reconcile_plugins(db, self.paths)
                plugins.load(p_enabled, p_configs)
                pool = GatewayPool(cfg.gateways, cfg.settings.gateway_timeout_s, cfg.settings.health_check_interval_s)
                engine = Engine(cfg, self.paths, db, plugins, pool, HttpProbe(), bus)
                await engine.start()
                queue = LocalQueue()
                for _ in range(max(1, iterations)):
                    for sc in cfg.scenarios:
                        for url in sc.urls:
                            await queue.put(Task(sc.id, url))
                await engine.run_tasks(queue, drain=True)
                await engine.close()
                return build_report(await db.ametric_rows(now))
            finally:
                db.close()

        if args.get("async_mode"):
            job_id = self.jobs.create()

            async def _bg() -> None:
                try:
                    report = await run_once()
                    self.jobs.finish(job_id, report, None)
                except Exception as exc:  # noqa: BLE001
                    self.jobs.finish(job_id, None, f"{type(exc).__name__}: {exc}")

            asyncio.create_task(_bg())
            return {"job_id": job_id, "status": "started"}
        return {"job_id": None, "status": "done", "report": await run_once()}

    async def get_diagnostic_report(self, args: dict[str, Any]) -> dict[str, Any]:
        db = Database(self.paths.db)
        db.open()
        try:
            since = args.get("since") or "1970-01-01T00:00:00"
            rows = db.metric_rows(since)
            failed_runs = db._read(  # noqa: SLF001 - truy vấn chẩn đoán chuyên biệt, không cần thêm API công khai
                "SELECT scenario_id, url, http_status, error_message, started_at FROM runs "
                "WHERE status = 'failed' AND started_at >= ? "
                + ("AND scenario_id = ? " if args.get("scenario_id") else "") + "ORDER BY id DESC LIMIT ?",
                (since, args["scenario_id"], int(args.get("limit", 50))) if args.get("scenario_id")
                else (since, int(args.get("limit", 50))))
        finally:
            db.close()

        categories: dict[str, int] = {}
        suggestions: list[str] = []
        for r in failed_runs:
            msg = (r.get("error_message") or "").lower()
            if "allowed_domains" in msg:
                cat = "domain_bị_chặn"
            elif "circuit_open" in msg:
                cat = "circuit_breaker_mở"
            elif r.get("http_status") in (429, 503):
                cat = "rate_limit_429_503"
            elif "timeout" in msg:
                cat = "timeout"
            elif any(k in msg for k in ("err_proxy", "err_tunnel", "err_socks", "err_connection")):
                cat = "lỗi_gateway"
            else:
                cat = "khác"
            categories[cat] = categories.get(cat, 0) + 1
        if categories.get("domain_bị_chặn"):
            suggestions.append("Có URL ngoài allowed_domains - kiểm tra lại scenarios.json hoặc settings.allowed_domains.")
        if categories.get("rate_limit_429_503"):
            suggestions.append("Máy chủ trả 429/503 nhiều - cân nhắc giảm max_concurrency hoặc tăng backoff_base_s.")
        if categories.get("lỗi_gateway"):
            suggestions.append("Nhiều lỗi kết nối qua gateway - kiểm tra gateways.txt hoặc chạy gateway_validator.")
        if categories.get("circuit_breaker_mở"):
            suggestions.append("Circuit breaker đang mở cho một số host - chờ cooldown hoặc kiểm tra host đích.")

        rep = build_report(rows)
        return {"summary": {"total_runs": rep["total_runs"], "ok": rep["ok"], "failed": rep["failed"]},
                "performance_p95": {i["scenario_id"]: i.get("ttfb_p95") for i in rep["items"]},
                "failure_categories": categories, "suggestions": suggestions,
                "recent_failures": failed_runs[:20]}

    # ------------------------------------------------------------ JSON-RPC dispatch
    async def handle(self, req: dict[str, Any]) -> Optional[dict[str, Any]]:
        req_id, method, params = req.get("id"), req.get("method"), req.get("params") or {}
        if method == "initialize":
            return self._ok(req_id, {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "synthetic-qa-orchestrator", "version": "1.0.0"},
            })
        if method in ("notifications/initialized", "initialized"):
            return None  # thông báo, không cần phản hồi
        if method == "tools/list":
            return self._ok(req_id, {"tools": TOOLS})
        if method == "tools/call":
            name, args = params.get("name"), params.get("arguments") or {}
            fn = {"create_test_scenario": self.create_test_scenario,
                  "trigger_execution": self.trigger_execution,
                  "get_diagnostic_report": self.get_diagnostic_report}.get(name)
            if fn is None:
                return self._err(req_id, -32601, f"Không có tool '{name}'")
            try:
                result = await fn(args)
                text = json.dumps(result, ensure_ascii=False, indent=2)
                return self._ok(req_id, {"content": [{"type": "text", "text": text}], "isError": False})
            except ToolError as exc:
                return self._ok(req_id, {"content": [{"type": "text", "text": str(exc)}], "isError": True})
            except Exception as exc:  # noqa: BLE001
                LOGGER.exception("Tool '%s' lỗi", name)
                return self._ok(req_id, {"content": [{"type": "text", "text": f"{type(exc).__name__}: {exc}"}],
                                         "isError": True})
        if req_id is None:
            return None
        return self._err(req_id, -32601, f"Không rõ method '{method}'")

    @staticmethod
    def _ok(req_id: Any, result: dict[str, Any]) -> dict[str, Any]:
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    @staticmethod
    def _err(req_id: Any, code: int, message: str) -> dict[str, Any]:
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}}


async def serve_stdio(paths: Paths) -> None:
    """Vòng lặp chính: đọc mỗi dòng trên stdin là một thông điệp JSON-RPC, ghi phản hồi (nếu
    có) ra một dòng trên stdout. Log đi ra stderr - KHÔNG được in gì khác ra stdout."""
    server = McpServer(paths)
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    await loop.connect_read_pipe(lambda: protocol, sys.stdin)

    LOGGER.info("MCP server sẵn sàng trên stdio (gói mcp chính thức không khả dụng - dùng JSON-RPC thủ công)")
    while True:
        line = await reader.readline()
        if not line:
            break
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            LOGGER.warning("Bỏ qua dòng không phải JSON hợp lệ: %s", line[:200])
            continue
        try:
            resp = await server.handle(req)
        except Exception as exc:  # noqa: BLE001 - lỗi không mong đợi không được làm sập server
            LOGGER.exception("Lỗi xử lý request MCP")
            resp = server._err(req.get("id"), -32603, f"Lỗi nội bộ: {exc}")
        if resp is not None:
            sys.stdout.write(json.dumps(resp, ensure_ascii=False) + "\n")
            sys.stdout.flush()


def main() -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s")
    paths = Paths.from_base(get_base_dir())
    paths.ensure_dirs()
    try:
        asyncio.run(serve_stdio(paths))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
