"""Nạp cấu hình (scenarios / environments / gateways) và đường dẫn di động."""
from __future__ import annotations

import json
import logging
import sys
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Optional
from urllib.parse import unquote, urlsplit

LOGGER = logging.getLogger("qa.config")
GATEWAY_SCHEMES = {"http", "https", "socks5"}


# ---------------------------------------------------------------- đường dẫn
def get_base_dir() -> Path:
    """Thư mục chứa tệp thực thi (Nuitka) hoặc thư mục mã nguồn. Không hard-code."""
    if "__compiled__" in globals() or getattr(sys, "frozen", False):
        return Path(sys.argv[0]).resolve().parent
    return Path(__file__).resolve().parent


@dataclass(frozen=True)
class Paths:
    base: Path
    scenarios: Path
    environments: Path
    gateways: Path
    profiles: Path
    plugins: Path
    init_scripts: Path
    db: Path
    secret_key: Path
    reports: Path
    logs: Path
    screenshots: Path
    browsers: Path

    @classmethod
    def from_base(cls, base: Path) -> "Paths":
        return cls(
            base=base,
            scenarios=base / "config" / "scenarios.json",
            environments=base / "config" / "environments.json",
            gateways=base / "config" / "gateways.txt",
            profiles=base / "profiles_data",
            plugins=base / "plugins",
            init_scripts=base / "plugins" / "init_scripts",
            db=base / "data" / "state.db",
            secret_key=base / "data" / "secret.key",
            reports=base / "data" / "reports",
            logs=base / "data" / "logs",
            screenshots=base / "data" / "screenshots",
            browsers=base / "browsers",
        )

    def ensure_dirs(self) -> None:
        for d in (self.profiles, self.init_scripts, self.reports, self.logs,
                  self.screenshots, self.browsers, self.scenarios.parent, self.db.parent):
            d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------- dữ liệu cấu hình
@dataclass
class Settings:
    max_concurrency: int = 5
    headless: bool = True
    iterations: int = 1
    schedule: Optional[str] = None          # cron 5 trường
    max_retries: int = 3
    backoff_base_s: float = 2.0
    backoff_max_s: float = 120.0
    breaker_failure_threshold: float = 0.5
    breaker_min_samples: int = 5
    breaker_cooldown_s: float = 60.0
    health_check_interval_s: float = 30.0
    gateway_timeout_s: float = 5.0
    exit_ip_url: Optional[str] = "https://api.ipify.org"   # null để tắt
    allowed_domains: list[str] = field(default_factory=list)  # rỗng = không giới hạn
    queue_backend: str = "local"            # local | redis
    redis_url: str = "redis://127.0.0.1:6379/0"
    redis_queue: str = "qa:tasks"
    dashboard_host: str = "127.0.0.1"
    dashboard_port: int = 8787
    llm: dict[str, Any] = field(default_factory=lambda: {"provider": "none"})
    # Phase 2
    router_default_engine: str = "chromium"           # engine dùng khi kịch bản cần DOM thật
    context_mode: str = "process"    # process = 1 tiến trình trình duyệt/profile (cô lập tuyệt đối, gồm IndexedDB)
                                      # shared  = 1 tiến trình dùng chung/engine, mỗi profile 1 BrowserContext
                                      #           (tiết kiệm RAM/CPU, nhưng storage_state KHÔNG lưu IndexedDB)
    bandwidth: dict[str, Any] = field(default_factory=dict)         # xem bandwidth_optimizer.BandwidthConfig
    gateway_validator: dict[str, Any] = field(default_factory=dict)  # xem gateway_validator.GatewayCheckConfig
    schedule_windows: list[dict[str, Any]] = field(default_factory=list)  # xem schedule_windows.ScheduleWindow


@dataclass
class Environment:
    name: str
    viewport: Optional[dict[str, int]] = None
    device_scale_factor: Optional[float] = None
    user_agent: Optional[str] = None
    locale: Optional[str] = None
    timezone_id: Optional[str] = None
    geolocation: Optional[dict[str, float]] = None
    is_mobile: Optional[bool] = None
    has_touch: Optional[bool] = None
    region: Optional[str] = None
    extra_http_headers: Optional[dict[str, str]] = None

    def context_kwargs(self) -> dict[str, Any]:
        kw: dict[str, Any] = {
            "viewport": self.viewport, "device_scale_factor": self.device_scale_factor,
            "user_agent": self.user_agent, "locale": self.locale,
            "timezone_id": self.timezone_id, "is_mobile": self.is_mobile,
            "has_touch": self.has_touch, "extra_http_headers": self.extra_http_headers,
        }
        if self.geolocation:
            kw["geolocation"] = self.geolocation
            kw["permissions"] = ["geolocation"]
        return {k: v for k, v in kw.items() if v is not None}


@dataclass
class Scenario:
    id: str
    name: str
    urls: list[str]
    profile_id: str
    environment: str = "default"
    region: Optional[str] = None
    timeout_ms: int = 30000
    active: bool = True
    screenshot_on_error: bool = True
    engine: str = "auto"             # auto | http | chromium | firefox | webkit (xem engine_router.py)
    bandwidth: dict[str, Any] = field(default_factory=dict)   # ghi đè settings.bandwidth cho riêng kịch bản này
    interaction: dict[str, Any] = field(default_factory=dict)
    steps: list[dict[str, Any]] = field(default_factory=list)
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Scenario":
        if not d.get("id") or not d.get("urls"):
            raise ValueError(f"Kịch bản thiếu 'id' hoặc 'urls': {d.get('name')!r}")
        return cls(
            id=str(d["id"]), name=str(d.get("name") or d["id"]),
            urls=[str(u) for u in d["urls"]],
            profile_id=str(d.get("profile_id") or d["id"]),
            environment=str(d.get("environment", "default")),
            region=d.get("region"), timeout_ms=int(d.get("timeout_ms", 30000)),
            active=bool(d.get("active", True)),
            screenshot_on_error=bool(d.get("screenshot_on_error", True)),
            engine=str(d.get("engine", "auto")),
            bandwidth=dict(d.get("bandwidth") or {}),
            interaction=dict(d.get("interaction") or {}),
            steps=list(d.get("steps") or []), raw=d,
        )


@dataclass(frozen=True)
class GatewayEntry:
    url: str
    region: str = "any"

    @property
    def parts(self):
        return urlsplit(self.url)

    @property
    def host(self) -> str:
        return self.parts.hostname or ""

    @property
    def port(self) -> int:
        return self.parts.port or 0

    @property
    def masked(self) -> str:
        return f"{self.parts.scheme}://{self.host}:{self.port}"

    @property
    def browser_compatible(self) -> bool:
        """Chromium không hỗ trợ SOCKS5 có xác thực."""
        return not (self.parts.scheme.startswith("socks") and self.parts.username)

    def playwright_proxy(self) -> dict[str, str]:
        p = {"server": self.masked}
        if self.parts.username:
            p["username"] = unquote(self.parts.username)
        if self.parts.password:
            p["password"] = unquote(self.parts.password)
        return p


@dataclass
class Config:
    settings: Settings
    environments: dict[str, Environment]
    scenarios: list[Scenario]
    gateways: list[GatewayEntry]


# ---------------------------------------------------------------- nạp
def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_environments(path: Path) -> dict[str, Environment]:
    envs: dict[str, Environment] = {"default": Environment(name="default")}
    if path.is_file():
        known = {f.name for f in fields(Environment)} - {"name"}
        for name, spec in _read_json(path).items():
            envs[name] = Environment(name=name, **{k: v for k, v in spec.items() if k in known})
    return envs


def load_gateways(path: Path) -> list[GatewayEntry]:
    """Mỗi dòng: `region|protocol://user:pass@host:port` hoặc chỉ URL (region = any)."""
    entries: list[GatewayEntry] = []
    if not path.is_file():
        return entries
    for no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        region, _, url = line.rpartition("|") if "|" in line else ("any", "", line)
        try:
            p = urlsplit(url.strip())
            if p.scheme not in GATEWAY_SCHEMES or not p.hostname or not p.port:
                raise ValueError
        except ValueError:
            LOGGER.warning("gateways.txt dòng %d không hợp lệ, bỏ qua", no)
            continue
        entry = GatewayEntry(url=url.strip(), region=(region.strip() or "any").lower())
        if not entry.browser_compatible:
            LOGGER.warning("Gateway %s (SOCKS5 có xác thực) chỉ dùng được cho HTTP client, "
                           "không dùng cho trình duyệt", entry.masked)
        entries.append(entry)
    return entries


def load_config(paths: Paths) -> Config:
    if not paths.scenarios.is_file():
        raise FileNotFoundError(f"Không tìm thấy {paths.scenarios}")
    data = _read_json(paths.scenarios)
    raw_settings = data.get("settings", {}) if isinstance(data, dict) else {}
    raw_scenarios = data.get("scenarios", []) if isinstance(data, dict) else data
    known = {f.name for f in fields(Settings)}
    settings = Settings(**{k: v for k, v in raw_settings.items() if k in known})
    return Config(
        settings=settings,
        environments=load_environments(paths.environments),
        scenarios=[Scenario.from_dict(s) for s in raw_scenarios],
        gateways=load_gateways(paths.gateways),
    )


def is_url_allowed(url: str, allowed_domains: list[str]) -> bool:
    """Danh sách trắng tên miền: rỗng = cho phép tất cả."""
    if not allowed_domains:
        return True
    host = (urlsplit(url).hostname or "").lower()
    return any(host == d.lower() or host.endswith("." + d.lower()) for d in allowed_domains)
