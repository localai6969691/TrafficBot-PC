"""Cửa sổ lập lịch đa ngày / qua đêm (vd. 22:00 thứ Sáu - 06:00 thứ Bảy).

APScheduler (CronTrigger) không có khái niệm "cửa sổ có giờ bắt đầu/kết thúc, lặp lại
đều đặn bên trong cửa sổ" sẵn có - phải tự ghép 2 thời điểm (bắt đầu/kết thúc) cộng một
vòng lặp. Module này triển khai điều đó bằng asyncio.Task thuần, chạy song song với
APScheduler (dùng cho lịch cron đơn giản, không theo cửa sổ) trong `main.py`.

Giờ dùng là giờ địa phương của máy chạy runner (`datetime.now()`), không phải UTC và
không tự quy đổi múi giờ của vùng kiểm thử - xem PROJECT.md mục giới hạn.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Optional

LOGGER = logging.getLogger("qa.schedule_windows")
_DAY_IDX = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
ALL_DAYS = tuple(_DAY_IDX)


@dataclass
class ScheduleWindow:
    days: tuple[str, ...]            # ngày BẮT ĐẦU cửa sổ, vd. ("fri","sat")
    start: str                       # "HH:MM"
    end: str                        # "HH:MM"; <= start nghĩa là cửa sổ kéo qua nửa đêm
    interval_minutes: float = 30.0   # khoảng cách giữa các chu kỳ chạy bên trong cửa sổ
    max_concurrency: Optional[int] = None
    iterations: Optional[int] = None
    label: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "ScheduleWindow":
        days = tuple(str(x).lower()[:3] for x in (d.get("days") or ALL_DAYS))
        unknown = set(days) - set(ALL_DAYS)
        if unknown:
            raise ValueError(f"schedule_windows: ngày không hợp lệ {unknown} (dùng mon..sun)")
        if "start" not in d or "end" not in d:
            raise ValueError("schedule_windows: mỗi cửa sổ cần 'start' và 'end' dạng HH:MM")
        return cls(days=days, start=str(d["start"]), end=str(d["end"]),
                   interval_minutes=float(d.get("interval_minutes", 30)),
                   max_concurrency=d.get("max_concurrency"), iterations=d.get("iterations"),
                   label=str(d.get("label", f"{d.get('start')}-{d.get('end')}")))

    def _minutes(self, hhmm: str) -> int:
        h, m = (int(x) for x in hhmm.split(":"))
        return h * 60 + m

    @property
    def duration(self) -> timedelta:
        start_m, end_m = self._minutes(self.start), self._minutes(self.end)
        if end_m <= start_m:
            end_m += 24 * 60
        return timedelta(minutes=end_m - start_m)

    def next_start(self, now: datetime) -> datetime:
        start_h, start_m = (int(x) for x in self.start.split(":"))
        candidates = []
        for day in self.days:
            ahead = (_DAY_IDX[day] - now.weekday()) % 7
            cand = (now + timedelta(days=ahead)).replace(hour=start_h, minute=start_m, second=0, microsecond=0)
            if cand <= now:
                cand += timedelta(days=7)
            candidates.append(cand)
        return min(candidates)


async def run_window(window: ScheduleWindow, run_cycle: Callable[[Optional[int]], Awaitable[Any]],
                     get_concurrency: Callable[[], int], set_concurrency: Callable[[int], None],
                     stop: asyncio.Event) -> None:
    """Vòng lặp vô hạn cho một cửa sổ: chờ tới giờ bắt đầu, chạy `run_cycle` lặp lại mỗi
    `interval_minutes` cho tới giờ kết thúc, khôi phục concurrency, rồi chờ lần kế tiếp."""
    LOGGER.info("Đã đăng ký cửa sổ lịch '%s': %s %s-%s", window.label, ",".join(window.days),
                window.start, window.end)
    while not stop.is_set():
        start_at = window.next_start(datetime.now())
        wait_s = max(0.0, (start_at - datetime.now()).total_seconds())
        LOGGER.info("[%s] Lần kế tiếp: %s (còn %.0f phút)", window.label, start_at, wait_s / 60)
        if await _wait_or_stop(stop, wait_s):
            return
        end_at = start_at + window.duration
        original = get_concurrency()
        if window.max_concurrency:
            set_concurrency(window.max_concurrency)
        LOGGER.info("[%s] Bắt đầu - dự kiến kết thúc %s", window.label, end_at)
        try:
            while datetime.now() < end_at and not stop.is_set():
                await run_cycle(window.iterations)
                remain_s = (end_at - datetime.now()).total_seconds()
                if remain_s <= 0:
                    break
                if await _wait_or_stop(stop, min(window.interval_minutes * 60, remain_s)):
                    return
        finally:
            set_concurrency(original)
            LOGGER.info("[%s] Kết thúc cửa sổ", window.label)


async def _wait_or_stop(stop: asyncio.Event, timeout_s: float) -> bool:
    """True nếu nhận tín hiệu dừng trong lúc chờ (nên thoát hẳn vòng lặp ngoài)."""
    try:
        await asyncio.wait_for(stop.wait(), timeout=max(0.0, timeout_s))
        return True
    except asyncio.TimeoutError:
        return False
