# SYNTHETIC AUTOMATION STUDIO — TÀI LIỆU DỰ ÁN TOÀN DIỆN

> **Mục đích tài liệu này:** Bất kỳ AI hay lập trình viên nào tiếp nhận dự án
> chỉ cần đọc file này là hiểu đủ để tiếp tục — không cần đọc lại chat history,
> không đoán mò, không làm lại từ đầu.

---

## 1. TẦM NHÌN & YÊU CẦU GỐC

**Mục tiêu:** Phần mềm desktop standalone (1-click, không cài đặt) chạy trên
Windows / macOS / Linux, dùng để tự động hóa trình duyệt và mô phỏng lưu lượng
web theo kịch bản có thể tùy chỉnh qua giao diện kéo-thả No-Code.

**Người dùng:** Không có máy để build cục bộ. Mọi binary đều phải sinh ra từ
GitHub Actions (Nuitka --standalone). Python + Playwright là stack chính.

**Spec gốc (5 tầng kiến trúc):**
```
Tầng 1: Dashboard UI   → PyWebView native window + SPA (FastAPI localhost)
Tầng 2: Orchestrator   → Campaign + ResourceGovernor + MCP server
Tầng 3: Engine Router  → HTTP/2 (curl_cffi) | Browser (Playwright) | Cloud CDP
Tầng 4: Network        → Gateway pool, sticky session, tunnel sidecar
Tầng 5: Persistence    → SQLite (state.db), AES vault, Smart cache prune
```

**Khởi chạy:**
```bash
python app_launcher.py           # Desktop GUI (PyWebView native window)
python app_launcher.py --no-gui  # Headless server mode
python app_launcher.py --port 18080
python main.py --dashboard       # CLI dashboard (cũ, vẫn hoạt động)
python main.py run --url https://example.com  # CLI no-dashboard
```

---

## 2. CẤU TRÚC THƯ MỤC ĐẦY ĐỦ

```
synthetic-qa-orchestrator/
│
├── app_launcher.py          # 1-Click Desktop Launcher (PyWebView + pystray)
├── main.py                  # CLI entry point (dashboard + run modes)
│
├── ui/
│   ├── __init__.py
│   └── desktop_window.py    # DesktopWindowManager + JSBridge (6 methods)
│
├── static_assets/           # Bundled JS/CSS — KHÔNG phụ thuộc CDN runtime
│   ├── drawflow.min.js      # v0.0.60 từ npm (46KB)
│   ├── drawflow.min.css     # (2KB)
│   └── alpine.min.js        # Alpine.js v3.17.5 từ npm (56KB)
│
├── dashboard.py             # FastAPI app + SSE + toàn bộ HTML/CSS/JS (2262 dòng)
├── admin_api.py             # 80 API routes (tất cả /api/* của dashboard)
│
├── engine.py                # Task queue, semaphore, workflow runner, metrics
├── engine_router.py         # Chọn engine: HTTP/2 | Browser | Cloud (TLSSessionStore)
├── interaction.py           # Log-normal dwell, scroll, hover (InteractionSimulator)
├── kinematic_input.py       # Bezier mouse, KeystrokeDynamics, InertialScroll
├── bandwidth_optimizer.py   # CDP route filter -70% bandwidth
├── self_healing.py          # Selector healer: CSS→XPath→text→AI fallback
├── referrer_orchestrator.py # Chuỗi referrer: Direct|Search|Social|Custom chain
│
├── persona_manager.py       # Device matrix: UA/screen/HW/font coherence
├── session_warmer.py        # Nuôi dưỡng profile: warming schedule tự động
├── credential_vault.py      # AES-256 encrypted accounts/captcha/cookies
├── secrets_store.py         # API key vault (AES at-rest, chmod 600)
│
├── campaign_controller.py   # StormController, RedirectBlocker, WorkspaceManager
├── resource_governor.py     # CPU/RAM watchdog, auto-throttle concurrency
├── schedule_windows.py      # Multi-day scheduling windows (overnight, cron)
│
├── network_manager.py       # Gateway pool, circuit breaker, HTTP probe
├── gateway_validator.py     # Batch validate: latency, Exit IP, GeoIP match
├── tunnel_manager.py        # Sidecar SOCKS5/tunnel process manager
├── cloud_browser_adapter.py # CDP remote + HybridScheduler (local↔cloud)
│
├── autopilot_rewriter.py    # LLM rewrite kịch bản (Ollama local / OpenAI compat)
├── test_data.py             # Form data generator (nội bộ + LLM optional)
├── trace_replayer.py        # Ghi & phát lại tương tác (TraceRecorder/Replayer)
├── action_synchronizer.py   # Multi-window sync (1 master → N slave contexts)
├── visual_picker.py         # Point-and-click element picker (CDP highlight)
│
├── js_sandbox_probe.py      # Chạy JS không cần browser (node/py_mini_racer)
├── widget_media_qa.py       # iframe + video/audio/image QA assertions
├── plugin_manager.py        # ZIP plugin loader (manifest.json driven)
├── mcp_server.py            # MCP stdio server cho Claude Desktop / Cursor
│
├── diagnostics_alerter.py   # Root-cause taxonomy, SmartCachePruner, AlertDispatcher
├── preflight_audit.py       # Pre-flight tự kiểm định môi trường trước khi chạy
├── remote_db_adapter.py     # MongoDB Atlas sync adapter
│
├── config_loader.py         # Paths, Settings, Scenario, GatewayEntry dataclasses
├── database.py              # SQLite (async): profiles, scenarios, runs, metrics
├── events.py                # In-process EventBus + SSE log handler
├── reporting.py             # p50/p95/p99 stats, HTML/CSV/JSON export
├── tray_daemon.py           # TrayDaemon, UARegistry (npm), ProxyParser, AutoStart
│
├── config/
│   ├── app_settings.json    # Port, RAM limit, bandwidth mode, MCP toggle
│   └── device_personas.json # Device matrix: Chrome/FF/Safari, desktop/mobile
│
├── data/
│   └── state.db             # SQLite (auto-created khi chạy lần đầu)
│
├── plugins/                 # Drop ZIP plugin vào đây (manifest.json inside)
├── profiles_data/           # Persistent browser profiles (cookies/storage)
│
├── .github/workflows/
│   ├── build.yml            # Nuitka matrix: Win + macOS + Linux → StudioApp
│   └── scheduled_runner.yml # Chạy lịch trình tự động qua Actions
│
├── requirements.txt
└── PROJECT.md               # ← file này
```

---

## 3. LỊCH SỬ XÂY DỰNG THEO PHIÊN

### Phiên 1-3: Nền tảng
- `engine.py` + `config_loader.py` + `database.py` + `events.py`
- `interaction.py` + `kinematic_input.py`: mô phỏng chuột/bàn phím
- `main.py` CLI, `dashboard.py` v1 (tab Command Center đầu tiên)
- Playwright Chromium headless cơ bản

### Phiên 4-5: Mạng & Profile
- `network_manager.py` + `gateway_validator.py`: pool proxy, circuit breaker
- `persona_manager.py`: device matrix 300+ cấu hình
- `session_warmer.py`: warming lifecycle
- `credential_vault.py` + `secrets_store.py`: AES encryption
- `bandwidth_optimizer.py`: CDP route filter

### Phiên 6-7: Dashboard 9 tabs + Plugin
- Dashboard mở rộng: 9 tabs (Command Center, Flow Studio, Profiles, Network,
  Extensions, Scheduler, Integrations, Vault, Capabilities)
- `plugin_manager.py`: ZIP drop-and-load với manifest.json
- `admin_api.py` tách ra từ dashboard (trước đây inline)
- `mcp_server.py`: MCP stdio cho AI assistant
- `autopilot_rewriter.py`: Ollama/OpenAI LLM rewrite

### Phiên 8-9: Campaign + Cloud + Sync
- `campaign_controller.py`: StormController, ramp curve, RedirectBlocker,
  WorkspaceManager (.qa-bundle export/import)
- `cloud_browser_adapter.py`: CDP remote + HybridScheduler
- `action_synchronizer.py`: multi-window sync realtime
- `resource_governor.py`: CPU/RAM watchdog → auto-throttle
- `engine_router.py` nâng cấp: TLSSessionStore, OS TCP fingerprint

### Phiên 10-11: Chẩn đoán + Visual + Trace
- `diagnostics_alerter.py`: FailureTaxonomyEngine + SmartCachePruner
- `visual_picker.py`: point-and-click CDP picker
- `trace_replayer.py`: recorder + replayer với jitter
- `widget_media_qa.py`: iframe/video/audio assertions
- `js_sandbox_probe.py`: node/py_mini_racer sandbox
- `tunnel_manager.py`: SOCKS5 sidecar process
- `referrer_orchestrator.py`: referrer chain simulation
- `preflight_audit.py`: môi trường self-audit
- `tray_daemon.py`: UARegistry, ProxyParser, AutoStart

### Phiên 12: Hoàn thiện Phase 1-9
- 38 modules, 15,952 dòng
- 41 actions trong engine
- Nâng cấp build.yml: Nuitka matrix 3 OS
- Campaign StormMode + ramp wired into Engine lifecycle
- ResourceGovernor integrated vào semaphore

### Phiên 13: Desktop App + Network Capabilities
- `app_launcher.py` (492L): 1-click launcher, BackendThread, SystemTray
- `ui/desktop_window.py` (327L): PyWebView + JSBridge 6 methods
- `static_assets/`: Drawflow + Alpine.js bundled từ npm (không CDN)
- 5 endpoints `/capabilities/*` dùng mạng thật
- UARegistry dùng npm tarball thật + builtin baseline
- build.yml viết lại: StudioApp (desktop) + runner (CLI)

### Phiên 14 (hiện tại): Audit + Fix + PROJECT.md
- Thêm `GET /scenarios` + `GET /scenarios/{id}` (đang thiếu, dashboard JS gọi)
- Xác nhận 7 "missing routes" → chỉ 2 thiếu thật, 5 còn lại là trailing slash
  của route đã có (FastAPI tự redirect)
- Viết PROJECT.md toàn diện này

---

## 4. BẢN ĐỒ API (80 ROUTES ban đầu + 17 route Phase 10/11 = ~97 ROUTES)

Route mới Phiên 16 (Phase 10/11, không lặp lại bảng nhóm cũ bên dưới):
`/engine/custom-build/status` (GET), `/engine/custom-build/download` (POST),
`/protocol/rotate` (GET), `/capabilities/hybrid-handoff-test` (POST),
`/js-probes/list` (GET), `/js-probes/run` (POST), `/display/xvfb/status` (GET),
`/display/xvfb/settings` (POST), `/display/fonts/provision` (POST),
`/gateways/quality-settings` (GET+POST), `/referrer/traffic-config` (nay có
thêm POST, trước Phiên 16 chỉ có GET trả default tĩnh).


| Nhóm | Routes | Mục đích |
|------|--------|----------|
| `/capabilities/*` | GET × 7, POST × 1 | Kiểm tra môi trường runtime |
| `/gateways/*` | GET × 3, POST × 2 | Proxy/gateway pool |
| `/tunnels/*` | GET × 1, POST × 1, DELETE × 2 | SOCKS5 tunnel sidecar |
| `/browser-settings/*` | GET × 1, POST × 2 | Playwright/CDP config |
| `/personas` | GET × 1 | Device persona list |
| `/profiles/*` | GET × 1, POST × 2 | Browser profiles warming |
| `/scenarios/*` | GET × 2 | Load scenario vào Flow Studio |
| `/workspaces/*` | GET × 2, POST × 3, DELETE × 1 | Workspace .qa-bundle |
| `/vault/*` | GET × 4, POST × 3, DELETE × 1 | Encrypted credentials |
| `/integrations/*` | GET × 1, POST × 2, DELETE × 1 | API key integrations |
| `/plugins/*` | GET × 1, POST × 2, DELETE × 1 | ZIP plugin management |
| `/autopilot/*` | GET × 1, POST × 2 | LLM scenario rewriter |
| `/storm/*` | GET × 1, POST × 1 | Storm mode campaign |
| `/alerts/*` | GET × 2, POST × 1 | Failure diagnostics |
| `/governor/status` | GET × 1 | CPU/RAM watchdog |
| `/healing/log` | GET × 1 | Self-healing log |
| `/tls/*` | GET × 1, POST × 1 | TLS profile management |
| `/ua/*` | GET × 1, POST × 1 | User-Agent registry |
| `/cloud/*` | GET × 2 | Cloud browser status |
| `/referrer/*` | GET × 1, POST × 1 | Referrer chain preview |
| `/mcp/status` | GET × 1 | MCP server status |
| `/picker/*` | GET × 1, POST × 2 | Visual element picker |
| `/proxy/parse` | POST × 1 | Proxy string parser |
| `/remote-db/*` | GET × 1, POST × 1 | MongoDB sync |
| `/schedule/slots` | GET × 1 | Schedule windows |
| `/system/*` | GET × 3, POST × 1 | Metrics + autostart |

---

## 5. TRẠNG THÁI MODULE (✅/⚠️/❌)

| File | Trạng thái | Ghi chú |
|------|-----------|---------|
| `app_launcher.py` | ✅ Hoàn chỉnh | Tested: port finder, JSBridge, fallback browser |
| `ui/desktop_window.py` | ✅ Hoàn chỉnh | pywebview OK on Linux/Win/Mac |
| `dashboard.py` | ✅ Hoàn chỉnh | 9 tabs, local JS bundle, 59 JS api() calls |
| `admin_api.py` | ✅ Hoàn chỉnh | 80 routes, scenarios added Phiên 14 |
| `engine.py` | ✅ Hoàn chỉnh | LocalQueue + RedisQueue, 41 action types |
| `engine_router.py` | ✅ | h2 là optional import (try/except), không lỗi |
| `persona_manager.py` | ✅ Hoàn chỉnh | |
| `network_manager.py` | ✅ Hoàn chỉnh | |
| `gateway_validator.py` | ✅ Hoàn chỉnh | |
| `campaign_controller.py` | ✅ Hoàn chỉnh | StormController + WorkspaceManager |
| `resource_governor.py` | ✅ Hoàn chỉnh | Wired vào Engine semaphore |
| `tray_daemon.py` | ✅ | UARegistry dùng npm tarball thật |
| `js_sandbox_probe.py` | ⚠️ | py_mini_racer/js2py là optional; node fallback ổn |
| `tunnel_manager.py` | ⚠️ | Chưa test với binary thật (cần cloudflared/frpc) |
| `cloud_browser_adapter.py` | ⚠️ | Chưa test với CDP endpoint thật |
| `mcp_server.py` | ⚠️ | Chưa test với Claude Desktop thật |
| `remote_db_adapter.py` | ⚠️ | Cần MongoDB Atlas URI thật để test |
| `autopilot_rewriter.py` | ⚠️ | Cần Ollama running local để test LLM path |

---

## 6. KỸ THUẬT THÀNH CÔNG ✅

| Kỹ thuật | File | Kết quả test |
|-----------|------|-------------|
| Playwright Chromium headless | engine.py | HTTP 200, nav 1308ms |
| curl_cffi Chrome TLS/JA3 | engine_router.py | 48ms vs httpx 121ms |
| SQLite async (aiosqlite) | database.py | Stable, WAL mode |
| FastAPI + SSE realtime | dashboard.py | Log stream OK |
| PyWebView native window | app_launcher.py | import OK, needs display |
| pystray system tray | app_launcher.py | Needs Gtk3 on Linux |
| AES-256 credential vault | credential_vault.py | Encrypt/decrypt OK |
| Drawflow visual canvas | dashboard.py | Served từ /static/ local |
| npm tarball download | tray_daemon.py | 16 unique UAs từ registry |
| Nuitka standalone build | build.yml | Matrix 3 OS |
| ResourceGovernor throttle | resource_governor.py | psutil CPU/RAM OK |
| Self-healing selector | self_healing.py | CSS→XPath→text fallback |
| Session warming schedule | session_warmer.py | APScheduler cron OK |
| Bezier mouse movement | kinematic_input.py | Natural curve OK |
| CDP bandwidth filter | bandwidth_optimizer.py | -70% confirmed |
| Multi-window sync | action_synchronizer.py | Master→slave replay OK |
| Trace record/replay | trace_replayer.py | JSON trace format OK |

---

## 7. KỸ THUẬT THẤT BẠI / KHÔNG HIỆU QUẢ ❌

| Kỹ thuật | Vấn đề | Giải pháp đã áp dụng |
|-----------|--------|---------------------|
| **Firefox/WebKit Playwright** | CDN playwright download bị block trong sandbox Claude | Chỉ cài Chromium; Firefox/WebKit ghi vào build.yml để cài khi GitHub Actions chạy |
| **cdn.jsdelivr.net** | Domain bị block hoàn toàn trong sandbox Claude | Bundle Drawflow/Alpine từ registry.npmjs.org vào static_assets/ |
| **ip-api.com GeoIP** | Domain không reachable trong sandbox | Bỏ live GeoIP test; capabilities chỉ test pypi/npmjs/github |
| **WebKit download** | Playwright install webkit thất bại trong sandbox | Đánh dấu ⚠️ cần `python -m playwright install webkit` sau |
| **pystray trên headless Linux** | Cần Gtk3 (`libappindicator3-dev`); không có trên server | Graceful try/except: nếu không có Gtk → chạy bình thường, chỉ không có tray icon |
| **PyWebView trên headless** | Cần display (X11/Wayland) | `app_launcher.py --no-gui` bypass hoàn toàn PyWebView |
| **h2 package** | Không phải stdlib, dùng optional trong engine_router | `try: import h2` trong try/except, không fail cứng |
| **py_mini_racer** | Không install được trong sandbox (C extension) | Node.js fallback trong js_sandbox_probe.py |
| **js2py** | Chậm, thiếu ES6+ support | Chỉ fallback cuối cùng; ưu tiên node |
| **Nuitka local build** | Không có máy để build | Toàn bộ build qua GitHub Actions matrix |
| **Redis production** | Chưa có Redis server trong test env | fakeredis làm drop-in replacement OK |

---

## 8. VẤN ĐỀ CÒN TỒN ĐỌNG

### Lỗi / thiếu sót cần sửa
| # | Vấn đề | File | Mức độ |
|---|--------|------|--------|
| 1 | `GET /scenarios` + `GET /scenarios/{id}` → thiếu | admin_api.py | ✅ **Đã fix Phiên 14** |
| 2 | `fetch_one`/`fetch_all` KHÔNG tồn tại trong Database class — xác nhận và **đã fix** | database.py | ✅ **Đã fix Phiên 15** |
| 3 | Firefox/WebKit chưa cài được trong sandbox (CDN block) | build.yml | Cần Actions chạy (không đổi) |
| 4 | UARegistry refresh chỉ lấy được 16 UA (npm index.json nhỏ) | tray_daemon.py | Chấp nhận được (không đổi) |
| 5 | `app_launcher.py._serve()`: `Settings.load()` không tồn tại, `Paths(ROOT)` sai constructor, `paths.state_db` sai tên field, `await db.init()` sai (phải là `db.open()` sync) → **server không khởi động được, crash ngay** | app_launcher.py | ✅ **Đã fix Phiên 15** |
| 6 | `dashboard.py`: thiếu `from pathlib import Path` → `NameError` khi gọi `create_app()` | dashboard.py | ✅ **Đã fix Phiên 15** |
| 7 | `admin_api.py`: `JsRunIn` định nghĩa lồng bên trong hàm → FastAPI đọc nhầm `body` thành query param → `POST /capabilities/js-run` luôn trả 422 | admin_api.py | ✅ **Đã fix Phiên 15** |
| 8 | `admin_api.py`: dò Playwright browsers dùng `sync_playwright()` bên trong async endpoint → treo/lỗi event loop, `chromium`/`firefox`/`webkit` luôn báo `False` dù đã cài | admin_api.py | ✅ **Đã fix Phiên 15** (chuyển sang dò path binary qua `asyncio.create_subprocess_exec`) |
| 9 | `/capabilities/ua-refresh`: trả `ua_count` = số UA **mới thêm** trong lần refresh này (thường = 0 nếu đã cache) thay vì tổng số UA trong pool → dashboard hiển thị sai | admin_api.py | ✅ **Đã fix Phiên 15** (trả `ua_count`=tổng pool, thêm field `newly_added`, `cached`) |
| 10 | `POST /capabilities/js-run`: gửi biểu thức đơn (vd. `"2+2"`) không có `console.log` → Node.js subprocess không in gì ra stdout → `output` luôn rỗng | admin_api.py | ✅ **Đã fix Phiên 15** (tự động wrap biểu thức đơn thành `console.log(JSON.stringify(...))`, trả thêm field `script_wrapped`) |

### Cải thiện tùy chọn (chưa làm, không urgent)
- [ ] Code signing: Windows (signtool), macOS (codesign + notarize)
- [ ] Auto-update: check GitHub releases JSON, download+replace binary
- [ ] Firefox/WebKit: cần CDN playwright không bị block để cài
- [ ] Live GeoIP: ip-api.com / ipinfo.io khi deploy ra ngoài sandbox
- [ ] MongoDB Atlas: test real connection cho remote_db_adapter.py
- [ ] Ollama: test autopilot_rewriter với model chạy local
- [ ] cloudflared/frpc: test tunnel_manager với binary thật
- [ ] `playwright_version` trong `/capabilities` trả về `"?"` — có thể lấy chính xác bằng `python -m playwright --version` subprocess nếu cần hiển thị

---

## 8bis. PHIÊN 15 — XÁC NHẬN TOÀN BỘ NETWORK CAPABILITIES HOẠT ĐỘNG

Sandbox đã mở network trong phiên này. Đã chạy server thật (`app_launcher.py --no-gui`)
và test trực tiếp qua HTTP cả 10 endpoint liên quan đến mạng + capabilities.
**Kết quả: 10/10 PASS.**

```
✅ GET  /api/admin/capabilities                 chromium=True, curl_cffi=True, playwright=True
✅ GET  /api/admin/capabilities/network-check    reachable=3/3 (pypi.org, npmjs.org, github.com, ~60-200ms)
✅ GET  /api/admin/capabilities/curl-test        HTTP 200, impersonate=chrome
✅ GET  /api/admin/capabilities/tls-fingerprint  curl_cffi 35ms vs httpx 62ms — cả hai đều hoạt động
✅ GET  /api/admin/capabilities/ua-refresh       ua_count=16 (sau fix), cached=True
✅ POST /api/admin/capabilities/js-run           output='4' cho "2+2", sha256 chạy đúng qua require('crypto')
✅ GET  /api/admin/scenarios                     total=0 (DB rỗng, nhưng fetch_all không còn crash)
✅ GET  /api/admin/capabilities/playwright-install  installed=['chromium']
✅ GET  /api/admin/capabilities/browser-live     Playwright Chromium thật: nav=180ms, HTTP 200, 232KB
```

Trước phiên này, server **không khởi động được** (crash ở `_serve()` do 4 bug liên hoàn
trong `app_launcher.py` + 1 bug `Path` thiếu trong `dashboard.py`) — nghĩa là toàn bộ
tab Capabilities **chưa bao giờ được chạy thử end-to-end** trong các phiên trước, dù
code trông có vẻ hoàn chỉnh. Đây là lý do tại sao việc "đọc code" không đủ — phải
thực sự khởi động server và gọi API thật mới phát hiện ra chuỗi bug này.

---

## 8ter. PHIÊN 16 — PHASE 10 (Biên dịch nhân trình duyệt & giao thức tầng thấp) + PHASE 11 (Tự động hóa môi trường Linux & chất lượng kết nối)

Triển khai đầy đủ 2 đặc tả kỹ thuật lớn theo yêu cầu người dùng, mỗi mục đều
**test thật** (network/Playwright/Node/Xvfb thật, không chỉ đọc code).

### Phase 10 — 5 phân hệ

| # | Tính năng | File | Trạng thái |
|---|---|---|---|
| 10.1 | Zero-Cost Custom Engine Build Pipeline | `.github/workflows/build_custom_engine.yml`, `engine_patches/README.md` | ✅ Tạo xong (chưa chạy thử trên GitHub Actions thật - chỉ review logic) |
| 10.2 | `rotate_protocol_profile()` - đồng bộ TLS/HTTP2/Client-Hints theo browser | `engine_router.py` | ✅ Test thật chrome/safari/mobile |
| 10.3 | `hybrid_browser_to_http_handoff()` | `engine_router.py` | ✅ **Test thật** Playwright + curl_cffi + network thật |
| 10.4 | Node `vm` DOM shim + `run_js_probe_file()` | `js_sandbox_probe.py`, `plugins/js_probes/` | ✅ Test thật qua Node |
| 10.5 | Fail-Safe Gate + Analytics Telemetry Verification | `engine.py`, `reporting.py`, `database.py` | ✅ **Test end-to-end thật** (Engine đầy đủ, DB, Playwright) |

**2 bug sản xuất có từ trước được phát hiện qua test thật (không phải do Phiên 16 gây ra), đã sửa:**
1. `preflight_audit.py` tự ghi chú từ lâu cần patch `navigator.webdriver` qua `add_init_script` nhưng chưa ai code → thêm `STEALTH_WEBDRIVER_JS` trong `engine.py`.
2. Cờ `--disable-blink-features=AutomationControlled` chỉ được truyền cho nhánh `shared_mode`, **thiếu hoàn toàn** ở nhánh `launch_persistent_context` (nhánh mặc định, phổ biến nhất) → đã thêm vào `engine.py`.

Nếu không phát hiện 2 bug này, việc bật "Fail-Safe Gate" mặc định ON (theo đúng yêu cầu "Mandatory" của đặc tả) sẽ khiến **100% scenario trình duyệt bị chặn vô thời hạn**.

### Phase 11 — 4 phân hệ

| # | Tính năng | File | Trạng thái |
|---|---|---|---|
| 11.1 | `XvfbManager` + `provision_cross_platform_fonts()` | `linux_display_manager.py` (mới) | ✅ **Test thật với Xvfb** có sẵn trong sandbox (start/stop/idempotent) + tải font thật qua network |
| 11.1b | Tích hợp Xvfb vào vòng đời `Engine.start()/close()` | `engine.py` | ✅ **Test end-to-end thật** - bật toggle, Xvfb chạy thật tại `:99` |
| 11.2 | Elite Header Check + ASN classification (`classify_infrastructure`/`classify_anonymity`) | `gateway_validator.py` | ✅ Unit test logic OK; gọi mạng thật qua httpbin.org không test được trong sandbox (domain ngoài whitelist mạng - giới hạn môi trường, không phải bug) |
| 11.2b | `GatewayPool.hot_swap()` - thay cổng cùng quốc gia ngay lập tức | `network_manager.py` | ✅ Unit test OK |
| 11.2c | Migration `infra_class`/`anonymity_level` | `database.py` | ✅ Test insert/đọc OK |
| 11.3 | Device Mix Slider (Mobile/Desktop) | `referrer_orchestrator.py`, `admin_api.py` | ✅ Test sampling 2000 lần ra đúng tỉ lệ |
| 11.3b | Biến thể mobile (`chrome_android`/`safari_ios`) cho `rotate_protocol_profile()` | `engine_router.py` | ✅ Test OK |
| 11.4 | `engine_updater.py` - tải browser từ GitHub Release | File mới | ✅ Test logic giải nén+dò executable với zip giả lập; gọi GitHub API thật bị rate-limit 403 (giới hạn IP chung sandbox, lỗi được xử lý graceful đã xác nhận) |

**Phát hiện "tính năng mồ côi" có từ trước, đã sửa:** `TrafficConfig.device_mix` đã tồn tại trong code từ phiên trước nhưng **chưa từng có UI nào gọi tới**, và `GET /referrer/traffic-config` chỉ trả về default tĩnh (không đọc/lưu DB). Default cũ là 65/30/5 (mobile/desktop/tablet) - đã đổi thành đúng khuyến nghị đặc tả Phase 11 (**75% Mobile/25% Desktop**) và thêm `POST /referrer/traffic-config` lưu thật.

### Bug phát hiện qua test thật trong chính Phiên 16 (lỗi tôi gây ra, đã tự sửa trước khi giao)
- 6 `BaseModel` request-body (`CustomEngineDownloadIn`, `HybridHandoffTestIn`, `JsProbeRunIn`, `VirtualDisplayIn`, `GatewayQualitySettingsIn`, `TrafficConfigIn`) bị định nghĩa lồng bên trong `create_admin_router()` thay vì ở module level → FastAPI đọc nhầm `body` thành query param → mọi POST endpoint liên quan trả 422. Đây là **lặp lại y hệt bug đã gặp và sửa ở Phiên 15 với `JsRunIn`** nhưng tôi quên áp dụng bài học khi viết thêm 6 class mới ở Phiên 16 - đã sửa, đưa cả 6 lên module-level, test lại 100% PASS.

### Endpoint mới (Phase 10+11, tổng 17 endpoint)
`GET/POST /engine/custom-build/{status,download}`, `GET /protocol/rotate`,
`POST /capabilities/hybrid-handoff-test`, `GET /js-probes/list`,
`POST /js-probes/run`, `GET/POST /display/xvfb/{status,settings}`,
`POST /display/fonts/provision`, `GET/POST /gateways/quality-settings`,
`GET/POST /referrer/traffic-config` (nay đã lưu thật thay vì chỉ trả default tĩnh).

---

## 8quater. PHIÊN 17 — ĐẶC TẢ HỢP NHẤT TOÀN DIỆN (MASTER UNIFIED SPECIFICATION, Phase 12)

Triển khai đặc tả hợp nhất 42 module thành Flow Studio nâng cấp (Session
Envelope + 3 cách tạo kịch bản + 12-node palette) và Command Center nâng cấp
(Live Browser Workers Grid + Run Now + Live Snapshot Preview). **Phát hiện và
sửa 1 lỗ hổng kiến trúc nghiêm trọng có từ rất lâu** trong lúc triển khai.

### Khám phá quan trọng nhất: 10/12 node đã có backend hoàn chỉnh từ trước
Trước khi viết code mới, rà soát `engine.py` phát hiện **38+ action type đã
được implement đầy đủ** từ các phase trước (`referrer_goto`, `prime_session`,
`human_click`/`healing_click`, `widget_qa`/`media_qa`, `sync_start`,
`hybrid_handoff`, `js_probe`, `classify_failure`...) nhưng **Flow Studio chỉ
có 8 nút bấm chung chung** (goto/click/type/scroll/wait/assert/branch/loop) -
toàn bộ các action chuyên biệt chỉ gọi được bằng cách tự tay sửa JSON. Đây là
"mồ côi" quy mô lớn nhất phát hiện được trong toàn bộ dự án.

### Đã triển khai

| # | Tính năng | File | Trạng thái |
|---|---|---|---|
| 1 | 12-Node Specialized Palette (nút bấm cho 10 action có sẵn + 2 action mới) | `dashboard.py` (`_NODE_TEMPLATES`) | ✅ Test HTML render OK |
| 2 | Action mới: `analytics_verify` (checkpoint thủ công GA4) | `engine.py` | ✅ Code xong, dùng lại `_analytics_state` có sẵn từ Phase 10.5 |
| 3 | Action mới: `ai_form_fill` (Local AI Form Filler - dò field + điền dữ liệu qua `TestDataGenerator`) | `engine.py` | ✅ **Test thật với Playwright + form HTML thật** - điền đúng 5/5 field theo ngữ cảnh (email→email, phone→phone...) |
| 4 | Session Envelope UI (Engine Mode/Pool Mode/Preflight/Xvfb/Device Mix/Bandwidth) | `dashboard.py` | ✅ Map trực tiếp vào field `scenario.engine`/`scenario.bandwidth` có sẵn + `raw.session_envelope` |
| 5 | 1-Click Blueprints (4 mẫu: Duyệt đọc sâu, Referrer chain, Video/Iframe QA, Form filler) | `config/templates/*.json` (mới) | ✅ Test JSON hợp lệ + endpoint `/flow/templates` trả đúng |
| 6 | Visual Action-to-Node Recorder (singleton session theo pattern `visual_picker.py`) | `trace_replayer.py` | ✅ **Test thật với Playwright** - ghi click+type thật, chuyển đổi đúng thành step JSON kèm thời gian nghỉ thực tế |
| 7 | Natural Language to Flow (Ollama) | `admin_api.py` | ✅ Code xong, xử lý lỗi graceful đã xác nhận; **Ollama không chạy trong sandbox nên chưa test được việc sinh JSON thật** |
| 8 | Live Browser Workers Grid (`Engine._workers` registry) | `engine.py`, `admin_api.py`, `dashboard.py` | ✅ **Test end-to-end thật** - worker xuất hiện, `current_step` cập nhật sống động (khởi tạo→goto→interact), biến mất khi xong |
| 9 | Live Snapshot Preview (`page.screenshot()` theo yêu cầu) | `admin_api.py` | ✅ Code xong, xác nhận trả lỗi graceful khi page chưa sẵn sàng |
| 10 | Stop Worker riêng lẻ | `admin_api.py` | ✅ Code xong (đóng `page.context`) |
| 11 | Nút "▶ Chạy Ngay" (Run Now) | `admin_api.py`, `dashboard.py` | ✅ **Test thật** - kích hoạt scenario qua HTTP, worker chạy thật, run được ghi vào DB |

### 2 lỗ hổng kiến trúc nghiêm trọng có từ trước, phát hiện qua test thật

1. **`app_launcher.py` (desktop launcher 1-click) chưa bao giờ tạo Engine.**
   `_serve()` trước Phiên 17 chỉ mở Database + hiển thị dashboard xem dữ liệu -
   **không có cách nào thực thi scenario nào cả** dù giao diện đầy đủ nút
   "chạy". Đây là gap nền tảng ảnh hưởng đúng tính năng cốt lõi mà đặc tả hợp
   nhất nhấn mạnh ("vận hành 1-click trên Desktop"). **Đã sửa**: `_serve()`
   giờ dùng chung `main.py::build_app()` + `running()` với đường CLI, đảm bảo
   Desktop và CLI dùng chung một Engine thật, cùng vòng đời Pool/Governor/Xvfb.
   Đồng thời phát hiện luôn: **toàn bộ dự án (kể cả CLI) chưa từng có endpoint
   nào để chủ động kích hoạt một lượt chạy theo yêu cầu** (chỉ có cron/schedule
   hoặc chạy 1 lần lúc khởi động `main.py run`) - đã thêm `POST /run-now`.

2. **4/8 scenario demo trong `config/scenarios.json` dùng sai schema** (field
   `"url"` số ít thay vì `"urls"` là list), khiến `load_config()` **crash toàn
   bộ** (không chỉ 4 scenario lỗi mà cả 4 scenario hợp lệ còn lại cũng không
   tải được, vì list-comprehension không bọc try/except per-item). Nghĩa là
   **`main.py run` với file config demo gốc của dự án đã luôn luôn crash** kể
   từ khi 4 scenario `phase3-*` này được thêm vào ở phase trước đó. Đã sửa
   bằng script chuyển `url` → `urls: [url]` cho cả 4 entry.

### Chưa làm / hạn chế trung thực
- Natural Language to Flow: chưa test được lệnh gọi Ollama thật (Ollama không
  cài trong sandbox) - chỉ xác nhận xử lý lỗi graceful khi Ollama không khả dụng.
- GitHub Actions `build_custom_engine.yml` (Phase 10): vẫn chưa chạy thử trên
  Actions thật.
- Fallback & Challenge Handler (`classify_failure`): node UI đã thêm, backend
  action đã tồn tại từ trước, nhưng CHƯA test riêng luồng rẽ nhánh 2 output
  (thành công/fallback) qua Drawflow canvas thật.
- `.small` CSS class dùng cho nút trong Live Worker Grid chưa chắc tồn tại
  trong stylesheet - không ảnh hưởng chức năng, chỉ có thể thiếu style nhỏ.

---

## 8quinquies. PHIÊN 18 — TÀI LIỆU ĐẶC TẢ KỸ THUẬT & KIỂM TOÁN TOÀN DIỆN

Biên soạn `AUDIT_SPEC.md` (494 dòng, 8 mục bắt buộc) theo yêu cầu kiểm toán độc
lập toàn bộ codebase. Trong lúc biên soạn, phát hiện và sửa:

1. **Bug cú pháp CI nghiêm trọng**: `.github/workflows/build.yml` dòng 17 có
   `runs-on: ${{ matrix.os }})` — dấu `)` thừa khiến GitHub Actions không tìm
   thấy runner nào, **mọi job build Nuitka standalone đã thất bại ngay từ bước
   chọn runner kể từ khi file được tạo**. Đã sửa.
2. **Phát hiện lỗ hổng topology nghiêm trọng nhất dự án**: `_updateFlowJson()`
   trong Flow Studio làm phẳng toàn bộ node Drawflow thành 1 mảng tuyến tính
   theo thứ tự object, **hoàn toàn không đọc dây nối giữa các node trên
   canvas**. `branch`/`classify_failure` có 2 output port trên UI nhưng
   `engine.py` đọc `then`/`else` là 2 mảng step LỒNG NHAU trong field dữ liệu
   — UI hiện tại còn chưa có ô nhập cho field này. Rẽ nhánh trực quan bằng
   kéo-dây **không tồn tại ở tầng thực thi**.
3. **3 lỗi tự phát hiện trong chính bản nháp audit** (redis/fakeredis,
   EventBus queue bound, cơ chế mã hoá) — đã tự `grep` xác minh lại và sửa
   trước khi hoàn tất, xem Mục 7 của `AUDIT_SPEC.md`.

File đính kèm: `AUDIT_SPEC.md` ở thư mục gốc dự án.

---

## 8sexies. PHIÊN 19 — SỬA THẬT (không chỉ ghi vào audit) 5 lỗi UI↔Engine nghiêm trọng nhất phát hiện được

Sau khi giao `AUDIT_SPEC.md` ở Phiên 18, người dùng yêu cầu sửa thẳng thay vì
chỉ ghi nhận. Đào sâu thêm phát hiện vấn đề **nghiêm trọng hơn** những gì đã
ghi trong Mục 2.4 của audit:

1. **4/8 node CƠ BẢN của Flow Studio hoàn toàn không chạy được** (nghiêm
   trọng hơn vấn đề topology `branch`, vì đây là node nền tảng, lỗi có từ rất
   lâu): node "Type" tạo `action:"type"` nhưng engine chỉ có `"fill"`; node
   "Wait" dùng field `duration_ms` nhưng engine chỉ đọc `ms`; node "Assert"
   tạo `action:"assert"` — không tồn tại; node "Loop" — **chưa từng được
   implement**. Đã sửa bằng alias 2 chiều (an toàn ngược) + implement `loop`
   thật trong `engine.py`.
2. **`scroll` với field `delta_y`** trước đây bị bỏ qua hoàn toàn (dùng cấu
   hình cố định cấp scenario) — đã thêm nhánh `page.mouse.wheel()` khi có
   `delta_y`. Trong lúc test phát hiện thêm 2 bug nhỏ tự tạo ra: thiếu
   `mouse.move()` trước `wheel()` (wheel không có tác dụng nếu con trỏ chưa
   ở trong viewport) và thiếu `wait_for_timeout` sau wheel (scroll là bất
   đồng bộ, cần 1 nhịp để áp dụng) — cả 2 đã sửa và test lại xác nhận.
3. **`probability_a` (Weighted Split) hoàn toàn chết** — `_condition()` chưa
   từng đọc field này, mọi "Weighted Split" luôn đi nhánh `else`. Đã thêm
   nhánh `random.random() < probability_a`, test phân phối 1000 lần ra đúng
   tỉ lệ.
4. **Viết lại hoàn toàn `_updateFlowJson()` → `_buildStepsFromGraph()`** —
   thuật toán cũ làm phẳng mọi node theo thứ tự object, bỏ qua dây nối canvas.
   Thuật toán mới duyệt đồ thị `inputs`/`outputs` thật của Drawflow, sinh
   đúng `then`/`else` cho `branch` và `steps` cho `loop` từ chính dây nối.
   Test bằng Node.js thuần với dữ liệu export Drawflow mô phỏng thật (3 case:
   branch 2 nhánh, nhiều chuỗi độc lập + node orphan, loop với thân lặp từ
   topology) — cả 3 đều đúng.
5. **`classify_failure` không nên là branch 2-output** — đã xác nhận cơ chế
   "Fallback Handler" thật trong dự án là field `on_error_fallback` (đã có
   sẵn, generic cho MỌI step, không cần node riêng) — sửa `classify_failure`
   về lại 1 output, không giả vờ là branch point.

Test cuối: scenario thật `wait → branch(probability_a=1.0) → then/else` chạy
qua Engine đầy đủ (Playwright thật, DB thật) — xác nhận đi đúng nhánh `then`
(0.9s, nếu đi `else` sẽ mất >9s).

`AUDIT_SPEC.md` đã được cập nhật lại các mục liên quan để phản ánh đúng trạng
thái ĐÃ SỬA thay vì chỉ "phát hiện".

---

## 9. DEPENDENCIES

### Python packages (requirements.txt)
```
playwright>=1.44        # Browser automation
httpx[http2,socks]>=0.27 # HTTP/2 client
fastapi>=0.110          # API server
uvicorn[standard]>=0.29 # ASGI server
apscheduler>=3.10,<4    # Scheduler (warming, cron)
curl_cffi>=0.7          # Chrome TLS/JA3 fingerprint
aiofiles>=23.2          # Async file I/O
aiohttp>=3.9            # Async HTTP (gateway check)
websockets>=12.0        # WebSocket client
redis>=5.0              # Task queue (production)
fakeredis>=2.21         # Drop-in Redis (dev/test)
motor>=3.3              # MongoDB async driver
cryptography>=42.0      # AES-256 vault
psutil>=5.9             # CPU/RAM monitoring
pywebview>=4.4          # Native desktop window
pystray>=0.19           # System tray icon
pillow>=10.0            # Tray icon image
```

### System requirements
```
Linux:   libwebkit2gtk-4.0-dev, libappindicator3-dev, libgtk-3-dev
macOS:   macOS 10.14+ (WKWebView built-in)
Windows: Edge/WebView2 Runtime (included in Windows 10 1803+)
Node.js: v18+ (optional, cho js_sandbox_probe.py)
```

### Reachable domains từ Claude sandbox
```
✅ pypi.org
✅ registry.npmjs.org
✅ github.com
✅ files.pythonhosted.org (cần full path)
❌ cdn.jsdelivr.net  (blocked)
❌ ip-api.com        (blocked)
❌ www.googleapis.com (blocked)
❌ raw.githubusercontent.com (hầu hết 404)
```

---

## 10. DATABASE SCHEMA (state.db)

```sql
CREATE TABLE profiles (
    id TEXT PRIMARY KEY, name TEXT, ua TEXT,
    screen_w INTEGER, screen_h INTEGER, timezone TEXT,
    locale TEXT, platform TEXT, warmth_score REAL,
    last_used TEXT, config TEXT, created_at TEXT
);

CREATE TABLE scenarios (
    id TEXT PRIMARY KEY, name TEXT, urls TEXT,
    profile_id TEXT, timeout_ms INTEGER, active INTEGER,
    config TEXT,  -- JSON: {steps:[], drawflow_data:{}, ...}
    updated_at TEXT
);

CREATE TABLE runs (
    id TEXT PRIMARY KEY, scenario_id TEXT, profile_id TEXT,
    gateway TEXT, started_at TEXT, finished_at TEXT,
    status TEXT, metrics TEXT, error TEXT
);

CREATE TABLE performance_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT, url TEXT, ttfb_ms REAL, fcp_ms REAL,
    lcp_ms REAL, cls REAL, tbt_ms REAL, recorded_at TEXT
);

CREATE TABLE integration_keys (     -- Phiên 7+
    name TEXT PRIMARY KEY, encrypted_key TEXT, service TEXT,
    created_at TEXT
);

CREATE TABLE tunnel_sessions (      -- Phiên 11+
    name TEXT PRIMARY KEY, protocol TEXT, local_port INTEGER,
    remote TEXT, pid INTEGER, started_at TEXT
);
```

---

## 11. CẤU HÌNH (config/app_settings.json)

```json
{
  "port": 18080,
  "host": "127.0.0.1",
  "max_workers": 10,
  "ram_limit_mb": 2048,
  "cpu_limit_pct": 80,
  "bandwidth_save_mode": true,
  "mcp_server_enabled": false,
  "log_level": "INFO",
  "profiles_dir": "profiles_data",
  "reports_dir": "data/reports",
  "plugins_dir": "plugins"
}
```

---

## 12. DASHBOARD — 9 TABS

| Tab | ID HTML | Nội dung chính |
|-----|---------|---------------|
| Command Center | `view-main` | KPI cards, line chart, live SSE log feed |
| Flow Studio | `view-flow` | Drawflow canvas kéo-thả, 7 loại node, load/save scenario |
| Profiles | `view-profiles` | Danh sách profile, warming status, bulk create |
| Network | `view-network` | Gateway import, latency check, GeoIP match |
| Extensions | `view-ext` | Custom browser path, plugin ZIP, CDP connectors |
| Scheduler | `view-sched` | Multi-day slots, Storm mode, resource sliders |
| Integrations | `view-integrations` | CapSolver / 2Captcha / MongoDB API keys |
| Vault | `view-vault` | Accounts, captcha keys, cookies (AES encrypted) |
| Capabilities | `view-caps` | Runtime check + 5 live network tests + Desktop status |

---

## 13. CÁCH TIẾP TỤC XÂY DỰNG (cho AI / developer kế tiếp)

### Bước 0 — Đọc file này xong, unzip dự án
```bash
unzip synthetic-qa-orchestrator-v14.zip
cd synthetic-qa-orchestrator
pip install -r requirements.txt
python -m playwright install chromium
python app_launcher.py --no-gui   # test headless
```

### Bước 1 — Kiểm tra nhanh trạng thái
```bash
python3 -c "
import ast, os, sys
sys.path.insert(0,'.')
errs=[]
for f in os.listdir('.'):
    if f.endswith('.py'):
        try: ast.parse(open(f).read())
        except SyntaxError as e: errs.append(f'{f}: {e}')
print('Syntax OK' if not errs else errs)
"
```

### Bước 2 — Xem vấn đề còn tồn đọng
Đọc **Mục 8** của file này.

### Bước 3 — Thêm tính năng mới
Mọi tính năng mới đều theo pattern này:
1. Logic nghiệp vụ → module riêng (ví dụ `feature_x.py`)
2. API endpoint → thêm vào `admin_api.py` trong `build_admin_router()`
3. UI → thêm section HTML vào `dashboard.py` trong chuỗi `PAGE`
4. JS handler → thêm vào phần `<script>` cuối `dashboard.py`
5. Test → `python3 -c "from feature_x import FeatureX; ..."` trước khi zip

### Bước 4 — Đóng gói
```bash
# Cập nhật PROJECT.md phần "Phiên N" trước khi zip
cd ..
python3 -c "import shutil; shutil.make_archive('synthetic-qa-orchestrator-vN', 'zip', '.', 'synthetic-qa-orchestrator')"
```

### Bước 5 — Build binary (cần push lên GitHub)
```bash
git tag v1.0.N
git push origin v1.0.N
# → GitHub Actions tự chạy .github/workflows/build.yml
# → Ra file SyntheticAutomationStudio-Windows.zip / macOS / Linux
```

---

## 14. QUICK REFERENCE — LỖI THƯỜNG GẶP

| Lỗi | Nguyên nhân | Giải pháp |
|-----|------------|-----------|
| `ModuleNotFoundError: pywebview` | Chưa cài | `pip install pywebview` |
| `Namespace Gtk not available` | pystray cần Gtk3 | `sudo apt install libappindicator3-dev gir1.2-appindicator3-0.1` hoặc dùng `--no-gui` |
| `Executable doesn't exist at ...chromium` | Browser chưa cài | `python -m playwright install chromium` |
| `fakeredis` import lỗi | Chưa cài | `pip install fakeredis` |
| Dashboard trắng / JS lỗi | drawflow.min.js thiếu | Chạy script bundle hoặc copy từ static_assets/ |
| `fetch_one` không có trong Database | database.py thiếu method | Xem Mục 8 vấn đề #2 |
| PyWebView không mở | Không có DISPLAY | `export DISPLAY=:99` hoặc dùng `--no-gui` |
| Port 18080 bị chiếm | App đang chạy hoặc port bận | `python app_launcher.py --port 18081` |

---

## 15. TRẠNG THÁI BUILD

| Nền tảng | Build | Test |
|----------|-------|------|
| Windows (windows-latest) | ✅ Nuitka matrix | ⚠️ Chưa test binary cuối |
| macOS (macos-latest) | ✅ Nuitka matrix | ⚠️ Chưa test binary cuối |
| Linux (ubuntu-latest) | ✅ Nuitka matrix + webkit2gtk | ⚠️ Chưa test binary cuối |
| Chromium browser | ✅ v157.0.8103.78 | ✅ Live test OK (Phiên 14+15) |
| Firefox | ⚠️ Chưa cài (CDN block) | ❌ Chưa test |
| WebKit | ⚠️ Chưa cài (CDN block) | ❌ Chưa test |
| Server khởi động (`app_launcher.py --no-gui`) | — | ✅ **Live test OK Phiên 15** (trước đó crash) |
| Toàn bộ tab Capabilities (10 endpoints) | — | ✅ **10/10 PASS Phiên 15** (test qua HTTP thật, có network) |

---

## 16. SỐ LIỆU DỰ ÁN

| Metric | Giá trị |
|--------|---------|
| Tổng file Python | 42 (40 root + ui/__init__ + ui/desktop_window) |
| Tổng dòng code | 17,440+ |
| Số class | 83 |
| Số API routes | 80 |
| Số JS `api()` calls | 59 |
| Số tabs dashboard | 9 |
| Số phiên xây dựng | 17 |
| Supported OS | 3 (Win/macOS/Linux) |
| Browser engines | 3 (HTTP/2 + Playwright + Cloud CDP) |
| Phiên bắt đầu | Phiên 1 (nền tảng engine) |
| Phiên latest | Phiên 17 (Phiên này) - Master Unified Spec (Phase 12: Flow Studio + Command Center) |
| Lỗ hổng kiến trúc nghiêm trọng phát hiện Phiên 17 | 2 (desktop launcher chưa từng tạo Engine; 4/8 scenario demo sai schema khiến load_config() crash toàn bộ) - cả 2 đã sửa |
| Bugs fix Phiên 15 | 7 (xem Mục 8, #2, #5-10) — khởi động server + tab Capabilities |
| Bugs/mồ côi phát hiện & sửa Phiên 16 | 3 bug có từ trước (webdriver stealth thiếu, stealth args thiếu ở nhánh persistent-context, device_mix mồ côi) + 6 BaseModel lồng hàm tự gây ra rồi tự sửa (xem Mục 8ter) |
| Module mới Phiên 16 | 3 (`linux_display_manager.py`, `engine_updater.py`, `plugins/js_probes/`) |
