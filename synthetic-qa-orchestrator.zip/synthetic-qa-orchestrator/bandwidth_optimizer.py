"""Tối ưu băng thông: chặn tài nguyên nặng không phục vụ đo lường qua `page.route`
(Playwright dùng CDP Network domain bên dưới), và tự động đóng hộp thoại cookie (GDPR).

GIỚI HẠN ĐÃ BIẾT (xem PROJECT.md):
* Mặc định KHÔNG chặn ảnh: ảnh lớn nhất trên trang (LCP element) thường là một <img>,
  chặn ảnh sẽ làm sai lệch chỉ số LCP - đi ngược mục tiêu "không làm sai lệch kịch bản
  đo lường" của đặc tả. Chặn ảnh là tuỳ chọn tắt mặc định (`block_images`), có cảnh báo.
* "Tiết kiệm ~70% băng thông" là số liệu minh hoạ của đặc tả, không phải cam kết cố
  định. Mặc định module chỉ đếm SỐ LƯỢNG request bị chặn theo loại (rẻ, không thêm độ
  trễ). Bật `measure_bytes: true` để ước lượng SỐ BYTE thật đã tránh tải: trước khi
  `route.abort()`, gửi một request `HEAD` riêng (qua `httpx`, timeout ngắn) chỉ để đọc
  header `Content-Length` - KHÔNG tải phần thân. Đây vẫn là ƯỚC LƯỢNG, không phải số
  byte tuyệt đối chính xác, vì: (a) một số máy chủ không trả `Content-Length` ở HEAD
  (ví dụ nội dung "chunked") → bỏ qua, không cộng dồn; (b) HEAD có thể trả kích thước
  khác GET thực tế trong vài trường hợp hiếm; (c) bật tính năng này làm MỖI request bị
  chặn tốn thêm một vòng round-trip HEAD (độ trễ nhỏ, không tải lại qua gateway nếu
  kịch bản dùng proxy - xem tham số `gateway` của `apply()`).
* Tự động đóng hộp thoại cookie là suy đoán theo mẫu (selector của các CMP phổ biến +
  tìm nút theo từ khoá "Accept/Agree/Đồng ý"). Không đảm bảo bắt được mọi banner tuỳ
  biến riêng của từng trang.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional
from urllib.parse import urlsplit

LOGGER = logging.getLogger("qa.bandwidth")

# Loại tài nguyên mặc định bị chặn: không ảnh hưởng tới DOM/CWV, chỉ tốn băng thông.
DEFAULT_BLOCKED_TYPES = ("media",)  # video/audio. KHÔNG gồm 'image' hay 'font' mặc định.

# Vài tên miền quảng cáo/analytics phổ biến - danh sách rút gọn, không đầy đủ.
DEFAULT_BLOCKED_DOMAINS = (
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "google-analytics.com", "googletagmanager.com", "facebook.net",
    "hotjar.com", "criteo.com", "taboola.com", "outbrain.com", "scorecardresearch.com",
)

# Selector của các nền tảng quản lý sự đồng thuận (CMP) phổ biến.
_CMP_SELECTORS = (
    "#onetrust-accept-btn-handler",
    "#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll",
    "#didomi-notice-agree-button",
    ".qc-cmp2-summary-buttons button[mode='primary']",
    "button[data-testid='uc-accept-all-button']",
    ".fc-cta-consent",
    "#truste-consent-button",
)
_CONSENT_WORDS = (
    "accept all", "accept cookies", "i agree", "agree", "got it", "allow all",
    "đồng ý", "chấp nhận", "tôi đồng ý",
)


@dataclass
class BandwidthConfig:
    enabled: bool = True
    block_resource_types: tuple[str, ...] = DEFAULT_BLOCKED_TYPES
    block_domains: tuple[str, ...] = DEFAULT_BLOCKED_DOMAINS
    block_images: bool = False         # tắt mặc định: xem cảnh báo LCP ở docstring
    block_fonts: bool = False          # tắt mặc định: font có thể ảnh hưởng FCP
    auto_dismiss_consent: bool = True
    consent_timeout_ms: int = 2500
    measure_bytes: bool = False        # bật để ước lượng byte thật qua HEAD - xem docstring module
    measure_timeout_s: float = 2.0

    @classmethod
    def from_dict(cls, d: Optional[dict[str, Any]]) -> "BandwidthConfig":
        d = dict(d or {})
        if "block_resource_types" in d:
            d["block_resource_types"] = tuple(d["block_resource_types"])
        if "block_domains" in d:
            d["block_domains"] = tuple(d["block_domains"])
        known = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in known})


@dataclass
class BandwidthStats:
    blocked_by_type: dict[str, int] = field(default_factory=dict)
    blocked_by_domain: int = 0
    allowed: int = 0
    consent_dismissed: bool = False
    consent_selector: Optional[str] = None
    estimated_bytes_saved: int = 0     # chỉ khớp khi measure_bytes=true, xem docstring module
    bytes_unknown: int = 0             # số request bị chặn mà không đo được Content-Length

    @property
    def total_blocked(self) -> int:
        return sum(self.blocked_by_type.values()) + self.blocked_by_domain

    def as_dict(self) -> dict[str, Any]:
        return {"blocked_by_type": dict(self.blocked_by_type), "blocked_by_domain": self.blocked_by_domain,
                "total_blocked": self.total_blocked, "allowed": self.allowed,
                "consent_dismissed": self.consent_dismissed, "consent_selector": self.consent_selector,
                "estimated_bytes_saved": self.estimated_bytes_saved, "bytes_unknown": self.bytes_unknown}


class BandwidthOptimizer:
    def __init__(self, cfg: BandwidthConfig, proxy_url: Optional[str] = None) -> None:
        self.cfg = cfg
        self.stats = BandwidthStats()
        self._proxy_url = proxy_url   # HEAD đo bytes đi qua CÙNG gateway nếu kịch bản có cấu hình

    async def _measure_head(self, url: str) -> None:
        try:
            import httpx

            async with httpx.AsyncClient(proxy=self._proxy_url, timeout=self.cfg.measure_timeout_s,
                                         follow_redirects=True) as client:
                resp = await client.head(url)
            size = resp.headers.get("content-length")
            if size is not None:
                self.stats.estimated_bytes_saved += int(size)
            else:
                self.stats.bytes_unknown += 1
        except Exception:  # noqa: BLE001 - đo lường là phần bổ sung, lỗi không được chặn request chính
            self.stats.bytes_unknown += 1

    async def apply(self, context: Any) -> None:
        """Đăng ký bộ lọc request cho mọi trang mở trong context này."""
        if not self.cfg.enabled:
            return
        blocked_types = set(self.cfg.block_resource_types)
        if self.cfg.block_images:
            blocked_types.add("image")
        if self.cfg.block_fonts:
            blocked_types.add("font")

        async def handler(route: Any) -> None:
            req = route.request
            rtype = req.resource_type
            host = urlsplit(req.url).hostname or ""
            blocked = rtype in blocked_types or any(dom in host for dom in self.cfg.block_domains)
            if blocked:
                if rtype in blocked_types:
                    self.stats.blocked_by_type[rtype] = self.stats.blocked_by_type.get(rtype, 0) + 1
                else:
                    self.stats.blocked_by_domain += 1
                if self.cfg.measure_bytes:
                    await self._measure_head(req.url)   # chờ trước khi abort - xem giới hạn độ trễ ở docstring
                await route.abort()
                return
            self.stats.allowed += 1
            await route.continue_()

        await context.route("**/*", handler)

    async def dismiss_consent(self, page: Any) -> bool:
        """Thử đóng hộp thoại cookie bằng selector CMP đã biết, rồi tới tìm nút theo từ khoá.
        Trả về True nếu đã bấm được một nút; không ném lỗi nếu không tìm thấy gì."""
        if not self.cfg.auto_dismiss_consent:
            return False
        timeout = self.cfg.consent_timeout_ms
        for selector in _CMP_SELECTORS:
            try:
                loc = page.locator(selector).first
                await loc.wait_for(state="visible", timeout=timeout // len(_CMP_SELECTORS) or 200)
                await loc.click(timeout=800)
                self.stats.consent_dismissed, self.stats.consent_selector = True, selector
                LOGGER.info("Đã đóng hộp thoại cookie qua selector CMP: %s", selector)
                return True
            except Exception:  # noqa: BLE001 - không thấy selector này, thử cái tiếp
                continue
        try:
            candidates = page.get_by_role("button").filter(has_text=_regex_any(_CONSENT_WORDS))
            await candidates.first.wait_for(state="visible", timeout=500)
            await candidates.first.click(timeout=800)
            self.stats.consent_dismissed, self.stats.consent_selector = True, "text-match"
            LOGGER.info("Đã đóng hộp thoại cookie qua tìm nút theo từ khoá")
            return True
        except Exception:  # noqa: BLE001 - không có hộp thoại cookie, hoặc không khớp mẫu
            return False


def _regex_any(words: tuple[str, ...]) -> "re.Pattern[str]":
    import re

    return re.compile("|".join(re.escape(w) for w in words), re.IGNORECASE)
