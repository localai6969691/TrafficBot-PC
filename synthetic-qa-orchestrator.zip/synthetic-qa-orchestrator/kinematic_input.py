"""Bộ Mô Phỏng Tương Tác Sinh Trắc Học Vi Mô (Micro-Kinematic Input Simulator).

Ba thành phần:
  1. BezierMouse       - di chuyển chuột theo đường cong Cubic Bezier với gia/giảm tốc
  2. KeystrokeDynamics - mô phỏng Dwell Time và Flight Time tự nhiên
  3. InertialScroll    - cuộn trang theo vật lý bánh xe chuột có quán tính

Tất cả đều dùng Playwright Mouse/Keyboard API và asyncio.sleep để mô phỏng
thời gian thực, không gửi input nhanh hơn 60fps (16ms per step).

GIỚI HẠN ĐÃ BIẾT:
  - Bezier path được tính trong Python rồi gửi từng bước qua Playwright mouse.move().
    Có thể tạo ra nhiều CDP roundtrips hơn so với native input. Mỗi bước ~16ms.
  - Trên headless browser, mousemove events được tạo ra nhưng không có GPU rendering
    nên timing có thể không hoàn toàn giống browser thật. Dùng headful để kiểm tra
    các hệ thống behavioral analytics chính xác nhất.
  - KeystrokeDynamics dùng phân phối Log-Normal để mô phỏng flight time (khoảng cách
    giữa các phím). Người dùng thật gõ nhanh hơn trên bigrams thường gặp (th, er, in)
    — module này không mô phỏng bigram-aware timing (cần corpus data).
  - InertialScroll gửi nhiều wheel events nhỏ liên tiếp. Một số trang có debounce
    scroll handler sẽ không nhận tất cả events — đây là behavior thật của browser,
    không phải lỗi implementation.
"""
from __future__ import annotations

import asyncio
import math
import random
from dataclasses import dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# 1. Bezier Mouse
# ---------------------------------------------------------------------------

@dataclass
class MouseProfile:
    """Thông số vận tốc chuột của người dùng."""
    base_speed_px_per_s: float = 800.0    # tốc độ trung bình (px/s)
    overshoot_prob: float = 0.15           # xác suất vượt mục tiêu rồi điều chỉnh lại
    jitter_sigma_px: float = 1.5          # nhiễu vi mô tay run (σ pixels)
    steps_per_100px: int = 8              # số bước cho mỗi 100px khoảng cách
    min_steps: int = 5


def _cubic_bezier_points(
    x0: float, y0: float,
    x3: float, y3: float,
    n: int,
    rng: random.Random,
) -> list[tuple[float, float]]:
    """Tạo n điểm trên đường cong Cubic Bezier từ (x0,y0) đến (x3,y3).

    Hai điểm kiểm soát (x1,y1), (x2,y2) được chọn ngẫu nhiên có định hướng
    để tạo ra đường cong tự nhiên (không thẳng, không loạn).
    """
    dx = x3 - x0
    dy = y3 - y0
    dist = math.hypot(dx, dy)

    # Control points: lệch ±30% theo chiều vuông góc
    perp_x = -dy / (dist + 1e-9)
    perp_y = dx / (dist + 1e-9)
    jitter1 = rng.gauss(0, dist * 0.2)
    jitter2 = rng.gauss(0, dist * 0.2)

    x1 = x0 + dx * 0.3 + perp_x * jitter1
    y1 = y0 + dy * 0.3 + perp_y * jitter1
    x2 = x0 + dx * 0.7 + perp_x * jitter2
    y2 = y0 + dy * 0.7 + perp_y * jitter2

    points: list[tuple[float, float]] = []
    for i in range(n + 1):
        t = i / n
        mt = 1 - t
        # B(t) = mt³P0 + 3mt²tP1 + 3mt²P2 + t³P3
        bx = mt**3*x0 + 3*mt**2*t*x1 + 3*mt*t**2*x2 + t**3*x3
        by = mt**3*y0 + 3*mt**2*t*y1 + 3*mt*t**2*y2 + t**3*y3
        points.append((bx, by))
    return points


def _ease_in_out(t: float) -> float:
    """Hàm easing: gia tốc đầu, giảm tốc cuối."""
    return t * t * (3 - 2 * t)


class BezierMouse:
    """Di chuyển và click chuột theo đường cong Bezier tự nhiên."""

    def __init__(self, page: Any, profile: Optional[MouseProfile] = None,
                 seed: Optional[int] = None) -> None:
        self.page = page
        self.profile = profile or MouseProfile()
        self._rng = random.Random(seed)
        self._current: tuple[float, float] = (0.0, 0.0)

    async def move_to(self, x: float, y: float) -> None:
        """Di chuyển chuột từ vị trí hiện tại đến (x, y) theo đường Bezier."""
        x0, y0 = self._current
        dist = math.hypot(x - x0, y - y0)
        if dist < 2:
            return

        # Tính số bước dựa trên khoảng cách
        n = max(
            self.profile.min_steps,
            int(dist / 100 * self.profile.steps_per_100px),
        )

        # Overshoot: đi xa hơn rồi quay lại
        target_x, target_y = x, y
        if self._rng.random() < self.profile.overshoot_prob:
            overshoot = dist * self._rng.uniform(0.03, 0.08)
            angle = math.atan2(y - y0, x - x0)
            target_x = x + math.cos(angle) * overshoot
            target_y = y + math.sin(angle) * overshoot

        points = _cubic_bezier_points(x0, y0, target_x, target_y, n, self._rng)

        # Tính tổng thời gian di chuyển (giây)
        total_time = dist / self.profile.base_speed_px_per_s
        total_time *= self._rng.uniform(0.8, 1.2)  # biến thiên tự nhiên

        step_time = total_time / n

        for i, (px, py) in enumerate(points[1:], 1):
            # Easing: nhanh ở giữa, chậm đầu và cuối
            t = i / n
            eased = _ease_in_out(t)
            # Jitter vi mô
            jx = px + self._rng.gauss(0, self.profile.jitter_sigma_px)
            jy = py + self._rng.gauss(0, self.profile.jitter_sigma_px)
            await self.page.mouse.move(jx, jy)
            await asyncio.sleep(step_time * max(0.3, 1 - abs(eased - 0.5) * 1.5))

        # Điều chỉnh về đích thật nếu có overshoot
        if (target_x, target_y) != (x, y):
            corr_points = _cubic_bezier_points(target_x, target_y, x, y,
                                               max(3, n // 3), self._rng)
            for px, py in corr_points[1:]:
                await self.page.mouse.move(px, py)
                await asyncio.sleep(step_time * 0.5)

        self._current = (x, y)

    async def click(self, x: float, y: float,
                    button: str = "left", delay_ms: Optional[float] = None) -> None:
        """Di chuyển đến (x,y) rồi click với delay tự nhiên giữa mousedown/up."""
        await self.move_to(x, y)
        # Dừng vi mô trước khi click (1-3 frames)
        await asyncio.sleep(self._rng.uniform(0.016, 0.050))
        hold_ms = delay_ms if delay_ms is not None else self._rng.gauss(80, 20)
        hold_ms = max(30, hold_ms)
        await self.page.mouse.down(button=button)
        await asyncio.sleep(hold_ms / 1000)
        await self.page.mouse.up(button=button)

    async def double_click(self, x: float, y: float) -> None:
        await self.move_to(x, y)
        await asyncio.sleep(self._rng.uniform(0.016, 0.040))
        await self.page.mouse.dblclick(x, y)

    async def drag_to(self, x0: float, y0: float, x1: float, y1: float) -> None:
        await self.move_to(x0, y0)
        await asyncio.sleep(self._rng.uniform(0.05, 0.15))
        await self.page.mouse.down()
        await self.move_to(x1, y1)
        await asyncio.sleep(self._rng.uniform(0.03, 0.08))
        await self.page.mouse.up()


# ---------------------------------------------------------------------------
# 2. Keystroke Dynamics
# ---------------------------------------------------------------------------

@dataclass
class KeyboardProfile:
    """Thông số nhịp gõ phím tự nhiên."""
    # Dwell time: thời gian giữ phím (ms) — Log-Normal(μ, σ)
    dwell_mean_ms: float = 80.0
    dwell_sigma_ms: float = 20.0
    # Flight time: khoảng nghỉ giữa 2 phím (ms) — Log-Normal
    flight_mean_ms: float = 120.0
    flight_sigma_ms: float = 40.0
    # Phím đặc biệt chậm hơn (tỷ lệ nhân)
    special_key_factor: float = 1.5
    # Xác suất sai và sửa
    typo_probability: float = 0.015


_SPECIAL_KEYS = {
    "Shift", "Control", "Alt", "Meta", "Tab", "Enter", "Backspace",
    "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Escape",
    "CapsLock", "Delete", "Home", "End", "PageUp", "PageDown",
}

_COMMON_TYPOS: dict[str, str] = {
    "a": "s", "s": "a", "e": "r", "r": "e", "t": "y", "y": "t",
    "u": "i", "i": "u", "o": "p", "p": "o", "n": "m", "m": "n",
}


class KeystrokeDynamics:
    """Mô phỏng nhịp gõ phím tự nhiên với Dwell Time và Flight Time."""

    def __init__(self, page: Any, profile: Optional[KeyboardProfile] = None,
                 seed: Optional[int] = None) -> None:
        self.page = page
        self.profile = profile or KeyboardProfile()
        self._rng = random.Random(seed)

    def _dwell_ms(self, key: str) -> float:
        """Thời gian giữ phím (ms)."""
        base = max(30, self._rng.lognormvariate(
            math.log(self.profile.dwell_mean_ms),
            math.log(1 + self.profile.dwell_sigma_ms / self.profile.dwell_mean_ms),
        ))
        if key in _SPECIAL_KEYS:
            base *= self.profile.special_key_factor
        return base

    def _flight_ms(self) -> float:
        """Khoảng nghỉ giữa 2 phím (ms)."""
        return max(20, self._rng.lognormvariate(
            math.log(self.profile.flight_mean_ms),
            math.log(1 + self.profile.flight_sigma_ms / self.profile.flight_mean_ms),
        ))

    async def press_key(self, key: str) -> None:
        """Nhấn một phím với dwell time tự nhiên."""
        await self.page.keyboard.down(key)
        await asyncio.sleep(self._dwell_ms(key) / 1000)
        await self.page.keyboard.up(key)

    async def type_text(self, text: str, selector: Optional[str] = None) -> None:
        """Gõ chuỗi text với nhịp tự nhiên, tùy chọn focus selector trước."""
        if selector:
            await self.page.locator(selector).first.click()
            await asyncio.sleep(self._rng.uniform(0.1, 0.25))

        for i, char in enumerate(text):
            # Typo simulation
            if (char.isalpha() and
                    self._rng.random() < self.profile.typo_probability and
                    char.lower() in _COMMON_TYPOS):
                wrong = _COMMON_TYPOS[char.lower()]
                if char.isupper():
                    wrong = wrong.upper()
                # Gõ sai
                await self._type_char(wrong)
                await asyncio.sleep(self._rng.uniform(0.1, 0.3))
                # Xóa và gõ lại
                await self.press_key("Backspace")
                await asyncio.sleep(self._rng.uniform(0.05, 0.15))

            await self._type_char(char)

            # Flight time giữa các ký tự
            if i < len(text) - 1:
                await asyncio.sleep(self._flight_ms() / 1000)

    async def _type_char(self, char: str) -> None:
        """Gõ một ký tự đơn với dwell time."""
        if char == "\n":
            await self.press_key("Enter")
        elif char == "\t":
            await self.press_key("Tab")
        else:
            dwell = self._dwell_ms(char)
            await self.page.keyboard.down(char)
            await asyncio.sleep(dwell / 1000)
            await self.page.keyboard.up(char)

    async def fill_form_field(self, selector: str, value: str,
                               clear_first: bool = True) -> None:
        """Điền form field với nhịp gõ tự nhiên."""
        loc = self.page.locator(selector).first
        await loc.click()
        await asyncio.sleep(self._rng.uniform(0.1, 0.2))
        if clear_first:
            await self.page.keyboard.press("Control+a")
            await asyncio.sleep(0.05)
            await self.page.keyboard.press("Delete")
            await asyncio.sleep(self._rng.uniform(0.05, 0.15))
        await self.type_text(value)


# ---------------------------------------------------------------------------
# 3. Inertial Scroll
# ---------------------------------------------------------------------------

@dataclass
class ScrollProfile:
    """Thông số vật lý cuộn trang."""
    wheel_delta_px: float = 120.0        # px mỗi tick bánh xe (chuẩn Windows)
    ticks_per_gesture: tuple[int,int] = (3, 8)  # số tick trong một cử chỉ cuộn
    tick_interval_ms: float = 50.0       # khoảng giữa các tick (ms)
    inertia_factor: float = 0.85         # hệ số quán tính (0.0 = ngay dừng, 1.0 = không dừng)
    read_pause_prob: float = 0.25        # xác suất dừng đọc nội dung giữa chừng
    read_pause_ms: tuple[float,float] = (500, 2000)  # thời gian dừng đọc (ms)


class InertialScroll:
    """Cuộn trang với vật lý bánh xe chuột và quán tính giảm dần."""

    def __init__(self, page: Any, profile: Optional[ScrollProfile] = None,
                 seed: Optional[int] = None) -> None:
        self.page = page
        self.profile = profile or ScrollProfile()
        self._rng = random.Random(seed)

    async def scroll_by(self, delta_y: float, x: float = 0, y: float = 0) -> None:
        """Cuộn một lượng delta_y pixels với quán tính tự nhiên."""
        if abs(delta_y) < 1:
            return
        direction = 1 if delta_y > 0 else -1
        remaining = abs(delta_y)
        tick = self.profile.wheel_delta_px
        velocity = tick

        while remaining > 1:
            step = min(velocity, remaining)
            await self.page.mouse.wheel(0, direction * step)
            remaining -= step
            velocity *= self.profile.inertia_factor
            await asyncio.sleep(self.profile.tick_interval_ms / 1000)
            if velocity < 10:
                break

    async def scroll_to(self, target_y: float, smooth: bool = True) -> None:
        """Cuộn đến vị trí tuyệt đối target_y."""
        current = await self.page.evaluate("() => window.scrollY")
        delta = target_y - current
        if smooth:
            await self.scroll_gesture(delta)
        else:
            await self.page.evaluate(f"window.scrollTo(0, {target_y})")

    async def scroll_gesture(self, total_delta: float) -> None:
        """Mô phỏng cử chỉ cuộn hoàn chỉnh: nhiều tick + quán tính + dừng đọc."""
        direction = 1 if total_delta > 0 else -1
        abs_delta = abs(total_delta)
        ticks = self._rng.randint(*self.profile.ticks_per_gesture)
        per_tick = abs_delta / ticks
        velocity = per_tick

        for _ in range(ticks):
            # Phân tán delta trong một tick thành nhiều wheel events nhỏ
            n_sub = self._rng.randint(1, 3)
            for j in range(n_sub):
                sub = velocity * direction / n_sub
                await self.page.mouse.wheel(0, sub)
                await asyncio.sleep(self._rng.uniform(8, 20) / 1000)

            # Quán tính giảm dần
            velocity *= self.profile.inertia_factor * self._rng.uniform(0.9, 1.1)
            await asyncio.sleep(self.profile.tick_interval_ms / 1000
                                * self._rng.uniform(0.8, 1.3))

            # Dừng đọc ngẫu nhiên
            if self._rng.random() < self.profile.read_pause_prob:
                pause_ms = self._rng.uniform(*self.profile.read_pause_ms)
                await asyncio.sleep(pause_ms / 1000)

    async def scroll_page_gradually(
        self,
        total_px: Optional[float] = None,
        direction: str = "down",
    ) -> None:
        """Cuộn toàn bộ trang từ từ, dừng đọc nội dung tự nhiên."""
        if total_px is None:
            total_px = await self.page.evaluate(
                "() => document.documentElement.scrollHeight - window.innerHeight"
            )
        sign = 1 if direction == "down" else -1
        scrolled = 0.0
        while scrolled < total_px:
            chunk = self._rng.uniform(200, 600)
            await self.scroll_gesture(sign * min(chunk, total_px - scrolled))
            scrolled += chunk
            if self._rng.random() < 0.3:
                await asyncio.sleep(self._rng.uniform(0.5, 2.0))


# ---------------------------------------------------------------------------
# KinematicSuite: facade tổng hợp
# ---------------------------------------------------------------------------

class KinematicSuite:
    """Facade tổng hợp BezierMouse + KeystrokeDynamics + InertialScroll."""

    def __init__(self, page: Any, seed: Optional[int] = None,
                 mouse_profile: Optional[MouseProfile] = None,
                 keyboard_profile: Optional[KeyboardProfile] = None,
                 scroll_profile: Optional[ScrollProfile] = None) -> None:
        self.mouse = BezierMouse(page, mouse_profile, seed)
        self.keyboard = KeystrokeDynamics(page, keyboard_profile, seed)
        self.scroll = InertialScroll(page, scroll_profile, seed)
        self.page = page

    async def human_click(self, selector: str) -> None:
        """Click vào selector như người thật: di chuột Bezier → click."""
        box = await self.page.locator(selector).first.bounding_box()
        if not box:
            await self.page.locator(selector).first.click()
            return
        cx = box["x"] + box["width"] / 2 + random.gauss(0, 2)
        cy = box["y"] + box["height"] / 2 + random.gauss(0, 2)
        await self.mouse.click(cx, cy)

    async def human_type(self, selector: str, text: str) -> None:
        await self.human_click(selector)
        await self.keyboard.type_text(text)

    async def human_scroll_down(self, px: float = 500) -> None:
        await self.scroll.scroll_gesture(px)
