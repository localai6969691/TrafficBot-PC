"""Báo cáo hiệu năng: p50/p95/p99, xuất HTML / CSV / JSON.

Phase 10.5 bổ sung `attach_analytics_listener()`: trình lắng nghe mạng
(Network Request Interceptor) xác thực các gói tin ghi nhận phân tích
(Google Analytics 4, Universal Analytics, Meta/TikTok Pixel...) thật sự
được gửi đi và server đã phản hồi thành công, trước khi báo cáo đánh dấu
lượt chạy là VERIFIED_SUCCESS.
"""
from __future__ import annotations

import csv
import html
import io
import json
import logging
import math
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Optional

LOGGER = logging.getLogger("qa.reporting")
METRICS = ("ttfb_ms", "fcp_ms", "lcp_ms", "load_ms")


def percentile(values: list[float], p: float) -> Optional[float]:
    """Nội suy tuyến tính giữa các hạng liền kề."""
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * p / 100
    lo, hi = math.floor(k), math.ceil(k)
    return s[lo] if lo == hi else s[lo] + (s[hi] - s[lo]) * (k - lo)


def build_report(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for r in rows:
        groups.setdefault((r["scenario_id"], r["url"]), []).append(r)

    items = []
    for (sid, url), rs in groups.items():
        item: dict[str, Any] = {
            "scenario_id": sid, "url": url, "runs": len(rs),
            "ok": sum(r["status"] == "ok" for r in rs),
            "failed": sum(r["status"] == "failed" for r in rs),
            "skipped": sum(r["status"] == "skipped" for r in rs),
        }
        # Phase 10.5: tỉ lệ lượt chạy xác thực được Analytics (chỉ tính trên
        # các lượt có bật tính năng này, bỏ qua None = chưa bật).
        checked = [r for r in rs if r.get("analytics_verified") is not None]
        if checked:
            verified = sum(r["analytics_verified"] == "VERIFIED_SUCCESS" for r in checked)
            item["analytics_verified_pct"] = round(100 * verified / len(checked), 1)
        else:
            item["analytics_verified_pct"] = None
        for m in METRICS:
            vals = [r[m] for r in rs if r.get(m) is not None]
            for p in (50, 95, 99):
                v = percentile(vals, p)
                item[f"{m[:-3]}_p{p}"] = round(v, 1) if v is not None else None
        items.append(item)
    total = sum(i["runs"] for i in items)
    return {"generated_at": datetime.now().isoformat(timespec="seconds"),
            "total_runs": total, "ok": sum(i["ok"] for i in items),
            "failed": sum(i["failed"] for i in items), "items": items}


def to_json(report: dict[str, Any]) -> str:
    return json.dumps(report, ensure_ascii=False, indent=2)


def to_csv(report: dict[str, Any]) -> str:
    buf = io.StringIO()
    if report["items"]:
        w = csv.DictWriter(buf, fieldnames=list(report["items"][0].keys()))
        w.writeheader()
        w.writerows(report["items"])
    return buf.getvalue()


def to_html(report: dict[str, Any]) -> str:
    items = report["items"]
    cols = list(items[0].keys()) if items else []
    head = "".join(f"<th>{html.escape(c)}</th>" for c in cols)
    body = "".join(
        "<tr>" + "".join(f"<td>{html.escape('' if i[c] is None else str(i[c]))}</td>" for c in cols) + "</tr>"
        for i in items)
    return f"""<!doctype html><html lang="vi"><meta charset="utf-8">
<title>Báo cáo QA</title>
<style>
:root{{color-scheme:light dark;font:14px system-ui,sans-serif}}
body{{margin:2rem}} table{{border-collapse:collapse;display:block;overflow-x:auto}}
th,td{{padding:.4rem .7rem;border-bottom:1px solid #8884;text-align:right;white-space:nowrap}}
th:nth-child(-n+2),td:nth-child(-n+2){{text-align:left}}
</style>
<h1>Báo cáo kiểm thử</h1>
<p>Tạo lúc {html.escape(report['generated_at'])} · {report['total_runs']} lượt ·
{report['ok']} thành công · {report['failed']} lỗi. Đơn vị thời gian: ms.</p>
<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></html>"""


# ---------------------------------------------------------------------------
# Phase 10.5: Analytics Telemetry Verification (Network Request Interceptor)
# ---------------------------------------------------------------------------

# Mẫu URL các endpoint thu thập số liệu phổ biến - chỉ cần khớp 1 trong số này
# VÀ nhận HTTP 200/204 thì coi là "gói tin ghi nhận đã được xác nhận gửi đi".
_ANALYTICS_URL_MARKERS = (
    "/g/collect",            # Google Analytics 4 (gtag.js)
    "google-analytics.com/collect",   # Universal Analytics (ga.js cũ)
    "/j/collect",            # Universal Analytics biến thể
    "facebook.com/tr",       # Meta/Facebook Pixel
    "analytics.tiktok.com",  # TikTok Pixel
    "px.ads.linkedin.com",   # LinkedIn Insight Tag
    "/collect?",             # mẫu chung nhiều nền tảng đo lường tự xây
)

_ANALYTICS_OK_STATUSES = (200, 204)


def attach_analytics_listener(page: Any, state: dict[str, Any]) -> None:
    """Gắn trình lắng nghe response lên `page` (Playwright) để xác thực các
    gói tin ghi nhận Analytics thật sự được gửi đi và server phản hồi thành công.

    Mục 2.5 đặc tả Phase 10: "Một lượt chạy chỉ được đánh dấu VERIFIED_SUCCESS
    khi hệ thống xác nhận gói tin ghi nhận dữ liệu đã được gửi đi và nhận phản
    hồi HTTP 200/204 thành công."

    Args:
        page: Playwright Page instance (đã mở, trước khi điều hướng tới URL kịch bản).
        state: dict dùng chung để ghi kết quả ngược ra ngoài closure (vì Playwright
               event handler không trả giá trị được) - engine.py đọc lại sau khi
               `_run_steps` chạy xong. Cấu trúc:
               {"verified": bool, "hits": int, "matched_urls": list[str]}

    An toàn: handler bọc try/except toàn bộ - lỗi đọc response (vd. response đã
    bị huỷ do điều hướng) không được phép làm vỡ luồng chạy chính.
    """
    state.setdefault("verified", False)
    state.setdefault("hits", 0)
    state.setdefault("matched_urls", [])

    def _on_response(response: Any) -> None:
        try:
            url = response.url
            if not any(marker in url for marker in _ANALYTICS_URL_MARKERS):
                return
            status = response.status
            if status in _ANALYTICS_OK_STATUSES:
                state["verified"] = True
                state["hits"] += 1
                if len(state["matched_urls"]) < 10:
                    state["matched_urls"].append(f"{status} {url[:150]}")
                LOGGER.debug("analytics_verify: khớp %s -> HTTP %s", url[:100], status)
            else:
                LOGGER.debug("analytics_verify: khớp %s nhưng HTTP %s (không tính)", url[:100], status)
        except Exception as exc:  # noqa: BLE001
            LOGGER.debug("analytics_verify: lỗi đọc response (bỏ qua): %s", exc)

    try:
        page.on("response", _on_response)
    except Exception as exc:  # noqa: BLE001
        LOGGER.warning("attach_analytics_listener: không gắn được listener: %s", exc)


def write_reports(report: dict[str, Any], out_dir: Path, formats: Iterable[str] = ("html", "csv", "json")) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    renderers = {"html": to_html, "csv": to_csv, "json": to_json}
    written = []
    for fmt in formats:
        path = out_dir / f"report_{stamp}.{fmt}"
        path.write_text(renderers[fmt](report), encoding="utf-8")
        written.append(path)
    return written
