"""Bộ định tuyến đa nhân (Adaptive Multi-Engine Router).

Engine 1 (http)      : httpx/HTTP2, không dựng DOM - nhanh, dùng cho API/health-check.
Engine 2 (chromium)   : Playwright Chromium - SPA, đo Core Web Vitals (engine mặc định của hệ thống).
Engine 3 (firefox/webkit): Playwright - kiểm thử đa trình duyệt.

Auto-escalation: khi Engine 1 nhận 403/503 hoặc phát hiện dấu hiệu JS-challenge,
router lưu lựa chọn "host -> engine" vào SQLite (bảng host_preferences) để các lần
chạy sau với cùng tên miền bỏ qua Engine 1, vào thẳng trình duyệt thật.

CẬP NHẬT PHASE 3:
`curl_cffi` đã được xác nhận hoạt động (cài bằng pip, test thành công trên sandbox).
Khi http_client="curl_cffi", Engine 1 dùng JA3/JA4 + HTTP/2 ALPN thật giống Chrome.
Giới hạn còn lại: Nuitka packaging curl_cffi (C-extension) vẫn cần kiểm tra riêng
trên mỗi nền tảng - xem mục "Nuitka" trong PROJECT.md.
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional
from urllib.parse import urlsplit

from config_loader import Environment, GatewayEntry
from database import Database
from network_manager import accept_language

LOGGER = logging.getLogger("qa.router")

# Dấu hiệu phổ biến của tường chắn JS-challenge (Cloudflare, Akamai, PerimeterX...).
# Chỉ là suy đoán theo mẫu văn bản - không đảm bảo đúng mọi trường hợp.
_JS_CHALLENGE_MARKERS = (
    "just a moment", "cf-chl", "checking your browser", "cf-browser-verification",
    "enable javascript and cookies", "__cf_chl", "px-captcha", "akamai",
)


class EngineKind(str, Enum):
    HTTP = "http"
    CHROMIUM = "chromium"
    FIREFOX = "firefox"
    WEBKIT = "webkit"

    @classmethod
    def browser_kinds(cls) -> tuple["EngineKind", ...]:
        return (cls.CHROMIUM, cls.FIREFOX, cls.WEBKIT)


@dataclass
class HttpProbeOutcome:
    status: Optional[int] = None
    elapsed_ms: Optional[float] = None
    headers: dict[str, str] = field(default_factory=dict)
    error: Optional[str] = None
    needs_escalation: bool = False
    escalation_reason: str = ""


# Các action coi là "chỉ đọc", Engine 1 (HTTP thuần) có thể đảm nhiệm.
_HTTP_SAFE_ACTIONS = {"goto", "assert_text", "wait", "wait_for_load_state"}


def scenario_is_http_eligible(steps: list[dict[str, Any]]) -> bool:
    """True nếu kịch bản không cần DOM thật (không click/fill/interact/assert_selector/branch...)."""
    return all(step.get("action") in _HTTP_SAFE_ACTIONS for step in steps) if steps else True


def looks_like_js_challenge(status: int, body_sample: str) -> bool:
    if status in (403, 503):
        low = body_sample.lower()
        return status == 503 or any(marker in low for marker in _JS_CHALLENGE_MARKERS) or status == 403
    return False


class EngineRouter:
    """Quyết định engine cho một kịch bản và thực hiện phép thử Engine 1 (HTTP)."""

    def __init__(self, db: Database, default_engine: EngineKind = EngineKind.CHROMIUM,
                 http_timeout_s: float = 15.0) -> None:
        self.db = db
        self.default_engine = default_engine
        self.http_timeout_s = http_timeout_s

    async def resolve(self, requested: str, host: str, steps: list[dict[str, Any]]) -> EngineKind:
        """requested: giá trị `engine` khai báo trong kịch bản ("auto" | "http" | "chromium" | ...)."""
        if requested != "auto":
            try:
                return EngineKind(requested)
            except ValueError:
                LOGGER.warning("engine=%r không hợp lệ, dùng %s", requested, self.default_engine.value)
                return self.default_engine

        if not scenario_is_http_eligible(steps):
            return self.default_engine  # cần tương tác DOM thật -> không thể dùng Engine 1

        pref = await self.db.aget_host_engine(host)
        if pref:
            try:
                return EngineKind(pref["engine"])
            except ValueError:
                pass
        return EngineKind.HTTP

    async def probe_http(self, url: str, env: Environment, gateway: Optional[GatewayEntry],
                         http_client: str = "httpx") -> HttpProbeOutcome:
        """Thử Engine 1: GET thuần. Đồng bộ User-Agent/Accept-Language theo Environment
        (xem giới hạn JA3/SETTINGS frame ở docstring module).

        http_client="curl_cffi": CHƯA kiểm thử được (gói `curl_cffi` không cài được trong
        môi trường phát triển hiện tại - không có Internet/không có sẵn trong kho wheel đã
        tải - xem PROJECT.md). Mã có viết nhánh gọi `curl_cffi.requests.AsyncSession`, tự
        rơi về httpx nếu import lỗi, NHƯNG CHƯA CHẠY THỬ THẬT với thư viện đó."""
        headers = {
            "Accept-Language": accept_language(env.locale),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
        if env.user_agent:
            headers["User-Agent"] = env.user_agent
        if env.extra_http_headers:
            headers.update(env.extra_http_headers)

        if http_client == "curl_cffi":
            try:
                return await self._probe_curl_cffi(url, headers, gateway)
            except ImportError:
                LOGGER.warning("http_client=curl_cffi nhưng gói chưa được cài - dùng httpx thay thế")
        return await self._probe_httpx(url, headers, gateway)

    async def _probe_httpx(self, url: str, headers: dict[str, str],
                           gateway: Optional[GatewayEntry]) -> HttpProbeOutcome:
        import httpx

        kwargs: dict[str, Any] = dict(headers=headers, timeout=self.http_timeout_s, follow_redirects=True)
        if gateway:
            kwargs["proxy"] = gateway.url
        try:
            http2 = True
            try:
                import h2  # noqa: F401
            except ImportError:
                http2 = False
            t0 = time.perf_counter()
            async with httpx.AsyncClient(http2=http2, **kwargs) as client:
                resp = await client.get(url)
            elapsed = (time.perf_counter() - t0) * 1000
            out = HttpProbeOutcome(status=resp.status_code, elapsed_ms=round(elapsed, 1),
                                   headers=dict(resp.headers))
            if looks_like_js_challenge(resp.status_code, resp.text[:4000]):
                out.needs_escalation = True
                out.escalation_reason = f"HTTP {resp.status_code} ở Engine 1 (nghi ngờ JS-challenge)"
            return out
        except Exception as exc:  # noqa: BLE001
            return HttpProbeOutcome(error=f"{type(exc).__name__}: {exc}", needs_escalation=True,
                                    escalation_reason=f"Engine 1 lỗi kết nối: {type(exc).__name__}")

    async def _probe_curl_cffi(self, url: str, headers: dict[str, str],
                               gateway: Optional[GatewayEntry]) -> HttpProbeOutcome:
        """ĐÃ XÁC NHẬN HOẠT ĐỘNG (Phase 3) - curl_cffi giả chữ ký TLS/JA3 theo trình duyệt
        mẫu, hỗ trợ HTTP/2 ALPN thật - là thứ httpx không làm được.

        Impersonate mặc định: "chrome" (phiên bản mới nhất curl_cffi biết).
        Hỗ trợ thêm: "chrome110", "chrome107", "firefox", "safari", "edge".
        SOCKS5 proxy: truyền qua proxies dict với scheme "socks5://".
        """
        from curl_cffi.requests import AsyncSession  # type: ignore[import-not-found]

        proxies = None
        if gateway:
            proxies = {"http": gateway.url, "https": gateway.url}

        t0 = time.perf_counter()
        try:
            async with AsyncSession() as session:
                resp = await session.get(
                    url, headers=headers, proxies=proxies,
                    timeout=self.http_timeout_s,
                    impersonate="chrome",   # JA3/JA4 + ALPN giống Chrome mới nhất
                    allow_redirects=True,
                )
        except Exception as exc:
            out = HttpProbeOutcome(error=str(exc)[:200])
            out.needs_escalation = True
            out.escalation_reason = f"curl_cffi lỗi kết nối: {exc}"
            return out

        elapsed = (time.perf_counter() - t0) * 1000
        out = HttpProbeOutcome(
            status=resp.status_code,
            elapsed_ms=round(elapsed, 1),
            headers=dict(resp.headers),
        )
        if looks_like_js_challenge(resp.status_code, resp.text[:4000]):
            out.needs_escalation = True
            out.escalation_reason = f"HTTP {resp.status_code} ở Engine 1/curl_cffi (nghi ngờ JS-challenge)"
        return out

    async def record_escalation(self, host: str, reason: str, now: str,
                                engine: EngineKind = EngineKind.CHROMIUM) -> None:
        LOGGER.warning("Leo thang '%s' -> engine %s (%s)", host, engine.value, reason)
        await self.db.aset_host_engine(host, engine.value, reason, now)

    @staticmethod
    def host_of(url: str) -> str:
        return (urlsplit(url).hostname or url).lower()


# ---------------------------------------------------------------------------
# Phase 8: Hybrid Browser→HTTP Handoff
# ---------------------------------------------------------------------------

class HybridHandoff:
    """Trích xuất session state từ Playwright page → inject vào curl_cffi client.

    Luồng:
      1. Browser mở trang đầu, giải quyết JS challenge, tạo session cookies.
      2. HybridHandoff.capture(page) trích xuất cookies + UA.
      3. Các request tiếp theo dùng apply_to_session(session) để inject vào
         curl_cffi AsyncSession → tốc độ cao, không cần browser mở thêm.

    GIỚI HẠN:
      - TLS Session Ticket không expose qua Playwright API → không thể handoff hoàn hảo.
        curl_cffi sẽ bắt đầu TLS session mới (nhưng có cookies hợp lệ nên vẫn được xác thực).
      - Cookie HTTPOnly được include trong handoff (Playwright có quyền đọc qua context.cookies()).
      - Cookies có domain/path cụ thể sẽ chỉ được gửi khi URL đích khớp.
    """

    def __init__(self) -> None:
        self.cookies: list[dict] = []
        self.user_agent: str = ""
        self.extra_headers: dict[str, str] = {}
        self.captured_at: float = 0.0

    async def capture(self, page: "Any") -> "HybridHandoff":
        """Trích xuất từ Playwright page. Trả về self để chain."""
        import time as _time
        # Lấy tất cả cookies
        self.cookies = await page.context.cookies()
        # Lấy User-Agent thực tế từ browser
        self.user_agent = await page.evaluate("navigator.userAgent")
        # Lấy accept-language
        lang = await page.evaluate("navigator.language || 'en-US'")
        self.extra_headers = {
            "Accept-Language": lang + ",en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
        self.captured_at = _time.time()
        import logging
        logging.getLogger("qa.hybrid").info(
            "hybrid_handoff: captured %d cookies, UA=%s…",
            len(self.cookies), self.user_agent[:50])
        return self

    def to_curl_cffi_cookies(self) -> dict[str, str]:
        """Chuyển cookies sang dict đơn giản cho curl_cffi."""
        return {c["name"]: c["value"] for c in self.cookies}

    def to_httpx_cookies(self) -> list[tuple[str, str]]:
        return [(c["name"], c["value"]) for c in self.cookies]

    async def apply_to_session(self, session: "Any", base_url: str = "") -> None:
        """Inject cookies + headers vào curl_cffi AsyncSession đang mở."""
        cookies = self.to_curl_cffi_cookies()
        headers = {"User-Agent": self.user_agent, **self.extra_headers}
        # curl_cffi AsyncSession: set cookies qua cookies attribute
        try:
            for name, value in cookies.items():
                session.cookies.set(name, value)
        except Exception:
            pass
        # Update headers
        try:
            session.headers.update(headers)
        except Exception:
            pass

    async def execute_requests(
        self,
        urls: list[str],
        method: str = "GET",
        timeout_s: float = 15.0,
        proxy_url: str = "",
    ) -> list[dict]:
        """Thực thi nhiều request với session đã handoff. Trả về list kết quả."""
        try:
            from curl_cffi.requests import AsyncSession
        except ImportError:
            return [{"error": "curl_cffi chưa cài", "url": u} for u in urls]

        cookies = self.to_curl_cffi_cookies()
        headers = {"User-Agent": self.user_agent, **self.extra_headers}
        proxies = {"https": proxy_url, "http": proxy_url} if proxy_url else None

        results = []
        async with AsyncSession(cookies=cookies, headers=headers) as session:
            for url in urls:
                import time as _time
                t0 = _time.perf_counter()
                try:
                    r = await session.request(
                        method, url,
                        proxies=proxies,
                        timeout=timeout_s,
                        impersonate="chrome",
                        allow_redirects=True,
                    )
                    results.append({
                        "url": url, "status": r.status_code,
                        "elapsed_ms": round((_time.perf_counter() - t0) * 1000, 1),
                        "size_bytes": len(r.content),
                    })
                except Exception as exc:
                    results.append({"url": url, "error": str(exc)[:100],
                                    "elapsed_ms": round((_time.perf_counter() - t0) * 1000, 1)})
        return results


async def hybrid_browser_to_http_handoff(
    browser_type: Any,
    priming_url: str,
    follow_up_urls: list[str],
    priming_wait_s: float = 7.0,
    launch_kwargs: Optional[dict[str, Any]] = None,
    context_kwargs: Optional[dict[str, Any]] = None,
    proxy_url: str = "",
    method: str = "GET",
    timeout_s: float = 15.0,
) -> dict[str, Any]:
    """Thực thi đầy đủ quy trình 2 bước của mục 2.3 (Instant Session Priming &
    Hybrid Handoff):

      Bước 1 — Khởi tạo phiên nhẹ: mở Playwright context ẩn, vào `priming_url`,
               chờ `priming_wait_s` giây để JS challenge (Cloudflare...) chạy
               xong và cookie phiên hợp lệ được cấp.
      Bước 2 — Chuyển giao: đóng browser (giải phóng RAM), bơm cookie/UA/headers
               đã thu hoạch vào `curl_cffi.AsyncSession`, bắn hàng loạt request
               tới `follow_up_urls` ở tốc độ HTTP/2 thuần.

    Đây là hàm orchestration gọn cho `engine.py` / admin_api.py gọi trực tiếp;
    logic trích xuất/inject thật nằm trong class `HybridHandoff` (đã có từ
    Phase 8) — hàm này chỉ nối 2 bước lại thành một lệnh gọi duy nhất.

    Args:
        browser_type: `playwright.chromium` (hoặc firefox/webkit) - instance đã
                      có sẵn từ `async_playwright()`, KHÔNG tự mở/đóng playwright
                      context quản lý (caller chịu trách nhiệm `async with`).
        priming_url: URL đầu tiên cần "làm nóng" (có JS challenge).
        follow_up_urls: danh sách URL thực thi tiếp theo qua curl_cffi.
        priming_wait_s: thời gian chờ ở bước 1 (giây) - đủ để challenge tự giải.
        launch_kwargs: tham số bổ sung cho `browser_type.launch()`.
        context_kwargs: tham số bổ sung cho `browser.new_context()` (vd. user_agent,
                        locale, viewport - nên khớp Environment/Persona đang dùng).
        proxy_url: proxy dùng CHUNG cho cả bước 1 (Playwright) và bước 2 (curl_cffi)
                   để tránh exit IP bị đổi giữa 2 bước (sẽ làm session bị vô hiệu).
        method, timeout_s: áp dụng cho các request ở bước 2.

    Returns:
        dict: {
          "priming": {"ok": bool, "cookies_captured": int, "user_agent": str, "elapsed_ms": float},
          "handoff_results": [...] (kết quả từng follow_up_url, xem HybridHandoff.execute_requests),
          "total_elapsed_ms": float,
        }

    GIỚI HẠN: xem docstring class `HybridHandoff` — không handoff được TLS
    Session Ticket thật (Playwright không expose), chỉ handoff cookie + UA + headers.
    """
    t0 = time.time()
    launch_kwargs = dict(launch_kwargs or {})
    context_kwargs = dict(context_kwargs or {})
    if proxy_url:
        launch_kwargs.setdefault("proxy", {"server": proxy_url})

    handoff = HybridHandoff()
    priming_info: dict[str, Any] = {"ok": False, "cookies_captured": 0,
                                     "user_agent": "", "elapsed_ms": 0.0}
    browser = None
    try:
        tp0 = time.perf_counter()
        browser = await browser_type.launch(headless=True, **launch_kwargs)
        context = await browser.new_context(**context_kwargs)
        page = await context.new_page()
        await page.goto(priming_url, wait_until="domcontentloaded", timeout=30000)
        # Bước 1: chờ JS challenge tự giải (vd. Cloudflare "Just a moment...")
        await page.wait_for_timeout(int(priming_wait_s * 1000))
        await handoff.capture(page)
        priming_info = {
            "ok": True,
            "cookies_captured": len(handoff.cookies),
            "user_agent": handoff.user_agent,
            "elapsed_ms": round((time.perf_counter() - tp0) * 1000, 1),
        }
    except Exception as exc:  # noqa: BLE001
        priming_info["error"] = f"{type(exc).__name__}: {exc}"
        LOGGER.warning("hybrid_handoff: priming thất bại: %s", priming_info["error"])
    finally:
        # Bước 2 (phần "đóng browser"): giải phóng RAM NGAY sau khi có cookie,
        # trước khi bắn request curl_cffi - đúng tinh thần "Instant Priming".
        if browser is not None:
            try:
                await browser.close()
            except Exception:  # noqa: BLE001
                pass

    # Bước 2 (phần "chuyển giao"): dùng curl_cffi cho toàn bộ follow_up_urls.
    handoff_results: list[dict[str, Any]] = []
    if priming_info.get("ok") and follow_up_urls:
        handoff_results = await handoff.execute_requests(
            follow_up_urls, method=method, timeout_s=timeout_s, proxy_url=proxy_url,
        )
    elif follow_up_urls:
        handoff_results = [{"url": u, "error": "priming thất bại - bỏ qua handoff"}
                           for u in follow_up_urls]

    return {
        "priming": priming_info,
        "handoff_results": handoff_results,
        "total_elapsed_ms": round((time.time() - t0) * 1000, 1),
    }


# ---------------------------------------------------------------------------
# Phase 9: TLS Session Persistence & TCP Socket Options
# ---------------------------------------------------------------------------

class TLSSessionStore:
    """Lưu trữ và tái sử dụng TLS session giữa các requests tới cùng host.

    curl_cffi tự xử lý TLS session resumption bên trong AsyncSession nếu dùng
    cùng 1 instance cho nhiều requests. Store này đảm bảo cùng session object
    được reuse theo hostname để tối đa 0-RTT resumption.

    GIỚI HẠN:
      - TLS Session Ticket có TTL do server quy định (thường 300-3600s).
        Sau khi hết hạn, curl_cffi sẽ tự động Full Handshake lại.
      - Không expose Session Ticket raw ra ngoài — curl_cffi quản lý internally.
      - Mỗi host có 1 session object; không thread-safe nếu dùng đa luồng thật.
    """

    def __init__(self, max_age_s: float = 3600.0) -> None:
        self._sessions: dict[str, Any] = {}       # host → AsyncSession
        self._created: dict[str, float] = {}       # host → timestamp
        self.max_age_s = max_age_s

    def _is_valid(self, host: str) -> bool:
        t = self._created.get(host, 0)
        return time.time() - t < self.max_age_s

    async def get_session(self, host: str, impersonate: str = "chrome") -> Any:
        """Lấy hoặc tạo AsyncSession cho host."""
        from curl_cffi.requests import AsyncSession
        if host in self._sessions and self._is_valid(host):
            return self._sessions[host]
        # Tạo mới (đóng cũ nếu có)
        old = self._sessions.pop(host, None)
        if old:
            try:
                await old.close()
            except Exception:
                pass
        sess = AsyncSession(impersonate=impersonate)
        self._sessions[host] = sess
        self._created[host] = time.time()
        import logging
        logging.getLogger("qa.tls").debug("tls_store: new session for %s", host)
        return sess

    async def close_all(self) -> None:
        for sess in self._sessions.values():
            try:
                await sess.close()
            except Exception:
                pass
        self._sessions.clear()
        self._created.clear()

    def stats(self) -> dict[str, Any]:
        now = time.time()
        return {
            "active_hosts": len(self._sessions),
            "hosts": [
                {"host": h, "age_s": round(now - self._created.get(h, now), 1),
                 "valid": self._is_valid(h)}
                for h in self._sessions
            ],
        }


# OS-specific TCP parameters (p0f fingerprint matching)
_TCP_OS_PROFILES: dict[str, dict[str, Any]] = {
    "Windows": {"ttl": 128, "window_size": 65535, "df_bit": True,
                "mss": 1460, "options_order": ["mss", "nop", "ws", "nop", "nop", "ts", "so", "eol"]},
    "macOS":   {"ttl": 64,  "window_size": 65535, "df_bit": True,
                "mss": 1460, "options_order": ["mss", "nop", "ws", "ts", "nop", "eol"]},
    "Linux":   {"ttl": 64,  "window_size": 29200, "df_bit": True,
                "mss": 1460, "options_order": ["mss", "so", "ts", "nop", "ws"]},
    "Android": {"ttl": 64,  "window_size": 65535, "df_bit": True,
                "mss": 1460, "options_order": ["mss", "so", "ts", "nop", "ws"]},
    "iOS":     {"ttl": 64,  "window_size": 65535, "df_bit": True,
                "mss": 1460, "options_order": ["mss", "nop", "ws", "ts", "nop", "eol"]},
}


def get_tcp_profile(os_name: str) -> dict[str, Any]:
    """Trả về TCP socket parameters cho OS đã cho."""
    return _TCP_OS_PROFILES.get(os_name, _TCP_OS_PROFILES["Windows"])


# ---------------------------------------------------------------------------
# Phase 10.2: Runtime Protocol Rotation (đồng bộ bộ ba tín hiệu)
# ---------------------------------------------------------------------------
#
# Mỗi khi đổi "danh tính trình duyệt" (Chrome/Edge/Safari...), TẤT CẢ các tầng
# phải đồng bộ cùng lúc, nếu không tạo ra bất nhất dễ bị phát hiện:
#   - Tầng TLS      : JA3/JA4 ClientHello (curl_cffi `impersonate=...`)
#   - Tầng HTTP/2   : khung SETTINGS (INITIAL_WINDOW_SIZE, HEADER_TABLE_SIZE...)
#   - Tầng Header   : thứ tự header (curl_cffi tự làm theo impersonate)
#   - Tầng Client Hints: chuỗi sec-ch-ua* phải khớp UA thật của profile đó
#
# curl_cffi tự đồng bộ JA3 + HTTP/2 SETTINGS + thứ tự header nội bộ theo tham
# số `impersonate=`, nên hàm này tập trung vào phần curl_cffi KHÔNG tự làm:
# soạn bộ header (Client Hints + Accept-Language + UA) khớp với browser đã chọn.

# Giá trị HTTP/2 SETTINGS tham khảo thực đo của từng trình duyệt (công khai,
# dùng cho mục đích hiển thị/ghi log - curl_cffi set thật theo `impersonate`).
_HTTP2_SETTINGS_REFERENCE: dict[str, dict[str, int]] = {
    "chrome": {"HEADER_TABLE_SIZE": 65536, "INITIAL_WINDOW_SIZE": 6291456,
               "MAX_CONCURRENT_STREAMS": 1000, "MAX_FRAME_SIZE": 16384},
    "edge":   {"HEADER_TABLE_SIZE": 65536, "INITIAL_WINDOW_SIZE": 6291456,
               "MAX_CONCURRENT_STREAMS": 1000, "MAX_FRAME_SIZE": 16384},
    "safari": {"HEADER_TABLE_SIZE": 4096,  "INITIAL_WINDOW_SIZE": 2097152,
               "MAX_CONCURRENT_STREAMS": 100,  "MAX_FRAME_SIZE": 16384},
    "firefox": {"HEADER_TABLE_SIZE": 65536, "INITIAL_WINDOW_SIZE": 131072,
                "MAX_CONCURRENT_STREAMS": 100,  "MAX_FRAME_SIZE": 16384},
}

# Bản đồ browser_profile -> tham số curl_cffi `impersonate` + UA mẫu + Client Hints.
# UA mẫu chỉ dùng khi Environment không tự khai báo user_agent riêng.
_PROTOCOL_PROFILES: dict[str, dict[str, Any]] = {
    "chrome": {
        "impersonate": "chrome",
        "sample_user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                               "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
        "client_hints": {
            "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Google Chrome";v="131"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        },
    },
    "edge": {
        "impersonate": "edge",
        "sample_user_agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                               "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0"),
        "client_hints": {
            "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Microsoft Edge";v="131"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        },
    },
    "safari": {
        "impersonate": "safari",
        "sample_user_agent": ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
                               "(KHTML, like Gecko) Version/17.4 Safari/605.1.15"),
        "client_hints": {},  # Safari không gửi sec-ch-ua*
    },
    "firefox": {
        "impersonate": "firefox",
        "sample_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
        "client_hints": {},  # Firefox không gửi sec-ch-ua* (chưa hỗ trợ Client Hints)
    },
    # Phase 11.3: biến thể mobile - dùng khi persona.device_type == "mobile"/"tablet",
    # đồng bộ với Device Mix Slider (persona_manager/referrer_orchestrator).
    "chrome_android": {
        "impersonate": "chrome",  # curl_cffi chưa có target JA3 Android riêng - dùng chrome desktop
        "sample_user_agent": ("Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
                               "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"),
        "client_hints": {
            "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Google Chrome";v="131"',
            "sec-ch-ua-mobile": "?1", "sec-ch-ua-platform": '"Android"',
        },
    },
    "safari_ios": {
        "impersonate": "safari_ios",  # curl_cffi có target JA3 riêng cho Safari iOS
        "sample_user_agent": ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) "
                               "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"),
        "client_hints": {},
    },
}


@dataclass
class ProtocolProfile:
    """Bộ ba tín hiệu đồng bộ cho một 'danh tính trình duyệt' cụ thể."""
    browser: str
    impersonate: str                      # tham số curl_cffi (JA3/JA4 + HTTP/2 ALPN thật)
    http2_settings: dict[str, int]         # tham khảo/ghi log - curl_cffi set thật nội bộ
    headers: dict[str, str]                # Client Hints + Accept-Language, GHÉP vào request
    tcp_profile: dict[str, Any]            # dấu vân tay TCP/OS (mục 2.2, TTL/window/MSS)
    rotated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "browser": self.browser, "impersonate": self.impersonate,
            "http2_settings": self.http2_settings, "headers": self.headers,
            "tcp_profile": self.tcp_profile, "rotated_at": self.rotated_at,
        }


def rotate_protocol_profile(
    browser: str = "chrome",
    os_name: str = "Windows",
    locale: Optional[str] = None,
    user_agent: Optional[str] = None,
    device_type: str = "desktop",
) -> ProtocolProfile:
    """Xoay (chọn) một bộ ba tín hiệu đồng bộ TLS/HTTP2/Header/Client-Hints cho `browser`.

    Dùng mỗi khi engine_router chuyển đổi cấu hình trình duyệt giữa các lượt
    chạy (vd. Chrome -> Edge -> Safari theo persona), để đảm bảo:
      - `impersonate` truyền vào curl_cffi khớp đúng browser (JA3/JA4 + ALPN thật)
      - Client Hints (`sec-ch-ua*`) khớp UA đang dùng (tránh browser=Safari nhưng
        header Accept vẫn mang dấu Chrome)
      - TCP/OS profile (mục 2.2 - `_TCP_OS_PROFILES`) đi kèm để tầng tunnel áp dụng

    Args:
        browser: "chrome" | "edge" | "safari" | "firefox".
        os_name: "Windows" | "macOS" | "Linux" | "Android" | "iOS" (khớp mục get_tcp_profile).
        locale: nếu truyền, sinh Accept-Language tương ứng (vd. "vi-VN" -> "vi-VN,vi;q=0.9,en;q=0.8").
        user_agent: nếu truyền, GHI ĐÈ sample_user_agent mặc định (đồng bộ theo Environment thật).

    Returns:
        ProtocolProfile — truyền `.impersonate` vào curl_cffi, `.headers` ghép vào
        request headers, `.tcp_profile` vào `apply_tcp_options_to_socks_tunnel()`.
    """
    key = browser.lower().strip()
    if device_type in ("mobile", "tablet"):
        # Mục 2.3 (Phase 11): "tự động điều chỉnh nhân curl_cffi sang chữ ký
        # giao thức của trình duyệt di động tương ứng" - Safari -> safari_ios,
        # mọi browser khác (chrome/edge/firefox) -> chrome_android (gần đúng
        # nhất với curl_cffi hiện có, vì curl_cffi chưa có target JA3 riêng
        # cho Edge/Firefox Android).
        key = "safari_ios" if key == "safari" else "chrome_android"
    profile = _PROTOCOL_PROFILES.get(key, _PROTOCOL_PROFILES["chrome"])
    headers = dict(profile["client_hints"])
    headers["Accept-Language"] = accept_language(locale) if locale else "en-US,en;q=0.9"
    ua = user_agent or profile["sample_user_agent"]
    headers["User-Agent"] = ua
    tcp_profile = get_tcp_profile(os_name)
    http2_settings = dict(_HTTP2_SETTINGS_REFERENCE.get(key, _HTTP2_SETTINGS_REFERENCE["chrome"]))
    LOGGER.debug("rotate_protocol_profile: %s (os=%s, impersonate=%s)", key, os_name, profile["impersonate"])
    return ProtocolProfile(
        browser=key, impersonate=profile["impersonate"],
        http2_settings=http2_settings, headers=headers, tcp_profile=tcp_profile,
    )


def apply_tcp_options_to_socks_tunnel(
    tunnel_config: dict[str, Any],
    os_name: str = "Windows",
) -> dict[str, Any]:
    """Thêm TCP profile vào config tunnel để sidecar apply khi tạo kết nối.

    Xray-core / Sing-box hỗ trợ custom TCP MSS qua tcpSettings.header.
    Đây là helper build config fragment; không tự ghi file.

    GIỚI HẠN: TTL và window_size thật cần hỗ trợ từ kernel hoặc raw socket
    (không khả thi trong Python userspace). Config này chỉ hint cho tunnel binary.
    """
    profile = get_tcp_profile(os_name)
    result = dict(tunnel_config)
    result.setdefault("streamSettings", {})
    result["streamSettings"]["tcpSettings"] = {
        "header": {"type": "none"},
        "_qa_tcp_profile": {  # annotation only, not used by Xray
            "os": os_name,
            "ttl": profile["ttl"],
            "window_size": profile["window_size"],
            "mss": profile["mss"],
        },
    }
    return result
