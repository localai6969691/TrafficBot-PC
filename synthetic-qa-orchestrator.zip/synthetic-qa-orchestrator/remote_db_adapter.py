"""Bộ Đồng Bộ Cơ Sở Dữ Liệu Đám Mây (Remote Database Adapter).

Đẩy dữ liệu từ SQLite cục bộ lên:
  - MongoDB Atlas  (MONGODB_URI env var)
  - Supabase / PostgreSQL (SUPABASE_URL + SUPABASE_KEY env var)

Chỉ đồng bộ những bản ghi mới kể từ lần sync trước (incremental sync dựa trên
watermark lưu trong bảng sync_state của SQLite).

GIỚI HẠN:
  - MongoDB: dùng motor (async driver). Nếu chưa cài: pip install motor.
  - Supabase: dùng REST API qua httpx (không cần thư viện supabase-py).
  - Mỗi lần sync tối đa 500 bản ghi để tránh timeout trên GitHub Actions.
  - Chỉ sync một chiều: Local → Cloud. Không pull về.
  - Nếu cả hai biến env đều trống, sync bị bỏ qua hoàn toàn (không báo lỗi).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

LOGGER = logging.getLogger("qa.remote_db")

_BATCH_SIZE = 500


# ---------------------------------------------------------------------------
# Sync watermark helpers
# ---------------------------------------------------------------------------

def _get_watermark(db_path: Path, table: str) -> str:
    """Lấy watermark (ISO timestamp) từ sync_state table."""
    import sqlite3
    try:
        con = sqlite3.connect(str(db_path))
        con.row_factory = sqlite3.Row
        con.execute("""CREATE TABLE IF NOT EXISTS sync_state
                       (table_name TEXT PRIMARY KEY, last_synced_at TEXT)""")
        row = con.execute("SELECT last_synced_at FROM sync_state WHERE table_name=?",
                          (table,)).fetchone()
        con.close()
        return row["last_synced_at"] if row else "1970-01-01T00:00:00+00:00"
    except Exception:
        return "1970-01-01T00:00:00+00:00"


def _set_watermark(db_path: Path, table: str, ts: str) -> None:
    import sqlite3
    try:
        con = sqlite3.connect(str(db_path))
        con.execute("""CREATE TABLE IF NOT EXISTS sync_state
                       (table_name TEXT PRIMARY KEY, last_synced_at TEXT)""")
        con.execute("""INSERT INTO sync_state(table_name, last_synced_at) VALUES(?,?)
                       ON CONFLICT(table_name) DO UPDATE SET last_synced_at=excluded.last_synced_at""",
                    (table, ts))
        con.commit()
        con.close()
    except Exception as exc:
        LOGGER.warning("watermark write lỗi: %s", exc)


def _fetch_new_rows(db_path: Path, table: str, ts_col: str, watermark: str,
                    limit: int = _BATCH_SIZE) -> list[dict[str, Any]]:
    """Lấy rows mới hơn watermark từ SQLite."""
    import sqlite3
    try:
        con = sqlite3.connect(str(db_path))
        con.row_factory = sqlite3.Row
        rows = con.execute(
            f"SELECT * FROM {table} WHERE {ts_col} > ? ORDER BY {ts_col} LIMIT ?",
            (watermark, limit)
        ).fetchall()
        con.close()
        return [dict(r) for r in rows]
    except Exception as exc:
        LOGGER.warning("fetch_new_rows '%s': %s", table, exc)
        return []


# Bảng cần sync và cột timestamp tương ứng
_SYNC_TABLES: list[tuple[str, str]] = [
    ("runs",              "started_at"),
    ("performance_metrics", "id"),       # dùng id vì không có ts
    ("cloud_usage_logs",  "started_at"),
    ("failure_events",    "occurred_at"),
    ("alert_history",     "sent_at"),
    ("preflight_results", "audited_at"),
]


# ---------------------------------------------------------------------------
# MongoDB Atlas adapter
# ---------------------------------------------------------------------------

async def sync_to_mongodb(db_path: Path, uri: str) -> dict[str, int]:
    """Đồng bộ lên MongoDB Atlas. Trả về {table: rows_synced}."""
    try:
        import motor.motor_asyncio  # type: ignore[import-not-found]
    except ImportError:
        LOGGER.warning("remote_db: motor chưa cài — pip install motor")
        return {}

    client = motor.motor_asyncio.AsyncIOMotorClient(uri, serverSelectionTimeoutMS=5000)
    db_name = "qa_orchestrator"
    mdb = client[db_name]
    results: dict[str, int] = {}

    for table, ts_col in _SYNC_TABLES:
        wm = _get_watermark(db_path, f"mongo:{table}")
        rows = _fetch_new_rows(db_path, table, ts_col, wm)
        if not rows:
            results[table] = 0
            continue
        try:
            # Thêm _source để biết row từ runner nào
            source_id = os.environ.get("GITHUB_RUN_ID", "local")
            for r in rows:
                r["_source"] = source_id
                r["_synced_at"] = datetime.now(timezone.utc).isoformat()
            await mdb[table].insert_many(rows, ordered=False)
            # Cập nhật watermark
            last_ts = str(rows[-1].get(ts_col, ""))
            if last_ts:
                _set_watermark(db_path, f"mongo:{table}", last_ts)
            results[table] = len(rows)
            LOGGER.info("mongo sync '%s': %d rows", table, len(rows))
        except Exception as exc:
            LOGGER.warning("mongo sync '%s' lỗi: %s", table, exc)
            results[table] = 0

    client.close()
    return results


# ---------------------------------------------------------------------------
# Supabase / PostgreSQL adapter (REST API)
# ---------------------------------------------------------------------------

async def sync_to_supabase(db_path: Path, url: str, key: str) -> dict[str, int]:
    """Đồng bộ lên Supabase qua REST API. Trả về {table: rows_synced}."""
    try:
        import httpx
    except ImportError:
        LOGGER.warning("remote_db: httpx chưa cài")
        return {}

    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal",
    }
    results: dict[str, int] = {}

    async with httpx.AsyncClient(timeout=30) as client:
        for table, ts_col in _SYNC_TABLES:
            wm = _get_watermark(db_path, f"supa:{table}")
            rows = _fetch_new_rows(db_path, table, ts_col, wm)
            if not rows:
                results[table] = 0
                continue
            try:
                # Supabase REST upsert
                r = await client.post(
                    f"{url}/rest/v1/{table}",
                    headers={**headers, "Prefer": "resolution=merge-duplicates"},
                    content=json.dumps(rows),
                )
                if r.status_code in (200, 201, 204):
                    last_ts = str(rows[-1].get(ts_col, ""))
                    if last_ts:
                        _set_watermark(db_path, f"supa:{table}", last_ts)
                    results[table] = len(rows)
                    LOGGER.info("supabase sync '%s': %d rows", table, len(rows))
                else:
                    LOGGER.warning("supabase '%s' HTTP %d: %s", table,
                                   r.status_code, r.text[:100])
                    results[table] = 0
            except Exception as exc:
                LOGGER.warning("supabase sync '%s' lỗi: %s", table, exc)
                results[table] = 0

    return results


# ---------------------------------------------------------------------------
# Entry point (dùng trong scheduled_runner.yml)
# ---------------------------------------------------------------------------

async def sync_to_remote(db_path: Optional[Path] = None) -> dict[str, Any]:
    """Đồng bộ lên tất cả remote targets đã cấu hình."""
    if db_path is None:
        db_path = Path(os.environ.get("QA_DATA_DIR", "data")) / "state.db"
    if not db_path.exists():
        LOGGER.info("remote_db: không tìm thấy DB tại %s — bỏ qua", db_path)
        return {"skipped": True}

    results: dict[str, Any] = {}

    # MongoDB Atlas
    mongo_uri = os.environ.get("MONGODB_URI", "")
    if mongo_uri:
        LOGGER.info("remote_db: sync → MongoDB Atlas")
        results["mongodb"] = await sync_to_mongodb(db_path, mongo_uri)
    else:
        LOGGER.debug("remote_db: MONGODB_URI trống — bỏ qua MongoDB")

    # Supabase
    supa_url = os.environ.get("SUPABASE_URL", "")
    supa_key = os.environ.get("SUPABASE_KEY", "")
    if supa_url and supa_key:
        LOGGER.info("remote_db: sync → Supabase")
        results["supabase"] = await sync_to_supabase(db_path, supa_url, supa_key)
    else:
        LOGGER.debug("remote_db: SUPABASE_URL/KEY trống — bỏ qua Supabase")

    if not results:
        LOGGER.info("remote_db: không có target nào được cấu hình")
        results["skipped"] = True

    return results
