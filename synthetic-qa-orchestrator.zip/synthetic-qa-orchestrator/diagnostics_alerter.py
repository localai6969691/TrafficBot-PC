"""Hệ Thống Chẩn Đoán Lỗi Tự Động & Cảnh Báo (Automated Root-Cause Diagnostics & Alerts).

Ba thành phần chính:
  1. FailureTaxonomyEngine  - phân loại nguyên nhân gốc rễ từ lỗi run, lưu vào DB.
  2. SmartCachePruner       - dọn dẹp cache trình duyệt, giữ nguyên dữ liệu phiên.
  3. AlertDispatcher        - gửi thông báo qua Telegram/Discord/Slack/Webhook.

GIỚI HẠN ĐÃ BIẾT:
  - Phân loại failure dựa trên pattern matching chuỗi lỗi — có thể false-positive với
    các trang trả về HTML không chuẩn. Luôn kiểm tra thủ công các failure_type=UNKNOWN.
  - SmartCachePruner dùng shutil.rmtree cho thư mục cache con — không thể hoàn tác.
    Chạy với dry_run=True trước để xem thư mục nào sẽ bị xóa.
  - Telegram Bot API: token và chat_id phải lưu trong environment variables,
    KHÔNG hardcode vào config file. Rate limit: 30 messages/second per bot.
  - Discord Webhook: giới hạn 2000 ký tự per message; nội dung dài sẽ bị cắt.
  - Alert deduplication: cùng (scenario_id, failure_type) trong cùng cooldown_minutes
    sẽ chỉ gửi 1 cảnh báo. Tránh spam khi lỗi xảy ra liên tục.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.diagnostics")

# ---------------------------------------------------------------------------
# 1. Failure Taxonomy Engine
# ---------------------------------------------------------------------------

class FailureType:
    NETWORK_TIMEOUT      = "NETWORK_TIMEOUT"
    GATEWAY_DEAD         = "GATEWAY_DEAD"
    PROTOCOL_MISMATCH    = "PROTOCOL_MISMATCH"
    WAF_CHALLENGE        = "WAF_CHALLENGE"
    GEO_LOCALE_CONFLICT  = "GEO_LOCALE_CONFLICT"
    DOM_SELECTOR_MISSING = "DOM_SELECTOR_MISSING"
    JS_ERROR             = "JS_ERROR"
    MEDIA_STALL          = "MEDIA_STALL"
    CLOUD_QUOTA_EXCEEDED = "CLOUD_QUOTA_EXCEEDED"
    UNKNOWN              = "UNKNOWN"


# Pattern → FailureType (ưu tiên từ trên xuống dưới)
_PATTERNS: list[tuple[str, str]] = [
    # Mạng & kết nối
    (r"(?i)(timeout|timed?\s*out|connection\s*reset|ERR_TIMED_OUT)", FailureType.NETWORK_TIMEOUT),
    (r"(?i)(ERR_CONNECTION_REFUSED|ERR_NAME_NOT_RESOLVED|gateway.*dead|proxy.*fail)", FailureType.GATEWAY_DEAD),
    # TLS / Protocol
    (r"(?i)(tls|ssl|certificate|protocol\s*mismatch|ERR_SSL|ERR_CERT)", FailureType.PROTOCOL_MISMATCH),
    # WAF / Bot protection
    (r"(?i)(403|challenge|captcha|cloudflare|access\s*denied|bot\s*detect|cf-ray|verif)", FailureType.WAF_CHALLENGE),
    # Geo/Locale conflict
    (r"(?i)(geo.*conflict|locale.*mismatch|timezone.*differ|ip.*country.*mismatch)", FailureType.GEO_LOCALE_CONFLICT),
    # DOM
    (r"(?i)(selector.*not\s*found|element.*not\s*found|locator.*resolv|waiting.*selector|no\s*element)", FailureType.DOM_SELECTOR_MISSING),
    # JS errors
    (r"(?i)(uncaught\s*exception|script\s*error|TypeError|ReferenceError|SyntaxError.*script)", FailureType.JS_ERROR),
    # Media
    (r"(?i)(buffering|MediaError|video.*stall|stream.*fail)", FailureType.MEDIA_STALL),
    # Cloud quota
    (r"(?i)(quota.*exceed|limit.*reach|usage.*limit|429|rate.?limit)", FailureType.CLOUD_QUOTA_EXCEEDED),
]

_COMPILED = [(re.compile(pat), ft) for pat, ft in _PATTERNS]


def classify_failure(error_message: str, http_status: Optional[int] = None) -> str:
    """Phân loại nguyên nhân lỗi từ chuỗi error_message và HTTP status."""
    if not error_message and not http_status:
        return FailureType.UNKNOWN

    text = f"{error_message or ''} HTTP:{http_status or ''}"

    # Ưu tiên HTTP status code
    if http_status == 403:
        return FailureType.WAF_CHALLENGE
    if http_status == 429:
        return FailureType.CLOUD_QUOTA_EXCEEDED
    if http_status and http_status >= 500:
        return FailureType.GATEWAY_DEAD

    for pattern, failure_type in _COMPILED:
        if pattern.search(text):
            return failure_type

    return FailureType.UNKNOWN


class FailureTaxonomyEngine:
    """Phân loại và ghi nhận nguyên nhân lỗi vào DB."""

    def __init__(self, db: Database) -> None:
        self.db = db

    async def classify_and_log(
        self,
        error_message: str,
        scenario_id: str = "",
        run_id: Optional[int] = None,
        http_status: Optional[int] = None,
    ) -> str:
        """Phân loại + lưu vào DB, trả về failure_type string."""
        ft = classify_failure(error_message, http_status)
        await self.db.alog_failure_event(
            failure_type=ft,
            scenario_id=scenario_id,
            run_id=run_id,
            detail=error_message[:500] if error_message else "",
        )
        LOGGER.debug("failure_taxonomy: %s → %s", scenario_id, ft)
        return ft

    async def failure_rate(self, scenario_id: str, window_minutes: int = 5) -> float:
        return await self.db.arecent_failure_rate(scenario_id, window_minutes)


# ---------------------------------------------------------------------------
# 2. Smart Cache Pruner
# ---------------------------------------------------------------------------

# Thư mục an toàn để xóa (cache tạm thời, không ảnh hưởng phiên)
_SAFE_CACHE_DIRS = {
    "Code Cache", "GPUCache", "Media Cache", "Cache", "Cache_Data",
    "Service Worker/CacheStorage", "DawnCache", "ShaderCache",
    "BlobStorage", "File System", "VideoDecodeStats",
}

# Thư mục PHẢI GIỮ NGUYÊN (chứa dữ liệu phiên quan trọng)
_PROTECTED_DIRS = {
    "Default", "Cookies", "Local Storage", "IndexedDB",
    "Preferences", "History", "Bookmarks", "Sessions",
    "Extension State", "Local Extension Settings",
}

# File PHẢI GIỮ NGUYÊN
_PROTECTED_FILES = {
    "Cookies", "Cookies-journal", "Preferences",
    "Local State", "History", "Bookmarks",
    "Login Data", "Web Data", "Secure Preferences",
}


@dataclass
class PruneResult:
    profile_id: str
    bytes_freed: int = 0
    dirs_removed: int = 0
    errors: list[str] = field(default_factory=list)
    dry_run: bool = False


def _safe_rmtree(path: Path, dry_run: bool = False) -> int:
    """Xóa thư mục an toàn, trả về số bytes đã giải phóng."""
    if not path.exists():
        return 0
    try:
        total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
        if not dry_run:
            shutil.rmtree(path, ignore_errors=True)
        return total
    except Exception:
        return 0


class SmartCachePruner:
    """Dọn dẹp cache trình duyệt sau mỗi phiên, bảo toàn dữ liệu quan trọng.

    Cấu trúc thư mục profile Chromium:
      profiles_data/<profile_id>/
        Default/              ← PHẢI GIỮ (chứa Cookies, LocalStorage...)
          Cache/              ← AN TOÀN để xóa
          Code Cache/         ← AN TOÀN để xóa
          GPUCache/           ← AN TOÀN để xóa
          ...
    """

    def __init__(self, profiles_root: Path, dry_run: bool = False) -> None:
        self.root = profiles_root
        self.dry_run = dry_run

    def prune_profile(self, profile_id: str) -> PruneResult:
        """Dọn dẹp cache cho một profile cụ thể."""
        result = PruneResult(profile_id=profile_id, dry_run=self.dry_run)
        profile_dir = self.root / profile_id
        if not profile_dir.exists():
            return result

        # Duyệt tất cả subdir trong profile
        for subdir in profile_dir.rglob("*"):
            if not subdir.is_dir():
                continue
            name = subdir.name
            # Bỏ qua thư mục được bảo vệ
            if name in _PROTECTED_DIRS:
                continue
            if name in _SAFE_CACHE_DIRS:
                freed = _safe_rmtree(subdir, self.dry_run)
                result.bytes_freed += freed
                result.dirs_removed += 1
                LOGGER.debug("pruner: %s%s → freed %.1fKB",
                             "[dry] " if self.dry_run else "", subdir, freed / 1024)

        return result

    def prune_all(self, max_age_days: Optional[float] = None) -> list[PruneResult]:
        """Dọn dẹp tất cả profiles, tùy chọn chỉ profile cũ hơn max_age_days ngày."""
        results = []
        if not self.root.exists():
            return results
        for profile_dir in self.root.iterdir():
            if not profile_dir.is_dir():
                continue
            if max_age_days is not None:
                age_days = (time.time() - profile_dir.stat().st_mtime) / 86400
                if age_days < max_age_days:
                    continue
            results.append(self.prune_profile(profile_dir.name))
        total_freed = sum(r.bytes_freed for r in results)
        LOGGER.info("pruner: %d profiles, freed %.1fMB%s",
                    len(results), total_freed / 1_048_576,
                    " [dry run]" if self.dry_run else "")
        return results

    def archive_profile(self, profile_id: str, archive_dir: Path) -> Optional[Path]:
        """Nén profile thành .tar.gz để lưu trữ lạnh."""
        import tarfile
        profile_dir = self.root / profile_id
        if not profile_dir.exists():
            return None
        archive_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        archive_path = archive_dir / f"{profile_id}_{ts}.tar.gz"
        with tarfile.open(archive_path, "w:gz") as tar:
            tar.add(profile_dir, arcname=profile_id)
        LOGGER.info("pruner: đã archive '%s' → %s (%.1fMB)",
                    profile_id, archive_path.name,
                    archive_path.stat().st_size / 1_048_576)
        return archive_path

    def enforce_ttl(self, ttl_days: float, archive_dir: Optional[Path] = None) -> int:
        """Xóa (hoặc archive) các profile quá hạn TTL. Trả về số profile đã xử lý."""
        if not self.root.exists():
            return 0
        count = 0
        cutoff = time.time() - ttl_days * 86400
        for profile_dir in self.root.iterdir():
            if not profile_dir.is_dir():
                continue
            if profile_dir.stat().st_mtime < cutoff:
                if archive_dir:
                    self.archive_profile(profile_dir.name, archive_dir)
                if not self.dry_run:
                    shutil.rmtree(profile_dir, ignore_errors=True)
                LOGGER.info("pruner: TTL expired '%s' → %s",
                            profile_dir.name, "archived+deleted" if archive_dir else "deleted")
                count += 1
        return count


# ---------------------------------------------------------------------------
# 3. Alert Dispatcher
# ---------------------------------------------------------------------------

@dataclass
class AlertConfig:
    channel: str                      # telegram | discord | slack | webhook
    # Telegram
    telegram_token: str = ""
    telegram_chat_id: str = ""
    # Discord / Slack
    webhook_url: str = ""
    # Thresholds
    error_rate_threshold: float = 0.15  # 15%
    window_minutes: int = 5
    cooldown_minutes: int = 15          # không gửi lại cùng scenario trong cooldown
    # Từ environment variables
    @classmethod
    def from_env(cls, channel: str = "telegram") -> "AlertConfig":
        return cls(
            channel=channel,
            telegram_token=os.environ.get("TG_BOT_TOKEN", ""),
            telegram_chat_id=os.environ.get("TG_CHAT_ID", ""),
            webhook_url=os.environ.get("ALERT_WEBHOOK_URL", ""),
        )


class AlertDispatcher:
    """Gửi cảnh báo qua Telegram/Discord/Slack khi vượt ngưỡng lỗi."""

    def __init__(self, db: Database, configs: list[AlertConfig]) -> None:
        self.db = db
        self.configs = configs
        self._last_alert: dict[tuple[str, str], float] = {}  # (scenario, channel) → timestamp

    async def check_and_alert(
        self,
        scenario_id: str,
        failure_type: str = "",
        extra_info: str = "",
    ) -> list[str]:
        """Kiểm tra ngưỡng và gửi alert nếu cần. Trả về danh sách channel đã gửi."""
        sent: list[str] = []
        for cfg in self.configs:
            rate = await self.db.arecent_failure_rate(scenario_id, cfg.window_minutes)
            if rate < cfg.error_rate_threshold:
                continue
            # Deduplication cooldown
            key = (scenario_id, cfg.channel)
            last = self._last_alert.get(key, 0)
            if time.time() - last < cfg.cooldown_minutes * 60:
                continue
            # Gửi alert
            msg = self._build_message(scenario_id, rate, failure_type, extra_info)
            ok, err = await self._send(cfg, msg)
            await self.db.alog_alert(
                channel=cfg.channel, message=msg[:500],
                scenario_id=scenario_id,
                status="ok" if ok else "failed",
                error=err,
            )
            if ok:
                self._last_alert[key] = time.time()
                sent.append(cfg.channel)
                LOGGER.warning("alert: gửi [%s] cho '%s' (rate=%.0f%%)",
                               cfg.channel, scenario_id, rate * 100)
        return sent

    def _build_message(self, scenario_id: str, rate: float,
                        failure_type: str, extra: str) -> str:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lines = [
            f"🚨 *QA Alert* — {ts}",
            f"Scenario: `{scenario_id}`",
            f"Error rate: *{rate:.0%}* (ngưỡng {self.configs[0].error_rate_threshold:.0%})",
        ]
        if failure_type:
            lines.append(f"Failure type: `{failure_type}`")
        if extra:
            lines.append(f"Detail: {extra[:200]}")
        return "\n".join(lines)

    async def _send(self, cfg: AlertConfig, message: str) -> tuple[bool, str]:
        """Gửi message, trả về (success, error_str)."""
        try:
            import httpx
            if cfg.channel == "telegram":
                return await self._send_telegram(cfg, message)
            elif cfg.channel in ("discord", "slack", "webhook"):
                return await self._send_webhook(cfg, message)
            else:
                return False, f"channel không hỗ trợ: {cfg.channel}"
        except Exception as exc:
            return False, str(exc)[:200]

    @staticmethod
    async def _send_telegram(cfg: AlertConfig, text: str) -> tuple[bool, str]:
        if not cfg.telegram_token or not cfg.telegram_chat_id:
            return False, "thiếu TG_BOT_TOKEN hoặc TG_CHAT_ID"
        import httpx
        url = f"https://api.telegram.org/bot{cfg.telegram_token}/sendMessage"
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(url, json={
                "chat_id": cfg.telegram_chat_id,
                "text": text[:4096],
                "parse_mode": "Markdown",
            })
        if r.status_code == 200:
            return True, ""
        return False, f"HTTP {r.status_code}: {r.text[:100]}"

    @staticmethod
    async def _send_webhook(cfg: AlertConfig, text: str) -> tuple[bool, str]:
        if not cfg.webhook_url:
            return False, "thiếu ALERT_WEBHOOK_URL"
        import httpx
        # Discord/Slack đều dùng JSON {"content": "..."}
        payload: dict[str, Any] = {}
        if "discord" in cfg.webhook_url:
            payload = {"content": text[:2000]}
        elif "hooks.slack.com" in cfg.webhook_url:
            payload = {"text": text[:4000]}
        else:
            payload = {"text": text, "channel": cfg.channel}
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(cfg.webhook_url, json=payload)
        ok = r.status_code in (200, 204)
        return ok, "" if ok else f"HTTP {r.status_code}"


# ---------------------------------------------------------------------------
# Session Lifecycle Manager (tích hợp Pruner + TTL)
# ---------------------------------------------------------------------------

class SessionLifecycleManager:
    """Quản lý vòng đời profile: pruning sau mỗi run, TTL archiving theo lịch."""

    def __init__(
        self,
        profiles_root: Path,
        ttl_days: float = 30.0,
        archive_root: Optional[Path] = None,
        dry_run: bool = False,
    ) -> None:
        self.pruner = SmartCachePruner(profiles_root, dry_run=dry_run)
        self.ttl_days = ttl_days
        self.archive_root = archive_root

    async def on_session_end(self, profile_id: str) -> PruneResult:
        """Gọi sau mỗi run để dọn cache của profile đó."""
        return await asyncio.to_thread(self.pruner.prune_profile, profile_id)

    async def run_maintenance(self) -> dict[str, Any]:
        """Chạy bảo trì định kỳ: prune all + enforce TTL."""
        results = await asyncio.to_thread(self.pruner.prune_all)
        expired = await asyncio.to_thread(
            self.pruner.enforce_ttl, self.ttl_days, self.archive_root
        )
        total_freed = sum(r.bytes_freed for r in results)
        return {
            "profiles_pruned": len(results),
            "bytes_freed": total_freed,
            "mb_freed": round(total_freed / 1_048_576, 2),
            "profiles_expired": expired,
        }
