"""Bộ Tự Kiểm Định Môi Trường Trước Khi Chạy (Pre-Flight Environment Self-Audit).

Chạy tự động trước khi bắt đầu campaign, kiểm tra 30+ chỉ số kỹ thuật:
  - Rò rỉ WebRTC/IP thật
  - Đồng bộ Timezone vs IP GeoIP
  - User-Agent nhất quán với Client Hints
  - WebGL/Canvas fingerprint đúng persona
  - Cờ automation bị lộ (navigator.webdriver, CDP artifacts)
  - TLS JA4 hash (qua curl_cffi nếu có)
  - DNS leak

Nếu phát hiện bất nhất → ghi DB + log WARNING. Nếu severity=BLOCK → chặn campaign.

GIỚI HẠN ĐÃ BIẾT:
  - WebRTC leak test cần browser thật; không test được trong chế độ http-only.
  - GeoIP lookup dùng ip-api.com (miễn phí, giới hạn 45 req/min). Dùng API key
    để tăng giới hạn: set biến môi trường IP_API_KEY.
  - TLS JA4 check yêu cầu curl_cffi. Nếu chưa cài → bỏ qua check này.
  - navigator.webdriver=false injection phải được thực hiện qua add_init_script
    TRƯỚC khi trang load. Nếu trang load trước khi audit → kết quả không chính xác.
  - Một số checks cần truy cập mạng ra ngoài (ip-api.com, browserleaks.com). Nếu
    mạng bị giới hạn → checks đó trả về status=skip.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from database import Database

LOGGER = logging.getLogger("qa.preflight")

# JS checks chạy trong browser
_JS_WEBDRIVER_CHECK = """
() => ({
  webdriver: navigator.webdriver,
  automation_flags: {
    webdriver: navigator.webdriver === true,
    cdc_vars: Object.keys(window).filter(k => k.startsWith('cdc_')).length,
    __nightmare: !!window.__nightmare,
    _phantom: !!window._phantom,
    callPhantom: !!window.callPhantom,
    domAutomation: !!window.domAutomation,
    domAutomationController: !!window.domAutomationController,
    _selenium: !!window._selenium,
    __webdriver_script_fn: !!window.__webdriver_script_fn,
  }
})
"""

_JS_FINGERPRINT_CHECK = """
() => {
  const c = document.createElement('canvas');
  c.width=200; c.height=50;
  const ctx = c.getContext('2d');
  ctx.font='14px Arial';
  ctx.fillStyle='red';
  ctx.fillRect(10,10,100,30);
  ctx.fillStyle='blue';
  ctx.fillText('QA Test 🎯', 15, 30);
  const hash = c.toDataURL().split('').reduce((a,b)=>((a<<5)-a)+b.charCodeAt(0)|0,0);

  // WebGL
  const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
  const ext = gl && gl.getExtension('WEBGL_debug_renderer_info');
  const vendor = ext ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : 'N/A';
  const renderer = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : 'N/A';

  return {
    canvas_hash: hash,
    webgl_vendor: vendor,
    webgl_renderer: renderer,
    navigator_ua: navigator.userAgent,
    platform: navigator.platform,
    hardware_concurrency: navigator.hardwareConcurrency,
    device_memory: navigator.deviceMemory,
    timezone_offset: new Date().getTimezoneOffset(),
    language: navigator.language,
    languages: navigator.languages,
    screen_width: screen.width,
    screen_height: screen.height,
    pixel_ratio: window.devicePixelRatio,
    webdriver_flag: navigator.webdriver,
  };
}
"""

_JS_WEBRTC_CHECK = """
async () => {
  return new Promise(resolve => {
    const ips = new Set();
    try {
      const pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
      pc.createDataChannel('');
      pc.createOffer().then(o => pc.setLocalDescription(o));
      pc.onicecandidate = e => {
        if (!e.candidate) {
          pc.close();
          resolve({leaked_ips: [...ips], leak_detected: ips.size > 0});
          return;
        }
        const m = e.candidate.candidate.match(/([0-9]{1,3}\\.){3}[0-9]{1,3}/g);
        if (m) m.forEach(ip => {
          if (!ip.startsWith('0.') && ip !== '0.0.0.0') ips.add(ip);
        });
      };
      setTimeout(() => { pc.close(); resolve({leaked_ips:[...ips], leak_detected:ips.size>0}); }, 3000);
    } catch(e) {
      resolve({leaked_ips:[], leak_detected:false, error: e.message});
    }
  });
}
"""


@dataclass
class CheckResult:
    name: str
    ok: bool
    value: Any = None
    expected: Any = None
    severity: str = "warn"    # info | warn | block
    message: str = ""


@dataclass
class AuditReport:
    run_id: str
    passed: bool
    blocked: bool
    checks: list[CheckResult]
    duration_ms: float
    audited_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "passed": self.passed,
            "blocked": self.blocked,
            "duration_ms": self.duration_ms,
            "audited_at": self.audited_at,
            "checks": {c.name: {"ok": c.ok, "value": c.value,
                                 "expected": c.expected, "severity": c.severity,
                                 "message": c.message} for c in self.checks},
            "summary": {
                "total": len(self.checks),
                "passed": sum(1 for c in self.checks if c.ok),
                "failed": sum(1 for c in self.checks if not c.ok),
                "blocked": sum(1 for c in self.checks if not c.ok and c.severity == "block"),
            },
        }


class PreFlightAuditor:
    """Chạy bộ kiểm định môi trường trước khi thực thi campaign."""

    def __init__(
        self,
        db: Optional[Database] = None,
        block_on_fail: bool = True,
        skip_checks: Optional[list[str]] = None,
    ) -> None:
        self.db = db
        self.block_on_fail = block_on_fail
        self.skip_checks = set(skip_checks or [])

    async def audit(
        self,
        page: Any,
        run_id: str = "",
        expected_timezone: Optional[str] = None,
        expected_locale: Optional[str] = None,
        expected_webgl_vendor: Optional[str] = None,
        expected_ip_country: Optional[str] = None,
        exit_ip: Optional[str] = None,
        skip_checks: Optional[list[str]] = None,
    ) -> AuditReport:
        """Chạy toàn bộ audit checks. Trả về AuditReport."""
        # Merge skip_checks từ __init__ và per-call
        if skip_checks:
            self.skip_checks = self.skip_checks | set(skip_checks)
        t0 = time.perf_counter()
        checks: list[CheckResult] = []

        # Điều hướng tới blank page để chạy checks an toàn
        try:
            if page.url not in ("about:blank", "chrome://new-tab-page/"):
                await page.goto("about:blank", timeout=5000)
        except Exception:
            pass

        # 1. Fingerprint & navigator checks
        fp = await self._check_fingerprint(page)
        checks.extend(fp)

        # 2. Webdriver/automation flags
        wd = await self._check_webdriver(page)
        checks.append(wd)

        # 3. WebRTC leak
        if "webrtc" not in self.skip_checks:
            rtc = await self._check_webrtc(page, exit_ip)
            checks.append(rtc)

        # 4. Timezone coherence
        if expected_timezone and "timezone" not in self.skip_checks:
            tz = self._check_timezone(fp, expected_timezone)
            checks.append(tz)

        # 5. Locale/Language coherence
        if expected_locale and "locale" not in self.skip_checks:
            lc = self._check_locale(fp, expected_locale)
            checks.append(lc)

        # 6. WebGL persona match
        if expected_webgl_vendor and "webgl" not in self.skip_checks:
            wg = self._check_webgl(fp, expected_webgl_vendor)
            checks.append(wg)

        # 7. GeoIP match (cần mạng)
        if exit_ip and expected_ip_country and "geoip" not in self.skip_checks:
            geo = await self._check_geoip(exit_ip, expected_ip_country)
            checks.append(geo)

        # 8. curl_cffi TLS JA4 (nếu có)
        if "tls_ja4" not in self.skip_checks:
            tls = await self._check_tls_ja4()
            checks.append(tls)

        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        blocked = any(not c.ok and c.severity == "block" for c in checks) and self.block_on_fail
        passed = all(c.ok for c in checks if c.severity == "block")

        report = AuditReport(
            run_id=run_id,
            passed=passed,
            blocked=blocked,
            checks=checks,
            duration_ms=duration_ms,
        )

        # Ghi DB
        if self.db:
            await self.db.alog_preflight(
                run_id=run_id,
                passed=passed,
                checks=report.to_dict()["checks"],
                blocked=blocked,
                reason="; ".join(c.message for c in checks if not c.ok and c.severity == "block"),
            )

        # Log kết quả
        failed = [c for c in checks if not c.ok]
        if failed:
            for c in failed:
                log = LOGGER.warning if c.severity in ("warn","block") else LOGGER.debug
                log("preflight [%s] ❌ %s: %s (severity=%s)",
                    run_id, c.name, c.message, c.severity)
        if blocked:
            LOGGER.error("preflight: CHẶN campaign '%s' — %d vấn đề nghiêm trọng",
                         run_id, sum(1 for c in checks if not c.ok and c.severity=="block"))
        else:
            LOGGER.info("preflight: '%s' — %d/%d checks OK (%.0fms)",
                        run_id, sum(1 for c in checks if c.ok), len(checks), duration_ms)
        return report

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    async def _check_fingerprint(self, page: Any) -> list[CheckResult]:
        """Lấy fingerprint từ browser và trả về list CheckResult."""
        try:
            fp: dict[str, Any] = await page.evaluate(_JS_FINGERPRINT_CHECK)
        except Exception as exc:
            return [CheckResult("fingerprint_read", False, message=str(exc), severity="warn")]

        # Lưu fp vào attribute để các check khác dùng
        self._last_fp = fp
        results = [
            CheckResult("fingerprint_read", True, value={"canvas_hash": fp.get("canvas_hash")}),
        ]
        return results

    async def _check_webdriver(self, page: Any) -> CheckResult:
        try:
            wd: dict[str, Any] = await page.evaluate(_JS_WEBDRIVER_CHECK)
        except Exception as exc:
            return CheckResult("automation_flags", False, message=str(exc), severity="warn")

        flags = wd.get("automation_flags", {})
        leaks = [k for k, v in flags.items() if v and k != "webdriver"]
        webdriver_exposed = flags.get("webdriver", False)
        ok = not webdriver_exposed and not leaks
        msg = ""
        if webdriver_exposed:
            msg += "navigator.webdriver=true "
        if leaks:
            msg += f"CDP artifacts: {leaks}"
        return CheckResult(
            "automation_flags", ok,
            value=flags,
            severity="block" if not ok else "info",
            message=msg.strip(),
        )

    async def _check_webrtc(self, page: Any, exit_ip: Optional[str] = None) -> CheckResult:
        try:
            rtc: dict[str, Any] = await page.evaluate(_JS_WEBRTC_CHECK)
        except Exception as exc:
            return CheckResult("webrtc_leak", True, message=f"skip: {exc}", severity="info")

        leaked = rtc.get("leaked_ips", [])
        # Lọc bỏ IP của exit_ip (IP này OK để lộ)
        if exit_ip:
            leaked = [ip for ip in leaked if ip != exit_ip]
        # Lọc loopback / link-local
        leaked = [ip for ip in leaked
                  if not ip.startswith(("127.", "169.254.", "::1", "fe80:"))]
        ok = len(leaked) == 0
        return CheckResult(
            "webrtc_leak", ok,
            value={"leaked_ips": leaked},
            severity="block" if not ok else "info",
            message=f"Rò rỉ IP qua WebRTC: {leaked}" if not ok else "",
        )

    def _check_timezone(self, fp_checks: list[CheckResult], expected_tz: str) -> CheckResult:
        fp = getattr(self, "_last_fp", {})
        tz_offset = fp.get("timezone_offset")
        # Chuyển timezone name sang offset để so sánh đơn giản
        import datetime as _dt
        try:
            import zoneinfo
            expected_offset = int(
                _dt.datetime.now(_dt.timezone.utc)
                .astimezone(zoneinfo.ZoneInfo(expected_tz))
                .utcoffset().total_seconds() / 60
            )
            # JS getTimezoneOffset() trả về âm của offset chuẩn
            actual_offset = -(tz_offset or 0)
            ok = abs(actual_offset - expected_offset) <= 60
            return CheckResult(
                "timezone_coherence", ok,
                value={"actual_offset_min": actual_offset},
                expected={"expected_tz": expected_tz, "expected_offset_min": expected_offset},
                severity="block" if not ok else "info",
                message="" if ok else f"Timezone lệch: actual={actual_offset}min expected={expected_offset}min",
            )
        except Exception as exc:
            return CheckResult("timezone_coherence", True, message=f"skip: {exc}", severity="info")

    def _check_locale(self, fp_checks: list[CheckResult], expected_locale: str) -> CheckResult:
        fp = getattr(self, "_last_fp", {})
        actual = fp.get("language", "")
        ok = actual.lower().startswith(expected_locale.lower()[:5])
        return CheckResult(
            "locale_coherence", ok,
            value=actual, expected=expected_locale,
            severity="warn" if not ok else "info",
            message="" if ok else f"Locale lệch: actual={actual} expected={expected_locale}",
        )

    def _check_webgl(self, fp_checks: list[CheckResult], expected_vendor: str) -> CheckResult:
        fp = getattr(self, "_last_fp", {})
        actual = fp.get("webgl_vendor", "")
        ok = expected_vendor.lower() in actual.lower()
        return CheckResult(
            "webgl_persona", ok,
            value=actual, expected=expected_vendor,
            severity="warn" if not ok else "info",
            message="" if ok else f"WebGL vendor không khớp: '{actual}' ≠ '{expected_vendor}'",
        )

    async def _check_geoip(self, exit_ip: str, expected_country: str) -> CheckResult:
        """Tra cứu GeoIP của exit_ip và so sánh với expected_country."""
        try:
            import httpx
            api_key = os.environ.get("IP_API_KEY", "")
            url = f"http://ip-api.com/json/{exit_ip}?fields=status,country,countryCode,timezone"
            if api_key:
                url += f"&key={api_key}"
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(url)
            data = r.json()
            actual_cc = data.get("countryCode", "")
            ok = actual_cc.upper() == expected_country.upper()
            return CheckResult(
                "geoip_coherence", ok,
                value={"ip": exit_ip, "country": actual_cc, "timezone": data.get("timezone")},
                expected={"country": expected_country},
                severity="block" if not ok else "info",
                message="" if ok else f"GeoIP conflict: IP ở {actual_cc} nhưng expected {expected_country}",
            )
        except Exception as exc:
            return CheckResult("geoip_coherence", True, message=f"skip: {exc}", severity="info")

    async def _check_tls_ja4(self) -> CheckResult:
        """Kiểm tra curl_cffi có sẵn và trả về JA4 hash (ước tính)."""
        try:
            from curl_cffi.requests import AsyncSession  # type: ignore[import-not-found]
            async with AsyncSession() as s:
                r = await s.get("https://pypi.org/pypi/pip/json",
                                impersonate="chrome", timeout=5)
            ok = r.status_code == 200
            return CheckResult(
                "tls_curl_cffi", ok,
                value={"status": r.status_code, "impersonate": "chrome"},
                severity="warn" if not ok else "info",
                message="" if ok else f"curl_cffi TLS check thất bại: HTTP {r.status_code}",
            )
        except ImportError:
            return CheckResult("tls_curl_cffi", True, message="skip: curl_cffi chưa cài", severity="info")
        except Exception as exc:
            return CheckResult("tls_curl_cffi", True, message=f"skip: {exc}", severity="info")


# ---------------------------------------------------------------------------
# Quick audit function (dùng từ engine.py)
# ---------------------------------------------------------------------------

async def run_preflight(
    page: Any,
    db: Optional[Database],
    run_id: str,
    expected_timezone: Optional[str] = None,
    expected_locale: Optional[str] = None,
    expected_webgl_vendor: Optional[str] = None,
    exit_ip: Optional[str] = None,
    expected_ip_country: Optional[str] = None,
    block_on_fail: bool = True,
    skip_checks: Optional[list[str]] = None,
) -> AuditReport:
    """Entry point gọn cho engine.py."""
    auditor = PreFlightAuditor(db=db, block_on_fail=block_on_fail, skip_checks=skip_checks)
    return await auditor.audit(
        page=page, run_id=run_id,
        expected_timezone=expected_timezone,
        expected_locale=expected_locale,
        expected_webgl_vendor=expected_webgl_vendor,
        expected_ip_country=expected_ip_country,
        exit_ip=exit_ip,
    )
