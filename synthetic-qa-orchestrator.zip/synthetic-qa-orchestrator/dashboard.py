"""Web Dashboard cục bộ: FastAPI + Server-Sent Events.

Lưu ý: KHÔNG dùng `from __future__ import annotations` ở đây - FastAPI cần phân giải
kiểu của tham số (Request) từ globals của module."""
import asyncio
import contextlib
import json
from pathlib import Path
from typing import Any, Callable, Optional

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
except ImportError:  # dashboard là tùy chọn
    FastAPI = None  # type: ignore[assignment,misc]
    StaticFiles = None  # type: ignore[assignment,misc]

from config_loader import Paths
from database import Database
from events import EventBus
from reporting import build_report, to_csv, to_html, to_json

PAGE = """<!doctype html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>QA Orchestrator</title>
<style>
:root{--bg:#f6f7f4;--panel:#fff;--ink:#1d2421;--mute:#667068;--line:#dfe3dc;--accent:#1f6f5c;--bad:#b3392f;--warn:#9a6a00;color-scheme:light dark}
@media(prefers-color-scheme:dark){:root{--bg:#14181a;--panel:#1c2124;--ink:#e6eae5;--mute:#8f9a93;--line:#2c3337;--accent:#4fb39a;--bad:#ef7a6e;--warn:#e2b04a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 system-ui,-apple-system,Segoe UI,sans-serif}
header{display:flex;gap:1rem;align-items:center;flex-wrap:wrap;padding:1rem 1.25rem;border-bottom:1px solid var(--line)}
h1{font-size:1.05rem;margin:0;font-weight:650}h2{font-size:.95rem;margin:0 0 .6rem;font-weight:650}
#conn{margin-left:auto;color:var(--mute)}#conn.on{color:var(--accent)}
main{display:grid;gap:1rem;padding:1rem 1.25rem;grid-template-columns:repeat(auto-fit,minmax(min(100%,420px),1fr))}
section{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:1rem;min-width:0}
.wide{grid-column:1/-1}.tiles{display:flex;gap:1.5rem;flex-wrap:wrap}
.tile b{display:block;font-size:1.5rem;font-variant-numeric:tabular-nums}.tile span{color:var(--mute)}
.tbl{overflow-x:auto}table{border-collapse:collapse;width:100%}
th,td{padding:.3rem .6rem;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap;font-variant-numeric:tabular-nums}
th{color:var(--mute);font-weight:500}.ok{color:var(--accent)}.failed{color:var(--bad)}.skipped{color:var(--warn)}
#log{height:300px;overflow:auto;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;border:1px solid var(--line);border-radius:4px;padding:.5rem}
#log div{white-space:pre-wrap;word-break:break-word}.WARNING{color:var(--warn)}.ERROR{color:var(--bad)}
input,select,textarea,button{font:inherit;padding:.3rem .55rem;border:1px solid var(--line);border-radius:4px;background:var(--bg);color:var(--ink)}
textarea{width:100%;min-height:90px;font:12px/1.4 ui-monospace,Menlo,Consolas,monospace}
button{cursor:pointer;background:var(--accent);color:#fff;border:none}
button.ghost{background:transparent;color:var(--ink);border:1px solid var(--line)}
button.danger{background:var(--bad)}
button:disabled{opacity:.5;cursor:default}
a{color:var(--accent)}
.navbtn{background:transparent;color:var(--ink);border:1px solid var(--line);border-radius:5px;padding:.3rem .8rem}
.navbtn.active{background:var(--accent);color:#fff;border-color:var(--accent)}
.hidden{display:none !important}
label{display:block;font-size:.8rem;color:var(--mute);margin:.5rem 0 .2rem}
.row{display:flex;gap:.6rem;flex-wrap:wrap;align-items:end}
.row>div{flex:1;min-width:180px}
.card{border:1px solid var(--line);border-radius:6px;padding:.75rem;margin-bottom:.6rem}
.card .top{display:flex;justify-content:space-between;align-items:center;gap:.5rem}
.switch{position:relative;width:38px;height:20px;flex:none}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;inset:0;background:var(--line);border-radius:20px;cursor:pointer;transition:.15s}
.slider::before{content:"";position:absolute;width:16px;height:16px;left:2px;top:2px;background:#fff;border-radius:50%;transition:.15s}
input:checked+.slider{background:var(--accent)}input:checked+.slider::before{transform:translateX(18px)}
.drop{border:2px dashed var(--line);border-radius:6px;padding:2rem;text-align:center;color:var(--mute)}
.drop.over{border-color:var(--accent);color:var(--accent)}
.progress{height:8px;border-radius:4px;background:var(--line);overflow:hidden;margin:.4rem 0}
.progress>i{display:block;height:100%;background:var(--accent);width:0;transition:.2s}
.badge{display:inline-block;padding:.1rem .4rem;border-radius:4px;font-size:.75rem;background:var(--line)}
.msg{font-size:.85rem;margin-top:.4rem}
</style></head><body>
<header><h1>QA Orchestrator</h1>
<button class="navbtn active" id="nav-monitor">Giám sát</button>
<button class="navbtn" id="nav-admin">Quản trị</button>
<button class="navbtn" id="nav-caps">Khả năng</button>
<button class="navbtn" id="nav-flow">Flow Studio</button>
<button class="navbtn" id="nav-profiles">Profiles</button>
<button class="navbtn" id="nav-scheduler">Lịch & MCP</button>
<button class="navbtn" id="nav-vault">Vault & Cloud</button>
<button class="navbtn" id="nav-tools">Công cụ</button>
<button class="navbtn" id="nav-campaign">Campaign & AI</button>
<span id="mc"></span><span id="conn">đang kết nối…</span>
<span>Xuất báo cáo: <a href="/api/report?format=html">HTML</a> · <a href="/api/report?format=csv">CSV</a> · <a href="/api/report?format=json">JSON</a></span></header>
<div id="view-monitor">
<main>
<section class="wide"><h2>Tổng quan</h2><div class="tiles" id="tiles"></div></section>

<section class="wide">
  <h2>▶ Chạy Ngay (Run Now)</h2>
  <div class="row">
    <div><label>Scenario (để trống = tất cả scenario đang active)</label>
      <select id="rn-scenarios" multiple size="4" style="width:100%"></select></div>
    <div><label>Số lần lặp</label><input id="rn-iterations" type="number" value="1" min="1" style="width:100%"></div>
  </div>
  <p><button id="rn-run">▶ Chạy ngay</button> <span class="msg" id="rn-msg"></span></p>
</section>

<section class="wide">
  <h2>🖥 Cụm Trình Duyệt Đang Chạy (Live Browser Workers Grid)</h2>
  <p style="color:var(--mute);font-size:.85rem">Tự làm mới mỗi 2 giây khi tab này đang mở.</p>
  <div class="tbl"><table id="workers"></table></div>
  <div id="worker-snapshot-box" class="hidden" style="margin-top:.6rem">
    <p><b id="worker-snapshot-title"></b> <button class="ghost" id="worker-snapshot-close">✕ Đóng</button></p>
    <img id="worker-snapshot-img" style="max-width:100%;border:1px solid var(--line);border-radius:4px">
  </div>
</section>
<section><h2>Nhật ký theo luồng</h2>
<p><input id="flt" placeholder="Lọc theo mã luồng hoặc từ khóa" size="32"></p><div id="log"></div></section>
<section><h2>Gateway và circuit breaker</h2><div class="tbl"><table id="gw"></table></div><p id="br"></p></section>
<section><h2>Bộ định tuyến đa nhân (engine_router)</h2>
<p id="routerinfo" style="color:var(--mute)"></p><div class="tbl"><table id="hostprefs"></table></div></section>
<section class="wide"><h2>Hiệu năng theo kịch bản (ms)</h2><div class="tbl"><table id="perf"></table></div></section>
<section class="wide"><h2>Các lượt chạy gần nhất</h2><div class="tbl"><table id="runs"></table></div></section>
<section class="wide"><h2>Kiểm định gateway ngoại tuyến (gateway_validator)</h2>
<p style="color:var(--mute)">Kết quả của lần chạy <code>runner validate-gateways</code> gần nhất - không tự làm mới liên tục.</p>
<div class="tbl"><table id="gwcheck"></table></div></section>
</main>
</div>
<div id="view-admin" class="hidden">
<main>

<section class="wide"><h2>Trình quản lý nhân trình duyệt (Browser Runtime Settings)</h2>
<div class="row">
<div><label>Đường dẫn tệp thực thi tuỳ chỉnh</label>
<input id="bs-exe" placeholder="vd. browsers/chromium-1243/chrome-linux/chrome" style="width:100%">
<select id="bs-exe-pick" style="width:100%;margin-top:.3rem"><option value="">— chọn từ thư mục browsers/ —</option></select></div>
<div><label>CDP endpoint (trình duyệt đang chạy sẵn)</label>
<input id="bs-cdp" placeholder="http://localhost:9222" style="width:100%">
<button class="ghost" id="bs-test-cdp" style="margin-top:.3rem">Test Connection</button></div>
<div><label>Thư viện HTTP Client (Engine 1)</label><select id="bs-http" style="width:100%"></select></div>
</div>
<div class="row" style="margin-top:.6rem">
<div><label><input type="checkbox" id="bs-preflight-gate"> Cổng Kiểm Định An Toàn Bắt Buộc (Fail-Safe Gate)</label>
<p class="hint" style="margin:.2rem 0 0;font-size:.85em;opacity:.75">Tự động kiểm tra IP leak / webdriver flag / TLS trước mỗi phiên chạy trình duyệt. Nếu phát hiện rò rỉ, tự hủy phiên, đổi gateway và thử lại.</p></div>
<div><label><input type="checkbox" id="bs-analytics-verify"> Xác thực ghi nhận Analytics (GA4/Pixel)</label>
<p class="hint" style="margin:.2rem 0 0;font-size:.85em;opacity:.75">Lắng nghe request tới /g/collect và các endpoint đo lường tương tự; chỉ đánh dấu VERIFIED_SUCCESS khi nhận HTTP 200/204.</p></div>
</div>
<p><button id="bs-save">Lưu cấu hình trình duyệt</button> <span class="msg" id="bs-msg"></span></p>
</section>

<section class="wide"><h2>Plugins &amp; Extensions</h2>
<div class="drop" id="plugin-drop">Kéo-thả tệp .zip plugin vào đây (gồm manifest.json + main.py), hoặc
<label class="ghost" style="display:inline-block;cursor:pointer;padding:.3rem .6rem;border:1px solid var(--line);border-radius:4px">chọn tệp<input type="file" id="plugin-file" accept=".zip" class="hidden"></label></div>
<p class="msg" id="plugin-msg"></p>
<div id="plugin-cards"></div>

<h3 style="margin-top:1.2rem">Nhân Trình Duyệt Mã Nguồn Mở Miễn Phí</h3>
<div class="row">
<div><label>Kho GitHub (owner/repo)</label><input id="ce-repo" value="daijro/camoufox" style="width:100%"></div>
<div><label>Mẫu tên tệp (để trống = tự đoán theo OS máy chủ)</label><input id="ce-pattern" placeholder="vd. linux, win64" style="width:100%"></div>
</div>
<p><button id="ce-download">⬇️ Tải/Cập nhật Nhân Trình Duyệt Từ GitHub Release</button> <span class="msg" id="ce-msg"></span></p>
<div id="ce-status" style="font-size:.85em;opacity:.8"></div>
</section>

<section class="wide"><h2>Integrations &amp; APIs</h2>
<div id="integration-cards"></div>
<h2 style="margin-top:1rem">Thêm / sửa tích hợp</h2>
<div class="row">
<div><label>Tên</label><input id="in-name" placeholder="vd. slack-alerts"></div>
<div><label>Loại dịch vụ</label><select id="in-type"></select></div>
<div><label>Endpoint URL</label><input id="in-url" placeholder="https://hooks.slack.com/..." style="width:100%"></div>
</div>
<div class="row">
<div><label>API Key (để trống nếu không đổi khi sửa)</label><input id="in-key" type="password" style="width:100%"></div>
<div><label>Extra (JSON)</label><input id="in-extra" placeholder='{"channel":"#qa"}' style="width:100%"></div>
</div>
<p><button id="in-save">Verify &amp; Save</button> <span class="msg" id="in-msg"></span></p>
<p style="color:var(--mute);font-size:.8rem">Dùng trong workflow qua bước <code>{"action":"call_integration","name":"ten-tich-hop","payload":{...}}</code>,
thường đặt trong <code>on_error_fallback</code> của một bước khác. Chỉ <code>service_type=webhook</code> gọi được từ workflow hiện tại.</p>
</section>

<section class="wide"><h2>Trình nhập &amp; kiểm định mạng (Visual Gateway Manager)</h2>
<label>Nội dung gateways.txt (mỗi dòng: <code>vùng|protocol://user:pass@host:port</code>)</label>
<textarea id="gw-text" placeholder="vn|http://user:pass@1.2.3.4:8080"></textarea>
<p>
<label style="display:inline"><input type="radio" name="gw-mode" value="replace" checked> Thay thế toàn bộ</label>
&nbsp;<label style="display:inline"><input type="radio" name="gw-mode" value="append"> Nối thêm vào cuối</label>
&nbsp;<button class="ghost" id="gw-import">Import</button>
&nbsp;<button id="gw-check">Run Health &amp; Geo Check</button>
</p>
<div class="progress hidden" id="gw-progress"><i></i></div>
<p class="msg" id="gw-msg"></p>
<div class="tbl"><table id="gw-result"></table></div>
</section>

</main>
</div>

<div id="view-caps" class="hidden">
<main>

<section class="wide"><h2>Kiểm tra môi trường chạy (Runtime Capabilities)</h2>
<p style="color:var(--mute)">Tự động phát hiện các khả năng có sẵn trên máy chủ hiện tại. Nhấn <strong>Kiểm tra</strong> để chạy lại.</p>
<p><button id="caps-run">🔍 Kiểm tra ngay</button> <span class="msg" id="caps-msg"></span></p>
<div id="caps-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:.8rem;margin-top:.8rem"></div>
</section>

<section class="wide"><h2>HTTP Client Engine 1 — curl_cffi (TLS Fingerprint)</h2>
<div id="curl-status" style="margin-bottom:.6rem"></div>
<p style="color:var(--mute);font-size:.85rem">
  curl_cffi giả chữ ký TLS/JA3 và HTTP/2 ALPN theo trình duyệt thật (Chrome/Firefox/Safari).
  Khi sẵn sàng, Engine 1 sẽ dùng curl_cffi thay vì httpx để vượt qua các bộ lọc Cloudflare/Akamai.
</p>
<p><button id="curl-test">🧪 Test curl_cffi live</button> <span class="msg" id="curl-msg"></span></p>
<div id="curl-result"></div>
</section>

<section class="wide"><h2>JavaScript Runtime (JS Probe)</h2>
<div id="js-status" style="margin-bottom:.6rem"></div>
<p style="color:var(--mute);font-size:.85rem">
  Thực thi JS nhẹ (không cần trình duyệt) cho Proof-of-Work, HMAC, token signing.
  Backend ưu tiên: PyMiniRacer → Node.js → js2py.
</p>
<textarea id="js-script" rows="4" style="width:100%;font-family:monospace;font-size:.85rem"
>console.log(JSON.stringify({result: 2+2, ts: Date.now()}))</textarea>
<p><button id="js-run">▶ Chạy JS</button> <span class="msg" id="js-msg"></span></p>
<pre id="js-output" style="background:var(--bg);padding:.6rem;border-radius:4px;min-height:2rem;white-space:pre-wrap;font-size:.82rem"></pre>
</section>

<section class="wide"><h2>Tunnel Manager (SOCKS5 Sidecar)</h2>
<div id="tunnel-list-wrap">
<div class="tbl"><table id="tunnel-list">
  <thead><tr><th>Tên</th><th>Proxy URL</th><th>PID</th><th>Thời gian chạy</th><th>Trạng thái</th><th></th></tr></thead>
  <tbody id="tunnel-rows"><tr><td colspan="6" style="color:var(--mute)">Chưa có tunnel nào đang chạy.</td></tr></tbody>
</table></div>
</div>
<h3 style="margin-top:1rem">Khởi động tunnel mới</h3>
<div class="row">
  <div><label>Tên tunnel</label><input id="tn-name" placeholder="vd. my-proxy"></div>
  <div><label>Binary (xray / sing-box)</label><input id="tn-bin" placeholder="xray" value="xray"></div>
  <div><label>Đường dẫn config JSON</label><input id="tn-cfg" placeholder="runtime/tunnels/config.json" style="width:100%"></div>
</div>
<p><button id="tn-start">▶ Khởi động</button>
   <button class="ghost" id="tn-stop-all" style="margin-left:.5rem">⏹ Dừng tất cả</button>
   <span class="msg" id="tn-msg"></span></p>
</section>

<section class="wide"><h2>Bộ ghi &amp; phát lại tương tác (Trace Recorder / Replayer)</h2>
<p style="color:var(--mute);font-size:.85rem">
  Tải lên file <code>recorded_trace.json</code> để kiểm tra hoặc phát lại. Dùng action
  <code>{"action":"trace_record","output_path":"recorded_trace.json","duration_s":30}</code>
  trong scenario để ghi tự động.
</p>
<div class="row">
  <div>
    <label>Tải lên trace file (.json)</label>
    <input type="file" id="trace-file" accept=".json">
  </div>
  <div>
    <label>Jitter thời gian σ (ms)</label>
    <input id="trace-sigma-t" type="number" value="50" min="0" max="500" style="width:100%">
  </div>
  <div>
    <label>Jitter toạ độ σ (px)</label>
    <input id="trace-sigma-c" type="number" value="3" min="0" max="20" style="width:100%">
  </div>
</div>
<p>
  <button id="trace-inspect">🔍 Kiểm tra trace</button>
  <button class="ghost" id="trace-dl-jitter" style="margin-left:.5rem">⬇ Tải trace đã jitter</button>
  <span class="msg" id="trace-msg"></span>
</p>
<pre id="trace-preview" style="background:var(--bg);padding:.6rem;border-radius:4px;min-height:3rem;white-space:pre-wrap;font-size:.8rem;max-height:300px;overflow:auto"></pre>
</section>

<section class="wide"><h2>Widget &amp; Media QA — Hướng dẫn tích hợp</h2>
<p style="color:var(--mute);font-size:.85rem">Thêm vào mảng <code>steps</code> trong scenario để kiểm thử iframe và media player:</p>
<pre style="background:var(--bg);padding:.8rem;border-radius:4px;font-size:.8rem;overflow-x:auto">{
  "steps": [
    <span style="color:var(--accent)">// Kiểm tra tất cả iframe trên trang</span>
    { "action": "widget_qa", "config": { "timeout_ms": 10000, "check_clicks": true } },

    <span style="color:var(--accent)">// Đo buffering video HTML5 trong 15 giây</span>
    { "action": "media_qa", "config": { "selector": "video", "retention_window_s": 15 } },

    <span style="color:var(--accent)">// Đo YouTube Embedded Player</span>
    { "action": "media_qa", "config": { "youtube": true, "retention_window_s": 10 } },

    <span style="color:var(--accent)">// Phát lại trace đã ghi với jitter tự nhiên</span>
    { "action": "trace_replay", "trace_path": "recorded_trace.json",
      "config": { "time_sigma_ms": 50, "speed_factor": 1.0 } },

    <span style="color:var(--accent)">// Chạy JS probe (Proof-of-Work) trước khi vào trang</span>
    { "action": "js_probe", "probe_key": "pow:example.com",
      "script": "...", "ttl_s": 3600 },

    <span style="color:var(--accent)">// Dùng SOCKS5 tunnel cho BrowserContext tiếp theo</span>
    { "action": "use_tunnel", "tunnel": "my-proxy",
      "config_path": "runtime/tunnels/config.json", "binary": "xray" }
  ]
}</pre>
</section>

<section class="wide"><h2>🌐 Kiểm tra mạng thực tế (Live Network Check)</h2>
<p style="color:var(--mute);font-size:.85rem">
  Kiểm tra kết nối thực tế từ máy chủ đến các host quan trọng. Phát hiện block DNS, timeout, lỗi SSL.
</p>
<p>
  <button id="net-check-run">🌐 Kiểm tra mạng ngay</button>
  <span class="msg" id="net-check-msg"></span>
</p>
<div id="net-check-result" style="margin-top:.6rem"></div>
</section>

<section class="wide"><h2>🎭 Live Browser Test (Playwright Chromium)</h2>
<p style="color:var(--mute);font-size:.85rem">
  Khởi động Chromium headless thật, truy cập URL và đo thời gian tải. Xác nhận Engine 2 (Browser) hoạt động.
</p>
<p>
  <button id="browser-live-run">🎭 Chạy Live Browser Test</button>
  <span class="msg" id="browser-live-msg"></span>
</p>
<div id="browser-live-result"></div>
</section>

<section class="wide"><h2>🔐 TLS Fingerprint Comparison</h2>
<p style="color:var(--mute);font-size:.85rem">
  So sánh curl_cffi (Chrome TLS/JA3) vs httpx (Python TLS) — quan trọng để vượt qua Cloudflare/Akamai.
</p>
<p>
  <button id="tls-fp-run">🔐 So sánh TLS Fingerprint</button>
  <span class="msg" id="tls-fp-msg"></span>
</p>
<div id="tls-fp-result"></div>
</section>

<section class="wide"><h2>📦 Playwright Browsers — Trạng thái cài đặt</h2>
<p style="color:var(--mute);font-size:.85rem">
  Kiểm tra Chromium / Firefox / WebKit đã được cài đặt chưa và hướng dẫn cài thêm.
</p>
<p>
  <button id="pw-install-run">📦 Kiểm tra browsers</button>
  <span class="msg" id="pw-install-msg"></span>
</p>
<div id="pw-install-result"></div>
</section>

<section class="wide"><h2>🖥️ Desktop App Launcher (PyWebView)</h2>
<p style="color:var(--mute);font-size:.85rem">
  Trạng thái chế độ Desktop Native. Khi chạy qua <code>python app_launcher.py</code>,
  ứng dụng mở trong cửa sổ gốc không có thanh địa chỉ — trông như phần mềm thật.
</p>
<div id="desktop-status" style="margin:.6rem 0;padding:.7rem 1rem;border-radius:6px;background:var(--bg);border:1px solid var(--line)">
  <span id="desktop-mode-badge" style="display:inline-block;padding:.25rem .7rem;border-radius:4px;font-size:.82rem;background:var(--line);color:var(--mute)">
    Đang chạy trong trình duyệt thường
  </span>
  <span id="desktop-info" style="margin-left:.8rem;font-size:.85rem;color:var(--mute)"></span>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;margin-top:.5rem">
  <div style="padding:.8rem;border:1px solid var(--line);border-radius:6px">
    <strong>Khởi động Desktop App</strong>
    <pre style="background:transparent;padding:.4rem 0;font-size:.82rem;color:var(--accent)">python app_launcher.py</pre>
    <small style="color:var(--mute)">Mở cửa sổ PyWebView native (1-click, không cần browser)</small>
  </div>
  <div style="padding:.8rem;border:1px solid var(--line);border-radius:6px">
    <strong>Headless Server Mode</strong>
    <pre style="background:transparent;padding:.4rem 0;font-size:.82rem;color:var(--accent)">python app_launcher.py --no-gui</pre>
    <small style="color:var(--mute)">Chỉ chạy server, không mở cửa sổ (dùng cho Linux headless)</small>
  </div>
</div>
<p style="margin-top:.8rem">
  <button id="pywebview-check">🔍 Kiểm tra PyWebView</button>
  <span class="msg" id="pywebview-msg"></span>
</p>
<div id="pywebview-result"></div>
</section>

</main>
</div>

<!-- ══ View: Flow Studio ════════════════════════════════════════════════ -->
<div id="view-flow" class="hidden">
<main>
<section class="wide">
  <h2>Session Envelope — Vỏ Bọc Môi Trường Phiên</h2>
  <p style="color:var(--mute);font-size:.85rem">Cấu hình chung áp dụng cho kịch bản đang chỉnh sửa. Lưu kèm vào JSON khi bấm "Lưu JSON" bên dưới - các field này map trực tiếp vào <code>scenario.engine</code>/<code>scenario.bandwidth</code> đã dùng, phần còn lại lưu vào <code>scenario.raw.session_envelope</code>.</p>
  <div class="row">
    <div><label>Nhân thực thi (Engine Mode)</label>
      <select id="env-engine" style="width:100%">
        <option value="auto">Auto (Multi-Engine Router)</option>
        <option value="chromium">Chromium (Playwright)</option>
        <option value="firefox">Firefox / Camoufox (Custom Binary)</option>
        <option value="http">HTTP thuần (curl_cffi, không trình duyệt)</option>
      </select>
    </div>
    <div><label>Kiến trúc đa luồng (Pool Mode)</label>
      <select id="env-pool" style="width:100%">
        <option value="isolated">Full Process Isolation</option>
        <option value="multiplex">Context Multiplexing (tiết kiệm RAM)</option>
      </select>
    </div>
  </div>
  <div class="row" style="margin-top:.5rem">
    <div><label><input type="checkbox" id="env-preflight" checked> Cổng Kiểm Định An Toàn (Mandatory Pre-Flight Audit)</label></div>
    <div><label><input type="checkbox" id="env-xvfb"> Tự động Xvfb trên Linux VPS (Auto Xvfb Provisioner)</label></div>
    <div><label><input type="checkbox" id="env-bandwidth"> Tiết kiệm băng thông CDP (~70%)</label></div>
  </div>
  <div class="row" style="margin-top:.5rem">
    <div><label>Tỷ trọng thiết bị: Mobile <b id="env-mobile-val">75</b>% / Desktop <b id="env-desktop-val">25</b>%</label>
      <input id="env-mobile" type="range" min="0" max="100" value="75" style="width:100%"></div>
  </div>
</section>

<section class="wide">
  <h2>Khởi Tạo Kịch Bản — 3 Cách Không Cần Biết Code</h2>
  <div style="display:flex;gap:1.5rem;flex-wrap:wrap">
    <div style="flex:1;min-width:260px">
      <h3 style="margin-top:0">1️⃣ Kho Mẫu Dựng Sẵn</h3>
      <select id="bp-select" style="width:100%;margin-bottom:.4rem"></select>
      <textarea id="bp-urls" placeholder="Dán danh sách URL, mỗi dòng một URL" style="width:100%;height:60px"></textarea>
      <p><button id="bp-apply">📋 Dùng mẫu này</button> <span class="msg" id="bp-msg"></span></p>
    </div>
    <div style="flex:1;min-width:260px">
      <h3 style="margin-top:0">2️⃣ Ghi Thao Tác Thực Tế</h3>
      <input id="rec-url" placeholder="URL bắt đầu ghi" style="width:100%;margin-bottom:.4rem">
      <p><button id="rec-start">🔴 Bắt đầu ghi</button> <button class="ghost" id="rec-stop">⏹ Dừng &amp; Chuyển thành Node</button></p>
      <p class="msg" id="rec-msg"></p>
    </div>
    <div style="flex:1;min-width:260px">
      <h3 style="margin-top:0">3️⃣ Trợ Lý AI Vẽ Sơ Đồ</h3>
      <textarea id="nl-desc" placeholder="VD: Làm nóng cookie 10s, vào trang đích qua Google, đọc 40s rồi click bài liên quan" style="width:100%;height:60px"></textarea>
      <p><button id="nl-generate">✨ Sinh sơ đồ bằng Ollama</button></p>
      <p class="msg" id="nl-msg"></p>
    </div>
  </div>
</section>

<section class="wide">
  <h2>Visual Flow Studio — Trình thiết kế kịch bản kéo-thả</h2>
  <div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:.8rem;align-items:center">
    <select id="flow-scenario-sel" style="min-width:200px"></select>
    <button id="flow-load">Tải kịch bản</button>
    <button id="flow-save" class="ghost">💾 Lưu JSON</button>
    <button id="flow-clear" class="ghost">🗑 Xoá canvas</button>
    <button id="flow-add-goto">+ Goto URL</button>
    <button id="flow-add-click">+ Click</button>
    <button id="flow-add-type">+ Type</button>
    <button id="flow-add-scroll">+ Scroll</button>
    <button id="flow-add-wait">+ Wait</button>
    <button id="flow-add-assert">+ Assert</button>
    <button id="flow-add-branch">+ Branch (2 dây ra)</button>
    <button id="flow-add-loop">+ Conditional Loop</button>
    <span class="msg" id="flow-msg"></span>
  </div>
  <details open style="margin-bottom:.6rem">
    <summary style="cursor:pointer;color:var(--mute);font-size:.85rem">🧩 Bảng 12 Khối Kỹ Thuật Chuyên Biệt (Specialized Node Palette)</summary>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.5rem">
      <button class="ghost" id="flow-add-referrer_goto">🔗 Referrer Chain</button>
      <button class="ghost" id="flow-add-prime_session">🔥 Session Pre-Warm</button>
      <button class="ghost" id="flow-add-human_click">🤚 Kinematic Human</button>
      <button class="ghost" id="flow-add-widget_qa">🎞 Widget/Media QA</button>
      <button class="ghost" id="flow-add-sync_start">🪟 Multi-Window Sync</button>
      <button class="ghost" id="flow-add-hybrid_handoff">⚡ Hybrid Handoff</button>
      <button class="ghost" id="flow-add-js_probe">🧪 JS Sandbox Probe</button>
      <button class="ghost" id="flow-add-classify_failure">🛟 Fallback/Challenge</button>
      <button class="ghost" id="flow-add-analytics_verify">📊 Analytics Verify</button>
      <button class="ghost" id="flow-add-ai_form_fill">🤖 AI Form Filler</button>
    </div>
  </details>
  <div id="drawflow" style="height:520px;border:1px solid var(--line);border-radius:6px;background:var(--bg);position:relative;overflow:hidden"></div>
  <details style="margin-top:.8rem">
    <summary style="cursor:pointer;color:var(--mute);font-size:.85rem">📋 JSON output (copy để dùng trong scenarios.json)</summary>
    <pre id="flow-json-out" style="background:var(--bg);padding:.6rem;border-radius:4px;font-size:.78rem;max-height:200px;overflow:auto;white-space:pre-wrap;margin-top:.4rem"></pre>
  </details>
</section>

<section class="wide">
  <h2>Visual Element Picker — Chọn phần tử bằng chuột</h2>
  <p style="color:var(--mute);font-size:.85rem">Mở trang trong browser thật, di chuột để highlight, click để lấy CSS/ARIA selector.</p>
  <div class="row">
    <div style="flex:3"><label>URL trang cần inspect</label>
      <input id="picker-url" placeholder="https://example.com" style="width:100%"></div>
    <div><label>Timeout (giây)</label>
      <input id="picker-timeout" type="number" value="90" min="10" max="300" style="width:100%"></div>
  </div>
  <p>
    <button id="picker-start">🎯 Mở Picker</button>
    <button class="ghost" id="picker-stop" style="margin-left:.5rem">⏹ Huỷ</button>
    <span class="msg" id="picker-msg"></span>
  </p>
  <div id="picker-result" style="display:none;border:1px solid var(--accent);border-radius:6px;padding:.8rem;margin-top:.6rem">
    <div style="display:flex;gap:1rem;flex-wrap:wrap">
      <div><label>CSS Selector</label><input id="picker-css" readonly style="width:280px;font-family:monospace"></div>
      <div><label>ARIA Label</label><input id="picker-aria" readonly style="width:200px"></div>
      <div><label>Inner Text</label><input id="picker-text" readonly style="width:200px"></div>
      <div><label>XPath</label><input id="picker-xpath" readonly style="width:280px;font-family:monospace"></div>
      <div><label>Confidence</label><input id="picker-conf" readonly style="width:80px"></div>
    </div>
    <p style="margin-top:.6rem">
      <button id="picker-add-click">➕ Thêm Click step</button>
      <button class="ghost" id="picker-add-type" style="margin-left:.4rem">➕ Thêm Type step</button>
      <button class="ghost" id="picker-copy-css" style="margin-left:.4rem">📋 Copy CSS</button>
    </p>
  </div>
</section>
</main>
</div>

<!-- ══ View: Profiles & Personas ════════════════════════════════════════ -->
<div id="view-profiles" class="hidden">
<main>
<section class="wide">
  <h2>Profiles & Personas — Quản lý hồ sơ trình duyệt</h2>
  <div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-bottom:.8rem;align-items:center">
    <input id="profiles-filter" placeholder="Lọc theo tên / trạng thái…" style="min-width:200px">
    <select id="profiles-status-filter">
      <option value="">Tất cả trạng thái</option>
      <option value="new">Mới tạo</option>
      <option value="warm">Đang làm nóng</option>
      <option value="ready">Sẵn sàng</option>
    </select>
    <button id="profiles-refresh">🔄 Làm mới</button>
    <button id="profiles-warm-selected" class="ghost">🔥 Warm các profile đã chọn</button>
  </div>
  <div class="tbl"><table id="profiles-table">
    <thead><tr>
      <th><input type="checkbox" id="profiles-sel-all"></th>
      <th>Profile ID</th><th>Trust Score</th><th>URLs thăm</th>
      <th>Cookies</th><th>Trạng thái</th><th>Lần warm cuối</th><th></th>
    </tr></thead>
    <tbody id="profiles-tbody">
      <tr><td colspan="8" style="color:var(--mute);text-align:center">Đang tải…</td></tr>
    </tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Session Warming — Nuôi dưỡng phiên định kỳ</h2>
  <p style="color:var(--mute);font-size:.85rem">Điều hướng profile qua nhiều trang trong N ngày để xây dựng cookie/cache tự nhiên.</p>
  <div class="row">
    <div><label>Số ngày warm</label>
      <input id="warm-days" type="number" value="3" min="1" max="30" style="width:100%"></div>
    <div><label>URLs mỗi ngày</label>
      <input id="warm-urls" type="number" value="5" min="1" max="20" style="width:100%"></div>
    <div><label>URL target (tuỳ chọn)</label>
      <input id="warm-target" placeholder="https://target.com" style="width:100%"></div>
    <div><label>Song song tối đa</label>
      <input id="warm-concurrency" type="number" value="2" min="1" max="5" style="width:100%"></div>
  </div>
  <p>
    <button id="warm-run">🔥 Bắt đầu Warming Campaign</button>
    <span class="msg" id="warm-msg"></span>
  </p>
  <div id="warm-progress" style="display:none">
    <div class="progress"><i id="warm-bar"></i></div>
    <div id="warm-status" style="font-size:.85rem;color:var(--mute)"></div>
  </div>
</section>

<section class="wide">
  <h2>Device Personas — Hồ sơ thiết bị</h2>
  <div class="tbl"><table id="personas-table">
    <thead><tr><th>ID</th><th>OS</th><th>Browser</th><th>Device</th><th>Locale</th><th>Timezone</th><th></th></tr></thead>
    <tbody id="personas-tbody">
      <tr><td colspan="7" style="color:var(--mute)">Đang tải…</td></tr>
    </tbody>
  </table></div>
</section>
</main>
</div>

<!-- ══ View: Scheduler & MCP ════════════════════════════════════════════ -->
<div id="view-scheduler" class="hidden">
<main>
<section class="wide">
  <h2>Lịch chạy trong tuần (Weekly Schedule)</h2>
  <p style="color:var(--mute);font-size:.85rem">Lịch hiển thị các kịch bản được lên lịch chạy theo ngày/giờ. Cấu hình trong tab Quản trị → Lịch trình.</p>
  <div id="schedule-grid" style="display:grid;grid-template-columns:60px repeat(7,1fr);gap:2px;font-size:.8rem">
    <!-- render bởi JS -->
  </div>
</section>

<section class="wide">
  <h2>MCP Server Status</h2>
  <p style="color:var(--mute);font-size:.85rem">Trạng thái kết nối Local MCP Server cho tích hợp AI agent.</p>
  <div id="mcp-status-wrap">
    <div class="tiles" id="mcp-tiles">
      <div class="tile"><span>Trạng thái MCP</span><b id="mcp-status-val">–</b></div>
      <div class="tile"><span>Requests hôm nay</span><b id="mcp-req-val">–</b></div>
      <div class="tile"><span>Uptime</span><b id="mcp-uptime-val">–</b></div>
    </div>
  </div>
  <div id="mcp-tools-wrap" style="margin-top:.8rem">
    <h3 style="font-size:.9rem">Tools đã đăng ký</h3>
    <div id="mcp-tools-list" style="display:flex;flex-wrap:wrap;gap:.4rem"></div>
  </div>
</section>

<section class="wide">
  <h2>Self-Healing Selector Log</h2>
  <p style="color:var(--mute);font-size:.85rem">Log các lần tự sửa selector khi kịch bản phát hiện phần tử bị đổi.</p>
  <div class="tbl"><table id="healing-table">
    <thead><tr><th>Thời điểm</th><th>Scenario</th><th>Selector cũ</th><th>Selector mới</th><th>Chiến lược</th><th>Confidence</th></tr></thead>
    <tbody id="healing-tbody">
      <tr><td colspan="6" style="color:var(--mute)">Chưa có lần heal nào.</td></tr>
    </tbody>
  </table></div>
</section>
</main>
</div>

<!-- ══ View: Vault & Cloud (Phase 7) ════════════════════════════════════ -->
<div id="view-vault" class="hidden">
<main>

<section class="wide">
  <h2>Cloud Browser Usage — Chi phí &amp; thống kê phiên đám mây</h2>
  <div class="tiles" id="cloud-tiles">
    <div class="tile"><span>Tổng phiên (24h)</span><b id="cloud-sessions">–</b></div>
    <div class="tile"><span>Thời gian (24h)</span><b id="cloud-duration">–</b></div>
    <div class="tile"><span>Chi phí ước tính</span><b id="cloud-cost">–</b></div>
    <div class="tile"><span>Tỷ lệ thành công</span><b id="cloud-ok-rate">–</b></div>
  </div>
  <div class="tbl" style="margin-top:.6rem"><table id="cloud-table">
    <thead><tr><th>Provider</th><th>Thời điểm</th><th>Thời gian (s)</th><th>Chi phí ($)</th><th>Trạng thái</th><th>Lỗi</th></tr></thead>
    <tbody id="cloud-tbody"><tr><td colspan="6" style="color:var(--mute)">Đang tải…</td></tr></tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Failure Taxonomy — Phân loại nguyên nhân lỗi</h2>
  <div id="failure-chart" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:.5rem;margin-bottom:.8rem"></div>
  <div class="tbl"><table>
    <thead><tr><th>Scenario</th><th>Failure Type</th><th>Số lần</th><th>Lần cuối</th></tr></thead>
    <tbody id="failure-tbody"><tr><td colspan="4" style="color:var(--mute)">Đang tải…</td></tr></tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Alert History — Lịch sử thông báo</h2>
  <div class="row" style="margin-bottom:.6rem">
    <div><label>Kênh thông báo</label>
      <select id="alert-channel">
        <option value="telegram">Telegram</option>
        <option value="discord">Discord</option>
        <option value="slack">Slack</option>
        <option value="webhook">Webhook</option>
      </select></div>
    <div><label>Test message</label>
      <input id="alert-msg" value="🧪 Test alert từ QA Dashboard" style="width:300px"></div>
    <div style="align-self:flex-end">
      <button id="alert-test">📤 Gửi test alert</button>
      <span class="msg" id="alert-msg-status"></span>
    </div>
  </div>
  <div class="tbl"><table>
    <thead><tr><th>Thời điểm</th><th>Kênh</th><th>Scenario</th><th>Nội dung</th><th>Trạng thái</th></tr></thead>
    <tbody id="alert-tbody"><tr><td colspan="5" style="color:var(--mute)">Đang tải…</td></tr></tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Credential Vault — Kho thông tin xác thực mã hóa</h2>
  <div style="display:flex;gap:.5rem;margin-bottom:.6rem">
    <button id="vault-tab-accounts" class="ghost" onclick="showVaultTab('accounts')">👤 Tài khoản</button>
    <button id="vault-tab-cookies" class="ghost" onclick="showVaultTab('cookies')">🍪 Cookies</button>
    <button id="vault-tab-captcha" class="ghost" onclick="showVaultTab('captcha')">🔑 Captcha Keys</button>
  </div>

  <div id="vault-panel-accounts">
    <div class="row">
      <div><label>Tên</label><input id="va-name" placeholder="user_vn_01"></div>
      <div><label>Username</label><input id="va-user"></div>
      <div><label>Password</label><input id="va-pass" type="password"></div>
      <div><label>Email</label><input id="va-email"></div>
      <div><label>Profile ID</label><input id="va-profile"></div>
    </div>
    <p><button id="va-save">💾 Lưu tài khoản</button> <span class="msg" id="va-msg"></span></p>
    <div class="tbl"><table>
      <thead><tr><th>Tên</th><th>Tags</th><th>Ngày tạo</th><th></th></tr></thead>
      <tbody id="va-tbody"></tbody>
    </table></div>
  </div>

  <div id="vault-panel-cookies" style="display:none">
    <div class="row">
      <div><label>Profile ID</label><input id="vc-profile" placeholder="profile_01"></div>
    </div>
    <label>Paste cookie JSON (từ EditThisCookie / browser export)</label>
    <textarea id="vc-json" rows="5" style="width:100%;font-family:monospace;font-size:.82rem" placeholder='[{"name":"session","value":"abc","domain":"example.com","path":"/"}]'></textarea>
    <p><button id="vc-import">📥 Import cookies</button> <span class="msg" id="vc-msg"></span></p>
    <div class="tbl"><table>
      <thead><tr><th>Profile :: Domain</th><th>Ngày import</th></tr></thead>
      <tbody id="vc-tbody"></tbody>
    </table></div>
  </div>

  <div id="vault-panel-captcha" style="display:none">
    <div class="row">
      <div><label>Service</label>
        <select id="vk-name">
          <option value="2captcha">2Captcha</option>
          <option value="capsolver">CapSolver</option>
          <option value="anticaptcha">Anti-Captcha</option>
        </select></div>
      <div><label>API Key</label><input id="vk-key" type="password" style="width:300px"></div>
    </div>
    <p><button id="vk-save">💾 Lưu API Key</button> <span class="msg" id="vk-msg"></span></p>
    <div class="tbl"><table>
      <thead><tr><th>Service</th><th>Ngày cập nhật</th></tr></thead>
      <tbody id="vk-tbody"></tbody>
    </table></div>
  </div>
</section>

<section class="wide">
  <h2>Referrer Chain — Thiết kế chuỗi điều hướng</h2>
  <p style="color:var(--mute);font-size:.85rem">Cấu hình nguồn lưu lượng và xem trước step JSON để thêm vào scenario.</p>
  <div class="row">
    <div><label>Nguồn lưu lượng</label>
      <select id="ref-source">
        <option value="direct">Direct</option>
        <option value="google" selected>Google Search</option>
        <option value="bing">Bing Search</option>
        <option value="facebook">Facebook</option>
        <option value="twitter">Twitter/X</option>
        <option value="email">Email (Gmail)</option>
        <option value="youtube">YouTube</option>
        <option value="reddit">Reddit</option>
        <option value="news">Hacker News</option>
      </select></div>
    <div><label>URL đích</label><input id="ref-url" placeholder="https://example.com" style="width:280px"></div>
    <div><label>Từ khóa tìm kiếm</label><input id="ref-query" placeholder="example site review"></div>
  </div>
  <div class="row">
    <div><label>utm_source</label><input id="ref-utm-source" placeholder="google"></div>
    <div><label>utm_medium</label><input id="ref-utm-medium" placeholder="organic"></div>
    <div><label>utm_campaign</label><input id="ref-utm-campaign" placeholder="q4_2026"></div>
  </div>
  <p><button id="ref-preview">👁 Xem trước step JSON</button></p>
  <pre id="ref-json" style="background:var(--bg);padding:.6rem;border-radius:4px;font-size:.8rem;min-height:3rem;white-space:pre-wrap"></pre>
</section>

<section class="wide">
  <h2>Remote DB Sync — Đồng bộ lên đám mây</h2>
  <div class="tiles" id="remote-tiles">
    <div class="tile"><span>MongoDB Atlas</span><b id="remote-mongo">–</b></div>
    <div class="tile"><span>Supabase</span><b id="remote-supa">–</b></div>
  </div>
  <p style="color:var(--mute);font-size:.82rem;margin-top:.4rem">
    Cấu hình MONGODB_URI và/hoặc SUPABASE_URL+SUPABASE_KEY trong file <code>.env</code> rồi khởi động lại.
  </p>
  <div class="tbl" style="margin-top:.6rem"><table>
    <thead><tr><th>Bảng</th><th>Lần sync cuối</th></tr></thead>
    <tbody id="remote-sync-tbody"><tr><td colspan="2" style="color:var(--mute)">Đang tải…</td></tr></tbody>
  </table></div>
  <p><button id="remote-sync-now">🔄 Sync ngay</button> <span class="msg" id="remote-msg"></span></p>
</section>

</main>
</div>

<!-- ══ View: Tools (Phase 8) ═════════════════════════════════════════════ -->
<div id="view-tools" class="hidden">
<main>

<section class="wide">
  <h2>System Resource Monitor — CPU / RAM realtime</h2>
  <div class="tiles" id="sys-tiles">
    <div class="tile"><span>CPU</span><b id="sys-cpu">–</b></div>
    <div class="tile"><span>RAM dùng</span><b id="sys-ram">–</b></div>
    <div class="tile"><span>RAM trống</span><b id="sys-ram-free">–</b></div>
    <div class="tile"><span>Disk trống</span><b id="sys-disk">–</b></div>
  </div>
  <div style="margin-top:.6rem;display:flex;gap:.5rem;flex-wrap:wrap;align-items:center">
    <label style="font-size:.85rem;color:var(--mute)">Tự động làm mới:</label>
    <input type="checkbox" id="sys-auto" checked>
    <span class="msg" id="sys-warn" style="color:var(--warn)"></span>
  </div>
  <div id="sys-chart-wrap" style="margin-top:.6rem">
    <canvas id="sys-chart" height="80" style="width:100%;border:1px solid var(--line);border-radius:4px;background:var(--bg)"></canvas>
  </div>
  <p style="margin-top:.6rem">
    <button id="sys-autostart-check">🔍 Trạng thái Autostart</button>
    <button class="ghost" id="sys-autostart-on" style="margin-left:.4rem">✅ Bật Autostart</button>
    <button class="ghost" id="sys-autostart-off" style="margin-left:.4rem">❌ Tắt Autostart</button>
    <span class="msg" id="sys-autostart-msg"></span>
  </p>
</section>

<section class="wide">
  <h2>UA Registry — Danh sách User-Agent</h2>
  <p style="color:var(--mute);font-size:.85rem">Danh sách UA mới nhất phân loại theo OS/Browser. Nhấn Cập nhật để lấy từ nguồn công khai.</p>
  <div style="display:flex;gap:.5rem;margin-bottom:.6rem;flex-wrap:wrap;align-items:center">
    <select id="ua-os-filter">
      <option value="">Tất cả OS</option>
      <option value="Windows">Windows</option>
      <option value="macOS">macOS</option>
      <option value="Linux">Linux</option>
      <option value="Android">Android</option>
      <option value="iOS">iOS</option>
    </select>
    <select id="ua-browser-filter">
      <option value="">Tất cả Browser</option>
      <option value="Chrome">Chrome</option>
      <option value="Firefox">Firefox</option>
      <option value="Safari">Safari</option>
      <option value="Edge">Edge</option>
    </select>
    <button id="ua-refresh">🔄 Cập nhật từ web</button>
    <button class="ghost" id="ua-load">📋 Tải danh sách</button>
    <span class="msg" id="ua-msg"></span>
  </div>
  <div class="tiles" id="ua-summary-tiles" style="margin-bottom:.6rem"></div>
  <div class="tbl"><table id="ua-table">
    <thead><tr><th>OS</th><th>Browser</th><th>Version</th><th>User-Agent String</th><th></th></tr></thead>
    <tbody id="ua-tbody"><tr><td colspan="5" style="color:var(--mute)">Nhấn "Tải danh sách" để xem.</td></tr></tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Proxy Parser — Chuẩn hoá &amp; Dedup hàng loạt</h2>
  <p style="color:var(--mute);font-size:.85rem">Paste proxy theo bất kỳ định dạng: <code>ip:port</code>, <code>ip:port:user:pass</code>, <code>socks5://user:pass@host:port</code>, v.v.</p>
  <div class="row">
    <div>
      <label>Protocol mặc định</label>
      <select id="proxy-proto">
        <option value="http">HTTP</option>
        <option value="https">HTTPS</option>
        <option value="socks5">SOCKS5</option>
        <option value="socks4">SOCKS4</option>
      </select>
    </div>
    <div>
      <label>Format xuất</label>
      <select id="proxy-out-fmt">
        <option value="url">URL đầy đủ</option>
        <option value="ip:port">ip:port</option>
        <option value="ip:port:user:pass">ip:port:user:pass</option>
      </select>
    </div>
  </div>
  <label>Proxy list đầu vào (nhiều dòng, nhiều định dạng)</label>
  <textarea id="proxy-input" rows="8" style="width:100%;font-family:monospace;font-size:.82rem"
    placeholder="192.168.1.1:8080&#10;socks5://user:pass@10.0.0.1:1080&#10;103.1.2.3:3128:admin:secret"></textarea>
  <p>
    <button id="proxy-parse-btn">🔍 Phân tích &amp; Dedup</button>
    <button class="ghost" id="proxy-copy-out" style="margin-left:.4rem">📋 Copy kết quả</button>
    <button class="ghost" id="proxy-import-gw" style="margin-left:.4rem">➕ Import vào Gateways</button>
    <span class="msg" id="proxy-msg"></span>
  </p>
  <div id="proxy-stats" style="display:none;margin:.4rem 0;font-size:.85rem;color:var(--mute)"></div>
  <label>Kết quả đã chuẩn hoá</label>
  <textarea id="proxy-output" rows="8" readonly style="width:100%;font-family:monospace;font-size:.82rem;background:var(--bg)"></textarea>
</section>

<section class="wide">
  <h2>Hybrid Browser→HTTP Handoff — Thông tin</h2>
  <p style="color:var(--mute);font-size:.85rem">
    Sau khi browser giải quyết JS challenge, tự động trích xuất cookies+UA rồi bàn giao cho
    curl_cffi để gửi N requests tiếp theo không cần giữ browser mở — tăng tốc đáng kể với
    các kịch bản cần gửi nhiều API request sau login.
  </p>
  <pre id="hybrid-info" style="background:var(--bg);padding:.8rem;border-radius:4px;font-size:.8rem">Đang tải…</pre>
</section>

<section class="wide">
  <h2>Phase 11 — Tự Động Hóa Môi Trường Máy Chủ Linux</h2>

  <h3>Tỷ Trọng Thiết Bị (Mobile / Desktop)</h3>
  <p style="color:var(--mute);font-size:.85rem">Phân bổ tỷ lệ thiết bị cho các kịch bản random/campaign. Khi chọn Mobile, hệ thống tự bật <code>has_touch</code>/<code>is_mobile</code> trong Playwright và đổi chữ ký giao thức curl_cffi sang trình duyệt di động tương ứng.</p>
  <div class="row">
    <div><label>Mobile: <b id="dm-mobile-val">75</b>%</label><input id="dm-mobile" type="range" min="0" max="100" value="75" style="width:100%"></div>
    <div><label>Desktop: <b id="dm-desktop-val">25</b>%</label><input id="dm-desktop" type="range" min="0" max="100" value="25" disabled style="width:100%"></div>
  </div>
  <p><button id="dm-save">Lưu tỷ trọng thiết bị</button> <span class="msg" id="dm-msg"></span></p>

  <h3 style="margin-top:1.2rem">Virtual Display Mode (Xvfb - chỉ Linux)</h3>
  <p style="color:var(--mute);font-size:.85rem">Khi bật và chạy headless=false trên Linux, tự khởi tạo màn hình ảo <code>Xvfb</code> thay vì cần màn hình vật lý/VNC.</p>
  <div class="row">
    <div><label><input type="checkbox" id="vd-enabled"> Bật Virtual Display Mode</label></div>
    <div><label>Độ phân giải</label>
      <select id="vd-res" style="width:100%">
        <option value="1920x1080">1920×1080</option>
        <option value="1366x768">1366×768</option>
        <option value="1280x720">1280×720</option>
      </select>
    </div>
  </div>
  <p><button id="vd-save">Lưu cấu hình Virtual Display</button> <span class="msg" id="vd-msg"></span></p>
  <div id="vd-status" style="font-size:.85em;opacity:.8"></div>

  <h3 style="margin-top:1.2rem">Chuẩn Hóa Phông Chữ Đa Nền Tảng</h3>
  <p style="color:var(--mute);font-size:.85rem">Tải Noto Sans + Liberation Sans vào thư mục phông cục bộ của ứng dụng (không đổi fontconfig hệ thống gốc của VPS) - giúp hiển thị văn bản đồng nhất giữa các máy chủ khác nhau.</p>
  <p><button id="font-provision">🔤 Chuẩn hóa Phông chữ Đa nền tảng</button> <span class="msg" id="font-msg"></span></p>

  <h3 style="margin-top:1.2rem">Bộ Lọc Chất Lượng Cổng Kết Nối</h3>
  <div class="row">
    <div><label><input type="checkbox" id="gwq-datacenter"> Chỉ dùng IP Viễn thông/Dân cư (loại bỏ Datacenter ASN)</label></div>
    <div><label><input type="checkbox" id="gwq-header"> Bật kiểm tra ẩn danh header (Elite Header Check)</label></div>
  </div>
  <div class="row">
    <div><label>Độ trễ tối đa: <b id="gwq-latency-val">Không giới hạn</b></label>
      <input id="gwq-latency" type="range" min="0" max="3000" step="100" value="0" style="width:100%"></div>
  </div>
  <p><button id="gwq-save">Lưu bộ lọc chất lượng</button> <span class="msg" id="gwq-msg"></span></p>
</section>

</main>
</div>

<!-- ══ View: Campaign & AI (Phase 9) ═════════════════════════════════════ -->
<div id="view-campaign" class="hidden">
<main>

<section class="wide">
  <h2>Resource Governor — Trạng thái điều tiết</h2>
  <div class="tiles" id="gov-tiles">
    <div class="tile"><span>Active contexts</span><b id="gov-active">–</b></div>
    <div class="tile"><span>Effective limit</span><b id="gov-limit">–</b></div>
    <div class="tile"><span>Trạng thái</span><b id="gov-state">–</b></div>
  </div>
  <p><button id="gov-refresh">🔄 Làm mới</button></p>
</section>

<section class="wide">
  <h2>Storm Mode — Đồ thị tải Ramp-up / Storm / Cool-down</h2>
  <p style="color:var(--mute);font-size:.85rem">Thiết kế đồ thị tăng tải để đo ngưỡng chịu tải máy chủ, có khởi động chậm và giảm dần.</p>
  <div class="row">
    <div><label>Warm-up (giây)</label><input id="storm-warmup" type="number" value="60" style="width:100%"></div>
    <div><label>Storm Peak (giây)</label><input id="storm-peak" type="number" value="300" style="width:100%"></div>
    <div><label>Cool-down (giây)</label><input id="storm-cooldown" type="number" value="60" style="width:100%"></div>
  </div>
  <div class="row">
    <div><label>Concurrency tối thiểu</label><input id="storm-min" type="number" value="1" style="width:100%"></div>
    <div><label>Concurrency đỉnh</label><input id="storm-max" type="number" value="10" style="width:100%"></div>
    <div><label>Đường cong</label>
      <select id="storm-curve">
        <option value="linear">Linear</option>
        <option value="sine">Sine (mượt)</option>
        <option value="exponential">Exponential (dốc)</option>
      </select></div>
  </div>
  <p><button id="storm-preview-btn">📈 Xem trước đồ thị</button> <span class="msg" id="storm-msg"></span></p>
  <canvas id="storm-chart" height="140" style="width:100%;border:1px solid var(--line);border-radius:4px;background:var(--bg)"></canvas>
  <h3 style="margin-top:1rem;font-size:.9rem">Lịch sử Storm Runs</h3>
  <div class="tbl"><table>
    <thead><tr><th>Scenario</th><th>Workspace</th><th>Submitted</th><th>Thời gian</th><th>Đỉnh</th><th>Lúc</th></tr></thead>
    <tbody id="storm-history-tbody"><tr><td colspan="6" style="color:var(--mute)">Chưa có lịch sử.</td></tr></tbody>
  </table></div>
</section>

<section class="wide">
  <h2>Autopilot Rewriter — Biến thể kịch bản bằng AI cục bộ</h2>
  <div id="ollama-status-badge" style="margin-bottom:.6rem"></div>
  <div class="row">
    <div><label>Mức độ biến đổi</label>
      <select id="auto-level">
        <option value="light">Light — thêm dwell nhẹ</option>
        <option value="medium" selected>Medium — shuffle + dwell</option>
        <option value="heavy">Heavy — shuffle toàn bộ + bỏ bớt</option>
      </select></div>
    <div><label>Dùng LLM (Ollama)</label>
      <select id="auto-use-llm">
        <option value="true">Có (fallback offline nếu không có Ollama)</option>
        <option value="false">Không — chỉ offline mutation</option>
      </select></div>
  </div>
  <label>Steps gốc (JSON array, lấy từ Flow Studio hoặc paste tay)</label>
  <textarea id="auto-steps-in" rows="6" style="width:100%;font-family:monospace;font-size:.8rem"
    placeholder='[{"action":"goto","url":"https://example.com"},{"action":"scroll","delta_y":300},{"action":"wait","duration_ms":1000}]'></textarea>
  <p><button id="auto-preview-btn">🎲 Sinh biến thể</button> <span class="msg" id="auto-msg"></span></p>
  <label>Kết quả biến thể</label>
  <pre id="auto-steps-out" style="background:var(--bg);padding:.6rem;border-radius:4px;font-size:.78rem;max-height:300px;overflow:auto;white-space:pre-wrap"></pre>

  <h3 style="margin-top:1rem;font-size:.9rem">Spintax Tester</h3>
  <div class="row">
    <div style="flex:3"><input id="spintax-in" placeholder="{Xin chào|Chào bạn|Hey there} và {đọc thêm|xem chi tiết}" style="width:100%"></div>
    <div><button id="spintax-test">🎲 Expand</button></div>
  </div>
  <p id="spintax-out" style="font-style:italic;color:var(--accent)"></p>
</section>

<section class="wide">
  <h2>Redirect &amp; Popup Blocker — Cấu hình</h2>
  <p style="color:var(--mute);font-size:.85rem">Thêm vào step JSON: <code>{"action":"block_redirects","allowed_domains":[...]}</code></p>
  <div class="row">
    <div style="flex:3"><label>Allowed domains (cách nhau dấu phẩy)</label>
      <input id="blocker-domains" placeholder="example.com, app.example.com" style="width:100%"></div>
  </div>
  <p><button id="blocker-gen">📋 Tạo step JSON</button></p>
  <pre id="blocker-json" style="background:var(--bg);padding:.6rem;border-radius:4px;font-size:.8rem;white-space:pre-wrap"></pre>
</section>

<section class="wide">
  <h2>Workspaces — Quản lý đa dự án</h2>
  <div class="row">
    <div><label>ID workspace</label><input id="ws-id" placeholder="project-alpha"></div>
    <div><label>Tên</label><input id="ws-name" placeholder="Dự án Alpha"></div>
    <div><label>Màu</label><input id="ws-color" type="color" value="#1f6f5c"></div>
  </div>
  <p><button id="ws-create">➕ Tạo workspace</button> <span class="msg" id="ws-msg"></span></p>
  <div class="tbl"><table id="ws-table">
    <thead><tr><th>ID</th><th>Tên</th><th>Màu</th><th></th></tr></thead>
    <tbody id="ws-tbody"><tr><td colspan="4" style="color:var(--mute)">Đang tải…</td></tr></tbody>
  </table></div>

  <h3 style="margin-top:1rem;font-size:.9rem">Xuất / Nhập .qa-bundle</h3>
  <div class="row">
    <div><label>Workspace để xuất</label>
      <select id="ws-export-sel"></select></div>
    <div style="align-self:flex-end"><button id="ws-export-btn">📦 Xuất bundle</button></div>
  </div>
  <p id="ws-export-result" style="font-size:.85rem;color:var(--mute)"></p>
  <div class="row" style="margin-top:.6rem">
    <div style="flex:3"><label>Đường dẫn .qa-bundle để nhập</label>
      <input id="ws-import-path" placeholder="/path/to/project.qa-bundle" style="width:100%"></div>
    <div style="align-self:flex-end"><button id="ws-import-btn">📥 Nhập bundle</button></div>
  </div>
  <p id="ws-import-result" style="font-size:.85rem;color:var(--mute)"></p>
</section>

</main>
</div>

<script>
const $=id=>document.getElementById(id), fmt=v=>v==null?'–':v;
function row(cells,tag='td'){const tr=document.createElement('tr');cells.forEach(c=>{const e=document.createElement(tag);if(c&&c.html!==undefined){e.innerHTML=c.html}else if(c&&c.cls){e.className=c.cls;e.textContent=c.t}else e.textContent=c;tr.appendChild(e)});return tr}
function fill(t,head,rows){t.replaceChildren(row(head,'th'),...rows.map(r=>row(r)))}
async function refresh(){
 const [rep,runs,st]=await Promise.all(['/api/report','/api/runs?limit=40','/api/status'].map(u=>fetch(u).then(r=>r.json())));
 $('tiles').replaceChildren(...[['Tổng lượt',rep.total_runs],['Thành công',rep.ok],['Lỗi',rep.failed]].map(([l,v])=>{const d=document.createElement('div');d.className='tile';d.innerHTML='<b></b><span></span>';d.firstChild.textContent=v;d.lastChild.textContent=l;return d}));
 $('mc').textContent='Đồng thời tối đa: '+st.max_concurrency;
 fill($('perf'),['Kịch bản','URL','Lượt','Lỗi','TTFB p50','p95','p99','FCP p50','p95','LCP p50','p95','p99'],rep.items.map(i=>[i.scenario_id,i.url,i.runs,i.failed,fmt(i.ttfb_p50),fmt(i.ttfb_p95),fmt(i.ttfb_p99),fmt(i.fcp_p50),fmt(i.fcp_p95),fmt(i.lcp_p50),fmt(i.lcp_p95),fmt(i.lcp_p99)]));
 fill($('runs'),['Lúc','Kịch bản','URL','Engine','Kết quả','HTTP','TTFB','FCP','LCP','Gateway','Exit IP','Analytics'],runs.map(r=>[r.finished_at.slice(11,19),r.scenario_id,r.url,fmt(r.engine),{t:r.status,cls:r.status},fmt(r.http_status),fmt(r.ttfb_ms),fmt(r.fcp_ms),fmt(r.lcp_ms),fmt(r.gateway),fmt(r.exit_ip),
   r.analytics_verified==null?fmt(null):{t:r.analytics_verified==='VERIFIED_SUCCESS'?'✅ VERIFIED':'⚠️ NOT_VERIFIED',cls:r.analytics_verified==='VERIFIED_SUCCESS'?'ok':'failed'}]));
 fill($('gw'),['Gateway','Vùng','Trạng thái','Độ trễ'],st.gateways.map(g=>[g.gateway,g.region,{t:g.healthy?'tốt':'mất kết nối',cls:g.healthy?'ok':'failed'},g.latency_ms==null?'–':g.latency_ms+' ms']));
 $('br').textContent=Object.keys(st.breakers).length?'Breaker: '+Object.entries(st.breakers).map(([k,v])=>k+' = '+v).join('; '):'Chưa có breaker nào được tạo.';
 $('routerinfo').textContent='Chế độ context: '+st.context_mode+' · Engine mặc định: '+st.router_default_engine+' · Request đã chặn (phiên này): '+bwBlocked+(bwBytes?' (~'+fmtBytes(bwBytes)+' ước lượng, cần bật measure_bytes)':'');
 fill($('hostprefs'),['Host','Leo thang tới','Lý do','Số lần','Cập nhật'],st.host_preferences.map(h=>[h.host,h.engine,h.reason||'–',h.escalations,h.updated_at.slice(0,19)]));
 fill($('gwcheck'),['Gateway','Vùng','Trạng thái','ms','Exit IP','Quốc gia','Thành phố','ISP','Timezone','Locale','Lúc kiểm tra'],
   st.gateway_checks.map(g=>[g.gateway,g.region,{t:g.healthy?'tốt':'lỗi',cls:g.healthy?'ok':'failed'},fmt(g.latency_ms),fmt(g.exit_ip),fmt(g.country),fmt(g.city),fmt(g.isp),fmt(g.timezone_id),fmt(g.locale),g.checked_at.slice(0,19)]));
}
let timer,bwBlocked=0,bwBytes=0;const later=()=>{clearTimeout(timer);timer=setTimeout(refresh,400)};
function fmtBytes(n){if(!n)return'0 B';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return n.toFixed(1)+' '+u[i]}
const log=$('log'),flt=$('flt');
function addLog(e){const d=document.createElement('div');d.className=e.level;d.dataset.t=((e.task||'')+' '+e.message).toLowerCase();d.textContent=`${e.ts} ${e.task?'['+e.task+'] ':''}${e.message}`;d.hidden=!d.dataset.t.includes(flt.value.toLowerCase());log.appendChild(d);while(log.childElementCount>600)log.firstChild.remove();log.scrollTop=log.scrollHeight}
flt.oninput=()=>[...log.children].forEach(d=>d.hidden=!d.dataset.t.includes(flt.value.toLowerCase()));
const es=new EventSource('/events');
es.onopen=()=>{$('conn').textContent='đang nhận dữ liệu trực tiếp';$('conn').className='on'};
es.onerror=()=>{$('conn').textContent='mất kết nối, đang thử lại…';$('conn').className=''};
es.onmessage=m=>{const e=JSON.parse(m.data);
 if(e.kind==='log')addLog(e);
 else if(e.kind==='run'){if(e.bandwidth_blocked)bwBlocked+=e.bandwidth_blocked;if(e.bandwidth_bytes)bwBytes+=e.bandwidth_bytes;later()}
 else if(e.kind==='gateway_check_progress')onGatewayProgress(e);
};
refresh();setInterval(refresh,15000);

// ── Phase 12: Live Browser Workers Grid + Run Now ───────────────────────────
async function loadWorkers(){
  try{
    const r=await fetch('/api/admin/workers/live').then(x=>x.json());
    const rows=(r.workers||[]).map(w=>[
      w.task_id, w.scenario_id, w.profile_id, w.url, w.current_step,
      w.started_at?w.started_at.slice(11,19):'',
      {html:`<button class="ghost small" onclick="_viewWorkerSnapshot('${w.task_id}')">👁 Xem</button> `+
            `<button class="ghost small" onclick="_stopWorker('${w.task_id}')">⏹ Dừng</button>`}
    ]);
    fill($('workers'),['Worker','Scenario','Profile','URL','Bước hiện tại','Bắt đầu lúc','Thao tác'],rows);
  }catch(e){}
}
window._viewWorkerSnapshot=async(taskId)=>{
  $('worker-snapshot-box').classList.remove('hidden');
  $('worker-snapshot-title').textContent='Đang tải ảnh chụp worker '+taskId+'…';
  try{
    const r=await fetch(`/api/admin/workers/${taskId}/snapshot`).then(x=>x.json());
    if(r.ok){
      $('worker-snapshot-img').src='data:image/png;base64,'+r.image_base64;
      $('worker-snapshot-title').textContent='Worker '+taskId+' — ảnh chụp trực tiếp';
    }else{
      $('worker-snapshot-title').textContent='Lỗi: '+r.error;
    }
  }catch(e){$('worker-snapshot-title').textContent='Lỗi: '+e.message}
};
window._stopWorker=async(taskId)=>{
  if(!confirm('Dừng worker '+taskId+'?'))return;
  try{await fetch(`/api/admin/workers/${taskId}/stop`,{method:'POST'});loadWorkers()}catch(e){}
};
$('worker-snapshot-close').onclick=()=>$('worker-snapshot-box').classList.add('hidden');
async function _loadRunNowScenarios(){
  try{
    const r=await fetch('/api/admin/scenarios').then(x=>x.json());
    $('rn-scenarios').replaceChildren(...(r.items||[]).map(sc=>{
      const op=document.createElement('option');op.value=sc.id;op.textContent=sc.id+(sc.active?'':' (tắt)');return op;
    }));
  }catch(e){}
}
_loadRunNowScenarios();
$('rn-run').onclick=async()=>{
  const ids=[...$('rn-scenarios').selectedOptions].map(o=>o.value);
  const btn=$('rn-run');btn.disabled=true;$('rn-msg').textContent='Đang kích hoạt…';$('rn-msg').style.color='var(--mute)';
  try{
    const r=await fetch('/api/admin/run-now',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({scenario_ids:ids.length?ids:null,iterations:+$('rn-iterations').value||1})}).then(x=>x.json());
    if(r.ok){$('rn-msg').textContent=`✅ Đã xếp ${r.tasks_queued} tác vụ cho ${r.scenarios.length} scenario.`;$('rn-msg').style.color='var(--accent)'}
    else{$('rn-msg').textContent='Lỗi: '+(r.detail||JSON.stringify(r));$('rn-msg').style.color='var(--bad)'}
  }catch(e){$('rn-msg').textContent='Lỗi: '+e.message;$('rn-msg').style.color='var(--bad)'}
  btn.disabled=false;
};
loadWorkers();setInterval(loadWorkers,2000);

/* ===================== Quản trị (mục 4.1-4.4) ===================== */
const viewMonitor=$('view-monitor'),viewAdmin=$('view-admin'),viewCaps=$('view-caps');
const viewFlow=$('view-flow'),viewProfiles=$('view-profiles'),viewScheduler=$('view-scheduler');
const viewVault=$('view-vault'),viewTools=$('view-tools'),viewCampaign=$('view-campaign');
const navM=$('nav-monitor'),navA=$('nav-admin'),navC=$('nav-caps');
const navF=$('nav-flow'),navP=$('nav-profiles'),navS=$('nav-scheduler');
const navV=$('nav-vault'),navT=$('nav-tools'),navCp=$('nav-campaign');
const allViews=[viewMonitor,viewAdmin,viewCaps,viewFlow,viewProfiles,viewScheduler,viewVault,viewTools,viewCampaign];
const allNavs=[navM,navA,navC,navF,navP,navS,navV,navT,navCp];
function switchTab(show,active){
  allViews.forEach(v=>v.classList.add('hidden'));
  allNavs.forEach(n=>n.classList.remove('active'));
  show.classList.remove('hidden'); active.classList.add('active');
}
navM.onclick=()=>switchTab(viewMonitor,navM);
navA.onclick=()=>{switchTab(viewAdmin,navA);loadAdmin()};
navC.onclick=()=>{switchTab(viewCaps,navC);initCaps()};
navF.onclick=()=>{switchTab(viewFlow,navF);initFlowStudio()};
navP.onclick=()=>{switchTab(viewProfiles,navP);loadProfiles()};
navS.onclick=()=>{switchTab(viewScheduler,navS);loadScheduler()};
navV.onclick=()=>{switchTab(viewVault,navV);loadVaultCloud()};
navT.onclick=()=>{switchTab(viewTools,navT);initTools()};
navCp.onclick=()=>{switchTab(viewCampaign,navCp);initCampaign()};

// ══ CAMPAIGN & AI (Phase 9) ══════════════════════════════════════════════
let campaignInited=false;
async function initCampaign(){
  if(!campaignInited){campaignInited=true;}
  loadGovernorStatus();
  loadOllamaStatus();
  loadStormHistory();
  loadWorkspaces();
}

// ── Resource Governor ──────────────────────────────────────────────────
async function loadGovernorStatus(){
  try{
    const r=await api('/governor/status');
    if(r.active!==undefined){
      $('gov-active').textContent=r.active;
      $('gov-limit').textContent=r.effective_limit;
      $('gov-state').textContent=r.paused?'⏸ Tạm dừng':r.throttled?'⚠️ Throttled':'✅ Bình thường';
      $('gov-state').style.color=r.paused?'var(--bad)':r.throttled?'var(--warn)':'var(--accent)';
    }else{
      $('gov-state').textContent=r.message||'N/A';
    }
  }catch(e){}
}
$('gov-refresh').onclick=loadGovernorStatus;

// ── Storm Mode ─────────────────────────────────────────────────────────
$('storm-preview-btn').onclick=async()=>{
  const body={
    warmup_s:parseFloat($('storm-warmup').value)||60,
    storm_s:parseFloat($('storm-peak').value)||300,
    cooldown_s:parseFloat($('storm-cooldown').value)||60,
    min_concurrency:parseInt($('storm-min').value)||1,
    max_concurrency:parseInt($('storm-max').value)||10,
    ramp_curve:$('storm-curve').value,
  };
  $('storm-msg').textContent='Đang tính…';
  try{
    const r=await api('/storm/preview',{method:'POST',body:JSON.stringify(body)});
    _drawStormChart(r.curve,body.max_concurrency);
    $('storm-msg').textContent=`✅ Tổng thời gian: ${r.total_s}s`;
    $('storm-msg').style.color='var(--accent)';
  }catch(e){$('storm-msg').textContent='Lỗi: '+e.message;$('storm-msg').style.color='var(--bad)'}
};
function _drawStormChart(curve,maxC){
  const cv=$('storm-chart');
  const ctx=cv.getContext('2d');
  const W=cv.clientWidth||600,H=140;
  cv.width=W;cv.height=H;
  ctx.clearRect(0,0,W,H);
  if(!curve||!curve.length)return;
  const maxT=curve[curve.length-1].t;
  ctx.beginPath();ctx.strokeStyle='#1f6f5c';ctx.lineWidth=2;ctx.fillStyle='rgba(31,111,92,.15)';
  ctx.moveTo(0,H);
  curve.forEach((p,i)=>{
    const x=p.t/maxT*W, y=H-(p.concurrency/maxC)*H*0.9-5;
    i===0?ctx.lineTo(x,y):ctx.lineTo(x,y);
  });
  ctx.lineTo(W,H);ctx.closePath();ctx.fill();
  ctx.beginPath();
  curve.forEach((p,i)=>{
    const x=p.t/maxT*W, y=H-(p.concurrency/maxC)*H*0.9-5;
    i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
  });
  ctx.strokeStyle='#1f6f5c';ctx.lineWidth=2;ctx.stroke();
  // Phase labels
  ctx.font='10px system-ui';ctx.fillStyle='var(--mute,#888)';
  ctx.fillText('Warm-up',4,12);
  ctx.fillText('Storm',W*0.4,12);
  ctx.fillText('Cool-down',W*0.8,12);
}
async function loadStormHistory(){
  try{
    const r=await api('/storm/history');
    $('storm-history-tbody').innerHTML=(r.runs||[]).map(x=>`<tr>
      <td>${x.scenario_id||'–'}</td><td>${x.workspace_id||'–'}</td>
      <td>${x.total_submitted}</td><td>${x.duration_s}s</td>
      <td>${x.peak_concurrency}</td>
      <td style="color:var(--mute);font-size:.8rem">${x.started_at?.slice(0,16)||'–'}</td>
    </tr>`).join('')||'<tr><td colspan="6" style="color:var(--mute)">Chưa có lịch sử.</td></tr>';
  }catch(e){}
}

// ── Autopilot Rewriter ─────────────────────────────────────────────────
async function loadOllamaStatus(){
  try{
    const r=await api('/autopilot/ollama-status');
    $('ollama-status-badge').innerHTML=r.running
      ?`<span class="badge" style="background:var(--accent);color:#fff">✅ Ollama đang chạy (${r.models.length} models: ${r.models.join(', ')})</span>`
      :`<span class="badge" style="background:var(--warn);color:#000">⚠️ Ollama không chạy — sẽ dùng offline mutation</span>`;
  }catch(e){}
}
$('auto-preview-btn').onclick=async()=>{
  let steps;
  try{ steps=JSON.parse($('auto-steps-in').value); }
  catch(e){ $('auto-msg').textContent='JSON không hợp lệ';return; }
  $('auto-msg').textContent='Đang sinh biến thể…';
  try{
    const r=await api('/autopilot/preview',{method:'POST',body:JSON.stringify({
      steps, level:$('auto-level').value,
      use_llm:$('auto-use-llm').value==='true',
    })});
    $('auto-steps-out').textContent=JSON.stringify(r.steps,null,2);
    $('auto-msg').textContent=r.used_llm?'✅ Dùng Ollama LLM':'✅ Offline mutation';
    $('auto-msg').style.color='var(--accent)';
  }catch(e){$('auto-msg').textContent='Lỗi: '+e.message;$('auto-msg').style.color='var(--bad)'}
};
$('spintax-test').onclick=async()=>{
  const text=$('spintax-in').value;
  if(!text)return;
  try{
    const r=await api('/autopilot/spintax',{method:'POST',body:JSON.stringify({text})});
    $('spintax-out').textContent='→ '+r.expanded;
  }catch(e){}
};

// ── Redirect Blocker ───────────────────────────────────────────────────
$('blocker-gen').onclick=()=>{
  const domains=$('blocker-domains').value.split(',').map(s=>s.trim()).filter(Boolean);
  $('blocker-json').textContent=JSON.stringify({
    action:'block_redirects', allowed_domains:domains,
    block_popups:true, block_new_tabs:true, log_blocked:true,
  },null,2);
};

// ── Workspaces ─────────────────────────────────────────────────────────
async function loadWorkspaces(){
  try{
    const r=await api('/workspaces');
    $('ws-tbody').innerHTML=(r.workspaces||[]).map(w=>`<tr>
      <td><code>${w.id}</code></td><td>${w.name}</td>
      <td><span style="display:inline-block;width:16px;height:16px;border-radius:3px;background:${w.color}"></span></td>
      <td><button class="ghost" style="font-size:.8rem" onclick="deleteWorkspace('${w.id}')">🗑</button></td>
    </tr>`).join('')||'<tr><td colspan="4" style="color:var(--mute)">Chưa có workspace nào.</td></tr>';
    $('ws-export-sel').innerHTML=(r.workspaces||[]).map(w=>`<option value="${w.id}">${w.name}</option>`).join('');
  }catch(e){}
}
$('ws-create').onclick=async()=>{
  const id=$('ws-id').value.trim(), name=$('ws-name').value.trim(), color=$('ws-color').value;
  if(!id||!name){$('ws-msg').textContent='Nhập ID và Tên';return;}
  try{
    await api('/workspaces',{method:'POST',body:JSON.stringify({id,name,color})});
    $('ws-msg').textContent='✅ Đã tạo';$('ws-msg').style.color='var(--accent)';
    loadWorkspaces();
  }catch(e){$('ws-msg').textContent='Lỗi: '+e.message;$('ws-msg').style.color='var(--bad)'}
};
async function deleteWorkspace(id){
  if(!confirm('Xoá workspace '+id+'?'))return;
  await api('/workspaces/'+id,{method:'DELETE'});loadWorkspaces();
}
$('ws-export-btn').onclick=async()=>{
  const id=$('ws-export-sel').value; if(!id)return;
  $('ws-export-result').textContent='Đang xuất…';
  try{
    const r=await api('/workspaces/'+id+'/export',{method:'POST'});
    $('ws-export-result').textContent=`✅ Đã xuất: ${r.path} (${r.size_kb}KB)`;
  }catch(e){$('ws-export-result').textContent='Lỗi: '+e.message}
};
$('ws-import-btn').onclick=async()=>{
  const p=$('ws-import-path').value.trim(); if(!p)return;
  $('ws-import-result').textContent='Đang nhập…';
  try{
    const r=await api('/workspaces/import',{method:'POST',body:JSON.stringify({bundle_path:p,merge:true})});
    $('ws-import-result').textContent=`✅ Đã nhập ${r.result.scenarios_added} scenarios vào workspace '${r.result.workspace_id}'`;
    loadWorkspaces();
  }catch(e){$('ws-import-result').textContent='Lỗi: '+e.message}
};

// ══ TOOLS (Phase 8) ══════════════════════════════════════════════════════
let toolsInited=false, sysInterval=null;
const sysCpuHistory=[], sysRamHistory=[];
const SYS_MAX_HIST=60;

async function initTools(){
  if(toolsInited)return; toolsInited=true;
  loadSystemMetrics();
  loadHybridInfo();
  loadPhase11Settings();
  $('sys-auto').onchange=()=>{
    if($('sys-auto').checked) sysInterval=setInterval(loadSystemMetrics,3000);
    else clearInterval(sysInterval);
  };
  if($('sys-auto').checked) sysInterval=setInterval(loadSystemMetrics,3000);
}

async function loadSystemMetrics(){
  try{
    const r=await api('/system/metrics');
    if(r.error){$('sys-warn').textContent='⚠️ '+r.error;return;}
    $('sys-cpu').textContent=r.cpu_pct+'%';
    $('sys-cpu').style.color=r.cpu_pct>80?'var(--bad)':r.cpu_pct>60?'var(--warn)':'var(--accent)';
    $('sys-ram').textContent=r.ram_pct+'%';
    $('sys-ram').style.color=r.ram_pct>85?'var(--bad)':r.ram_pct>70?'var(--warn)':'var(--accent)';
    $('sys-ram-free').textContent=r.ram_available_mb+'MB';
    $('sys-disk').textContent=r.disk_free_gb+'GB';
    if(r.ram_pct>85) $('sys-warn').textContent='⚠️ RAM >85% — nguy cơ OOM';
    else $('sys-warn').textContent='';
    // Mini chart (canvas)
    sysCpuHistory.push(r.cpu_pct); sysRamHistory.push(r.ram_pct);
    if(sysCpuHistory.length>SYS_MAX_HIST){sysCpuHistory.shift();sysRamHistory.shift();}
    _drawSysChart();
  }catch(e){}
}

function _drawSysChart(){
  const cv=$('sys-chart');
  if(!cv) return;
  const ctx=cv.getContext('2d');
  const W=cv.clientWidth||600, H=80;
  cv.width=W; cv.height=H;
  ctx.clearRect(0,0,W,H);
  const drawLine=(data,color)=>{
    if(!data.length)return;
    ctx.beginPath(); ctx.strokeStyle=color; ctx.lineWidth=1.5;
    data.forEach((v,i)=>{
      const x=i/(SYS_MAX_HIST-1)*W, y=H-(v/100)*H;
      i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    });
    ctx.stroke();
  };
  drawLine(sysCpuHistory,'#f90');
  drawLine(sysRamHistory,'#39c');
  // Legend
  ctx.font='10px system-ui'; ctx.fillStyle='#f90'; ctx.fillText('CPU',4,12);
  ctx.fillStyle='#39c'; ctx.fillText('RAM',34,12);
}

// Autostart
$('sys-autostart-check').onclick=async()=>{
  const r=await api('/system/autostart');
  $('sys-autostart-msg').textContent=r.enabled?'✅ Đã bật ('+r.platform+')':'❌ Chưa bật ('+r.platform+')';
};
$('sys-autostart-on').onclick=async()=>{
  const r=await api('/system/autostart',{method:'POST',body:JSON.stringify({enabled:true})});
  $('sys-autostart-msg').textContent=r.ok?'✅ Đã đăng ký autostart':'❌ Lỗi';
  $('sys-autostart-msg').style.color=r.ok?'var(--accent)':'var(--bad)';
};
$('sys-autostart-off').onclick=async()=>{
  const r=await api('/system/autostart',{method:'POST',body:JSON.stringify({enabled:false})});
  $('sys-autostart-msg').textContent=r.ok?'✅ Đã huỷ autostart':'❌ Lỗi';
};

// ── UA Registry ────────────────────────────────────────────────────────
$('ua-load').onclick=async()=>{
  const os=$('ua-os-filter').value, br=$('ua-browser-filter').value;
  let url='/ua/list';
  const params=[];
  if(os)params.push('os_filter='+encodeURIComponent(os));
  if(br)params.push('browser_filter='+encodeURIComponent(br));
  if(params.length)url+='?'+params.join('&');
  try{
    const r=await api(url);
    const s=r.summary||{};
    $('ua-summary-tiles').innerHTML=`
      <div class="tile"><span>Tổng</span><b>${s.total||0}</b></div>
      ${Object.entries(s.by_os||{}).map(([k,v])=>`<div class="tile"><span>${k}</span><b>${v}</b></div>`).join('')}
    `;
    $('ua-tbody').innerHTML=(r.uas||[]).map(u=>`<tr>
      <td><span class="badge">${u.os}</span></td>
      <td>${u.browser}</td>
      <td>${u.version}</td>
      <td style="font-size:.78rem;font-family:monospace;max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${u.ua}">${u.ua.slice(0,80)}…</td>
      <td><button class="ghost" style="font-size:.78rem" onclick="copyUA('${u.ua.replace(/'/g,'\\'')}')">📋</button></td>
    </tr>`).join('')||'<tr><td colspan="5" style="color:var(--mute)">Không có kết quả.</td></tr>';
    $('ua-msg').textContent='✅ '+r.uas.length+' UA';
  }catch(e){$('ua-msg').textContent='Lỗi: '+e.message;$('ua-msg').style.color='var(--bad)'}
};
$('ua-refresh').onclick=async()=>{
  $('ua-msg').textContent='Đang cập nhật…';
  try{
    const r=await api('/ua/refresh',{method:'POST'});
    $('ua-msg').textContent=`✅ Đã thêm ${r.added} UA mới (tổng ${r.summary?.total||'?'})`;
    $('ua-msg').style.color='var(--accent)';
    $('ua-load').click();
  }catch(e){$('ua-msg').textContent='Lỗi: '+e.message;$('ua-msg').style.color='var(--bad)'}
};
function copyUA(ua){navigator.clipboard.writeText(ua)}
$('ua-os-filter').onchange=()=>$('ua-load').click();
$('ua-browser-filter').onchange=()=>$('ua-load').click();

// ── Proxy Parser ───────────────────────────────────────────────────────
$('proxy-parse-btn').onclick=async()=>{
  const raw=$('proxy-input').value.trim();
  if(!raw){$('proxy-msg').textContent='Nhập proxy list';return;}
  try{
    const r=await api('/proxy/parse',{method:'POST',body:JSON.stringify({
      raw_text:raw,
      default_protocol:$('proxy-proto').value,
      output_format:$('proxy-out-fmt').value,
    })});
    $('proxy-output').value=r.output_text||'';
    const s=r.stats||{};
    $('proxy-stats').style.display='block';
    $('proxy-stats').innerHTML=`✅ <strong>${s.total}</strong> proxy (${Object.entries(s.by_protocol||{}).map(([k,v])=>k+':'+v).join(', ')}) | ${s.with_auth} có auth | ${s.without_auth} không auth`;
    $('proxy-msg').textContent='';
  }catch(e){$('proxy-msg').textContent='Lỗi: '+e.message;$('proxy-msg').style.color='var(--bad)'}
};
$('proxy-copy-out').onclick=()=>navigator.clipboard.writeText($('proxy-output').value);
$('proxy-import-gw').onclick=async()=>{
  const lines=$('proxy-output').value.trim();
  if(!lines)return;
  try{
    await api('/gateways/import',{method:'POST',body:JSON.stringify({raw:lines})});
    $('proxy-msg').textContent='✅ Đã import vào Gateways';
    $('proxy-msg').style.color='var(--accent)';
  }catch(e){$('proxy-msg').textContent='Lỗi: '+e.message;$('proxy-msg').style.color='var(--bad)'}
};

// ── Hybrid Handoff info ────────────────────────────────────────────────
async function loadHybridInfo(){
  try{
    const r=await api('/hybrid/info');
    $('hybrid-info').textContent=r.how_it_works+'\n\nStep JSON mẫu:\n'+JSON.stringify(r.usage?.step_json,null,2);
  }catch(e){$('hybrid-info').textContent='Chưa có thông tin.'}
}

// ── Phase 11: Device Mix / Virtual Display / Font / Gateway Quality ─────
async function loadPhase11Settings(){
  // Device Mix
  try{
    const tc=await api('/referrer/traffic-config');
    const mobilePct=Math.round((tc.device_mix?.mobile??0.75)*100);
    $('dm-mobile').value=mobilePct; $('dm-mobile-val').textContent=mobilePct;
    $('dm-desktop').value=100-mobilePct; $('dm-desktop-val').textContent=100-mobilePct;
  }catch(e){}
  // Virtual Display
  try{
    const st=await api('/display/xvfb/status');
    $('vd-enabled').checked=!!st.enabled_setting;
    $('vd-status').textContent=st.platform_supported?('Nền tảng hỗ trợ Xvfb. Cài đặt đã lưu: '+(st.enabled_setting?'BẬT':'TẮT')):'Nền tảng hiện tại không hỗ trợ Xvfb (chỉ Linux).';
  }catch(e){}
  // Gateway quality
  try{
    const gq=await api('/gateways/quality-settings');
    $('gwq-datacenter').checked=!!gq.datacenter_filter_enabled;
    $('gwq-header').checked=!!gq.header_check_enabled;
    $('gwq-latency').value=gq.max_latency_ms||0;
    $('gwq-latency-val').textContent=gq.max_latency_ms?Math.round(gq.max_latency_ms)+'ms':'Không giới hạn';
  }catch(e){}
}
$('dm-mobile').oninput=()=>{const v=+$('dm-mobile').value;$('dm-mobile-val').textContent=v;$('dm-desktop').value=100-v;$('dm-desktop-val').textContent=100-v};
$('dm-save').onclick=async()=>{
  try{
    const m=+$('dm-mobile').value/100, d=1-m;
    await api('/referrer/traffic-config',{method:'POST',body:JSON.stringify({device_mix:{mobile:m,desktop:d}})});
    $('dm-msg').textContent='Đã lưu.';$('dm-msg').style.color='var(--accent)';
  }catch(e){$('dm-msg').textContent='Lỗi: '+e.message;$('dm-msg').style.color='var(--bad)'}
};
$('vd-save').onclick=async()=>{
  try{
    const [w,h]=$('vd-res').value.split('x').map(Number);
    await api('/display/xvfb/settings',{method:'POST',body:JSON.stringify({enabled:$('vd-enabled').checked,width:w,height:h})});
    $('vd-msg').textContent='Đã lưu (áp dụng từ lần khởi động Engine tiếp theo).';$('vd-msg').style.color='var(--accent)';
  }catch(e){$('vd-msg').textContent='Lỗi: '+e.message;$('vd-msg').style.color='var(--bad)'}
};
$('font-provision').onclick=async()=>{
  const btn=$('font-provision');btn.disabled=true;$('font-msg').textContent='Đang tải phông chữ…';$('font-msg').style.color='var(--mute)';
  try{
    const r=await api('/display/fonts/provision',{method:'POST'});
    $('font-msg').textContent=r.ok?`✅ Đã tải ${r.downloaded.length} phông (${r.skipped.length} đã có sẵn)`:'Lỗi: '+(r.error||JSON.stringify(r.failed));
    $('font-msg').style.color=r.ok?'var(--accent)':'var(--bad)';
  }catch(e){$('font-msg').textContent='Lỗi: '+e.message;$('font-msg').style.color='var(--bad)'}
  btn.disabled=false;
};
$('gwq-latency').oninput=()=>{const v=+$('gwq-latency').value;$('gwq-latency-val').textContent=v?v+'ms':'Không giới hạn'};
$('gwq-save').onclick=async()=>{
  try{
    await api('/gateways/quality-settings',{method:'POST',body:JSON.stringify({
      datacenter_filter_enabled:$('gwq-datacenter').checked,
      header_check_enabled:$('gwq-header').checked,
      max_latency_ms:+$('gwq-latency').value||null,
    })});
    $('gwq-msg').textContent='Đã lưu.';$('gwq-msg').style.color='var(--accent)';
  }catch(e){$('gwq-msg').textContent='Lỗi: '+e.message;$('gwq-msg').style.color='var(--bad)'}
};

// ══ VAULT & CLOUD (Phase 7) ══════════════════════════════════════════════
let vaultCloudInited=false;
async function loadVaultCloud(){
  if(!vaultCloudInited){vaultCloudInited=true;}
  loadCloudUsage(); loadFailureTaxonomy(); loadAlertHistory();
  loadVaultAccounts(); loadVaultCookies(); loadVaultCaptcha();
  loadReferrerPreview(); loadRemoteDbStatus();
}

// ── Cloud Usage ────────────────────────────────────────────────────────
async function loadCloudUsage(){
  try{
    const r=await api('/cloud/usage');
    const prov=(r.summary?.providers||[]);
    const totSessions=prov.reduce((a,p)=>a+(p.sessions||0),0);
    const totDur=prov.reduce((a,p)=>a+(p.total_s||0),0);
    const totCost=prov.reduce((a,p)=>a+(p.total_usd||0),0);
    const totOk=prov.reduce((a,p)=>a+(p.ok_count||0),0);
    $('cloud-sessions').textContent=totSessions;
    $('cloud-duration').textContent=totDur?Math.round(totDur)+'s':'–';
    $('cloud-cost').textContent=totCost?'$'+totCost.toFixed(4):'$0';
    $('cloud-ok-rate').textContent=totSessions?(Math.round(totOk/totSessions*100)+'%'):'–';
    $('cloud-tbody').innerHTML=(r.recent||[]).map(s=>`<tr>
      <td><span class="badge">${s.provider}</span></td>
      <td style="color:var(--mute);font-size:.8rem">${s.started_at?.slice(0,16)||'–'}</td>
      <td>${s.duration_s!=null?Math.round(s.duration_s):'–'}</td>
      <td>${s.cost_usd!=null?'$'+s.cost_usd.toFixed(5):'–'}</td>
      <td><span class="badge" style="background:${s.status==='ok'?'var(--accent)':'var(--bad)'};color:#fff">${s.status}</span></td>
      <td style="color:var(--bad);font-size:.8rem">${s.error||''}</td>
    </tr>`).join('')||'<tr><td colspan="6" style="color:var(--mute)">Chưa có phiên cloud nào.</td></tr>';
  }catch(e){console.warn(e)}
}

// ── Failure Taxonomy ───────────────────────────────────────────────────
async function loadFailureTaxonomy(){
  try{
    const r=await api('/alerts/failure-rates');
    // Nhóm theo failure_type để vẽ mini chart
    const byType={};
    (r.rates||[]).forEach(x=>{
      byType[x.failure_type]=(byType[x.failure_type]||0)+x.n;
    });
    const typeColors={WAF_CHALLENGE:'#e55',NETWORK_TIMEOUT:'#f90',GATEWAY_DEAD:'#c33',
      DOM_SELECTOR_MISSING:'#39c',PROTOCOL_MISMATCH:'#93c',UNKNOWN:'#777'};
    $('failure-chart').innerHTML=Object.entries(byType).map(([t,n])=>
      `<div style="background:var(--bg-2,var(--bg));border:1px solid var(--line);border-radius:5px;padding:.6rem;text-align:center">
         <div style="color:${typeColors[t]||'var(--accent)'};font-weight:700;font-size:1.3rem">${n}</div>
         <div style="font-size:.75rem;color:var(--mute)">${t.replace(/_/g,' ')}</div>
       </div>`
    ).join('')||'<div style="color:var(--mute)">Không có lỗi nào được ghi nhận.</div>';
    $('failure-tbody').innerHTML=(r.rates||[]).map(x=>`<tr>
      <td>${x.scenario_id||'–'}</td>
      <td><span class="badge" style="background:${typeColors[x.failure_type]||'#555'};color:#fff">${x.failure_type}</span></td>
      <td style="font-weight:600">${x.n}</td>
      <td style="color:var(--mute);font-size:.8rem">${x.last?.slice(0,16)||'–'}</td>
    </tr>`).join('')||'<tr><td colspan="4" style="color:var(--mute)">Không có dữ liệu.</td></tr>';
  }catch(e){console.warn(e)}
}

// ── Alert History ──────────────────────────────────────────────────────
async function loadAlertHistory(){
  try{
    const r=await api('/alerts/history');
    $('alert-tbody').innerHTML=(r.alerts||[]).map(a=>`<tr>
      <td style="color:var(--mute);font-size:.8rem">${a.sent_at?.slice(0,16)||'–'}</td>
      <td><span class="badge">${a.channel}</span></td>
      <td>${a.scenario_id||'–'}</td>
      <td style="font-size:.82rem">${(a.message||'').slice(0,60)}</td>
      <td><span class="badge" style="background:${a.status==='ok'?'var(--accent)':'var(--bad)'};color:#fff">${a.status}</span></td>
    </tr>`).join('')||'<tr><td colspan="5" style="color:var(--mute)">Chưa có alert nào.</td></tr>';
  }catch(e){}
}
$('alert-test').onclick=async()=>{
  const ch=$('alert-channel').value, msg=$('alert-msg').value;
  $('alert-msg-status').textContent='Đang gửi…';
  try{
    const r=await api('/alerts/test',{method:'POST',body:JSON.stringify({channel:ch,message:msg})});
    $('alert-msg-status').textContent=r.ok?'✅ Gửi thành công':'❌ '+(r.error||'Lỗi');
    $('alert-msg-status').style.color=r.ok?'var(--accent)':'var(--bad)';
    loadAlertHistory();
  }catch(e){$('alert-msg-status').textContent='Lỗi: '+e.message;$('alert-msg-status').style.color='var(--bad)'}
};

// ── Credential Vault ───────────────────────────────────────────────────
function showVaultTab(tab){
  ['accounts','cookies','captcha'].forEach(t=>{
    $('vault-panel-'+t).style.display=t===tab?'':'none';
    $('vault-tab-'+t).classList.toggle('active',t===tab);
  });
}
showVaultTab('accounts');

async function loadVaultAccounts(){
  try{
    const r=await api('/vault/accounts');
    $('va-tbody').innerHTML=(r.accounts||[]).map(a=>`<tr>
      <td><strong>${a.name}</strong></td>
      <td style="color:var(--mute);font-size:.82rem">${a.tags||'–'}</td>
      <td style="color:var(--mute);font-size:.8rem">${a.created_at?.slice(0,10)||'–'}</td>
      <td><button class="ghost" style="font-size:.8rem" onclick="deleteAccount('${a.name}')">🗑</button></td>
    </tr>`).join('')||'<tr><td colspan="4" style="color:var(--mute)">Chưa có tài khoản nào.</td></tr>';
  }catch(e){}
}
async function deleteAccount(name){
  if(!confirm('Xoá tài khoản '+name+'?'))return;
  await api('/vault/accounts/'+name,{method:'DELETE'});loadVaultAccounts();
}
$('va-save').onclick=async()=>{
  const body={name:$('va-name').value.trim(),username:$('va-user').value.trim(),
    password:$('va-pass').value,email:$('va-email').value,
    profile_id:$('va-profile').value.trim()};
  if(!body.name||!body.username||!body.password){$('va-msg').textContent='Điền đủ Tên/Username/Password';return;}
  try{
    await api('/vault/accounts',{method:'POST',body:JSON.stringify(body)});
    $('va-msg').textContent='✅ Đã lưu';$('va-msg').style.color='var(--accent)';
    loadVaultAccounts();
  }catch(e){$('va-msg').textContent='Lỗi: '+e.message;$('va-msg').style.color='var(--bad)'}
};

async function loadVaultCookies(){
  try{
    const r=await api('/vault/cookies');
    $('vc-tbody').innerHTML=(r.cookies||[]).map(c=>`<tr>
      <td><code style="font-size:.8rem">${c.name}</code></td>
      <td style="color:var(--mute);font-size:.8rem">${c.created_at?.slice(0,16)||'–'}</td>
    </tr>`).join('')||'<tr><td colspan="2" style="color:var(--mute)">Chưa có cookie nào.</td></tr>';
  }catch(e){}
}
$('vc-import').onclick=async()=>{
  const pid=$('vc-profile').value.trim(), json=$('vc-json').value.trim();
  if(!pid||!json){$('vc-msg').textContent='Điền Profile ID và JSON';return;}
  try{
    const r=await api('/vault/cookies/import',{method:'POST',body:JSON.stringify({profile_id:pid,cookies_json:json})});
    $('vc-msg').textContent=`✅ Đã import ${r.imported} cookies`;$('vc-msg').style.color='var(--accent)';
    loadVaultCookies();
  }catch(e){$('vc-msg').textContent='Lỗi: '+e.message;$('vc-msg').style.color='var(--bad)'}
};

async function loadVaultCaptcha(){
  try{
    const r=await api('/vault/captcha');
    $('vk-tbody').innerHTML=(r.services||[]).map(s=>`<tr>
      <td><strong>${s.name}</strong></td>
      <td style="color:var(--mute);font-size:.8rem">${s.updated_at?.slice(0,16)||s.created_at?.slice(0,16)||'–'}</td>
    </tr>`).join('')||'<tr><td colspan="2" style="color:var(--mute)">Chưa có key nào.</td></tr>';
  }catch(e){}
}
$('vk-save').onclick=async()=>{
  const name=$('vk-name').value, key=$('vk-key').value.trim();
  if(!key){$('vk-msg').textContent='Nhập API key';return;}
  try{
    await api('/vault/captcha',{method:'POST',body:JSON.stringify({name,api_key:key})});
    $('vk-msg').textContent='✅ Đã lưu';$('vk-msg').style.color='var(--accent)';
    loadVaultCaptcha();
  }catch(e){$('vk-msg').textContent='Lỗi: '+e.message;$('vk-msg').style.color='var(--bad)'}
};

// ── Referrer Chain ─────────────────────────────────────────────────────
async function loadReferrerPreview(){
  $('ref-json').textContent='Nhấn "Xem trước" để tạo step JSON';
}
$('ref-preview').onclick=async()=>{
  const body={
    source:$('ref-source').value,
    target_url:$('ref-url').value||'https://example.com',
    search_query:$('ref-query').value,
    utm_source:$('ref-utm-source').value,
    utm_medium:$('ref-utm-medium').value,
    utm_campaign:$('ref-utm-campaign').value,
  };
  try{
    const r=await api('/referrer/preview',{method:'POST',body:JSON.stringify(body)});
    $('ref-json').textContent=JSON.stringify(r.step_json,null,2);
    if(df)_addFlowNode('goto',{url:r.final_url},300,100);
  }catch(e){$('ref-json').textContent='Lỗi: '+e.message}
};

// ── Remote DB Sync ─────────────────────────────────────────────────────
async function loadRemoteDbStatus(){
  try{
    const r=await api('/remote-db/status');
    $('remote-mongo').textContent=r.mongodb_configured?'✅ Đã cấu hình':'❌ Chưa';
    $('remote-mongo').style.color=r.mongodb_configured?'var(--accent)':'var(--bad)';
    $('remote-supa').textContent=r.supabase_configured?'✅ Đã cấu hình':'❌ Chưa';
    $('remote-supa').style.color=r.supabase_configured?'var(--accent)':'var(--bad)';
    $('remote-sync-tbody').innerHTML=(r.last_syncs||[]).map(s=>`<tr>
      <td><code>${s.table_name}</code></td>
      <td style="color:var(--mute);font-size:.8rem">${s.last_synced_at?.slice(0,16)||'–'}</td>
    </tr>`).join('')||'<tr><td colspan="2" style="color:var(--mute)">Chưa sync lần nào.</td></tr>';
  }catch(e){}
}
$('remote-sync-now').onclick=async()=>{
  $('remote-msg').textContent='Đang sync…';
  try{
    const r=await api('/remote-db/sync',{method:'POST'});
    const total=Object.values(r.result||{}).reduce((a,v)=>a+(typeof v==='object'?Object.values(v).reduce((x,y)=>x+(y||0),0):0),0);
    $('remote-msg').textContent=`✅ Sync xong (${total} rows)`;
    $('remote-msg').style.color='var(--accent)';
    loadRemoteDbStatus();
  }catch(e){$('remote-msg').textContent='Lỗi: '+e.message;$('remote-msg').style.color='var(--bad)'}
};

// ══ FLOW STUDIO (Drawflow) ═══════════════════════════════════════════════
let df=null, flowInited=false;
function initFlowStudio(){
  if(flowInited)return; flowInited=true;
  // Tải Drawflow từ CDN
  const s=document.createElement('script');
  // Ưu tiên bundle cục bộ, fallback về CDN nếu local không có
  s.src='/static/drawflow.min.js';
  s.onerror=()=>{const fb=document.createElement('script');fb.src='https://cdn.jsdelivr.net/npm/drawflow@0.0.60/dist/drawflow.min.js';document.head.appendChild(fb);};
  s.onload=()=>{
    const lnk=document.createElement('link');
    lnk.rel='stylesheet';
    lnk.href='/static/drawflow.min.css';
    document.head.appendChild(lnk);
    df=new Drawflow($('drawflow'));
    df.reroute=true;
    df.start();
    // Thêm node mẫu
    _addFlowNode('goto',{url:'https://example.com'},300,100);
    _addFlowNode('click',{selector:'#btn'},500,100);
    df.on('nodeDataChanged', _updateFlowJson);
    df.on('nodeMoved', _updateFlowJson);
    df.on('connectionCreated', _updateFlowJson);
    df.on('connectionRemoved', _updateFlowJson);
    _updateFlowJson();
    $('flow-msg').textContent='✅ Drawflow đã khởi động';
  };
  s.onerror=()=>{
    $('flow-msg').textContent='⚠️ Không tải được Drawflow (cần mạng). Dùng JSON editor thủ công.';
    $('flow-msg').style.color='var(--warn)';
  };
  document.head.appendChild(s);
  loadFlowScenarios();
}

const _NODE_TEMPLATES={
  goto:   {label:'🌐 Goto URL',   fields:['url','wait_until']},
  click:  {label:'🖱 Click',       fields:['selector','timeout_ms']},
  type:   {label:'⌨ Type',         fields:['selector','text']},
  scroll: {label:'↕ Scroll',       fields:['delta_y']},
  wait:   {label:'⏱ Wait',         fields:['duration_ms']},
  assert: {label:'✔ Assert',       fields:['selector','expected_text']},
  branch: {label:'🔀 Branch (kéo dây 2 nhánh bên dưới)',
           fields:['probability_a','if_selector','if_url_contains','if_text']},
  //: 4 field trên là các kiểu điều kiện _condition() trong engine.py thật sự
  // đọc (Phiên 19 fix) - điền probability_a cho Weighted Split ngẫu nhiên,
  // HOẶC một trong 3 field if_* cho điều kiện xác định (ưu tiên theo thứ tự
  // if_selector > if_url_contains > if_text > probability_a nếu điền nhiều).
  // Nhánh "then"/"else" giờ lấy từ DÂY NỐI trên canvas (output 1/2 của node
  // này), KHÔNG cần gõ tay JSON nữa.
  loop:   {label:'🔄 Conditional Loop',fields:['count','selector_wait']},
  // ── 12-Node Specialized Palette (đặc tả hợp nhất, mục 3.1.C) ──────────────
  referrer_goto:      {label:'🔗 Referrer Chain & UTM',    fields:['referrer_type','target_url','utm_source']},
  prime_session:      {label:'🔥 Session Pre-Warming',     fields:['warmup_url','duration_s']},
  human_click:        {label:'🤚 Kinematic Human Action',  fields:['selector','behavior']},
  widget_qa:          {label:'🎞 Widget & Media QA',       fields:['iframe_selector','check_type']},
  sync_start:         {label:'🪟 Multi-Window Sync',       fields:['slave_count','jitter_ms']},
  hybrid_handoff:      {label:'⚡ Hybrid HTTP Handoff',     fields:['priming_wait_s','follow_up_urls']},
  js_probe:           {label:'🧪 Sandboxed JS Probe',      fields:['filename']},
  classify_failure:   {label:'🛟 Fallback & Challenge',    fields:['on_error_strategy','integration_name']},
  analytics_verify:   {label:'📊 Analytics Telemetry Verify',fields:['require']},
  ai_form_fill:       {label:'🤖 Local AI Form Filler',    fields:['form_selector','submit']},
};
//: Danh sách node 1-click (không cần field riêng, dùng mặc định): sync_stop,
// healing_click, vault_load_cookies... vẫn chạy được qua JSON thủ công, chỉ
// 12 khối trên có nút kéo-thả riêng theo đặc tả.

function _addFlowNode(type, data, x, y){
  if(!df)return;
  const tmpl=_NODE_TEMPLATES[type]||{label:type,fields:[]};
  const inputs=type==='goto'?0:1, outputs=type==='branch'?2:1;
  const html=`<div class="flow-node-inner">
    <div style="font-weight:600;margin-bottom:.3rem">${tmpl.label}</div>
    ${tmpl.fields.map(f=>`<div style="font-size:.78rem;color:var(--mute)">${f}</div>
      <input data-field="${f}" value="${data[f]||''}" style="width:140px;font-size:.8rem;padding:2px 4px">`).join('')}
  </div>`;
  df.addNode(type,inputs,outputs,x,y,`flow-${type}`,data,html);
}

// ── Phiên 19 FIX CỐT LÕI ─────────────────────────────────────────────────
// Trước đây _updateFlowJson() làm PHẲNG mọi node thành 1 mảng tuyến tính theo
// Object.values(nodes) (thứ tự nội bộ, KHÔNG theo dây nối) — dây nối trên
// canvas hoàn toàn không ảnh hưởng JSON xuất ra, "branch" có 2 output port
// nhưng không bao giờ sinh ra field then/else thật. Hàm dưới đây DUYỆT ĐỒ THỊ
// kết nối thật của Drawflow (inputs/outputs connections) để xây steps lồng nhau.
//
// GIỚI HẠN ĐÃ BIẾT (ghi rõ để không quảng cáo quá khả năng thật):
// - Giả định mỗi output port chỉ nối tới ĐÚNG 1 node tiếp theo (lấy connections[0]).
// - KHÔNG tự động phát hiện điểm hội tụ (re-converge) sau branch — nhánh "then"
//   và "else" được duyệt ĐỘC LẬP tới khi hết output hoặc gặp lại 1 node đã đi
//   qua (chống lặp vô hạn). Nếu muốn có bước chung chạy sau cả 2 nhánh, người
//   dùng cần đặt bước đó lặp lại ở CUỐI của cả 2 nhánh (then VÀ else).
// - Node không kết nối tới bất kỳ chuỗi nào (orphan trên canvas) vẫn được đưa
//   vào cuối mảng "steps" chính, theo thứ tự node id, để không mất dữ liệu
//   âm thầm — nhưng thứ tự chạy của chúng so với chuỗi chính không được đảm bảo.
function _buildStepsFromGraph(nodes){
  const ids=Object.keys(nodes);
  const incomingCount={};
  for(const id of ids){
    const n=nodes[id]; let c=0;
    for(const k in (n.inputs||{})) c+=((n.inputs[k].connections)||[]).length;
    incomingCount[id]=c;
  }
  function outputTarget(node, outKey){
    const conns=(node.outputs && node.outputs[outKey] && node.outputs[outKey].connections)||[];
    return conns.length? String(conns[0].node): null;
  }
  const visited=new Set();
  function walkChain(startId){
    const chain=[];
    let curId=startId;
    while(curId && !visited.has(curId) && nodes[curId]){
      visited.add(curId);
      const node=nodes[curId];
      const step={action:node.name, ...node.data, _flow_id:curId};
      const outKeys=Object.keys(node.outputs||{});
      if(node.name==='branch' && outKeys.length>=2){
        const thenTarget=outputTarget(node,'output_1');
        const elseTarget=outputTarget(node,'output_2');
        step.then = thenTarget? walkChain(thenTarget): [];
        step.else = elseTarget? walkChain(elseTarget): [];
        chain.push(step);
        break; // mỗi nhánh branch là điểm cuối của chuỗi chính (xem giới hạn ở trên)
      }
      if(node.name==='loop'){
        // Thân vòng lặp = nhánh DUY NHẤT đi ra từ node Loop trên canvas (giống
        // cơ chế branch ở trên) - gán vào field "steps" mà engine.py đọc.
        const bodyTarget=outKeys.length? outputTarget(node, outKeys[0]): null;
        step.steps = bodyTarget? walkChain(bodyTarget): [];
        chain.push(step);
        break; // mọi node sau Loop trên canvas đều đã nằm TRONG step.steps ở trên
      }
      chain.push(step);
      curId = outKeys.length? outputTarget(node, outKeys[0]) : null;
    }
    return chain;
  }
  // Tìm (các) node gốc: không ai trỏ vào (incomingCount===0) — có thể có NHIỀU
  // chuỗi độc lập trên cùng canvas, mỗi chuỗi gốc là 1 nhánh song song trong "steps".
  const roots=ids.filter(id=>incomingCount[id]===0);
  let steps=[];
  for(const r of roots) steps=steps.concat(walkChain(r));
  // Node còn sót (chưa visited — vòng lặp hoặc orphan không có root rõ ràng)
  // vẫn được thêm vào cuối, không âm thầm mất dữ liệu.
  for(const id of ids){
    if(!visited.has(id)){
      const node=nodes[id];
      steps.push({action:node.name, ...node.data, _flow_id:id, _orphan_on_canvas:true});
      visited.add(id);
    }
  }
  return steps;
}

function _updateFlowJson(){
  if(!df)return;
  const exportData=df.export();
  const nodes=exportData.drawflow.Home.data;
  const steps=_buildStepsFromGraph(nodes);
  // Phase 12: Session Envelope - map vào field scenario thật (engine/bandwidth)
  // + phần còn lại lưu riêng vào raw.session_envelope.
  const envelope={
    pool_mode:$('env-pool')?.value||'isolated',
    preflight_override:$('env-preflight')?.checked??true,
    xvfb_override:$('env-xvfb')?.checked??false,
    device_mix:{mobile:(+($('env-mobile')?.value||75))/100, desktop:1-(+($('env-mobile')?.value||75))/100},
  };
  const out={
    steps,
    engine:$('env-engine')?.value||'auto',
    bandwidth:{enabled:$('env-bandwidth')?.checked??false},
    raw:{session_envelope:envelope},
  };
  $('flow-json-out').textContent=JSON.stringify(out,null,2);
}
$('env-mobile').oninput=()=>{const v=+$('env-mobile').value;$('env-mobile-val').textContent=v;$('env-desktop-val').textContent=100-v;_updateFlowJson()};
['env-engine','env-pool','env-preflight','env-xvfb','env-bandwidth'].forEach(id=>{
  const el=$(id); if(el) el.addEventListener('change',_updateFlowJson);
});

async function loadFlowScenarios(){
  try{
    const r=await api('/scenarios');
    const sel=$('flow-scenario-sel');
    sel.innerHTML='<option value="">-- Chọn kịch bản --</option>';
    (r.scenarios||[]).forEach(s=>{
      sel.innerHTML+=`<option value="${s.id}">${s.id}${s.description?' — '+s.description.slice(0,40):''}</option>`;
    });
  }catch(e){}
}

$('flow-load').onclick=async()=>{
  const id=$('flow-scenario-sel').value; if(!id)return;
  try{
    const r=await api('/scenarios/'+id);
    if(!df){$('flow-msg').textContent='Chờ Drawflow tải…';return;}
    df.clearModuleSelected();
    let x=100,y=80;
    (r.scenario?.steps||[]).forEach(step=>{
      const type=step.action||'goto';
      _addFlowNode(type,step,x,y);
      x+=200; if(x>900){x=100;y+=120;}
    });
    _updateFlowJson();
    $('flow-msg').textContent=`✅ Đã tải '${id}'`;
  }catch(e){$('flow-msg').textContent='Lỗi: '+e.message;$('flow-msg').style.color='var(--bad)'}
};

$('flow-save').onclick=()=>{
  const json=$('flow-json-out').textContent;
  if(!json)return;
  const blob=new Blob([json],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download='scenario_flow.json';a.click();
};
$('flow-clear').onclick=()=>{ if(df){df.clearModuleSelected();$('flow-json-out').textContent='';} };

// ── Phase 12: 3 cách khởi tạo kịch bản không cần biết code ──────────────────
function _stepsToFlow(steps){
  if(!df)return;
  df.clearModuleSelected();
  let x=100,y=100;
  for(const st of steps){
    const {action,_flow_id,_x,_y,...data}=st;
    _addFlowNode(action, data, x, y);
    x+=220; if(x>900){x=100;y+=150}
  }
  _updateFlowJson();
}

// 1) Kho Mẫu Dựng Sẵn
async function _loadBlueprints(){
  try{
    const r=await api('/flow/templates');
    $('bp-select').replaceChildren(...r.templates.map(t=>{
      const op=document.createElement('option');op.value=t.id;op.textContent=t.name+' — '+t.description.slice(0,50)+'…';return op;
    }));
  }catch(e){}
}
_loadBlueprints();
$('bp-apply').onclick=async()=>{
  try{
    const r=await api('/flow/templates');
    const tpl=r.templates.find(t=>t.id===$('bp-select').value);
    if(!tpl){$('bp-msg').textContent='Không tìm thấy mẫu.';return}
    const url=($('bp-urls').value.split('\n').map(s=>s.trim()).filter(Boolean)[0])||'https://example.com';
    const steps=tpl.steps.map(s=>({...s, url:s.url==='__URL__'?url:s.url, target_url:s.target_url==='__URL__'?url:s.target_url}));
    _stepsToFlow(steps);
    $('bp-msg').textContent=`✅ Đã áp dụng mẫu "${tpl.name}" (${steps.length} bước).`;$('bp-msg').style.color='var(--accent)';
  }catch(e){$('bp-msg').textContent='Lỗi: '+e.message;$('bp-msg').style.color='var(--bad)'}
};

// 2) Ghi Thao Tác Thực Tế
let _recPoll=null;
$('rec-start').onclick=async()=>{
  const url=$('rec-url').value.trim(); if(!url){$('rec-msg').textContent='Nhập URL trước.';return}
  $('rec-msg').textContent='Đang mở trình duyệt để ghi…';$('rec-msg').style.color='var(--mute)';
  try{
    const r=await api('/flow/recorder/start',{method:'POST',body:JSON.stringify({url})});
    if(!r.ok){$('rec-msg').textContent='Lỗi: '+(r.error||'')+' '+(r.hint||'');$('rec-msg').style.color='var(--bad)';return}
    $('rec-msg').textContent='🔴 Đang ghi — thao tác trên cửa sổ trình duyệt vừa mở, xong bấm "Dừng".';
    $('rec-msg').style.color='var(--accent)';
    _recPoll=setInterval(async()=>{
      try{const st=await api('/flow/recorder/status');if(st.active)$('rec-msg').textContent=`🔴 Đang ghi — ${st.events_captured||0} sự kiện đã bắt.`}catch(e){}
    },2000);
  }catch(e){$('rec-msg').textContent='Lỗi: '+e.message;$('rec-msg').style.color='var(--bad)'}
};
$('rec-stop').onclick=async()=>{
  if(_recPoll){clearInterval(_recPoll);_recPoll=null}
  try{
    const r=await api('/flow/recorder/stop',{method:'POST',body:JSON.stringify({})});
    if(!r.ok){$('rec-msg').textContent='Lỗi: '+r.error;$('rec-msg').style.color='var(--bad)';return}
    _stepsToFlow(r.steps);
    $('rec-msg').textContent=`✅ Đã chuyển ${r.events_raw} sự kiện thành ${r.steps.length} node trên canvas.`;
    $('rec-msg').style.color='var(--accent)';
  }catch(e){$('rec-msg').textContent='Lỗi: '+e.message;$('rec-msg').style.color='var(--bad)'}
};

// 3) Trợ Lý AI Vẽ Sơ Đồ (Ollama)
$('nl-generate').onclick=async()=>{
  const desc=$('nl-desc').value.trim(); if(!desc){$('nl-msg').textContent='Nhập mô tả trước.';return}
  const btn=$('nl-generate');btn.disabled=true;$('nl-msg').textContent='Đang gọi Ollama…';$('nl-msg').style.color='var(--mute)';
  try{
    const r=await api('/flow/nl-to-flow',{method:'POST',body:JSON.stringify({description:desc})});
    if(!r.ok){$('nl-msg').textContent='Lỗi: '+r.error+(r.note?' — '+r.note:'');$('nl-msg').style.color='var(--bad)';btn.disabled=false;return}
    _stepsToFlow(r.steps);
    $('nl-msg').textContent=`✅ Đã sinh ${r.steps.length} bước từ mô tả.`;$('nl-msg').style.color='var(--accent)';
  }catch(e){$('nl-msg').textContent='Lỗi: '+e.message;$('nl-msg').style.color='var(--bad)'}
  btn.disabled=false;
};
['goto','click','type','scroll','wait','assert','branch','loop',
 'referrer_goto','prime_session','human_click','widget_qa','sync_start',
 'hybrid_handoff','js_probe','classify_failure','analytics_verify','ai_form_fill'].forEach(t=>{
  const btn=$('flow-add-'+t); if(btn) btn.onclick=()=>_addFlowNode(t,{},Math.random()*400+100,Math.random()*300+80);
});

// ══ VISUAL PICKER ════════════════════════════════════════════════════════
let pickerPolling=null;
$('picker-start').onclick=async()=>{
  const url=$('picker-url').value.trim();
  const timeout=parseInt($('picker-timeout').value)||90;
  if(!url){$('picker-msg').textContent='Nhập URL';return;}
  $('picker-msg').textContent='Đang mở browser…';
  $('picker-result').style.display='none';
  try{
    await api('/picker/start',{method:'POST',body:JSON.stringify({url,timeout_s:timeout})});
    $('picker-msg').textContent='🎯 Browser đang mở — click phần tử cần chọn';
    // Poll kết quả
    pickerPolling=setInterval(async()=>{
      const r=await api('/picker/result');
      if(r.status==='ok'){
        clearInterval(pickerPolling);
        const el=r.element||{};
        $('picker-css').value=el.css||el.value||'';
        $('picker-aria').value=el.aria_label||'';
        $('picker-text').value=el.inner_text||'';
        $('picker-xpath').value=el.xpath||'';
        $('picker-conf').value=el.confidence||'';
        $('picker-result').style.display='block';
        $('picker-msg').textContent='✅ Đã chọn: '+el.tag+' ('+el.confidence+')';
      } else if(r.status==='cancelled'||r.status==='timeout'){
        clearInterval(pickerPolling);
        $('picker-msg').textContent='Phiên kết thúc: '+r.status;
      }
    },1500);
  }catch(e){$('picker-msg').textContent='Lỗi: '+e.message;$('picker-msg').style.color='var(--bad)'}
};
$('picker-stop').onclick=async()=>{
  clearInterval(pickerPolling);
  await api('/picker/stop',{method:'POST'});
  $('picker-msg').textContent='Đã huỷ';
};
$('picker-copy-css').onclick=()=>{navigator.clipboard.writeText($('picker-css').value)};
$('picker-add-click').onclick=()=>{
  const sel=$('picker-css').value; if(!sel)return;
  if(df)_addFlowNode('click',{selector:sel},300,200);
  $('picker-msg').textContent='✅ Đã thêm Click node vào Flow Studio';
};
$('picker-add-type').onclick=()=>{
  const sel=$('picker-css').value; if(!sel)return;
  if(df)_addFlowNode('type',{selector:sel,text:''},300,200);
};

// ══ PROFILES & PERSONAS ══════════════════════════════════════════════════
let selectedProfiles=new Set();
async function loadProfiles(){
  try{
    const [warmth,personas]=await Promise.all([
      api('/profiles/warmth'),
      api('/personas'),
    ]);
    renderProfilesTable(warmth.profiles||[]);
    renderPersonasTable(personas.personas||[]);
  }catch(e){console.warn('loadProfiles:',e)}
}
function renderProfilesTable(profiles){
  const tbody=$('profiles-tbody');
  if(!profiles.length){tbody.innerHTML='<tr><td colspan="8" style="color:var(--mute)">Chưa có profile nào.</td></tr>';return;}
  const filter=$('profiles-filter').value.toLowerCase();
  const statusFilter=$('profiles-status-filter').value;
  const filtered=profiles.filter(p=>
    (!filter||p.profile_id.toLowerCase().includes(filter))&&
    (!statusFilter||p.status===statusFilter)
  );
  tbody.innerHTML=filtered.map(p=>{
    const score=p.trust_score||0;
    const color=score>=60?'var(--accent)':score>=30?'var(--warn)':'var(--bad)';
    const statusBadge={new:'🆕 Mới',warm:'🔥 Warming',ready:'✅ Sẵn sàng'}[p.status]||p.status;
    return `<tr>
      <td><input type="checkbox" class="profile-chk" value="${p.profile_id}"></td>
      <td><code>${p.profile_id}</code></td>
      <td><span style="color:${color};font-weight:600">${score.toFixed(1)}</span>
          <div class="progress" style="width:80px;display:inline-block;vertical-align:middle;margin-left:.3rem"><i style="width:${Math.min(100,score)}%;background:${color}"></i></div></td>
      <td>${p.urls_visited||0}</td>
      <td>${p.cookies||0}</td>
      <td>${statusBadge}</td>
      <td style="color:var(--mute);font-size:.8rem">${p.warmed_at?p.warmed_at.slice(0,16):'-'}</td>
      <td><button class="ghost" style="font-size:.8rem" onclick="quickWarm('${p.profile_id}')">🔥</button></td>
    </tr>`;
  }).join('');
  // Sync checkboxes
  document.querySelectorAll('.profile-chk').forEach(c=>{
    c.checked=selectedProfiles.has(c.value);
    c.onchange=()=>{c.checked?selectedProfiles.add(c.value):selectedProfiles.delete(c.value)};
  });
}
function renderPersonasTable(personas){
  $('personas-tbody').innerHTML=personas.map(p=>`<tr>
    <td><code style="font-size:.8rem">${p.id}</code></td>
    <td>${p.os}</td><td>${p.browser}</td><td>${p.device_type}</td>
    <td>${p.locale||'–'}</td><td>${p.timezone||'–'}</td>
    <td><button class="ghost" style="font-size:.78rem" onclick="copyPersona('${p.id}')">📋</button></td>
  </tr>`).join('');
}
async function quickWarm(profileId){
  const target=prompt('URL target để prime (để trống bỏ qua):','');
  try{
    await api('/profiles/prime',{method:'POST',body:JSON.stringify({profile_id:profileId,target_url:target||null})});
    loadProfiles();
  }catch(e){alert('Lỗi: '+e.message)}
}
function copyPersona(id){navigator.clipboard.writeText(JSON.stringify({persona_id:id}))}
$('profiles-filter').oninput=()=>loadProfiles();
$('profiles-status-filter').onchange=()=>loadProfiles();
$('profiles-refresh').onclick=()=>loadProfiles();
$('profiles-sel-all').onchange=function(){
  document.querySelectorAll('.profile-chk').forEach(c=>{
    c.checked=this.checked;
    this.checked?selectedProfiles.add(c.value):selectedProfiles.delete(c.value);
  });
};
$('profiles-warm-selected').onclick=async()=>{
  if(!selectedProfiles.size){alert('Chọn ít nhất 1 profile');return;}
  const days=parseInt($('warm-days').value)||3;
  const urls=parseInt($('warm-urls').value)||5;
  const target=$('warm-target').value.trim()||null;
  const conc=parseInt($('warm-concurrency').value)||2;
  $('warm-msg').textContent='Đang khởi động warming…';
  $('warm-progress').style.display='block';
  $('warm-bar').style.width='5%';
  try{
    await api('/profiles/warm',{method:'POST',body:JSON.stringify({
      profile_ids:[...selectedProfiles],days,urls_per_day:urls,
      target_url:target,max_concurrency:conc,
    })});
    $('warm-msg').textContent='✅ Warming đã bắt đầu (chạy nền)';
    $('warm-bar').style.width='100%';
    setTimeout(loadProfiles,3000);
  }catch(e){$('warm-msg').textContent='Lỗi: '+e.message;$('warm-msg').style.color='var(--bad)'}
};
$('warm-run').onclick=()=>$('profiles-warm-selected').click();

// ══ SCHEDULER & MCP ══════════════════════════════════════════════════════
async function loadScheduler(){
  renderScheduleGrid();
  loadMcpStatus();
  loadHealingLog();
}
function renderScheduleGrid(){
  const grid=$('schedule-grid');
  const days=['','Thứ 2','Thứ 3','Thứ 4','Thứ 5','Thứ 6','Thứ 7','CN'];
  const hours=[0,2,4,6,8,10,12,14,16,18,20,22];
  grid.innerHTML='';
  // Header row
  days.forEach(d=>grid.innerHTML+=`<div style="text-align:center;color:var(--mute);font-weight:600;padding:4px;border-bottom:1px solid var(--line)">${d}</div>`);
  // Time rows
  hours.forEach(h=>{
    grid.innerHTML+=`<div style="color:var(--mute);font-size:.75rem;padding:4px;text-align:right">${String(h).padStart(2,'0')}:00</div>`;
    for(let d=1;d<=7;d++) grid.innerHTML+=`<div style="border:1px solid var(--line);border-radius:3px;min-height:28px;padding:2px;font-size:.72rem" id="sched-${d}-${h}"></div>`;
  });
  // Điền dữ liệu từ API
  api('/schedule/slots').then(r=>{
    (r.slots||[]).forEach(sl=>{
      const cell=$(`sched-${sl.day_of_week}-${sl.hour}`);
      if(cell) cell.innerHTML+=`<div style="background:var(--accent);color:#fff;border-radius:2px;padding:1px 3px;overflow:hidden;white-space:nowrap">${sl.scenario_id}</div>`;
    });
  }).catch(()=>{});
}
async function loadMcpStatus(){
  try{
    const r=await api('/mcp/status');
    $('mcp-status-val').textContent=r.running?'🟢 Chạy':'🔴 Dừng';
    $('mcp-status-val').style.color=r.running?'var(--accent)':'var(--bad)';
    $('mcp-req-val').textContent=r.requests_today??'–';
    $('mcp-uptime-val').textContent=r.uptime_human||'–';
    const toolsDiv=$('mcp-tools-list');
    toolsDiv.innerHTML=(r.tools||[]).map(t=>
      `<span class="badge" title="${t.description||''}">${t.name}</span>`
    ).join('');
  }catch(e){$('mcp-status-val').textContent='⚠️ Lỗi'}
}
async function loadHealingLog(){
  try{
    const r=await api('/healing/log');
    const tbody=$('healing-tbody');
    if(!r.entries||!r.entries.length){
      tbody.innerHTML='<tr><td colspan="6" style="color:var(--mute)">Chưa có lần heal nào.</td></tr>';return;
    }
    tbody.innerHTML=r.entries.map(e=>`<tr>
      <td style="color:var(--mute);font-size:.8rem">${e.healed_at?.slice(0,16)||'–'}</td>
      <td>${e.scenario_id||'–'}</td>
      <td><code style="font-size:.78rem">${(e.old_selector||'').slice(0,40)}</code></td>
      <td><code style="font-size:.78rem;color:var(--accent)">${(e.new_selector||'').slice(0,40)}</code></td>
      <td><span class="badge">${e.strategy||'–'}</span></td>
      <td>${(e.confidence*100||0).toFixed(0)}%</td>
    </tr>`).join('');
  }catch(e){}
}

// ── Tab Khả năng ─────────────────────────────────────────────────────────
let capsInited=false;
async function initCaps(){
  if(capsInited)return; capsInited=true;
  await runCapsCheck();
  loadTunnelList();
}

function capCard(name,ok,detail,icon){
  const color=ok===true?'var(--accent)':ok===false?'var(--bad)':'var(--warn)';
  const sym=ok===true?'✅':ok===false?'❌':'⚠️';
  return `<div style="border:1px solid var(--line);border-radius:6px;padding:.8rem">
    <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.3rem">
      <span style="font-size:1.3rem">${icon||sym}</span>
      <strong>${name}</strong>
      <span style="color:${color};margin-left:auto">${sym}</span>
    </div>
    <div style="font-size:.82rem;color:var(--mute)">${detail}</div>
  </div>`;
}

async function runCapsCheck(){
  $('caps-msg').textContent='Đang kiểm tra…';
  try{
    const r=await api('/capabilities');
    const g=$('caps-grid'); g.innerHTML='';
    const cards=[
      capCard('curl_cffi (TLS Fingerprint)', r.curl_cffi,
        r.curl_cffi?`v${r.curl_cffi_version||'?'} — JA3/JA4 + HTTP/2 ALPN thật`:'pip install curl_cffi','🔐'),
      capCard('Node.js (JS Probe)', r.nodejs,
        r.nodejs?`${r.nodejs_version||'?'} — PoW/HMAC/token signing`:'Cài Node.js để dùng js_probe','⚡'),
      capCard('PyMiniRacer (V8 cô lập)', r.miniracer,
        r.miniracer?'V8 sandbox - không cần Node':'pip install py-mini-racer','🏎'),
      capCard('Chromium (Playwright)', r.chromium,
        r.chromium?`${r.chromium_version||'?'}`:'playwright install chromium','🌐'),
      capCard('Firefox (Playwright)', r.firefox,
        r.firefox?r.firefox_version||'OK':'playwright install firefox — bị chặn ở môi trường sandbox','🦊'),
      capCard('WebKit (Playwright)', r.webkit,
        r.webkit?r.webkit_version||'OK':'playwright install webkit','🧭'),
      capCard('SQLite', r.sqlite, r.sqlite?`v${r.sqlite_version||'?'}`:'Lỗi DB','🗄'),
      capCard('httpx (HTTP/2)', r.httpx,
        r.httpx?`v${r.httpx_version||'?'} — HTTP/2 không có JA3`:'pip install httpx','📡'),
    ];
    g.innerHTML=cards.join('');
    $('caps-msg').textContent='';
    // Cập nhật curl status
    $('curl-status').innerHTML=r.curl_cffi
      ?`<span class="badge" style="background:var(--accent);color:#fff">✅ curl_cffi ${r.curl_cffi_version} sẵn sàng</span>`
      :`<span class="badge" style="background:var(--bad);color:#fff">❌ curl_cffi chưa cài — chạy: pip install curl_cffi</span>`;
    $('js-status').innerHTML=r.nodejs
      ?`<span class="badge" style="background:var(--accent);color:#fff">✅ Node.js ${r.nodejs_version}</span>`
      :r.miniracer
      ?`<span class="badge" style="background:var(--accent);color:#fff">✅ PyMiniRacer (V8)</span>`
      :`<span class="badge" style="background:var(--warn);color:#000">⚠️ Chưa có JS backend — cài Node.js hoặc py-mini-racer</span>`;
  }catch(e){$('caps-msg').textContent='Lỗi: '+e.message;$('caps-msg').style.color='var(--bad)'}
}
$('caps-run').onclick=()=>{capsInited=false;$('caps-grid').innerHTML='';initCaps()};

// curl_cffi live test
$('curl-test').onclick=async()=>{
  $('curl-msg').textContent='Đang test…'; $('curl-result').innerHTML='';
  try{
    const r=await api('/capabilities/curl-test');
    const ok=r.status===200||r.ok;
    $('curl-result').innerHTML=`<pre style="font-size:.8rem;background:var(--bg);padding:.5rem;border-radius:4px">${JSON.stringify(r,null,2)}</pre>`;
    $('curl-msg').textContent=ok?'✅ Thành công!':'⚠️ Có kết quả nhưng không phải 200';
    $('curl-msg').style.color=ok?'var(--accent)':'var(--warn)';
  }catch(e){$('curl-msg').textContent='Lỗi: '+e.message;$('curl-msg').style.color='var(--bad)'}
};

// JS probe test
$('js-run').onclick=async()=>{
  $('js-msg').textContent='Đang chạy…'; $('js-output').textContent='';
  try{
    const r=await api('/capabilities/js-run',{method:'POST',
      body:JSON.stringify({script:$('js-script').value})});
    $('js-output').textContent=r.output||r.error||'(không có output)';
    $('js-msg').textContent=r.error?'❌ Lỗi':'✅ Xong trong '+r.elapsed_ms+'ms';
    $('js-msg').style.color=r.error?'var(--bad)':'var(--accent)';
  }catch(e){$('js-msg').textContent='Lỗi: '+e.message;$('js-msg').style.color='var(--bad)'}
};

// ═══ Live Network Check ═══════════════════════════════════════════════════
$('net-check-run').onclick=async()=>{
  const btn=$('net-check-run'),msg=$('net-check-msg'),out=$('net-check-result');
  btn.disabled=true; msg.textContent='Đang kiểm tra mạng…'; msg.style.color='var(--mute)';
  out.innerHTML='';
  try{
    const r=await api('/capabilities/network-check');
    const rows=r.results.map(h=>{
      const icon=h.ok?'✅':'❌';
      const lat=h.ok?`<span style="color:var(--accent)">${h.elapsed_ms}ms</span>`:`<span style="color:var(--bad)">—</span>`;
      const detail=h.ok?`HTTP ${h.status} · ${(h.bytes/1024).toFixed(1)}KB`:`<span style="color:var(--bad)">${h.error||'timeout'}</span>`;
      return `<tr><td>${icon} <b>${h.host}</b></td><td>${lat}</td><td>${detail}</td></tr>`;
    }).join('');
    out.innerHTML=`<table style="width:100%;border-collapse:collapse;font-size:.85rem">
      <thead><tr style="color:var(--mute)"><th style="text-align:left;padding:.3rem .5rem">Host</th><th>Latency</th><th style="text-align:left;padding:.3rem .5rem">Kết quả</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
    const ok=r.reachable>0;
    msg.textContent=ok?`✅ ${r.reachable}/${r.total} host có thể truy cập`:`❌ Không thể kết nối bất kỳ host nào`;
    msg.style.color=ok?'var(--accent)':'var(--bad)';
  }catch(e){msg.textContent='Lỗi: '+e.message;msg.style.color='var(--bad)'}
  finally{btn.disabled=false}
};

// ═══ Live Browser Test ════════════════════════════════════════════════════
$('browser-live-run').onclick=async()=>{
  const btn=$('browser-live-run'),msg=$('browser-live-msg'),out=$('browser-live-result');
  btn.disabled=true; msg.textContent='Khởi động Chromium headless…'; msg.style.color='var(--mute)'; out.innerHTML='';
  try{
    const r=await api('/capabilities/browser-live');
    if(r.ok){
      out.innerHTML=`<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem;margin-top:.4rem">
        <div style="padding:.6rem;border:1px solid var(--line);border-radius:5px;text-align:center">
          <div style="font-size:1.6rem;font-weight:700;color:var(--accent)">${r.nav_elapsed_ms}ms</div>
          <div style="font-size:.78rem;color:var(--mute)">Nav Time</div>
        </div>
        <div style="padding:.6rem;border:1px solid var(--line);border-radius:5px;text-align:center">
          <div style="font-size:1.6rem;font-weight:700;color:var(--accent)">HTTP ${r.http_status}</div>
          <div style="font-size:.78rem;color:var(--mute)">Status Code</div>
        </div>
        <div style="padding:.6rem;border:1px solid var(--line);border-radius:5px;text-align:center">
          <div style="font-size:1.6rem;font-weight:700;color:var(--accent)">${(r.page_bytes/1024).toFixed(1)}KB</div>
          <div style="font-size:.78rem;color:var(--mute)">Page Size</div>
        </div>
      </div>
      <div style="margin-top:.5rem;font-size:.82rem;color:var(--mute)">URL: ${r.url} · Browser: ${r.browser} · Total: ${r.total_elapsed_ms}ms</div>`;
      msg.textContent='✅ Chromium hoạt động bình thường'; msg.style.color='var(--accent)';
    } else {
      out.innerHTML=`<pre style="font-size:.8rem;color:var(--bad);white-space:pre-wrap">${r.error}</pre>`;
      msg.textContent='❌ Browser test thất bại'; msg.style.color='var(--bad)';
    }
  }catch(e){msg.textContent='Lỗi: '+e.message;msg.style.color='var(--bad)'}
  finally{btn.disabled=false}
};

// ═══ TLS Fingerprint Comparison ═══════════════════════════════════════════
$('tls-fp-run').onclick=async()=>{
  const btn=$('tls-fp-run'),msg=$('tls-fp-msg'),out=$('tls-fp-result');
  btn.disabled=true; msg.textContent='Đang so sánh TLS fingerprint…'; msg.style.color='var(--mute)'; out.innerHTML='';
  try{
    const r=await api('/capabilities/tls-fingerprint');
    const cards=Object.entries(r.tests).map(([name,t])=>{
      const color=t.ok?(name==='curl_cffi'?'var(--accent)':'var(--warn)'):'var(--bad)';
      const icon=t.ok?(name==='curl_cffi'?'🛡️':'⚠️'):'❌';
      return `<div style="padding:.7rem;border:1px solid ${color};border-radius:6px;border-left:3px solid ${color}">
        <div style="font-weight:600">${icon} ${name} ${t.ok?`<span style="color:var(--accent)">${t.elapsed_ms}ms</span>`:''}</div>
        <div style="font-size:.8rem;color:var(--mute);margin-top:.3rem">${t.tls_library||''}</div>
        <div style="font-size:.78rem;margin-top:.3rem">${t.note||t.error||''}</div>
      </div>`;
    }).join('');
    out.innerHTML=`<div style="display:grid;grid-template-columns:1fr 1fr;gap:.7rem;margin-top:.5rem">${cards}</div>
      <div style="margin-top:.6rem;padding:.5rem .8rem;border-radius:5px;background:var(--bg);font-size:.83rem">
        💡 ${r.conclusion}
      </div>`;
    msg.textContent=r.ok?'✅ So sánh hoàn tất':'⚠️ Một số test thất bại';
    msg.style.color=r.ok?'var(--accent)':'var(--warn)';
  }catch(e){msg.textContent='Lỗi: '+e.message;msg.style.color='var(--bad)'}
  finally{btn.disabled=false}
};

// ═══ Playwright Browser Install Check ════════════════════════════════════
$('pw-install-run').onclick=async()=>{
  const btn=$('pw-install-run'),msg=$('pw-install-msg'),out=$('pw-install-result');
  btn.disabled=true; msg.textContent='Đang kiểm tra browsers…'; msg.style.color='var(--mute)'; out.innerHTML='';
  try{
    const r=await api('/capabilities/playwright-install');
    const rows=Object.entries(r.browsers).map(([name,b])=>{
      const icon=b.installed?'✅':'❌';
      const ver=b.version?`<code style="font-size:.78rem">${b.version}</code>`:'';
      const cmd=b.install_cmd?`<code style="font-size:.78rem;color:var(--accent)">${b.install_cmd}</code>`:'';
      return `<tr>
        <td style="padding:.35rem .5rem">${icon} <b>${name}</b></td>
        <td style="padding:.35rem .5rem">${b.installed?'Đã cài'+' '+ver:'Chưa cài '+cmd}</td>
      </tr>`;
    }).join('');
    out.innerHTML=`<table style="width:100%;border-collapse:collapse;font-size:.85rem;margin-top:.4rem">
      <tbody>${rows}</tbody></table>
      <div style="margin-top:.5rem;font-size:.8rem;color:var(--mute)">${r.note}</div>`;
    msg.textContent=`✅ ${r.installed.length} browser đã cài · ${r.missing.length} chưa cài`;
    msg.style.color=r.installed.length>0?'var(--accent)':'var(--bad)';
  }catch(e){msg.textContent='Lỗi: '+e.message;msg.style.color='var(--bad)'}
  finally{btn.disabled=false}
};

// ═══ PyWebView Desktop Mode Check ═════════════════════════════════════════
(()=>{
  // Phát hiện xem có đang chạy trong cửa sổ PyWebView không
  const isDesktop=window.__QA_DESKTOP_MODE__||
    document.documentElement.getAttribute('data-desktop')==='1';
  if(isDesktop){
    $('desktop-mode-badge').textContent='🖥️ Đang chạy trong cửa sổ Desktop (PyWebView)';
    $('desktop-mode-badge').style.background='var(--accent)';
    $('desktop-mode-badge').style.color='#fff';
    if(window.pywebview&&window.pywebview.api){
      window.pywebview.api.get_app_info().then(info=>{
        $('desktop-info').textContent=`v${info.version} · ${info.platform} · port ${info.base_url.split(':').pop()}`;
      }).catch(()=>{});
    }
  }
})();
$('pywebview-check').onclick=async()=>{
  const btn=$('pywebview-check'),msg=$('pywebview-msg'),out=$('pywebview-result');
  btn.disabled=true; msg.textContent='Kiểm tra…'; msg.style.color='var(--mute)'; out.innerHTML='';
  try{
    const r=await api('/capabilities');
    const pywv=r.modules&&r.modules.pywebview;
    const pyst=r.modules&&r.modules.pystray;
    out.innerHTML=`<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:.5rem;margin-top:.5rem">
      <div style="padding:.6rem;border:1px solid var(--line);border-radius:5px">
        <b>${pywv?'✅':'❌'} pywebview</b>
        <div style="font-size:.8rem;color:var(--mute);margin-top:.2rem">${pywv?'Cài đặt OK — Native window sẵn sàng':'Chưa cài: pip install pywebview'}</div>
      </div>
      <div style="padding:.6rem;border:1px solid var(--line);border-radius:5px">
        <b>${pyst?'✅':'❌'} pystray</b>
        <div style="font-size:.8rem;color:var(--mute);margin-top:.2rem">${pyst?'Cài đặt OK — System tray sẵn sàng':'Chưa cài hoặc thiếu Gtk (Linux)'}</div>
      </div>
    </div>
    <div style="margin-top:.6rem;font-size:.82rem;color:var(--mute)">
      Chạy <code>python app_launcher.py</code> từ thư mục dự án để mở cửa sổ desktop.
    </div>`;
    msg.textContent=(pywv&&pyst)?'✅ Đầy đủ — Desktop app sẵn sàng':pywv?'⚠️ pywebview OK nhưng thiếu pystray/Gtk':'⚠️ Thiếu pywebview';
    msg.style.color=(pywv&&pyst)?'var(--accent)':'var(--warn)';
  }catch(e){msg.textContent='Lỗi: '+e.message;msg.style.color='var(--bad)'}
  finally{btn.disabled=false}
};

// Tunnel list
async function loadTunnelList(){
  try{
    const r=await api('/tunnels');
    const tbody=$('tunnel-rows');
    if(!r.tunnels||!r.tunnels.length){
      tbody.innerHTML='<tr><td colspan="6" style="color:var(--mute)">Chưa có tunnel nào đang chạy.</td></tr>';return;
    }
    tbody.innerHTML=r.tunnels.map(t=>`<tr>
      <td><strong>${t.name}</strong></td>
      <td><code>${t.proxy_url}</code></td>
      <td>${t.pid}</td>
      <td>${Math.round(t.age_s)}s</td>
      <td><span class="badge" style="background:${t.healthy?'var(--accent)':'var(--bad)'};color:#fff">${t.healthy?'OK':'DEAD'}</span></td>
      <td><button class="ghost" onclick="stopTunnel('${t.name}')">Stop</button></td>
    </tr>`).join('');
  }catch(e){console.warn('loadTunnelList:',e)}
}
async function stopTunnel(name){
  try{await api('/tunnels/'+name,{method:'DELETE'});loadTunnelList();}catch(e){alert(e.message)}
}
$('tn-start').onclick=async()=>{
  const name=$('tn-name').value.trim(), binary=$('tn-bin').value.trim()||'xray';
  const cfg=$('tn-cfg').value.trim();
  if(!name){$('tn-msg').textContent='Nhập tên tunnel';return}
  $('tn-msg').textContent='Đang khởi động…';
  try{
    const r=await api('/tunnels',{method:'POST',body:JSON.stringify({name,binary,config_path:cfg||null})});
    $('tn-msg').textContent=`✅ ${r.proxy_url}`;$('tn-msg').style.color='var(--accent)';
    loadTunnelList();
  }catch(e){$('tn-msg').textContent='Lỗi: '+e.message;$('tn-msg').style.color='var(--bad)'}
};
$('tn-stop-all').onclick=async()=>{
  try{await api('/tunnels',{method:'DELETE'});$('tn-msg').textContent='Đã dừng tất cả';loadTunnelList();}catch(e){alert(e.message)}
};

// Trace inspector
let traceData=null;
$('trace-file').onchange=async(e)=>{
  const f=e.target.files[0]; if(!f)return;
  traceData=JSON.parse(await f.text());
  $('trace-preview').textContent=`✅ Đã tải: ${traceData.events?.length||0} sự kiện | URL: ${traceData.url||'?'}`;
  $('trace-msg').textContent='';
};
$('trace-inspect').onclick=()=>{
  if(!traceData){$('trace-msg').textContent='Chưa tải file';return}
  const evs=traceData.events||[];
  const types=evs.reduce((m,e)=>{m[e.type]=(m[e.type]||0)+1;return m},{});
  const dur=evs.length?evs[evs.length-1].t/1000:0;
  $('trace-preview').textContent=JSON.stringify({
    events:evs.length, duration_s:dur.toFixed(1),
    types, url:traceData.url, viewport:traceData.viewport,
    sample_events:evs.slice(0,5)
  },null,2);
};
$('trace-dl-jitter').onclick=()=>{
  if(!traceData){$('trace-msg').textContent='Chưa tải file';return}
  const sigmaT=parseFloat($('trace-sigma-t').value)||50;
  const sigmaC=parseFloat($('trace-sigma-c').value)||3;
  // Áp jitter đơn giản phía client
  const rng=()=>{ let u=0,v=0; while(!u)u=Math.random(); while(!v)v=Math.random();
    return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); };
  const vw=(traceData.viewport||{}).width||1280, vh=(traceData.viewport||{}).height||800;
  let prevT=0;
  const jittered={...traceData,events:traceData.events.map(ev=>{
    const delay=ev.t-prevT; prevT=ev.t;
    const jDelay=Math.max(0,delay+rng()*sigmaT);
    const jx=ev.x!=null?Math.max(0,Math.min(vw,ev.x+rng()*sigmaC)):ev.x;
    const jy=ev.y!=null?Math.max(0,Math.min(vh,ev.y+rng()*sigmaC)):ev.y;
    return {...ev,x:jx!=null?Math.round(jx*10)/10:ev.x,y:jy!=null?Math.round(jy*10)/10:ev.y};
  })};
  const blob=new Blob([JSON.stringify(jittered,null,2)],{type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download='recorded_trace_jittered.json'; a.click();
};
function adminKey(){return sessionStorage.getItem('qa_admin_key')||''}
let keyPromptInFlight=null;
async function askAdminKey(){
 if(keyPromptInFlight)return keyPromptInFlight;
 // Gán cờ TRƯỚC khi gọi prompt() (qua setTimeout tách khỏi ngăn xếp hiện tại): prompt() là API
 // chặn kiểu cũ, trình duyệt có thể chạy một vòng lặp sự kiện lồng bên trong lúc chờ người dùng
 // trả lời, khiến các lệnh gọi api() song song khác kịp chạy TRƯỚC KHI gán cờ nếu gán sau prompt().
 const p=new Promise((resolve,reject)=>{
   setTimeout(()=>{
     const entered=prompt('Tab Quản trị yêu cầu khoá xác thực (xem "python main.py admin-key"). Nhập khoá:');
     if(entered===null){reject(new Error('Cần khoá quản trị (X-Admin-Key)'));return}
     sessionStorage.setItem('qa_admin_key',entered);resolve(entered);
   },0);
 });
 keyPromptInFlight=p;
 try{return await p}finally{keyPromptInFlight=null}
}
async function api(path,opts){
 const headers={'Content-Type':'application/json'};const k=adminKey();if(k)headers['X-Admin-Key']=k;
 let r=await fetch('/api/admin'+path,{headers,...opts});
 if(r.status===401){
   headers['X-Admin-Key']=await askAdminKey();  // nhiều lệnh gọi song song dùng chung MỘT lần hỏi
   r=await fetch('/api/admin'+path,{headers,...opts});
 }
 const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.detail||r.statusText);return d;
}
function toB64(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(',')[1]);r.onerror=rej;r.readAsDataURL(file)})}
let adminLoaded=false;
async function loadAdmin(){await Promise.all([loadBrowserSettings(),loadPlugins(),loadIntegrations(),loadGatewayTab()]);adminLoaded=true}

/* -- 4.1 Browser Runtime Settings -- */
async function loadBrowserSettings(){
 const s=await api('/browser-settings');
 $('bs-exe').value=s.executable_path||'';$('bs-cdp').value=s.cdp_endpoint||'';
 $('bs-preflight-gate').checked=s.preflight_gate_enabled!==false;
 $('bs-analytics-verify').checked=s.analytics_verification_enabled!==false;
 $('bs-http').replaceChildren(...s.http_client_options.map(o=>{const op=document.createElement('option');op.value=o.value;op.textContent=o.label+(o.available?'':' [chưa cài]');op.selected=o.value===s.http_client;return op}));
 try{const f=await api('/browser-files');$('bs-exe-pick').replaceChildren($('bs-exe-pick').firstChild,...f.files.map(p=>{const op=document.createElement('option');op.value='browsers/'+p;op.textContent=p;return op}))}catch(e){}
 try{const cs=await api('/engine/custom-build/status');
   $('ce-status').textContent=cs.items.length?('Đã tải: '+cs.items.map(i=>i.name+' ('+i.size_mb+'MB)').join(', ')):'Chưa tải nhân trình duyệt tùy chỉnh nào.';
 }catch(e){}
}
$('bs-exe-pick').onchange=()=>{if($('bs-exe-pick').value)$('bs-exe').value=$('bs-exe-pick').value};
$('bs-test-cdp').onclick=async()=>{const btn=$('bs-test-cdp');btn.disabled=true;$('bs-msg').textContent='Đang kết nối…';
 try{const r=await api('/browser-settings/test-cdp',{method:'POST',body:JSON.stringify({endpoint:$('bs-cdp').value})});
 $('bs-msg').textContent=r.ok?`Kết nối OK - ${r.browser_version} (${r.existing_contexts} context đang mở)`:'Lỗi: '+r.error;
 $('bs-msg').style.color=r.ok?'var(--accent)':'var(--bad)'}catch(e){$('bs-msg').textContent='Lỗi: '+e.message;$('bs-msg').style.color='var(--bad)'}
 btn.disabled=false};
$('bs-save').onclick=async()=>{try{await api('/browser-settings',{method:'POST',body:JSON.stringify({
 executable_path:$('bs-exe').value,cdp_endpoint:$('bs-cdp').value,http_client:$('bs-http').value,
 preflight_gate_enabled:$('bs-preflight-gate').checked,analytics_verification_enabled:$('bs-analytics-verify').checked,
})});$('bs-msg').textContent='Đã lưu.';$('bs-msg').style.color='var(--accent)'}catch(e){$('bs-msg').textContent='Lỗi: '+e.message;$('bs-msg').style.color='var(--bad)'}};

/* -- Phase 10.1: Tải nhân trình duyệt mã nguồn mở từ GitHub Release -- */
$('ce-download').onclick=async()=>{
 const btn=$('ce-download');btn.disabled=true;$('ce-msg').textContent='Đang tải (có thể mất 1-2 phút)…';$('ce-msg').style.color='var(--mute)';
 try{
   const r=await api('/engine/custom-build/download',{method:'POST',body:JSON.stringify({repo:$('ce-repo').value,asset_pattern:$('ce-pattern').value})});
   if(r.ok){$('ce-msg').textContent=`✅ Đã tải ${r.asset} (${r.size_mb}MB)`+(r.executable_saved_to_settings?' - đã tự cập nhật executable_path':'');$('ce-msg').style.color='var(--accent)';
     if(r.executable_path)$('bs-exe').value=r.executable_path;
     loadBrowserSettings();
   }else{$('ce-msg').textContent='Không tìm thấy asset phù hợp: '+(r.available_assets||[]).join(', ');$('ce-msg').style.color='var(--bad)'}
 }catch(e){$('ce-msg').textContent='Lỗi: '+e.message;$('ce-msg').style.color='var(--bad)'}
 btn.disabled=false};

/* -- 4.2 Plugins & Extensions -- */
function inputField(name,inp,val){
 const id='pc-'+name+'-'+inp.key;
 if(inp.type==='boolean')return `<label style="display:inline-flex;align-items:center;gap:.4rem"><input type="checkbox" id="${id}" ${val?'checked':''}> ${inp.label}</label>`;
 const t=inp.type==='number'?'number':(inp.type==='password'?'password':'text');
 return `<label>${inp.label}</label><input id="${id}" type="${t}" value="${val==null?'':String(val).replace(/"/g,'&quot;')}">`;
}
async function loadPlugins(){
 const {plugins}=await api('/plugins');
 $('plugin-cards').replaceChildren(...plugins.map(p=>{
   const el=document.createElement('div');el.className='card';
   const manifest=p.manifest;const inputsHtml=manifest?manifest.inputs.map(i=>inputField(p.plugin_name,i,p.config[i.key])).join(''):'';
   el.innerHTML=`<div class="top"><div><b>${p.plugin_name}</b> <span class="badge">${manifest?manifest.version:'legacy'}</span><br>
     <span style="color:var(--mute)">${manifest?manifest.description:'Plugin kiểu cũ - không có biểu mẫu cấu hình'}</span></div>
     <label class="switch"><input type="checkbox" ${p.enabled?'checked':''} data-name="${p.plugin_name}" class="plg-toggle"><span class="slider"></span></label></div>
     ${inputsHtml?`<div style="margin-top:.5rem">${inputsHtml}<p><button class="ghost plg-save" data-name="${p.plugin_name}">Lưu cấu hình</button> <button class="danger plg-del" data-name="${p.plugin_name}">Xoá plugin</button></p></div>`:
       `<p><button class="danger plg-del" data-name="${p.plugin_name}">Xoá plugin</button></p>`}`;
   return el;
 }));
 $$('.plg-toggle').forEach(el=>el.onchange=async()=>{await api(`/plugins/${el.dataset.name}/enabled`,{method:'POST',body:JSON.stringify({enabled:el.checked})})});
 $$('.plg-save').forEach(el=>el.onclick=async()=>{
   const p=plugins.find(x=>x.plugin_name===el.dataset.name);const config={};
   (p.manifest?p.manifest.inputs:[]).forEach(i=>{const node=$('pc-'+p.plugin_name+'-'+i.key);config[i.key]=i.type==='boolean'?node.checked:node.value});
   await api(`/plugins/${p.plugin_name}/config`,{method:'POST',body:JSON.stringify({config})});
   $('plugin-msg').textContent=`Đã lưu cấu hình cho ${p.plugin_name}.`;$('plugin-msg').style.color='var(--accent)';
 });
 $$('.plg-del').forEach(el=>el.onclick=async()=>{if(!confirm('Xoá plugin '+el.dataset.name+'?'))return;await api('/plugins/'+el.dataset.name,{method:'DELETE'});loadPlugins()});
}
function $$(sel){return [...document.querySelectorAll(sel)]}
async function installPluginFile(file){
 $('plugin-msg').textContent='Đang cài '+file.name+'…';$('plugin-msg').style.color='var(--ink)';
 try{const b64=await toB64(file);const r=await api('/plugins/install',{method:'POST',body:JSON.stringify({filename:file.name,content_base64:b64})});
 $('plugin-msg').textContent=`Đã cài plugin '${r.installed}'.`;$('plugin-msg').style.color='var(--accent)';loadPlugins()}
 catch(e){$('plugin-msg').textContent='Lỗi cài plugin: '+e.message;$('plugin-msg').style.color='var(--bad)'}
}
const dz=$('plugin-drop');
['dragover','dragleave','drop'].forEach(ev=>dz.addEventListener(ev,e=>e.preventDefault()));
dz.addEventListener('dragover',()=>dz.classList.add('over'));
dz.addEventListener('dragleave',()=>dz.classList.remove('over'));
dz.addEventListener('drop',e=>{dz.classList.remove('over');const f=e.dataTransfer.files[0];if(f)installPluginFile(f)});
$('plugin-file').onchange=e=>{const f=e.target.files[0];if(f)installPluginFile(f)};

/* -- 4.3 Integrations & APIs -- */
const SERVICE_TYPES=[['webhook','Webhook (gọi được từ workflow)'],['captcha_solver','Dịch vụ giải biểu mẫu xác thực (chỉ lưu cấu hình)'],['cloud_storage','Lưu trữ đám mây (chỉ lưu cấu hình)'],['custom','Khác']];
$('in-type').replaceChildren(...SERVICE_TYPES.map(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;return o}));
async function loadIntegrations(){
 const {integrations}=await api('/integrations');
 $('integration-cards').replaceChildren(...integrations.map(i=>{
   const el=document.createElement('div');el.className='card';
   el.innerHTML=`<div class="top"><div><b>${i.name}</b> <span class="badge">${i.service_type}</span>
     ${i.verified?'<span class="badge ok">đã xác minh</span>':'<span class="badge failed">chưa xác minh</span>'}<br>
     <span style="color:var(--mute)">${i.endpoint_url||'(chưa có endpoint)'} · key: ${i.api_key_masked||'(chưa có)'}</span></div>
     <button class="danger int-del" data-name="${i.name}">Xoá</button></div>`;
   return el;
 }));
 $$('.int-del').forEach(el=>el.onclick=async()=>{if(!confirm('Xoá tích hợp '+el.dataset.name+'?'))return;await api('/integrations/'+el.dataset.name,{method:'DELETE'});loadIntegrations()});
}
$('in-save').onclick=async()=>{
 $('in-msg').textContent='Đang lưu…';$('in-msg').style.color='var(--ink)';
 let extra={};try{extra=$('in-extra').value.trim()?JSON.parse($('in-extra').value):{}}catch(e){$('in-msg').textContent='Extra không phải JSON hợp lệ';$('in-msg').style.color='var(--bad)';return}
 try{
   await api('/integrations',{method:'POST',body:JSON.stringify({name:$('in-name').value,service_type:$('in-type').value,endpoint_url:$('in-url').value,api_key:$('in-key').value||null,extra})});
   const v=await api(`/integrations/${encodeURIComponent($('in-name').value)}/verify`,{method:'POST'});
   $('in-msg').textContent=(v.ok?'Đã lưu và xác minh OK.':'Đã lưu, nhưng xác minh thất bại: '+(v.error||v.http_status))+(v.note?' '+v.note:'');
   $('in-msg').style.color=v.ok?'var(--accent)':'var(--warn)';
   $('in-key').value='';loadIntegrations();
 }catch(e){$('in-msg').textContent='Lỗi: '+e.message;$('in-msg').style.color='var(--bad)'}
};

/* -- 4.4 Visual Gateway Manager -- */
async function loadGatewayTab(){const g=await api('/gateways');$('gw-text').value=g.raw_text;renderGwChecks((await api('/gateways/checks')).checks)}
$('gw-import').onclick=async()=>{
 const mode=document.querySelector('input[name=gw-mode]:checked').value;
 try{const r=await api('/gateways/import',{method:'POST',body:JSON.stringify({text:$('gw-text').value,mode})});
 $('gw-msg').textContent=`Đã nạp ${r.parsed_count} gateway hợp lệ.`;$('gw-msg').style.color='var(--accent)';loadGatewayTab()}
 catch(e){$('gw-msg').textContent='Lỗi: '+e.message;$('gw-msg').style.color='var(--bad)'}
};
function flagEmoji(cc){if(!cc||cc.length!==2)return'';try{return String.fromCodePoint(...[...cc.toUpperCase()].map(c=>0x1F1E6+c.charCodeAt(0)-65))}catch(e){return''}}
function renderGwChecks(checks){
 fill($('gw-result'),['Gateway','Vùng','Trạng thái','ms','Quốc gia','Timezone','Locale','Lúc kiểm tra'],
   checks.map(c=>[c.gateway,c.region,{t:c.healthy?'tốt':'lỗi',cls:c.healthy?'ok':'failed'},fmt(c.latency_ms),flagEmoji(c.country),fmt(c.timezone_id),fmt(c.locale),(c.checked_at||'').slice(0,19)]));
}
let gwJob=null;
$('gw-check').onclick=async()=>{
 try{const r=await api('/gateways/check',{method:'POST'});gwJob=r.job_id;
 $('gw-progress').classList.remove('hidden');$('gw-progress').querySelector('i').style.width='0%';
 $('gw-msg').textContent=`Đang kiểm tra 0/${r.total}…`;$('gw-msg').style.color='var(--ink)'}
 catch(e){$('gw-msg').textContent='Lỗi: '+e.message;$('gw-msg').style.color='var(--bad)'}
};
function onGatewayProgress(e){
 if(e.job_id!==gwJob)return;
 const pct=e.total?Math.round(100*e.done/e.total):0;
 $('gw-progress').querySelector('i').style.width=pct+'%';
 $('gw-msg').textContent=`Đang kiểm tra ${e.done}/${e.total}…`;
 if(e.finished){$('gw-msg').textContent=`Hoàn tất ${e.total}/${e.total}.`;$('gw-msg').style.color='var(--accent)';
   setTimeout(()=>$('gw-progress').classList.add('hidden'),1500);api('/gateways/checks').then(r=>renderGwChecks(r.checks))}
}
</script></body></html>"""


def create_app(db: Database, bus: EventBus, status_fn: Callable[[], dict], paths: Paths) -> Any:
    if FastAPI is None:
        raise RuntimeError("Cần cài fastapi và uvicorn để dùng dashboard: pip install fastapi uvicorn")
    app = FastAPI(title="QA Orchestrator", docs_url=None, redoc_url=None)

    # Bảng điều khiển No-Code (mục 4.1-4.4) - nhập ở đây (không phải đầu module) vì nó
    # giả định fastapi đã có sẵn, điều mà nhánh ImportError phía trên vừa xác nhận.
    from admin_api import create_admin_router
    app.include_router(create_admin_router(db, paths, bus), prefix="/api/admin")

    # Phục vụ JS/CSS đã bundle cục bộ (Drawflow, Alpine.js) — không cần CDN
    _static_dir = Path(__file__).parent / "static_assets"
    if StaticFiles is not None and _static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def index() -> str:
        return PAGE

    @app.get("/events")
    async def events(request: Request) -> StreamingResponse:
        queue = bus.subscribe()

        async def stream():
            try:
                for e in bus.history()[-200:]:
                    yield f"data: {json.dumps(e, ensure_ascii=False)}\n\n"
                while not await request.is_disconnected():
                    try:
                        e = await asyncio.wait_for(queue.get(), timeout=15)
                        yield f"data: {json.dumps(e, ensure_ascii=False)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keep-alive\n\n"
            finally:
                bus.unsubscribe(queue)

        return StreamingResponse(stream(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/api/runs")
    async def runs(limit: int = 100) -> Any:
        return JSONResponse(await db.arecent_runs(min(max(limit, 1), 500)))

    @app.get("/api/status")
    async def status() -> Any:
        result = status_fn()
        if asyncio.iscoroutine(result):
            result = await result
        return JSONResponse(result)

    @app.get("/api/report")
    async def report(format: str = "json", since: Optional[str] = None) -> Any:
        rep = build_report(await db.ametric_rows(since))
        if format == "csv":
            return PlainTextResponse(to_csv(rep), media_type="text/csv; charset=utf-8")
        if format == "html":
            return HTMLResponse(to_html(rep))
        return JSONResponse(json.loads(to_json(rep)))

    return app


def make_server(app: Any, host: str, port: int) -> Any:
    """Tạo uvicorn.Server chạy trong cùng event loop; tín hiệu do main.py quản lý."""
    import uvicorn

    server = uvicorn.Server(uvicorn.Config(app, host=host, port=port, log_level="warning"))
    server.install_signal_handlers = lambda: None          # uvicorn < 0.29
    server.capture_signals = contextlib.nullcontext        # uvicorn >= 0.29
    return server
