"""Mô phỏng tương tác giao diện: dừng đọc (log-normal), di chuyển con trỏ theo đường cong,
cuộn từng phân đoạn, điều hướng liên kết nội bộ, điền biểu mẫu dữ liệu giả.
Mục đích: kích hoạt đầy đủ lazy-load / IntersectionObserver / onscroll / onmouseover khi test."""
from __future__ import annotations

import asyncio
import logging
import math
import random
from dataclasses import dataclass
from typing import Any, Callable, Optional
from urllib.parse import urldefrag, urlsplit

from test_data import TestDataGenerator

LOGGER = logging.getLogger("qa.interaction")

FILLABLE = ("input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=checkbox])"
            ":not([type=radio]):not([type=file]):not([type=image]), textarea")


@dataclass
class InteractionConfig:
    dwell_time_range: tuple[float, float] = (1.0, 4.0)   # giây
    scroll: bool = True
    cursor: bool = True
    hover_samples: int = 3
    internal_click_depth: int = 0
    fill_forms: bool = False
    submit_forms: bool = False
    max_scroll_steps: int = 40

    @classmethod
    def from_dict(cls, d: Optional[dict[str, Any]]) -> "InteractionConfig":
        d = dict(d or {})
        if "dwell_time_range" in d:
            d["dwell_time_range"] = tuple(d["dwell_time_range"])
        known = cls.__dataclass_fields__
        return cls(**{k: v for k, v in d.items() if k in known})


class InteractionSimulator:
    def __init__(self, cfg: InteractionConfig, data: TestDataGenerator,
                 rng: Optional[random.Random] = None) -> None:
        self.cfg, self.data = cfg, data
        self.rng = rng or random.Random()
        self._pos = (0.0, 0.0)

    # ------------------------------------------------------------ dwell
    def sample_dwell(self) -> float:
        """Log-normal: trung vị = trung bình nhân của khoảng, ~90% mẫu nằm trong khoảng."""
        lo, hi = self.cfg.dwell_time_range
        lo = max(lo, 0.05)
        hi = max(hi, lo)
        if hi == lo:
            return lo
        sigma = math.log(hi / lo) / 3.29
        value = self.rng.lognormvariate(math.log(math.sqrt(lo * hi)), sigma)
        return min(max(value, lo), hi)

    async def dwell(self) -> float:
        seconds = self.sample_dwell()
        await asyncio.sleep(seconds)
        return seconds

    # ------------------------------------------------------------ con trỏ
    async def move_cursor(self, page: Any, x: float, y: float, steps: int = 24) -> None:
        """Đường cong Bezier bậc 3 với điểm điều khiển ngẫu nhiên."""
        x0, y0 = self._pos
        c1 = (x0 + (x - x0) * 0.3 + self.rng.uniform(-60, 60), y0 + (y - y0) * 0.1 + self.rng.uniform(-60, 60))
        c2 = (x0 + (x - x0) * 0.7 + self.rng.uniform(-60, 60), y0 + (y - y0) * 0.9 + self.rng.uniform(-60, 60))
        for i in range(1, steps + 1):
            t = i / steps
            u = 1 - t
            bx = u**3 * x0 + 3 * u**2 * t * c1[0] + 3 * u * t**2 * c2[0] + t**3 * x
            by = u**3 * y0 + 3 * u**2 * t * c1[1] + 3 * u * t**2 * c2[1] + t**3 * y
            await page.mouse.move(bx, by)
            await asyncio.sleep(0.006)
        self._pos = (x, y)

    async def hover_samples(self, page: Any) -> int:
        loc = page.locator("a[href], button")
        try:
            count = await loc.count()
        except Exception:  # noqa: BLE001
            return 0
        hovered = 0
        for idx in self.rng.sample(range(count), min(count, self.cfg.hover_samples)):
            try:
                box = await loc.nth(idx).bounding_box()
                if box and box["width"] > 0 and box["height"] > 0:
                    await self.move_cursor(page, box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
                    hovered += 1
            except Exception:  # noqa: BLE001 - phần tử biến mất: bỏ qua
                continue
        return hovered

    # ------------------------------------------------------------ cuộn
    async def incremental_scroll(self, page: Any) -> int:
        try:
            vh = await page.evaluate("window.innerHeight")
        except Exception:  # noqa: BLE001
            return 0
        steps = 0
        for _ in range(self.cfg.max_scroll_steps):
            await page.mouse.wheel(0, int(vh * self.rng.uniform(0.4, 0.8)))
            await page.wait_for_timeout(self.rng.randint(150, 450))
            steps += 1
            if await page.evaluate("window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2"):
                break
        return steps

    # ------------------------------------------------------------ liên kết nội bộ
    async def click_internal_links(self, page: Any, is_allowed: Callable[[str], bool]) -> list[str]:
        visited: list[str] = []
        for _ in range(self.cfg.internal_click_depth):
            host = urlsplit(page.url).hostname
            hrefs: list[str] = await page.eval_on_selector_all("a[href]", "els => els.map(e => e.href)")
            current = urldefrag(page.url)[0]
            cands = [(i, h) for i, h in enumerate(hrefs)
                     if h.startswith(("http://", "https://")) and urlsplit(h).hostname == host
                     and urldefrag(h)[0] != current and is_allowed(h)]
            if not cands:
                break
            idx, target = self.rng.choice(cands)
            try:
                await page.locator("a[href]").nth(idx).click(timeout=5000)
                await page.wait_for_load_state("load")
            except Exception:  # noqa: BLE001 - không bấm được: điều hướng trực tiếp
                await page.goto(target, wait_until="load")
            visited.append(page.url)
            await self.dwell()
        return visited

    # ------------------------------------------------------------ biểu mẫu
    async def fill_forms(self, page: Any) -> int:
        filled = 0
        for form in await page.locator("form").all():
            fields = await form.locator(FILLABLE).all()
            for el in fields:
                try:
                    if not (await el.is_visible() and await el.is_editable()):
                        continue
                    attrs = await el.evaluate(
                        "e => [e.type, e.name, e.id, e.placeholder, e.autocomplete, "
                        "e.getAttribute('aria-label'), e.tagName].filter(Boolean).join(' ')")
                    free = "TEXTAREA" in attrs or "message" in attrs.lower() or "comment" in attrs.lower()
                    await el.fill(await self.data.text(attrs, free_text=free), timeout=3000)
                    filled += 1
                except Exception:  # noqa: BLE001
                    continue
            if self.cfg.submit_forms:
                try:
                    await form.locator("[type=submit], button:not([type])").first.click(timeout=3000)
                except Exception:  # noqa: BLE001
                    pass
        return filled

    # ------------------------------------------------------------ tổng hợp
    async def run(self, page: Any, is_allowed: Callable[[str], bool]) -> dict[str, Any]:
        summary: dict[str, Any] = {}
        if self.cfg.cursor:
            summary["hovered"] = await self.hover_samples(page)
        if self.cfg.scroll:
            summary["scroll_steps"] = await self.incremental_scroll(page)
        if self.cfg.fill_forms:
            summary["fields_filled"] = await self.fill_forms(page)
        summary["dwell_s"] = round(await self.dwell(), 2)
        if self.cfg.internal_click_depth:
            summary["visited"] = await self.click_internal_links(page, is_allowed)
        return summary
