"""
ui/desktop_window.py — Quản Lý Cửa Sổ Desktop (PyWebView)
Phân hệ cửa sổ gốc không viền trình duyệt dùng thư viện pywebview.

Tính năng:
  - Cửa sổ native (không có thanh địa chỉ) → trông như phần mềm thật
  - Tích hợp JS bridge: dashboard có thể gọi Python API từ JS
  - Tự phát hiện nền tảng và chọn backend WebView phù hợp
  - Hỗ trợ multi-window (có thể mở thêm cửa sổ chọn phần tử / preview)
  - Xử lý graceful fallback khi không có display

Giới hạn:
  - PyWebView yêu cầu display (X11/Wayland/Quartz/Win32).
    Trên headless server: set DISPLAY=:99 hoặc dùng Xvfb.
  - macOS: cần chạy trong main thread (pywebview yêu cầu main thread).
  - Linux: cần libwebkit2gtk-4.0 (thường có sẵn trên Ubuntu 20+).
  - Windows: dùng Edge/WebView2 mặc định (cần Edge Chromium hoặc WebView2 Runtime).
"""
from __future__ import annotations

import logging
import os
import platform
import threading
from pathlib import Path
from typing import Any, Callable, Optional

LOGGER = logging.getLogger("qa.desktop_window")

APP_TITLE = "Synthetic Automation Studio"
APP_WIDTH  = 1360
APP_HEIGHT = 860
APP_MIN_W  = 960
APP_MIN_H  = 640


# ---------------------------------------------------------------------------
# JS Bridge — Python API có thể gọi từ JS trong WebView
# ---------------------------------------------------------------------------

class JSBridge:
    """
    Các method của class này sẽ được expose vào JavaScript dưới namespace
    ``window.pybridge.*`` (pywebview v3+) hoặc ``window.qabridge.*``.

    Ví dụ trong JS của dashboard:
        const info = await window.pywebview.api.get_app_info();
    """

    def __init__(self, base_url: str, version: str = "1.0") -> None:
        self._base_url = base_url
        self._version = version

    def get_app_info(self) -> dict:
        """Trả về thông tin ứng dụng cho dashboard."""
        return {
            "app_title": APP_TITLE,
            "version": self._version,
            "platform": platform.system(),
            "base_url": self._base_url,
            "mode": "desktop",
        }

    def open_url_external(self, url: str) -> bool:
        """Mở URL trong trình duyệt hệ thống mặc định."""
        import webbrowser
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False

    def show_folder(self, folder: str) -> bool:
        """Mở thư mục trong File Explorer / Finder."""
        import subprocess
        path = Path(folder)
        if not path.exists():
            return False
        try:
            system = platform.system()
            if system == "Windows":
                os.startfile(str(path))
            elif system == "Darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
            return True
        except Exception as exc:
            LOGGER.warning("Không mở được thư mục %s: %s", folder, exc)
            return False

    def pick_file(self, file_types: Optional[list] = None) -> Optional[str]:
        """Mở hộp thoại chọn file (chạy trong WebView thread)."""
        try:
            import webview
            result = webview.windows[0].create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=tuple(file_types) if file_types else (),
            )
            return result[0] if result else None
        except Exception:
            return None

    def pick_directory(self) -> Optional[str]:
        """Mở hộp thoại chọn thư mục."""
        try:
            import webview
            result = webview.windows[0].create_file_dialog(
                webview.FOLDER_DIALOG,
            )
            return result[0] if result else None
        except Exception:
            return None

    def save_file(self, suggested: str = "export.json",
                  file_types: Optional[list] = None) -> Optional[str]:
        """Mở hộp thoại lưu file."""
        try:
            import webview
            result = webview.windows[0].create_file_dialog(
                webview.SAVE_DIALOG,
                save_filename=suggested,
                file_types=tuple(file_types) if file_types else (),
            )
            return result if isinstance(result, str) else None
        except Exception:
            return None


# ---------------------------------------------------------------------------
# Main window manager
# ---------------------------------------------------------------------------

class DesktopWindowManager:
    """
    Quản lý toàn bộ cửa sổ PyWebView cho ứng dụng.
    Phải được tạo và .open() từ main thread (đặc biệt trên macOS).
    """

    def __init__(
        self,
        dashboard_url: str,
        title: str = APP_TITLE,
        on_close_to_tray: Optional[Callable] = None,
        on_destroy: Optional[Callable] = None,
        version: str = "1.0",
    ) -> None:
        self.dashboard_url = dashboard_url
        self.title = title
        self._on_close_to_tray = on_close_to_tray
        self._on_destroy = on_destroy
        self._version = version
        self._window: Any = None
        self._webview_available = False
        self._stopped = False

    # ------------------------------------------------------------------
    # Import check
    # ------------------------------------------------------------------

    def check_available(self) -> bool:
        """Kiểm tra pywebview có sẵn hay không."""
        try:
            import webview  # noqa: F401
            self._webview_available = True
            LOGGER.debug("pywebview OK")
        except ImportError:
            LOGGER.warning(
                "pywebview chưa được cài đặt. "
                "Chạy: pip install pywebview "
                "Để có cửa sổ gốc native trên %s", platform.system()
            )
        return self._webview_available

    # ------------------------------------------------------------------
    # Window creation
    # ------------------------------------------------------------------

    def open(self) -> None:
        """
        Tạo và hiện cửa sổ. Blocking — chương trình block ở đây
        cho đến khi cửa sổ bị đóng hẳn.
        Nếu pywebview không có: mở trình duyệt hệ thống.
        """
        if not self._webview_available:
            self._fallback_browser()
            return

        import webview

        bridge = JSBridge(self.dashboard_url, self._version)

        self._window = webview.create_window(
            self.title,
            url=self.dashboard_url,
            js_api=bridge,
            width=APP_WIDTH,
            height=APP_HEIGHT,
            min_size=(APP_MIN_W, APP_MIN_H),
            resizable=True,
            text_select=True,
            easy_drag=False,
            on_top=False,
            shadow=True,
        )

        # Hook sự kiện đóng cửa sổ
        self._window.events.closing += self._handle_closing
        self._window.events.loaded  += self._handle_loaded

        LOGGER.info("Mở cửa sổ desktop: %s", self.dashboard_url)
        # webview.start() BLOCKING — block cho đến khi tất cả windows đóng
        webview.start(debug=False, gui=self._detect_gui())
        LOGGER.info("Tất cả cửa sổ đã đóng")

        if self._on_destroy:
            self._on_destroy()

    # ------------------------------------------------------------------
    # Window control
    # ------------------------------------------------------------------

    def show(self) -> None:
        """Hiện cửa sổ đang ẩn (khi restore từ tray)."""
        if self._window and not self._stopped:
            try:
                self._window.show()
                self._window.on_top = True
                self._window.on_top = False
                LOGGER.debug("Hiện lại cửa sổ")
            except Exception as exc:
                LOGGER.debug("show() lỗi: %s", exc)

    def hide(self) -> None:
        """Ẩn cửa sổ xuống tray."""
        if self._window:
            try:
                self._window.hide()
            except Exception:
                pass

    def destroy(self) -> None:
        """Đóng và hủy cửa sổ."""
        self._stopped = True
        if self._window:
            try:
                import webview
                for w in list(webview.windows):
                    w.destroy()
            except Exception:
                pass

    def open_child(self, url: str, title: str = "",
                   width: int = 1024, height: int = 768) -> None:
        """Mở cửa sổ con (ví dụ: Visual Picker)."""
        if not self._webview_available:
            import webbrowser
            webbrowser.open(url)
            return
        import webview
        webview.create_window(title or url, url=url, width=width, height=height)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_closing(self) -> Optional[bool]:
        """
        Gọi khi người dùng nhấn ×.
        Trả về False → ngăn đóng (ẩn xuống tray thay thế).
        Trả về None/True → cho phép đóng.
        """
        if self._on_close_to_tray and not self._stopped:
            LOGGER.info("Ẩn cửa sổ xuống system tray")
            self._window.hide()
            self._on_close_to_tray()
            return False
        return None

    def _handle_loaded(self) -> None:
        """Gọi khi trang đã load xong — inject JS tiện ích."""
        if self._window:
            try:
                # Inject helper để dashboard biết đang chạy trong desktop mode
                self._window.evaluate_js(
                    "window.__QA_DESKTOP_MODE__ = true;"
                    "document.documentElement.setAttribute('data-desktop','1');"
                )
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_gui() -> Optional[str]:
        """Chọn backend GUI phù hợp theo nền tảng."""
        sys_name = platform.system()
        if sys_name == "Windows":
            return "edgechromium"
        if sys_name == "Darwin":
            return "cocoa"
        # Linux: thử mshtml (không có), dùng gtk mặc định
        return None

    def _fallback_browser(self) -> None:
        """Fallback: mở trình duyệt hệ thống khi không có PyWebView."""
        import webbrowser
        LOGGER.info("Fallback: mở %s trong trình duyệt hệ thống", self.dashboard_url)
        webbrowser.open(self.dashboard_url)


# ---------------------------------------------------------------------------
# Quick test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:18080"
    mgr = DesktopWindowManager(url)
    if not mgr.check_available():
        print(f"pywebview không có. Mở {url} trong trình duyệt.")
        mgr._fallback_browser()
    else:
        print(f"Mở cửa sổ desktop: {url}")
        mgr.open()
