# Synthetic QA Orchestrator

Kiểm thử giao diện (E2E), đo Core Web Vitals từ nhiều vùng mạng, quản lý nhiều profile trình duyệt,
định tuyến đa nhân (HTTP thuần / Chromium / Firefox / WebKit), và một bảng điều khiển trên web để
cấu hình mọi thứ **không cần sửa code**. Chạy di động trên Windows / macOS / Linux.

**Phase 3 (mới nhất):** Thực thi JS nhẹ (Proof-of-Work/HMAC) trước khi mở trình duyệt,
quản lý SOCKS5 tunnel sidecar (Xray-core/Sing-box), kiểm định iframe đa nguồn & đo
buffering media, và ghi/phát lại chuỗi thao tác người dùng với Gaussian Jitter.

> **Đang phát triển tiếp dự án này?** Đọc `PROJECT.md` trước - đó là tài liệu tiến độ đầy đủ
> (đã làm gì, đã test gì, giới hạn gì, còn tồn đọng gì) để không phải đọc lại lịch sử chat.

## Có build sẵn cho cả 3 hệ điều hành mà không cần máy tính riêng

Nuitka không biên dịch chéo, nhưng GitHub Actions có sẵn máy ảo Windows, macOS và Linux (miễn phí cho repo công khai;
repo riêng tư dùng hạn mức miễn phí hằng tháng). Workflow `.github/workflows/build.yml` tự biên dịch cả 3 bản.

1. Tạo repo trên github.com và tải toàn bộ mã nguồn lên (nhớ cả thư mục `.github/workflows/`).
   - Trên điện thoại, thư mục ẩn khó tải lên: dùng *Add file > Create new file*, gõ tên
     `.github/workflows/build.yml` rồi dán nội dung tệp này.
2. Mở tab **Actions** > **Build portable packages** > **Run workflow**. Chờ khoảng 10-20 phút.
3. Vào lần chạy vừa xong, mục **Artifacts** ở cuối trang: tải `synthetic-qa-orchestrator-Windows/macOS/Linux`.
   Giải nén hai lớp zip (GitHub bọc thêm một lớp). Đẩy tag dạng `v1.0.0` thì bản build còn được đính vào **Releases**.
4. **Bước này CHƯA được chạy thử thật** (môi trường phát triển không có GitHub) - nếu một bước nào đó báo đỏ,
   gửi lại log của bước đó để sửa `build.yml` hoặc phần `# nuitka-project:` đầu `main.py`.

Gói tải về đã chứa sẵn Chromium trong `browsers/`, không cần cài gì thêm.
- Windows: nhấp đúp `runner.exe` (SmartScreen hiện cảnh báo thì chọn *More info > Run anyway*).
- macOS (Apple Silicon): chạy `xattr -dr com.apple.quarantine <thư mục>` một lần, rồi `./runner`.
- Linux: `./runner`. Nếu báo thiếu thư viện `.so`, cài thêm `libnss3`, `libgbm1`, `libasound2`.

## Chạy từ mã nguồn
    pip install -r requirements.txt
    python main.py install-browsers
    python main.py run --dashboard        # chạy một lần, mở http://127.0.0.1:8787
    python main.py schedule --cron "*/30 * * * *"
    python main.py validate-gateways       # kiểm định hàng loạt gateway, ghi vào DB
    python main.py mcp-server               # MCP server qua stdio cho Claude Desktop/Cursor
    python main.py report --format all

## Lệnh
| Lệnh | Việc làm |
|---|---|
| `run` (mặc định) | chạy một lần mọi kịch bản `active`; xuất báo cáo vào `data/reports/` |
| `schedule` | chạy theo cron (APScheduler) HOẶC theo `settings.schedule_windows` (đa ngày/qua đêm) |
| `produce` / `worker` | phân tán: đẩy tác vụ vào Redis / nhận tác vụ từ Redis |
| `report` | xuất HTML / CSV / JSON (p50, p95, p99) từ `data/state.db` |
| `validate-gateways` | kiểm định hàng loạt gateway: độ trễ, exit IP, quốc gia/ISP, timezone |
| `mcp-server` | chạy MCP server qua stdio (tools: `create_test_scenario`, `trigger_execution`, `get_diagnostic_report`) |
| `admin-key --generate` | sinh khoá bảo vệ tab Quản trị (`--set KEY` / `--clear` / không tham số để xem trạng thái) |

Tùy chọn chung: `--concurrency N`, `--iterations N`, `--scenario ID`, `--headed`, `-v`.

## Bảng điều khiển trên Web (Dashboard → tab "Quản trị")

Mở `python main.py run --dashboard`, vào `http://127.0.0.1:8787`, bấm tab **Quản trị** để:
- **Browser Runtime Settings**: trỏ tới trình duyệt tuỳ chỉnh, kết nối tới trình duyệt đang chạy sẵn
  qua CDP (`http://localhost:9222`), đổi thư viện HTTP client (`httpx`/`curl_cffi`).
- **Plugins & Extensions**: kéo-thả một file `.zip` (gồm `manifest.json` + `main.py`) để cài plugin,
  bật/tắt, và điền cấu hình qua biểu mẫu tự sinh từ `manifest.json` - không cần mở code.
- **Integrations & APIs**: lưu endpoint + API key (mã hoá tại chỗ) cho 3 loại dịch vụ, gọi được từ
  workflow qua bước `{"action":"call_integration","name":"...","payload":{...}}`:
  - `webhook`: POST JSON + Bearer token (Slack/Discord/nội bộ).
  - `captcha_solver`: giao thức kiểu 2Captcha (`in.php`/`res.php`), tự điền token vào trang qua
    `payload.inject_selector` (mặc định `#g-recaptcha-response`). Chỉ đúng với endpoint tương
    thích 2Captcha.
  - `cloud_storage`: PUT ảnh chụp màn hình gần nhất (cần có step `screenshot` trước đó, hoặc
    `payload.file`) lên `endpoint_url` kèm Bearer token - không phải chữ ký AWS SigV4 chuẩn.
- **Visual Gateway Manager**: dán nội dung `gateways.txt` qua textarea, import, và chạy kiểm định
  hàng loạt (độ trễ + GeoIP) với thanh tiến trình realtime.
- **Khả năng (Capabilities)** *(tab mới Phase 3)*: kiểm tra môi trường tự động (curl_cffi,
  Node.js, PyMiniRacer, Chromium/Firefox/WebKit), test curl_cffi live, chạy JS probe từ
  browser, quản lý SOCKS5 tunnel, kiểm tra và tải trace đã jitter.

## Phase 3 — Phân hệ chuyên sâu (action mới trong `steps`)

| Action | Việc làm |
|---|---|
| `js_probe` | Chạy JS nhẹ (Node.js/PyMiniRacer) để giải PoW/HMAC/token trước khi mở trình duyệt; kết quả cache vào SQLite theo `ttl_s`. |
| `use_tunnel` | Khởi động tiến trình Xray-core/Sing-box từ `runtime/tunnels/`, mở SOCKS5 cục bộ; tự động dọn dẹp khi kịch bản xong. Binary phải đặt sẵn trong `runtime/tunnels/`. |
| `widget_qa` | Quét tất cả iframe trên trang, đo thời gian tải, kiểm tra redirect/popup khi click. |
| `media_qa` | Đo buffering video HTML5 hoặc YouTube Embedded Player trong khoảng thời gian `retention_window_s`. |
| `trace_record` | Ghi chuỗi sự kiện người dùng (chuột/phím/cuộn) ra file `recorded_trace.json` trong `duration_s` giây. |
| `trace_replay` | Phát lại trace với Gaussian Jitter (`time_sigma_ms`, `coord_sigma_px`) để mô phỏng người dùng thật. |

Ví dụ thêm vào `steps` trong `config/scenarios.json`:
```json
{ "action": "js_probe", "probe_key": "pow:example.com", "script": "...", "ttl_s": 3600 },
{ "action": "use_tunnel", "tunnel": "my-proxy", "config_path": "runtime/tunnels/config.json" },
{ "action": "widget_qa", "config": { "timeout_ms": 10000, "check_clicks": true } },
{ "action": "media_qa", "config": { "selector": "video", "retention_window_s": 15 } },
{ "action": "trace_replay", "trace_path": "recorded_trace.json",
  "config": { "time_sigma_ms": 50, "speed_factor": 1.0 } }
```

## Cấu hình (`config/`)
- `scenarios.json`: khối `settings` và danh sách `scenarios` (xem file để biết ví dụ đầy đủ mọi tính năng).
  Bước (`steps`) hỗ trợ: `goto`, `click`, `fill` (dùng `{data:email}`, `{data:name}`...), `wait`,
  `wait_for_selector`, `wait_for_load_state`, `scroll`, `interact`, `assert_selector`, `assert_text`,
  `screenshot`, `call_integration`, và `branch` (`if_selector` / `if_url_contains` / `if_text` với
  `then` / `else`). Mọi bước có thể thêm `"optional": true`, `"max_retries": N`, `"on_error_fallback": [...]`.
  Mỗi kịch bản có thể đặt `"engine": "auto"|"http"|"chromium"|"firefox"|"webkit"`.
- `environments.json`: viewport, device_scale_factor, user_agent, locale, timezone_id, geolocation, region.
- `gateways.txt`: `vùng|protocol://user:pass@host:port`. Cùng `profile_id` luôn nhận cùng gateway (sticky);
  gateway mất kết nối bị loại tự động. Sửa qua tab Quản trị hoặc sửa file trực tiếp đều được.
- `settings.allowed_domains`: danh sách trắng tên miền; điền vào để engine từ chối mọi URL ngoài danh sách.
- `settings.context_mode`: `"process"` (mặc định, mỗi profile 1 tiến trình trình duyệt, cô lập tuyệt đối
  gồm IndexedDB) hoặc `"shared"` (1 tiến trình dùng chung/engine, tiết kiệm RAM, cô lập qua `storage_state`
  - KHÔNG gồm IndexedDB).
- `settings.bandwidth`: chặn tài nguyên nặng (`block_resource_types`, `block_domains`) + tự đóng cookie
  banner. Thêm `"measure_bytes": true` để ước lượng SỐ BYTE thật đã tránh tải (qua HEAD probe, thêm
  độ trễ nhỏ mỗi request bị chặn) thay vì chỉ đếm số request.
- `settings.schedule_windows`: lập lịch đa ngày/qua đêm, vd. `[{"days":["fri","sat"],"start":"22:00","end":"06:00"}]`.
- `settings.llm`: `{"provider":"ollama"|"openai", ...}` để sinh văn bản mẫu cho ô nhập tự do; lỗi thì dùng bộ sinh nội bộ.
- `plugins/*.py` (hook cũ, không cấu hình qua UI) hoặc `plugins/<tên>/{manifest.json,main.py}` (cài qua UI,
  có biểu mẫu cấu hình). Hook: `on_context_created(context, scenario, config)`,
  `on_page_loaded(page, scenario, config)`, `on_run_finished(run, scenario, config)` - mọi tham số tùy chọn.

## Lưu ý quan trọng
- Chromium không hỗ trợ SOCKS5 có user/pass: gateway kiểu đó chỉ dùng cho HTTP client, không dùng cho trình duyệt.
- Dashboard mặc định chỉ nghe `127.0.0.1`. Tab Quản trị có thể bảo vệ bằng khoá (`python main.py
  admin-key --generate`) - khi chưa đặt khoá, bất kỳ ai mở được dashboard đều cài được plugin (chạy mã
  tuỳ ý) và đổi mọi cấu hình. **Nên đặt khoá trước khi đổi `dashboard_host` sang `0.0.0.0`** để truy cập
  từ xa; khoá chỉ là một chuỗi tĩnh dùng chung (không phải hệ thống tài khoản), vẫn nên kết hợp thêm
  VPN/reverse-proxy nếu mở hẳn ra Internet.
- Mã hoá API key trong tab Integrations là mã hoá tại chỗ tối giản (không phải AES-GCM chuẩn) - xem giới hạn
  chi tiết trong `PROJECT.md`.
- Redis queue giao hàng "at-most-once": worker chết giữa chừng sẽ làm mất tác vụ đang xử lý.
- Plugin là mã tùy ý: chỉ cài plugin bạn tin tưởng. Chỉ kiểm thử hệ thống bạn sở hữu hoặc được phép.
- LCP đo tại thời điểm trang ổn định (tối đa 5 giây chờ mạng rảnh), là xấp xỉ so với công cụ Lighthouse.
- `http_client: "curl_cffi"` **đã xác nhận hoạt động** (Phase 3) — JA3/JA4 + HTTP/2 ALPN thật giống Chrome.
- `engine: "firefox"/"webkit"` đã viết xong nhưng CHƯA chạy thử thật — cần `playwright install firefox webkit`.
