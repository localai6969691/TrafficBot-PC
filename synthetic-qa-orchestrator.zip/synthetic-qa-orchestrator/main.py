#!/usr/bin/env python3
"""Synthetic QA Orchestrator - điểm khởi chạy.

    runner                      chạy một lần tất cả kịch bản (nhấp đúp cũng được)
    runner run --dashboard      chạy một lần và mở dashboard
    runner schedule             chạy theo lịch cron (kèm dashboard)
    runner produce / worker     chế độ phân tán qua Redis
    runner report               xuất báo cáo từ state.db
    runner install-browsers     tải Chromium vào thư mục browsers/ (khi chạy từ mã nguồn)
"""
# Các tùy chọn dưới đây do Nuitka đọc khi biên dịch (xem .github/workflows/build.yml).
# nuitka-project: --include-package=playwright
# nuitka-project: --include-package-data=playwright
# nuitka-project: --include-package=uvicorn
# nuitka-project: --include-package=fastapi
# nuitka-project: --include-package=starlette
# nuitka-project: --include-package=pydantic
# nuitka-project: --include-package=pydantic_core
# nuitka-project: --include-package=apscheduler
# nuitka-project: --include-package=httpx
# nuitka-project: --include-package=httpcore
# nuitka-project: --include-package=h2
# nuitka-project: --include-package=anyio
# nuitka-project: --include-package=redis
# nuitka-project: --include-package=fakeredis
# Phase 3 — curl_cffi là C-extension, cần copy .so/.pyd thủ công trên mỗi OS
# nuitka-project: --include-package=curl_cffi
# nuitka-project: --include-package-data=curl_cffi
# Phase 4 modules
# nuitka-project: --include-package=aiohttp
# nuitka-project: --include-package=websockets
# Phase 5 modules
# nuitka-project: --include-package=zoneinfo
# Phase 7 modules
# nuitka-project: --include-package=cryptography
# nuitka-project: --include-package=motor
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import subprocess
import sys
from contextlib import asynccontextmanager
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from typing import Any, AsyncIterator, Optional

from config_loader import Config, Paths, get_base_dir, load_config
from database import Database
from engine import Engine, LocalQueue, RedisQueue, Task, TaskQueue, utc_now
from events import BusLogHandler, EventBus
from network_manager import GatewayPool, HttpProbe
from plugin_manager import PluginManager, reconcile_plugins
from reporting import build_report, write_reports

VERSION = "1.0.0"
LOGGER = logging.getLogger("qa.main")


# ============================================================================ khởi tạo
@dataclass
class App:
    cfg: Config
    paths: Paths
    db: Database
    bus: EventBus
    plugins: PluginManager
    pool: GatewayPool
    engine: Engine


def setup_logging(paths: Paths, verbose: bool) -> None:
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%H:%M:%S")
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    logfile = RotatingFileHandler(paths.logs / "runner.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    logfile.setFormatter(fmt)
    root.handlers[:] = [console, logfile]
    logging.getLogger("httpx").setLevel(logging.WARNING)  # bớt nhiễu: mỗi request httpx ghi một dòng INFO


async def build_app(paths: Paths, args: argparse.Namespace) -> App:
    cfg = load_config(paths)
    s = cfg.settings
    if getattr(args, "concurrency", None):
        s.max_concurrency = args.concurrency
    if getattr(args, "headed", False):
        s.headless = False
    only = set(getattr(args, "scenario", None) or [])
    if only:
        unknown = only - {sc.id for sc in cfg.scenarios}
        if unknown:
            raise ValueError(f"Không có kịch bản: {', '.join(sorted(unknown))}")
        cfg.scenarios = [sc for sc in cfg.scenarios if sc.id in only]

    db = Database(paths.db)
    db.open()
    now = utc_now()
    for sc in cfg.scenarios:
        await db.aupsert_scenario(sc, now)

    bus = EventBus()
    logging.getLogger("qa").addHandler(BusLogHandler(bus))
    plugins = PluginManager(paths.plugins, paths.init_scripts)
    enabled, configs = await reconcile_plugins(db, paths)
    plugins.load(enabled, configs)
    pool = GatewayPool(cfg.gateways, s.gateway_timeout_s, s.health_check_interval_s)
    engine = Engine(cfg, paths, db, plugins, pool, HttpProbe(), bus)
    bus.engine = engine  # Phase 12: tham chiếu nhẹ để admin_api.py đọc _workers (Live Worker Grid)
    LOGGER.info("Thư mục gốc: %s | %d kịch bản | %d gateway | tối đa %d luồng",
                paths.base, len(cfg.scenarios), len(cfg.gateways), s.max_concurrency)
    return App(cfg, paths, db, bus, plugins, pool, engine)


@asynccontextmanager
async def running(app: App, dashboard: bool) -> AsyncIterator[None]:
    """Khởi động pool health-check, Playwright, (tùy chọn) dashboard; dọn dẹp khi thoát."""
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, app.engine.stop.set)
        except (NotImplementedError, RuntimeError):
            pass  # Windows: KeyboardInterrupt được xử lý ở main()

    server = server_task = None
    try:
        if dashboard:
            try:
                from dashboard import create_app, make_server

                s = app.cfg.settings
                server = make_server(create_app(app.db, app.bus, app.engine.status, app.paths),
                                    s.dashboard_host, s.dashboard_port)
                server_task = asyncio.create_task(server.serve())
                LOGGER.info("Dashboard: http://%s:%d", s.dashboard_host, s.dashboard_port)
            except (ImportError, RuntimeError) as exc:
                LOGGER.error("Không bật được dashboard: %s", exc)
        await app.pool.check_all()
        app.pool.start()
        await app.engine.start()
        yield
    finally:
        await app.engine.close()
        await app.pool.stop()
        if server is not None and server_task is not None:
            server.should_exit = True
            await asyncio.gather(server_task, return_exceptions=True)
        app.db.close()


def build_tasks(cfg: Config, iterations: int) -> list[Task]:
    return [Task(sc.id, url) for _ in range(max(1, iterations))
            for sc in cfg.scenarios if sc.active for url in sc.urls]


async def run_cycle(app: App, iterations: int) -> dict[str, Any]:
    """Một chu kỳ: nạp lại plugin, đẩy tác vụ vào hàng đợi nội bộ, chạy, xuất báo cáo."""
    enabled, configs = await reconcile_plugins(app.db, app.paths)
    app.plugins.load(enabled, configs)
    queue = LocalQueue()
    tasks = build_tasks(app.cfg, iterations)
    for t in tasks:
        await queue.put(t)
    started = utc_now()
    LOGGER.info("Bắt đầu chu kỳ: %d tác vụ", len(tasks))
    await app.engine.run_tasks(queue, drain=True)
    report = build_report(await app.db.ametric_rows(started))
    files = await asyncio.to_thread(write_reports, report, app.paths.reports)
    LOGGER.info("KẾT QUẢ: %d lượt | %d thành công | %d lỗi | báo cáo: %s", report["total_runs"],
                report["ok"], report["failed"], ", ".join(f.name for f in files))
    return report


# ============================================================================ lệnh
async def cmd_run(args: argparse.Namespace, paths: Paths) -> int:
    app = await build_app(paths, args)
    async with running(app, args.dashboard):
        report = await run_cycle(app, args.iterations or app.cfg.settings.iterations)
        if args.dashboard and not app.engine.stop.is_set():
            LOGGER.info("Dashboard vẫn mở - nhấn Ctrl+C để thoát.")
            await app.engine.stop.wait()
    return 1 if report["failed"] else 0


async def cmd_schedule(args: argparse.Namespace, paths: Paths) -> int:
    app = await build_app(paths, args)
    window_specs = app.cfg.settings.schedule_windows
    cron = args.cron or app.cfg.settings.schedule

    async with running(app, not args.no_dashboard):
        tasks: list[asyncio.Task[None]] = []
        if window_specs:
            # Lập lịch đa ngày / qua đêm: mỗi cửa sổ là một vòng lặp asyncio riêng,
            # chạy song song, không dùng APScheduler (xem docstring schedule_windows.py).
            from schedule_windows import ScheduleWindow, run_window

            def get_conc() -> int:
                return app.cfg.settings.max_concurrency

            def set_conc(n: int) -> None:
                app.cfg.settings.max_concurrency = n

            for spec in window_specs:
                window = ScheduleWindow.from_dict(spec)
                tasks.append(asyncio.create_task(
                    run_window(window, lambda it: run_cycle(app, it or app.cfg.settings.iterations),
                              get_conc, set_conc, app.engine.stop)))
            LOGGER.info("Lập lịch theo %d cửa sổ đa ngày - Ctrl+C để dừng", len(window_specs))
        elif cron:
            try:
                from apscheduler.schedulers.asyncio import AsyncIOScheduler
                from apscheduler.triggers.cron import CronTrigger
            except ImportError:
                raise SystemExit("Cần cài apscheduler: pip install 'apscheduler<4'")
            scheduler = AsyncIOScheduler()
            scheduler.add_job(run_cycle, CronTrigger.from_crontab(cron),
                              args=[app, args.iterations or app.cfg.settings.iterations],
                              max_instances=1, coalesce=True, id="campaign")
            scheduler.start()
            LOGGER.info("Chạy theo lịch '%s' - Ctrl+C để dừng", cron)
        else:
            raise SystemExit("Thiếu lịch: dùng --cron \"*/30 * * * *\", đặt settings.schedule, "
                             "hoặc cấu hình settings.schedule_windows")

        await app.engine.stop.wait()
        for t in tasks:
            t.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    return 0


async def cmd_validate_gateways(args: argparse.Namespace, paths: Paths) -> int:
    from gateway_validator import GatewayCheckConfig, GatewayValidator, utc_now as gutc

    cfg = load_config(paths)
    if not cfg.gateways:
        print("Không có gateway nào trong config/gateways.txt")
        return 0
    gv_cfg = GatewayCheckConfig(**{k: v for k, v in cfg.settings.gateway_validator.items()
                                   if k in GatewayCheckConfig.__dataclass_fields__})
    validator = GatewayValidator(gv_cfg)
    LOGGER.info("Đang kiểm tra %d gateway (đồng thời tối đa %d)...", len(cfg.gateways), gv_cfg.concurrency)
    results = await validator.check_all(cfg.gateways)

    db = Database(paths.db)
    db.open()
    try:
        now = gutc()
        for r in results:
            await db.ainsert_gateway_check(**r.to_db_row(now))
    finally:
        db.close()

    healthy = sum(r.healthy for r in results)
    print(f"\n{'Gateway':<32} {'Vùng':<6} {'OK':<4} {'ms':<7} {'Exit IP':<16} {'Quốc gia':<10} {'Timezone':<20} {'Lỗi'}")
    for r in results:
        print(f"{r.gateway:<32} {r.region:<6} {'có' if r.healthy else 'không':<4} "
              f"{r.latency_ms or '-':<7} {r.exit_ip or '-':<16} {r.country_code or '-':<10} "
              f"{r.timezone_id or '-':<20} {r.error or ''}")
    print(f"\n{healthy}/{len(results)} gateway khỏe mạnh")
    return 0 if healthy == len(results) else 1


async def cmd_admin_key(args: argparse.Namespace, paths: Paths) -> int:
    """Quản lý khoá bảo vệ tab Quản trị trên dashboard (`/api/admin/*`). Không đặt khoá =
    không yêu cầu xác thực (mặc định, giống các bản trước) - CHỈ an toàn khi
    `dashboard_host` vẫn là `127.0.0.1`. Xem README mục cảnh báo bảo mật."""
    import secrets as pysecrets

    db = Database(paths.db)
    db.open()
    try:
        now = utc_now()
        if args.clear:
            await db.aset_setting("admin_api_key", "", now)
            print("Đã xoá khoá - tab Quản trị không còn yêu cầu xác thực.")
        elif args.generate:
            key = pysecrets.token_urlsafe(24)
            await db.aset_setting("admin_api_key", key, now)
            print(f"Khoá quản trị mới (chỉ hiện MỘT LẦN, hãy lưu lại ngay):\n\n  {key}\n")
            print("Dán khoá này vào ô 'Admin Key' khi dashboard hỏi lúc mở tab Quản trị.")
        elif args.set:
            await db.aset_setting("admin_api_key", args.set, now)
            print("Đã đặt khoá quản trị theo giá trị bạn cung cấp.")
        else:
            current = await db.aget_setting("admin_api_key", "")
            print("Đã đặt khoá (ẩn)." if current else "Chưa đặt khoá - tab Quản trị đang mở tự do.")
    finally:
        db.close()
    return 0


async def cmd_mcp_server(args: argparse.Namespace, paths: Paths) -> int:
    from mcp_server import serve_stdio

    await serve_stdio(paths)
    return 0


def _redis_queue(cfg: Config) -> RedisQueue:
    try:
        return RedisQueue(cfg.settings.redis_url, cfg.settings.redis_queue)
    except ImportError:
        raise SystemExit("Cần cài redis: pip install redis")


async def cmd_produce(args: argparse.Namespace, paths: Paths) -> int:
    cfg = load_config(paths)
    only = set(args.scenario or [])
    if only:
        cfg.scenarios = [s for s in cfg.scenarios if s.id in only]
    queue = _redis_queue(cfg)
    tasks = build_tasks(cfg, args.iterations or cfg.settings.iterations)
    for t in tasks:
        await queue.put(t)
    await queue.aclose()
    LOGGER.info("Đã đẩy %d tác vụ vào Redis '%s'", len(tasks), cfg.settings.redis_queue)
    return 0


async def cmd_worker(args: argparse.Namespace, paths: Paths) -> int:
    app = await build_app(paths, args)
    queue: TaskQueue = _redis_queue(app.cfg)
    async with running(app, args.dashboard):
        LOGGER.info("Worker đang chờ tác vụ từ Redis (Ctrl+C để dừng)")
        await app.engine.run_tasks(queue, drain=False)
    await queue.aclose()
    return 0


async def cmd_report(args: argparse.Namespace, paths: Paths) -> int:
    db = Database(paths.db)
    db.open()
    try:
        report = build_report(await db.ametric_rows(args.since))
    finally:
        db.close()
    formats = ("html", "csv", "json") if args.format == "all" else (args.format,)
    for f in write_reports(report, paths.reports, formats):
        print(f)
    return 0


def install_browsers() -> int:
    from playwright._impl._driver import compute_driver_executable, get_driver_env

    driver = compute_driver_executable()
    cmd = list(driver) if isinstance(driver, (tuple, list)) else [str(driver)]
    return subprocess.run([*cmd, "install", "chromium"], env=get_driver_env()).returncode


# ============================================================================ CLI
def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("-v", "--verbose", action="store_true")
    common.add_argument("--concurrency", type=int, help="số trình duyệt chạy đồng thời")
    common.add_argument("--iterations", type=int, help="số lần lặp mỗi URL")
    common.add_argument("--headed", action="store_true", help="hiện cửa sổ trình duyệt")
    common.add_argument("--scenario", action="append", metavar="ID", help="chỉ chạy kịch bản này (lặp được)")

    p = argparse.ArgumentParser(prog="runner", description="Synthetic QA Orchestrator")
    p.add_argument("--version", action="version", version=f"runner {VERSION}")
    sub = p.add_subparsers(dest="cmd")

    r = sub.add_parser("run", parents=[common], help="chạy một lần")
    r.add_argument("--dashboard", action="store_true")
    s = sub.add_parser("schedule", parents=[common], help="chạy theo lịch cron")
    s.add_argument("--cron", help='ví dụ "*/30 * * * *"')
    s.add_argument("--no-dashboard", action="store_true")
    sub.add_parser("produce", parents=[common], help="đẩy tác vụ vào Redis")
    w = sub.add_parser("worker", parents=[common], help="nhận tác vụ từ Redis")
    w.add_argument("--dashboard", action="store_true")
    rp = sub.add_parser("report", parents=[common], help="xuất báo cáo")
    rp.add_argument("--since", help="ISO-8601, ví dụ 2026-01-31T00:00:00")
    rp.add_argument("--format", choices=("html", "csv", "json", "all"), default="all")
    sub.add_parser("install-browsers", help="tải Chromium vào browsers/")
    sub.add_parser("validate-gateways", parents=[common],
                   help="kiểm tra hàng loạt gateway: độ trễ, exit IP, quốc gia/ISP, timezone")
    sub.add_parser("mcp-server", help="chạy MCP server qua stdio cho Claude Desktop/Cursor")
    ak = sub.add_parser("admin-key", help="quản lý khoá bảo vệ tab Quản trị trên dashboard")
    ak_g = ak.add_mutually_exclusive_group()
    ak_g.add_argument("--generate", action="store_true", help="sinh khoá ngẫu nhiên mới và lưu lại")
    ak_g.add_argument("--set", metavar="KEY", help="đặt khoá theo giá trị tự chọn")
    ak_g.add_argument("--clear", action="store_true", help="xoá khoá - tắt xác thực tab Quản trị")

    args = p.parse_args(argv)
    if args.cmd is None:  # nhấp đúp / không tham số: chạy một lần
        args = p.parse_args(["run"])
    return args


def main() -> int:
    double_clicked = len(sys.argv) == 1
    args = parse_args()
    paths = Paths.from_base(get_base_dir())
    paths.ensure_dirs()
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(paths.browsers)  # Chromium đi kèm, không cài hệ thống
    setup_logging(paths, getattr(args, "verbose", False))

    handlers = {"run": cmd_run, "schedule": cmd_schedule, "produce": cmd_produce,
                "worker": cmd_worker, "report": cmd_report,
                "validate-gateways": cmd_validate_gateways, "mcp-server": cmd_mcp_server,
                "admin-key": cmd_admin_key}
    code = 0
    try:
        if args.cmd == "install-browsers":
            code = install_browsers()
        else:
            code = asyncio.run(handlers[args.cmd](args, paths))
    except KeyboardInterrupt:
        LOGGER.info("Đã dừng theo yêu cầu.")
    except (FileNotFoundError, ValueError) as exc:
        LOGGER.error("Lỗi cấu hình: %s", exc)
        code = 2
    except Exception:  # noqa: BLE001
        LOGGER.exception("Lỗi nghiêm trọng")
        code = 3

    if os.name == "nt" and double_clicked and sys.stdout and sys.stdout.isatty():
        input("\nNhấn Enter để thoát...")
    return code


if __name__ == "__main__":
    sys.exit(main())
