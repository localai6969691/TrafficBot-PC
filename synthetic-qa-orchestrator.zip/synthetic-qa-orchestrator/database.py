"""SQLite: profiles, scenarios, runs, performance_metrics."""
from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
    id           TEXT PRIMARY KEY,
    environment  TEXT,
    region       TEXT,
    gateway      TEXT,
    created_at   TEXT NOT NULL,
    last_used_at TEXT,
    run_count    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS scenarios (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    urls        TEXT NOT NULL,
    profile_id  TEXT,
    timeout_ms  INTEGER NOT NULL DEFAULT 30000,
    active      INTEGER NOT NULL DEFAULT 1,
    config      TEXT,
    updated_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_id   TEXT NOT NULL,
    profile_id    TEXT,
    url           TEXT NOT NULL,
    started_at    TEXT NOT NULL,
    finished_at   TEXT NOT NULL,
    status        TEXT NOT NULL,          -- ok | failed | skipped
    http_status   INTEGER,
    exit_ip       TEXT,
    gateway       TEXT,
    attempts      INTEGER NOT NULL DEFAULT 1,
    error_message TEXT,
    engine        TEXT              -- http | chromium | firefox | webkit (Phase 2 - engine_router.py)
);
CREATE TABLE IF NOT EXISTS performance_metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id      INTEGER NOT NULL REFERENCES runs (id),
    ttfb_ms     REAL, fcp_ms REAL, lcp_ms REAL, cls REAL,
    dcl_ms      REAL, load_ms REAL
);
CREATE TABLE IF NOT EXISTS host_preferences (
    host           TEXT PRIMARY KEY,
    engine         TEXT NOT NULL,        -- http | chromium | firefox | webkit
    reason         TEXT,                 -- vì sao bị leo thang (vd. 'HTTP 403 ở engine http')
    escalations    INTEGER NOT NULL DEFAULT 1,
    updated_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS gateway_checks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    gateway     TEXT NOT NULL,           -- host:port đã che thông tin đăng nhập
    region      TEXT,
    checked_at  TEXT NOT NULL,
    healthy     INTEGER NOT NULL,
    latency_ms  REAL,
    exit_ip     TEXT,
    country     TEXT,
    city        TEXT,
    isp         TEXT,
    asn         TEXT,
    timezone_id TEXT,
    locale      TEXT,
    error       TEXT
);
CREATE TABLE IF NOT EXISTS system_settings (
    key        TEXT PRIMARY KEY,
    value      TEXT,                 -- JSON-encoded
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS plugin_configs (
    plugin_name  TEXT PRIMARY KEY,
    enabled      INTEGER NOT NULL DEFAULT 1,
    config_json  TEXT NOT NULL DEFAULT '{}',
    manifest_json TEXT,
    installed_at TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS integrations (
    name         TEXT PRIMARY KEY,
    service_type TEXT NOT NULL,       -- webhook | captcha_solver | cloud_storage | custom
    endpoint_url TEXT,
    api_key_enc  TEXT,                -- mã hoá bằng secrets_store.SecretBox, xem giới hạn ở đó
    extra_json   TEXT NOT NULL DEFAULT '{}',
    verified     INTEGER NOT NULL DEFAULT 0,
    updated_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS session_cache (
    probe_key      TEXT PRIMARY KEY,
    payload        TEXT NOT NULL,        -- JSON kết quả probe (cookie, token, raw output)
    created_at_ts  REAL NOT NULL         -- unix timestamp (float) để tính TTL
);
CREATE TABLE IF NOT EXISTS tunnel_states (
    name        TEXT PRIMARY KEY,
    state_json  TEXT NOT NULL,           -- JSON: pid, proxy_url, config_path, started_at
    updated_at  TEXT NOT NULL
);
-- Phase 4: Cloud usage tracking
CREATE TABLE IF NOT EXISTS cloud_usage_logs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    provider     TEXT NOT NULL,
    endpoint     TEXT,
    browser_type TEXT DEFAULT 'chromium',
    started_at   TEXT NOT NULL,
    finished_at  TEXT,
    duration_s   REAL,
    cost_usd     REAL,
    status       TEXT DEFAULT 'connecting',  -- connecting|ok|connect_failed|error
    error        TEXT
);
-- Phase 4: Failure taxonomy
CREATE TABLE IF NOT EXISTS failure_events (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id       INTEGER REFERENCES runs(id),
    scenario_id  TEXT,
    failure_type TEXT NOT NULL,  -- NETWORK_TIMEOUT|GATEWAY_DEAD|PROTOCOL_MISMATCH|WAF_CHALLENGE|GEO_LOCALE_CONFLICT|DOM_SELECTOR_MISSING|UNKNOWN
    detail       TEXT,
    occurred_at  TEXT NOT NULL
);
-- Phase 4: Alert history (Telegram/Discord/Slack)
CREATE TABLE IF NOT EXISTS alert_history (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    channel      TEXT NOT NULL,  -- telegram|discord|slack|webhook
    scenario_id  TEXT,
    message      TEXT NOT NULL,
    sent_at      TEXT NOT NULL,
    status       TEXT DEFAULT 'ok',  -- ok|failed
    error        TEXT
);
-- Phase 5: Pre-flight audit results
CREATE TABLE IF NOT EXISTS preflight_results (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id       TEXT,            -- campaign/task ID
    passed       INTEGER NOT NULL, -- 1=pass, 0=fail
    checks       TEXT NOT NULL,   -- JSON: {check_name: {ok, value, expected}}
    blocked      INTEGER DEFAULT 0,
    reason       TEXT,
    audited_at   TEXT NOT NULL
);

-- Phase 6: Self-healing log
CREATE TABLE IF NOT EXISTS healing_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_id   TEXT,
    old_selector  TEXT NOT NULL,
    new_selector  TEXT NOT NULL,
    strategy      TEXT,
    confidence    REAL,
    healed_at     TEXT NOT NULL
);
-- Phase 6: Session warming state
CREATE TABLE IF NOT EXISTS profile_warmth (
    profile_id   TEXT PRIMARY KEY,
    trust_score  REAL DEFAULT 0,
    urls_visited INTEGER DEFAULT 0,
    cookies      INTEGER DEFAULT 0,
    warmed_at    TEXT,
    status       TEXT DEFAULT 'new'  -- new|warming|warm|ready
);

-- Phase 9: Workspaces
CREATE TABLE IF NOT EXISTS workspaces (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    color       TEXT DEFAULT '#1f6f5c',
    created_at  TEXT,
    updated_at  TEXT
);
CREATE TABLE IF NOT EXISTS workspace_items (
    workspace_id TEXT NOT NULL,
    item_type    TEXT NOT NULL,
    item_id      TEXT NOT NULL,
    PRIMARY KEY (workspace_id, item_type, item_id)
);
CREATE TABLE IF NOT EXISTS storm_runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scenario_id     TEXT,
    workspace_id    TEXT,
    phase           TEXT,
    total_submitted INTEGER DEFAULT 0,
    duration_s      REAL,
    peak_concurrency INTEGER,
    started_at      TEXT,
    finished_at     TEXT
);

CREATE INDEX IF NOT EXISTS idx_runs_scenario    ON runs (scenario_id);
CREATE INDEX IF NOT EXISTS idx_runs_started     ON runs (started_at);
CREATE INDEX IF NOT EXISTS idx_metrics_run      ON performance_metrics (run_id);
CREATE INDEX IF NOT EXISTS idx_gwchecks_gw      ON gateway_checks (gateway, checked_at);
CREATE INDEX IF NOT EXISTS idx_session_cache_key ON session_cache (probe_key);
CREATE INDEX IF NOT EXISTS idx_cloud_started    ON cloud_usage_logs (started_at);
CREATE INDEX IF NOT EXISTS idx_failure_scenario ON failure_events (scenario_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_preflight_run    ON preflight_results (run_id);
"""


class Database:
    def __init__(self, path: Path) -> None:
        self._path = Path(path)
        self._lock = threading.Lock()
        self._conn: Optional[sqlite3.Connection] = None

    def open(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA)
        self._conn.commit()
        self._migrate()

    def _migrate(self) -> None:
        """Thêm cột mới cho state.db tạo từ bản trước (Phase 1), không có trong CREATE TABLE
        gốc. An toàn để gọi nhiều lần: chỉ ALTER khi cột chưa tồn tại."""
        assert self._conn is not None
        cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(runs)")}
        if "engine" not in cols:
            self._conn.execute("ALTER TABLE runs ADD COLUMN engine TEXT")
            self._conn.commit()
        if "analytics_verified" not in cols:
            # Phase 10.5: VERIFIED_SUCCESS | NOT_VERIFIED | NOT_APPLICABLE | NULL (chưa bật check)
            self._conn.execute("ALTER TABLE runs ADD COLUMN analytics_verified TEXT")
            self._conn.commit()
        if "preflight_status" not in cols:
            # Phase 10.5: ok | blocked | skipped | NULL (chưa bật Fail-Safe Gate)
            self._conn.execute("ALTER TABLE runs ADD COLUMN preflight_status TEXT")
            self._conn.commit()

        gw_cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(gateway_checks)")}
        if "infra_class" not in gw_cols:
            # Phase 11.2: isp_residential | mobile | datacenter | NULL
            self._conn.execute("ALTER TABLE gateway_checks ADD COLUMN infra_class TEXT")
            self._conn.commit()
        if "anonymity_level" not in gw_cols:
            # Phase 11.2: elite | anonymous | transparent | NULL
            self._conn.execute("ALTER TABLE gateway_checks ADD COLUMN anonymity_level TEXT")
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None

    def _write(self, sql: str, params: tuple = ()) -> int:
        with self._lock:
            assert self._conn is not None, "Database chưa mở"
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur.lastrowid or 0

    def _read(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        with self._lock:
            assert self._conn is not None, "Database chưa mở"
            return [dict(r) for r in self._conn.execute(sql, params)]

    # ------------------------------------------------------------ ghi
    def upsert_scenario(self, sc: Any, now: str) -> None:
        self._write(
            """INSERT INTO scenarios (id, name, urls, profile_id, timeout_ms, active, config, updated_at)
               VALUES (?,?,?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET name=excluded.name, urls=excluded.urls,
                 profile_id=excluded.profile_id, timeout_ms=excluded.timeout_ms,
                 active=excluded.active, config=excluded.config, updated_at=excluded.updated_at""",
            (sc.id, sc.name, json.dumps(sc.urls, ensure_ascii=False), sc.profile_id,
             sc.timeout_ms, int(sc.active), json.dumps(sc.raw, ensure_ascii=False), now))

    def touch_profile(self, profile_id: str, environment: str, region: Optional[str],
                      gateway: Optional[str], now: str) -> None:
        self._write(
            """INSERT INTO profiles (id, environment, region, gateway, created_at, last_used_at, run_count)
               VALUES (?,?,?,?,?,?,1)
               ON CONFLICT(id) DO UPDATE SET environment=excluded.environment,
                 region=excluded.region, gateway=excluded.gateway,
                 last_used_at=excluded.last_used_at, run_count=run_count+1""",
            (profile_id, environment, region, gateway, now, now))

    def insert_run(self, **r: Any) -> int:
        r.setdefault("engine", None)
        r.setdefault("analytics_verified", None)
        r.setdefault("preflight_status", None)
        return self._write(
            """INSERT INTO runs (scenario_id, profile_id, url, started_at, finished_at, status,
                                http_status, exit_ip, gateway, attempts, error_message, engine,
                                analytics_verified, preflight_status)
               VALUES (:scenario_id,:profile_id,:url,:started_at,:finished_at,:status,
                       :http_status,:exit_ip,:gateway,:attempts,:error_message,:engine,
                       :analytics_verified,:preflight_status)""", r)  # type: ignore[arg-type]

    # ------------------------------------------------------------ system_settings (4.1 Browser Runtime)
    def get_setting(self, key: str, default: Any = None) -> Any:
        rows = self._read("SELECT value FROM system_settings WHERE key = ?", (key,))
        return json.loads(rows[0]["value"]) if rows else default

    def all_settings(self) -> dict[str, Any]:
        return {r["key"]: json.loads(r["value"]) for r in self._read("SELECT key, value FROM system_settings")}

    def set_setting(self, key: str, value: Any, now: str) -> None:
        self._write(
            """INSERT INTO system_settings (key, value, updated_at) VALUES (?,?,?)
               ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
            (key, json.dumps(value, ensure_ascii=False), now))

    # ------------------------------------------------------------ plugin_configs (4.2 Plugin Manager)
    def upsert_plugin_config(self, name: str, enabled: bool, config: dict[str, Any],
                             manifest: Optional[dict[str, Any]], now: str) -> None:
        self._write(
            """INSERT INTO plugin_configs (plugin_name, enabled, config_json, manifest_json, installed_at, updated_at)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(plugin_name) DO UPDATE SET enabled=excluded.enabled,
                 config_json=excluded.config_json, manifest_json=excluded.manifest_json,
                 updated_at=excluded.updated_at""",
            (name, int(enabled), json.dumps(config, ensure_ascii=False),
             json.dumps(manifest, ensure_ascii=False) if manifest else None, now, now))

    def set_plugin_enabled(self, name: str, enabled: bool, now: str) -> None:
        self._write("UPDATE plugin_configs SET enabled=?, updated_at=? WHERE plugin_name=?",
                    (int(enabled), now, name))

    def all_plugin_configs(self) -> list[dict[str, Any]]:
        rows = self._read("SELECT * FROM plugin_configs ORDER BY plugin_name")
        for r in rows:
            r["config"] = json.loads(r.pop("config_json") or "{}")
            r["manifest"] = json.loads(r.pop("manifest_json") or "null")
            r["enabled"] = bool(r["enabled"])
        return rows

    def delete_plugin_config(self, name: str) -> None:
        self._write("DELETE FROM plugin_configs WHERE plugin_name=?", (name,))

    # ------------------------------------------------------------ integrations (4.3 Service Connectors)
    def upsert_integration(self, name: str, service_type: str, endpoint_url: Optional[str],
                           api_key_enc: Optional[str], extra: dict[str, Any], verified: bool, now: str) -> None:
        self._write(
            """INSERT INTO integrations (name, service_type, endpoint_url, api_key_enc, extra_json, verified, updated_at)
               VALUES (?,?,?,?,?,?,?)
               ON CONFLICT(name) DO UPDATE SET service_type=excluded.service_type,
                 endpoint_url=excluded.endpoint_url, api_key_enc=excluded.api_key_enc,
                 extra_json=excluded.extra_json, verified=excluded.verified, updated_at=excluded.updated_at""",
            (name, service_type, endpoint_url, api_key_enc, json.dumps(extra, ensure_ascii=False),
             int(verified), now))

    def get_integration(self, name: str) -> Optional[dict[str, Any]]:
        rows = self._read("SELECT * FROM integrations WHERE name=?", (name,))
        if not rows:
            return None
        rows[0]["extra"] = json.loads(rows[0].pop("extra_json") or "{}")
        rows[0]["verified"] = bool(rows[0]["verified"])
        return rows[0]

    def all_integrations(self) -> list[dict[str, Any]]:
        rows = self._read("SELECT * FROM integrations ORDER BY name")
        for r in rows:
            r["extra"] = json.loads(r.pop("extra_json") or "{}")
            r["verified"] = bool(r["verified"])
        return rows

    def delete_integration(self, name: str) -> None:
        self._write("DELETE FROM integrations WHERE name=?", (name,))

    # ------------------------------------------------------------ host_preferences (engine_router)
    def get_host_engine(self, host: str) -> Optional[dict[str, Any]]:
        rows = self._read("SELECT * FROM host_preferences WHERE host = ?", (host,))
        return rows[0] if rows else None

    def set_host_engine(self, host: str, engine: str, reason: str, now: str) -> None:
        self._write(
            """INSERT INTO host_preferences (host, engine, reason, escalations, updated_at)
               VALUES (?,?,?,1,?)
               ON CONFLICT(host) DO UPDATE SET engine=excluded.engine, reason=excluded.reason,
                 escalations=escalations+1, updated_at=excluded.updated_at""",
            (host, engine, reason, now))

    def all_host_preferences(self) -> list[dict[str, Any]]:
        return self._read("SELECT * FROM host_preferences ORDER BY updated_at DESC")

    # ------------------------------------------------------------ gateway_checks (gateway_validator)
    def insert_gateway_check(self, **r: Any) -> None:
        r.setdefault("infra_class", None)
        r.setdefault("anonymity_level", None)
        self._write(
            """INSERT INTO gateway_checks (gateway, region, checked_at, healthy, latency_ms, exit_ip,
                                          country, city, isp, asn, timezone_id, locale, error,
                                          infra_class, anonymity_level)
               VALUES (:gateway,:region,:checked_at,:healthy,:latency_ms,:exit_ip,
                       :country,:city,:isp,:asn,:timezone_id,:locale,:error,
                       :infra_class,:anonymity_level)""", r)  # type: ignore[arg-type]

    def latest_gateway_checks(self) -> list[dict[str, Any]]:
        return self._read(
            """SELECT gc.* FROM gateway_checks gc
                 JOIN (SELECT gateway, MAX(id) AS max_id FROM gateway_checks GROUP BY gateway) last
                   ON last.gateway = gc.gateway AND last.max_id = gc.id
                ORDER BY gc.gateway""")

    def insert_metrics(self, run_id: int, m: dict[str, Optional[float]]) -> None:
        self._write(
            """INSERT INTO performance_metrics (run_id, ttfb_ms, fcp_ms, lcp_ms, cls, dcl_ms, load_ms)
               VALUES (?,?,?,?,?,?,?)""",
            (run_id, m.get("ttfb"), m.get("fcp"), m.get("lcp"), m.get("cls"), m.get("dcl"), m.get("load")))

    # ------------------------------------------------------------ đọc
    def recent_runs(self, limit: int = 100) -> list[dict[str, Any]]:
        return self._read(
            """SELECT r.*, m.ttfb_ms, m.fcp_ms, m.lcp_ms, m.cls, m.load_ms
                 FROM runs r LEFT JOIN performance_metrics m ON m.run_id = r.id
                ORDER BY r.id DESC LIMIT ?""", (limit,))

    def metric_rows(self, since: Optional[str] = None) -> list[dict[str, Any]]:
        return self._read(
            """SELECT r.scenario_id, r.url, r.status, r.http_status, r.started_at,
                      r.analytics_verified,
                      m.ttfb_ms, m.fcp_ms, m.lcp_ms, m.cls, m.load_ms
                 FROM runs r LEFT JOIN performance_metrics m ON m.run_id = r.id
                WHERE r.started_at >= ? ORDER BY r.id""", (since or "",))

    # ------------------------------------------------------------ async
    async def aupsert_scenario(self, sc: Any, now: str) -> None:
        await asyncio.to_thread(self.upsert_scenario, sc, now)

    async def atouch_profile(self, *a: Any) -> None:
        await asyncio.to_thread(self.touch_profile, *a)

    async def asave_run(self, run: dict[str, Any], metrics: Optional[dict[str, Any]]) -> int:
        def _save() -> int:
            run_id = self.insert_run(**run)
            if metrics:
                self.insert_metrics(run_id, metrics)
            return run_id
        return await asyncio.to_thread(_save)

    async def arecent_runs(self, limit: int = 100) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.recent_runs, limit)

    async def ametric_rows(self, since: Optional[str] = None) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.metric_rows, since)

    async def aget_setting(self, key: str, default: Any = None) -> Any:
        return await asyncio.to_thread(self.get_setting, key, default)

    async def aall_settings(self) -> dict[str, Any]:
        return await asyncio.to_thread(self.all_settings)

    async def aset_setting(self, key: str, value: Any, now: str) -> None:
        await asyncio.to_thread(self.set_setting, key, value, now)

    async def aupsert_plugin_config(self, *a: Any) -> None:
        await asyncio.to_thread(self.upsert_plugin_config, *a)

    async def aset_plugin_enabled(self, name: str, enabled: bool, now: str) -> None:
        await asyncio.to_thread(self.set_plugin_enabled, name, enabled, now)

    async def aall_plugin_configs(self) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.all_plugin_configs)

    async def adelete_plugin_config(self, name: str) -> None:
        await asyncio.to_thread(self.delete_plugin_config, name)

    async def aupsert_integration(self, *a: Any) -> None:
        await asyncio.to_thread(self.upsert_integration, *a)

    async def aget_integration(self, name: str) -> Optional[dict[str, Any]]:
        return await asyncio.to_thread(self.get_integration, name)

    async def aall_integrations(self) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.all_integrations)

    async def adelete_integration(self, name: str) -> None:
        await asyncio.to_thread(self.delete_integration, name)

    async def aget_host_engine(self, host: str) -> Optional[dict[str, Any]]:
        return await asyncio.to_thread(self.get_host_engine, host)

    async def aset_host_engine(self, host: str, engine: str, reason: str, now: str) -> None:
        await asyncio.to_thread(self.set_host_engine, host, engine, reason, now)

    async def aall_host_preferences(self) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.all_host_preferences)

    async def ainsert_gateway_check(self, **r: Any) -> None:
        await asyncio.to_thread(self.insert_gateway_check, **r)

    async def alatest_gateway_checks(self) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.latest_gateway_checks)

    # ── Phase 3: Session Cache (js_sandbox_probe) ─────────────────────────
    def get_session_cache(self, probe_key: str) -> Optional[dict[str, Any]]:
        rows = self._read(
            "SELECT probe_key, payload, created_at_ts FROM session_cache WHERE probe_key = ?",
            (probe_key,))
        return dict(rows[0]) if rows else None

    def set_session_cache(self, probe_key: str, payload: str) -> None:
        import time
        self._write(
            """INSERT INTO session_cache (probe_key, payload, created_at_ts)
               VALUES (?, ?, ?)
               ON CONFLICT(probe_key) DO UPDATE SET payload=excluded.payload,
                 created_at_ts=excluded.created_at_ts""",
            (probe_key, payload, time.time()))

    def delete_session_cache(self, probe_key: str) -> None:
        self._write("DELETE FROM session_cache WHERE probe_key = ?", (probe_key,))

    async def aget_session_cache(self, probe_key: str) -> Optional[dict[str, Any]]:
        return await asyncio.to_thread(self.get_session_cache, probe_key)

    async def aset_session_cache(self, probe_key: str, payload: str) -> None:
        await asyncio.to_thread(self.set_session_cache, probe_key, payload)

    async def adelete_session_cache(self, probe_key: str) -> None:
        await asyncio.to_thread(self.delete_session_cache, probe_key)

    # ── Phase 3: Tunnel States (tunnel_manager) ───────────────────────────
    def set_tunnel_state(self, name: str, state: dict[str, Any]) -> None:
        from datetime import datetime, timezone
        self._write(
            """INSERT INTO tunnel_states (name, state_json, updated_at)
               VALUES (?, ?, ?)
               ON CONFLICT(name) DO UPDATE SET state_json=excluded.state_json,
                 updated_at=excluded.updated_at""",
            (name, json.dumps(state), datetime.now(timezone.utc).isoformat()))

    def delete_tunnel_state(self, name: str) -> None:
        self._write("DELETE FROM tunnel_states WHERE name = ?", (name,))

    def all_tunnel_states(self) -> list[dict[str, Any]]:
        return [dict(r) for r in self._read(
            "SELECT name, state_json, updated_at FROM tunnel_states ORDER BY updated_at DESC")]

    async def aset_tunnel_state(self, name: str, state: dict[str, Any]) -> None:
        await asyncio.to_thread(self.set_tunnel_state, name, state)

    async def adelete_tunnel_state(self, name: str) -> None:
        await asyncio.to_thread(self.delete_tunnel_state, name)

    # ── Phase 4: Cloud Usage Logs ─────────────────────────────────────────
    def log_cloud_session_start(self, provider: str, endpoint: str,
                                 browser_type: str, started_at: str) -> int:
        self._write(
            """INSERT INTO cloud_usage_logs (provider, endpoint, browser_type, started_at, status)
               VALUES (?,?,?,?,'connecting')""",
            (provider, endpoint, browser_type, started_at))
        rows = self._read("SELECT last_insert_rowid() AS id")
        return int(rows[0]["id"]) if rows else -1

    def log_cloud_session_end(self, log_id: int, duration_s: float = 0,
                               cost_usd: float = 0, status: str = "ok",
                               error: str = "") -> None:
        from datetime import datetime, timezone
        self._write(
            """UPDATE cloud_usage_logs SET finished_at=?, duration_s=?, cost_usd=?,
               status=?, error=? WHERE id=?""",
            (datetime.now(timezone.utc).isoformat(), duration_s, cost_usd,
             status, error or None, log_id))

    def cloud_usage_summary(self, since_hours: float = 24.0) -> dict[str, Any]:
        import time
        from datetime import datetime, timezone
        cutoff = datetime.fromtimestamp(time.time() - since_hours * 3600,
                                        tz=timezone.utc).isoformat()
        rows = self._read(
            """SELECT provider, COUNT(*) sessions, SUM(duration_s) total_s,
               SUM(cost_usd) total_usd, SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) ok_count
               FROM cloud_usage_logs WHERE started_at >= ? GROUP BY provider""",
            (cutoff,))
        return {"since_hours": since_hours, "providers": [dict(r) for r in rows]}

    async def alog_cloud_session_start(self, **kw: Any) -> int:
        return await asyncio.to_thread(self.log_cloud_session_start, **kw)

    async def alog_cloud_session_end(self, log_id: int, **kw: Any) -> None:
        await asyncio.to_thread(self.log_cloud_session_end, log_id, **kw)

    async def acloud_usage_summary(self, since_hours: float = 24.0) -> dict[str, Any]:
        return await asyncio.to_thread(self.cloud_usage_summary, since_hours)

    # ── Phase 4: Failure Taxonomy ─────────────────────────────────────────
    def log_failure_event(self, failure_type: str, scenario_id: str = "",
                           run_id: Optional[int] = None, detail: str = "") -> None:
        from datetime import datetime, timezone
        self._write(
            """INSERT INTO failure_events (run_id, scenario_id, failure_type, detail, occurred_at)
               VALUES (?,?,?,?,?)""",
            (run_id, scenario_id, failure_type, detail,
             datetime.now(timezone.utc).isoformat()))

    def recent_failure_rate(self, scenario_id: str, window_minutes: int = 5) -> float:
        """Trả về tỷ lệ lỗi (0.0–1.0) của scenario trong window_minutes phút gần nhất."""
        import time
        from datetime import datetime, timezone
        cutoff = datetime.fromtimestamp(time.time() - window_minutes * 60,
                                        tz=timezone.utc).isoformat()
        total = self._read(
            "SELECT COUNT(*) n FROM runs WHERE scenario_id=? AND started_at>=?",
            (scenario_id, cutoff))
        failures = self._read(
            "SELECT COUNT(*) n FROM runs WHERE scenario_id=? AND started_at>=? AND status='failed'",
            (scenario_id, cutoff))
        t = int(total[0]["n"]) if total else 0
        f = int(failures[0]["n"]) if failures else 0
        return f / t if t > 0 else 0.0

    async def alog_failure_event(self, **kw: Any) -> None:
        await asyncio.to_thread(self.log_failure_event, **kw)

    async def arecent_failure_rate(self, scenario_id: str, window_minutes: int = 5) -> float:
        return await asyncio.to_thread(self.recent_failure_rate, scenario_id, window_minutes)

    # ── Phase 4: Alert History ────────────────────────────────────────────
    def log_alert(self, channel: str, message: str, scenario_id: str = "",
                   status: str = "ok", error: str = "") -> None:
        from datetime import datetime, timezone
        self._write(
            """INSERT INTO alert_history (channel, scenario_id, message, sent_at, status, error)
               VALUES (?,?,?,?,?,?)""",
            (channel, scenario_id, message, datetime.now(timezone.utc).isoformat(),
             status, error or None))

    async def alog_alert(self, **kw: Any) -> None:
        await asyncio.to_thread(self.log_alert, **kw)

    # ── Phase 5: Pre-flight Results ───────────────────────────────────────
    def log_preflight(self, run_id: str, passed: bool, checks: dict[str, Any],
                       blocked: bool = False, reason: str = "") -> None:
        from datetime import datetime, timezone
        self._write(
            """INSERT INTO preflight_results (run_id, passed, checks, blocked, reason, audited_at)
               VALUES (?,?,?,?,?,?)""",
            (run_id, int(passed), json.dumps(checks), int(blocked),
             reason or None, datetime.now(timezone.utc).isoformat()))

    async def alog_preflight(self, **kw: Any) -> None:
        await asyncio.to_thread(self.log_preflight, **kw)

    # ── Phase 9: Storm runs ───────────────────────────────────────────────
    def log_storm_run(self, scenario_id: str, workspace_id: str,
                       total_submitted: int, duration_s: float,
                       peak_concurrency: int) -> None:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        self._write(
            """INSERT INTO storm_runs (scenario_id, workspace_id, total_submitted,
               duration_s, peak_concurrency, started_at, finished_at)
               VALUES (?,?,?,?,?,?,?)""",
            (scenario_id, workspace_id, total_submitted,
             round(duration_s, 1), peak_concurrency, now, now))

    async def alog_storm_run(self, **kw: Any) -> None:
        await asyncio.to_thread(self.log_storm_run, **kw)

    def recent_storm_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        return [dict(r) for r in self._read(
            "SELECT * FROM storm_runs ORDER BY started_at DESC LIMIT ?", (limit,))]

    async def arecent_storm_runs(self, limit: int = 20) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self.recent_storm_runs, limit)

    # ── Phase 6: Profile Warmth ───────────────────────────────────────────
    def set_profile_warmth(self, profile_id: str, trust_score: float,
                            urls_visited: int, cookies: int, warmed_at: str) -> None:
        status = "ready" if trust_score >= 60 else "warm" if trust_score >= 30 else "new"
        self._write(
            """INSERT INTO profile_warmth (profile_id, trust_score, urls_visited, cookies, warmed_at, status)
               VALUES (?,?,?,?,?,?)
               ON CONFLICT(profile_id) DO UPDATE SET
                 trust_score=excluded.trust_score, urls_visited=urls_visited+excluded.urls_visited,
                 cookies=excluded.cookies, warmed_at=excluded.warmed_at, status=excluded.status""",
            (profile_id, trust_score, urls_visited, cookies, warmed_at, status))

    def get_profile_warmth(self, profile_id: str) -> Optional[dict[str, Any]]:
        rows = self._read(
            "SELECT * FROM profile_warmth WHERE profile_id=?", (profile_id,))
        return dict(rows[0]) if rows else None

    def all_profile_warmth(self) -> list[dict[str, Any]]:
        return [dict(r) for r in self._read(
            "SELECT * FROM profile_warmth ORDER BY trust_score DESC")]

    async def aset_profile_warmth(self, **kw: Any) -> None:
        await asyncio.to_thread(self.set_profile_warmth, **kw)

    async def aget_profile_warmth(self, profile_id: str) -> Optional[dict[str, Any]]:
        return await asyncio.to_thread(self.get_profile_warmth, profile_id)

    # ------------------------------------------------------------------ fetch_all / fetch_one
    # Async query helpers dùng bởi admin_api.py (/scenarios, /scenarios/{id})
    # Pattern nhất quán với asyncio.to_thread (giống các method a* khác trong class)

    async def fetch_all(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        """Chạy SELECT async, trả về list[dict]. Wrapper của _read()."""
        return await asyncio.to_thread(self._read, sql, params)

    async def fetch_one(self, sql: str, params: tuple = ()) -> Optional[dict[str, Any]]:
        """Chạy SELECT async, trả về dict đầu tiên hoặc None."""
        rows = await asyncio.to_thread(self._read, sql, params)
        return rows[0] if rows else None
