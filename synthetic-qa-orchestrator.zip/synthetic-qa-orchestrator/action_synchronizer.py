"""Bộ Đồng Bộ Hóa Thao Tác Song Song (Real-Time Multi-Context Action Synchronizer).

Cho phép một cửa sổ trình duyệt làm Master (có giao diện, kỹ sư QA thao tác trực tiếp)
và phát tất cả thao tác sang nhiều Slave contexts chạy song song — dùng để:
  * Kiểm thử cùng lúc trên nhiều thiết bị (desktop/mobile/tablet).
  * Mô phỏng nhiều người dùng thực hiện cùng thao tác từ nhiều vùng địa lý.
  * Stress test: gửi đồng thời từ N sessions mà không cần viết N script riêng.

Kiến trúc:
  Master page (headful) → JS CDP listener → EventBus → SyncBroadcaster
       → asyncio.Queue per Slave → SlaveWorker → Playwright API calls

Jitter: mỗi Slave có độ trễ ngẫu nhiên riêng (Gaussian hoặc Uniform trong [min, max]),
được áp vào từng sự kiện để tránh request storm đồng thời.

GIỚI HẠN ĐÃ BIẾT:
  - Master phải chạy HEADLESS=False (có giao diện) để kỹ sư QA thao tác thủ công.
    Không thể dùng headless Master vì Playwright expose function chỉ hoạt động với
    page đang chạy trong context thật.
  - CDP Input domain chỉ hỗ trợ mouse/keyboard/touch. Scroll qua CDP dispatchMouseEvent
    với button='none' type='mouseMoved' + mousewheel event.
  - Không đồng bộ file dialog, alert/confirm/prompt, hoặc browser extension UI.
  - Slave contexts phải ở cùng browser instance (hoặc dùng connect_over_cdp).
    Không hỗ trợ broadcast qua mạng tới browser trên máy khác trong phiên bản này.
  - Nếu trang Slave navigate sang URL khác với Master, tọa độ click sẽ sai do
    layout khác nhau. Dùng selector-based fallback khi có thể.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from dataclasses import dataclass, field
from typing import Any, Optional

LOGGER = logging.getLogger("qa.sync")

# JS inject vào Master page để bắt sự kiện và gọi về Python
_JS_MASTER_HOOK = """
(callbackName) => {
  if (window.__qa_sync_active) return 'already_active';
  window.__qa_sync_active = true;
  const cb = callbackName;
  const vw = () => window.innerWidth, vh = () => window.innerHeight;

  const send = (type, data) => {
    try { window[cb](JSON.stringify({type, ...data, ts: Date.now()})); }
    catch(e) {}
  };

  // Mouse
  document.addEventListener('click', e => send('click', {
    x: e.clientX, y: e.clientY,
    rx: e.clientX / vw(), ry: e.clientY / vh(),   // relative coords (0..1)
    button: ['left','middle','right'][e.button]||'left',
    selector: e.target?.id ? '#'+e.target.id :
              e.target?.className ? '.'+e.target.className.split(' ')[0] : null
  }), true);

  document.addEventListener('mousemove', (() => {
    let last = 0;
    return e => {
      if (Date.now()-last < 50) return; last = Date.now();
      send('mousemove', {x:e.clientX, y:e.clientY, rx:e.clientX/vw(), ry:e.clientY/vh()});
    };
  })(), true);

  // Keyboard
  document.addEventListener('keydown', e => {
    if (!['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)) return;
    send('keydown', {key: e.key});
  }, true);
  document.addEventListener('keyup', e => {
    if (!['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName)) return;
    send('keyup', {key: e.key});
  }, true);

  // Input (text)
  document.addEventListener('input', e => {
    if (e.target?.type === 'password') return;  // không ghi mật khẩu
    send('input', {
      text: e.data || '',
      selector: e.target?.id ? '#'+e.target.id : e.target?.tagName?.toLowerCase()
    });
  }, true);

  // Scroll
  window.addEventListener('scroll', (() => {
    let last = 0;
    return () => {
      if (Date.now()-last < 100) return; last = Date.now();
      send('scroll', {sx: Math.round(window.scrollX), sy: Math.round(window.scrollY)});
    };
  })(), {passive:true});

  // Navigation (pushState / location)
  const origPush = history.pushState.bind(history);
  history.pushState = (...args) => { origPush(...args); send('navigate', {url: location.href}); };
  window.addEventListener('popstate', () => send('navigate', {url: location.href}));

  return 'hooked';
}
"""


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class SyncEvent:
    type: str                    # click | mousemove | keydown | keyup | input | scroll | navigate
    ts: float                    # timestamp từ Master (ms epoch)
    # Mouse
    x: Optional[float] = None
    y: Optional[float] = None
    rx: Optional[float] = None   # relative x (0..1) — dùng khi Slave viewport khác
    ry: Optional[float] = None
    button: Optional[str] = None
    selector: Optional[str] = None
    # Keyboard/Input
    key: Optional[str] = None
    text: Optional[str] = None
    # Scroll/Navigate
    sx: Optional[float] = None
    sy: Optional[float] = None
    url: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "SyncEvent":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


@dataclass
class SlaveConfig:
    name: str
    page: Any                        # Playwright page object
    jitter_min_ms: float = 50.0
    jitter_max_ms: float = 300.0
    follow_navigation: bool = True   # có theo URL của Master không
    viewport_scale: bool = True      # dùng relative coords để scale theo viewport

    def jitter(self) -> float:
        return random.uniform(self.jitter_min_ms, self.jitter_max_ms)


# ---------------------------------------------------------------------------
# Broadcaster
# ---------------------------------------------------------------------------

class ActionSynchronizer:
    """Master-Slave broadcaster: bắt sự kiện từ Master → phát sang tất cả Slaves.

    Dùng như async context manager:
        async with ActionSynchronizer(master_page, slaves) as sync:
            # kỹ sư QA thao tác trên master_page (headful)
            await asyncio.sleep(60)  # hoặc await sync.wait_until_stopped()
    """

    def __init__(
        self,
        master_page: Any,
        slaves: list[SlaveConfig],
        sync_jitter_ms: tuple[float, float] = (50.0, 300.0),
        queue_maxsize: int = 500,
    ) -> None:
        self.master = master_page
        self.slaves = slaves
        self.jitter_range = sync_jitter_ms
        self._queues: dict[str, asyncio.Queue[Optional[SyncEvent]]] = {}
        self._workers: list[asyncio.Task[None]] = []
        self._running = False
        self._stats: dict[str, int] = {"broadcast": 0, "errors": 0}
        self._stop_event = asyncio.Event()
        self._queue_maxsize = queue_maxsize

    async def __aenter__(self) -> "ActionSynchronizer":
        await self.start()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.stop()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Inject JS listener vào Master và khởi động worker cho từng Slave."""
        if self._running:
            return
        self._running = True

        # Khởi tạo queue cho từng slave
        for sc in self.slaves:
            self._queues[sc.name] = asyncio.Queue(maxsize=self._queue_maxsize)

        # Inject Master hook và expose callback vào Python
        result = await self.master.evaluate(_JS_MASTER_HOOK, "__qa_sync_cb__")
        LOGGER.info("sync: master hook inject = %s, %d slaves", result, len(self.slaves))

        await self.master.expose_function("__qa_sync_cb__", self._on_master_event)

        # Khởi động workers
        for sc in self.slaves:
            task = asyncio.create_task(
                self._slave_worker(sc),
                name=f"sync-slave-{sc.name}",
            )
            self._workers.append(task)

        LOGGER.info("sync: đang phát tới %d slave(s)", len(self.slaves))

    async def stop(self) -> None:
        """Dừng tất cả workers và dọn dẹp."""
        if not self._running:
            return
        self._running = False
        self._stop_event.set()

        # Gửi sentinel None để workers thoát
        for q in self._queues.values():
            await q.put(None)

        for t in self._workers:
            t.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()
        LOGGER.info("sync: dừng. broadcast=%d errors=%d",
                    self._stats["broadcast"], self._stats["errors"])

    async def wait_until_stopped(self) -> None:
        """Block cho đến khi stop() được gọi (dùng trong headful session)."""
        await self._stop_event.wait()

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _on_master_event(self, json_str: str) -> None:
        """Callback được gọi từ JS khi Master có sự kiện. Chạy trong thread Playwright."""
        try:
            import json as _json
            d = _json.loads(json_str)
            evt = SyncEvent.from_dict(d)
            # Push vào tất cả slave queues (non-blocking, drop nếu full)
            for sc in self.slaves:
                q = self._queues.get(sc.name)
                if q:
                    try:
                        q.put_nowait(evt)
                    except asyncio.QueueFull:
                        pass  # drop sự kiện nếu slave queue đầy
            self._stats["broadcast"] += 1
        except Exception as exc:
            self._stats["errors"] += 1
            LOGGER.debug("sync: parse event error: %s", exc)

    # ------------------------------------------------------------------
    # Slave worker
    # ------------------------------------------------------------------

    async def _slave_worker(self, sc: SlaveConfig) -> None:
        """Nhận sự kiện từ queue và phát lại trên slave page với jitter."""
        q = self._queues[sc.name]
        LOGGER.debug("sync: worker '%s' bắt đầu", sc.name)
        while True:
            try:
                evt = await asyncio.wait_for(q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                if not self._running:
                    break
                continue

            if evt is None:  # sentinel
                break

            # Áp jitter
            jitter_ms = sc.jitter()
            if jitter_ms > 0:
                await asyncio.sleep(jitter_ms / 1000.0)

            try:
                await self._dispatch_to_slave(sc, evt)
            except Exception as exc:
                LOGGER.debug("sync: slave '%s' dispatch lỗi [%s]: %s",
                             sc.name, evt.type, exc)
            finally:
                q.task_done()

        LOGGER.debug("sync: worker '%s' dừng", sc.name)

    async def _dispatch_to_slave(self, sc: SlaveConfig, evt: SyncEvent) -> None:
        """Phát lại một sự kiện lên slave page."""
        page = sc.page

        if evt.type == "navigate" and sc.follow_navigation and evt.url:
            await page.goto(evt.url, wait_until="domcontentloaded", timeout=15_000)

        elif evt.type == "click":
            x, y = self._scale_coords(sc, page, evt)
            if x is not None and y is not None:
                await page.mouse.click(x, y, button=evt.button or "left")
            elif evt.selector:
                try:
                    await page.locator(evt.selector).first.click(timeout=3000)
                except Exception:
                    pass

        elif evt.type == "mousemove":
            x, y = self._scale_coords(sc, page, evt)
            if x is not None and y is not None:
                await page.mouse.move(x, y)

        elif evt.type == "keydown":
            if evt.key:
                await page.keyboard.down(evt.key)

        elif evt.type == "keyup":
            if evt.key:
                await page.keyboard.up(evt.key)

        elif evt.type == "input":
            if evt.text and evt.selector:
                try:
                    await page.locator(evt.selector).first.type(evt.text, delay=20)
                except Exception:
                    if evt.text:
                        await page.keyboard.type(evt.text)

        elif evt.type == "scroll":
            if evt.sx is not None and evt.sy is not None:
                await page.evaluate(
                    f"window.scrollTo({{left:{evt.sx},top:{evt.sy},behavior:'smooth'}})"
                )

    @staticmethod
    def _scale_coords(
        sc: SlaveConfig,
        page: Any,
        evt: SyncEvent,
    ) -> tuple[Optional[float], Optional[float]]:
        """Scale tọa độ từ Master sang Slave viewport."""
        if not sc.viewport_scale or evt.rx is None or evt.ry is None:
            return evt.x, evt.y
        vp = page.viewport_size
        if not vp:
            return evt.x, evt.y
        return evt.rx * vp["width"], evt.ry * vp["height"]

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    @property
    def stats(self) -> dict[str, int]:
        return dict(self._stats)


# ---------------------------------------------------------------------------
# Convenience: chạy sync session có thời hạn
# ---------------------------------------------------------------------------

async def run_sync_session(
    master_page: Any,
    slave_pages: list[Any],
    duration_s: float = 60.0,
    jitter_min_ms: float = 50.0,
    jitter_max_ms: float = 300.0,
    follow_navigation: bool = True,
) -> dict[str, Any]:
    """Chạy session đồng bộ trong `duration_s` giây rồi dừng.

    Args:
        master_page: Playwright page (headful) làm điều khiển chính.
        slave_pages: danh sách Playwright pages nhận sự kiện.
        duration_s: thời gian chạy tối đa (giây).
        jitter_min_ms / jitter_max_ms: dải jitter cho mỗi slave.

    Returns:
        dict với stats: broadcast_count, errors, duration_s.
    """
    slaves = [
        SlaveConfig(
            name=f"slave-{i}",
            page=pg,
            jitter_min_ms=jitter_min_ms,
            jitter_max_ms=jitter_max_ms,
            follow_navigation=follow_navigation,
        )
        for i, pg in enumerate(slave_pages)
    ]
    t0 = time.perf_counter()
    async with ActionSynchronizer(master_page, slaves) as sync:
        await asyncio.sleep(duration_s)
    return {
        "broadcast_count": sync.stats["broadcast"],
        "errors": sync.stats["errors"],
        "duration_s": round(time.perf_counter() - t0, 1),
        "slave_count": len(slaves),
    }
