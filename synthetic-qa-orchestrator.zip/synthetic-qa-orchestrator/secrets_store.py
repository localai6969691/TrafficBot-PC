"""Mã hoá tại chỗ (at-rest) cho API key/secret người dùng nhập ở tab Integrations.

GIỚI HẠN ĐÃ BIẾT (xem PROJECT.md):
Đây KHÔNG phải mã hoá học thuật mạnh (không phải AES-GCM có xác thực). Dự án chỉ dùng
thư viện chuẩn Python (không có `cryptography`/`pycryptodome` do môi trường phát triển
không tải được gói mới qua Internet - xem lịch sử trong PROJECT.md). Cơ chế ở đây là một
stream cipher tối giản: khoá 32 byte sinh ngẫu nhiên một lần, lưu tại `data/secret.key`
(quyền 600 trên hệ điều hành hỗ trợ), keystream = SHA-256(khoá || bộ đếm) nối tiếp, XOR
với plaintext. Mục đích CHỈ là để API key không nằm ở dạng chữ rõ ngay trong tệp
`state.db` (phòng trường hợp lộ file DB một mình) - KHÔNG chống được kẻ tấn công có quyền
đọc cả `data/secret.key` lẫn `state.db` trên cùng máy. Muốn mã hoá đúng chuẩn, cần cài
`cryptography` và đổi `encrypt`/`decrypt` sang Fernet/AES-GCM - chưa triển khai.
"""
from __future__ import annotations

import base64
import hashlib
import os
import secrets
from pathlib import Path


class SecretBox:
    def __init__(self, key_path: Path) -> None:
        self.key_path = Path(key_path)
        self._key = self._load_or_create_key()

    def _load_or_create_key(self) -> bytes:
        if self.key_path.is_file():
            data = self.key_path.read_bytes()
            if len(data) == 32:
                return data
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        key = secrets.token_bytes(32)
        self.key_path.write_bytes(key)
        try:
            os.chmod(self.key_path, 0o600)
        except OSError:
            pass  # Windows: không có chmod kiểu POSIX, bỏ qua
        return key

    def _keystream(self, n: int) -> bytes:
        out, counter = bytearray(), 0
        while len(out) < n:
            out += hashlib.sha256(self._key + counter.to_bytes(4, "big")).digest()
            counter += 1
        return bytes(out[:n])

    def encrypt(self, plaintext: str) -> str:
        data = plaintext.encode("utf-8")
        ct = bytes(a ^ b for a, b in zip(data, self._keystream(len(data))))
        return base64.urlsafe_b64encode(ct).decode("ascii")

    def decrypt(self, token: str) -> str:
        ct = base64.urlsafe_b64decode(token.encode("ascii"))
        data = bytes(a ^ b for a, b in zip(ct, self._keystream(len(ct))))
        return data.decode("utf-8")

    @staticmethod
    def mask(plaintext: str, keep: int = 4) -> str:
        if len(plaintext) <= keep:
            return "*" * len(plaintext)
        return "*" * (len(plaintext) - keep) + plaintext[-keep:]
