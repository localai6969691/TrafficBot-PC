"""Hệ Thống Giám Sát Tài Nguyên & Tự Điều Tiết Luồng (Adaptive Resource Governor).

Hai thành phần:
  1. SystemTelemetry  - đo CPU/RAM/process liên tục, expose metrics lên dashboard.
  2. ConcurrencyThrottler - tự động giảm/tăng số BrowserContext được phép chạy song song
     dựa trên RAM/CPU thực tế, ngăn OOM crash trên máy cấu hình thấp.

Tích hợp vào Engine:
  engine.py khởi tạo ResourceGovernor(settings) và gọi await governor.can_start_context()
  trước mỗi lần spawn BrowserContext mới. Nếu trả về False → chờ cho đến khi tài nguyên
  đủ rồi mới cho qua.

GIỚI HẠN:
  - psutil đo CPU theo interval 1s (blocking nếu dùng synchronously). Luôn gọi qua
    asyncio.to_thread() để không block event loop.
  - RAM measurement bao gồm cả buffer/cache của hệ thống (Linux). available_percent
    dùng psutil.virtual_memory().available thay vì (1 - used_percent) để chính xác hơn.
  - Windows: process tree memory không hoàn toàn chính xác do shared memory với dll.
  - Throttler không kill context đang chạy — chỉ block SPAWN mới. Context đang chạy
    sẽ hoàn thành bình thường.
  - cpu_throttle_pct: nếu CPU > ngưỡng liên tục > cpu_sustained_s giây mới throttle.
    Spike ngắn không trigger throttle.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

LOGGER = logging.getLogger("qa.governor")


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class SystemSnapshot:
    cpu_pct: float
    ram_pct: float
    ram_available_mb: float
    ram_total_mb: float
    process_ram_mb: float          # RAM của process orchestrator này
    active_contexts: int = 0
    timestamp: float = field(default_factory=time.time)

    @property
    def ram_used_pct(self) -> float:
        return 100.0 - (self.ram_available_mb / self.ram_total_mb * 100)

    def to_dict(self) -> dict[str, Any]:
        return {
            "cpu_pct": round(self.cpu_pct, 1),
            "ram_pct": round(self.ram_pct, 1),
            "ram_available_mb": round(self.ram_available_mb),
            "ram_total_mb": round(self.ram_total_mb),
            "process_ram_mb": round(self.process_ram_mb, 1),
            "active_contexts": self.active_contexts,
            "timestamp": self.timestamp,
            "ts_human": datetime.fromtimestamp(self.timestamp, tz=timezone.utc).isoformat(),
        }


@dataclass
class ThrottleConfig:
    max_concurrency: int = 4           # giới hạn tối đa (cứng)
    ram_throttle_pct: float = 80.0     # RAM% → giảm slot
    ram_pause_pct: float = 90.0        # RAM% → tạm dừng hoàn toàn
    cpu_throttle_pct: float = 85.0     # CPU% → giảm slot
    cpu_sustained_s: float = 10.0      # CPU cao phải duy trì bao lâu mới throttle
    poll_interval_s: float = 3.0       # interval đo lường
    wait_timeout_s: float = 60.0       # max chờ slot khi throttled
    min_concurrency: int = 1           # không giảm xuống dưới 1


# ---------------------------------------------------------------------------
# SystemTelemetry
# ---------------------------------------------------------------------------

class SystemTelemetry:
    """Thu thập CPU/RAM định kỳ, lưu history ring-buffer."""

    _HISTORY_LEN = 60  # 60 × poll_interval = 3 phút history

    def __init__(self, poll_interval_s: float = 3.0) -> None:
        self.poll_interval = poll_interval_s
        self._latest: Optional[SystemSnapshot] = None
        self._history: list[SystemSnapshot] = []
        self._task: Optional[asyncio.Task] = None
        self._active_contexts: int = 0

    async def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="sys-telemetry")
        LOGGER.info("telemetry: bắt đầu giám sát (poll=%.0fs)", self.poll_interval)

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def _loop(self) -> None:
        while True:
            try:
                snap = await asyncio.to_thread(self._measure)
                snap.active_contexts = self._active_contexts
                self._latest = snap
                self._history.append(snap)
                if len(self._history) > self._HISTORY_LEN:
                    self._history.pop(0)
            except Exception as exc:
                LOGGER.debug("telemetry measure lỗi: %s", exc)
            await asyncio.sleep(self.poll_interval)

    @staticmethod
    def _measure() -> SystemSnapshot:
        import psutil
        vm = psutil.virtual_memory()
        cpu = psutil.cpu_percent(interval=1.0)
        proc = psutil.Process(os.getpid())
        try:
            proc_mem = proc.memory_info().rss / 1_048_576
        except Exception:
            proc_mem = 0.0
        return SystemSnapshot(
            cpu_pct=cpu,
            ram_pct=vm.percent,
            ram_available_mb=vm.available / 1_048_576,
            ram_total_mb=vm.total / 1_048_576,
            process_ram_mb=proc_mem,
        )

    @property
    def latest(self) -> Optional[SystemSnapshot]:
        return self._latest

    def history_dicts(self, last_n: int = 20) -> list[dict[str, Any]]:
        return [s.to_dict() for s in self._history[-last_n:]]

    def set_active_contexts(self, n: int) -> None:
        self._active_contexts = n

    def avg_cpu_last_n(self, n: int = 10) -> float:
        if not self._history:
            return 0.0
        samples = [s.cpu_pct for s in self._history[-n:]]
        return sum(samples) / len(samples)


# ---------------------------------------------------------------------------
# ConcurrencyThrottler
# ---------------------------------------------------------------------------

class ConcurrencyThrottler:
    """Điều tiết số BrowserContext chạy đồng thời dựa trên tài nguyên thực tế."""

    def __init__(self, telemetry: SystemTelemetry, cfg: ThrottleConfig) -> None:
        self.telemetry = telemetry
        self.cfg = cfg
        self._active = 0
        self._lock = asyncio.Lock()
        self._cpu_high_since: Optional[float] = None

    @property
    def active_count(self) -> int:
        return self._active

    def _effective_limit(self) -> int:
        """Tính giới hạn hiệu dụng dựa trên RAM/CPU hiện tại."""
        snap = self.telemetry.latest
        if snap is None:
            return self.cfg.max_concurrency

        # Pause hoàn toàn khi RAM cực cao
        if snap.ram_pct >= self.cfg.ram_pause_pct:
            LOGGER.warning("governor: RAM %.0f%% ≥ pause_pct %.0f%% → tạm dừng spawn",
                           snap.ram_pct, self.cfg.ram_pause_pct)
            return 0

        limit = self.cfg.max_concurrency

        # Giảm theo RAM
        if snap.ram_pct >= self.cfg.ram_throttle_pct:
            factor = 1 - (snap.ram_pct - self.cfg.ram_throttle_pct) / (
                self.cfg.ram_pause_pct - self.cfg.ram_throttle_pct + 1)
            limit = max(self.cfg.min_concurrency, int(limit * factor))

        # Giảm theo CPU sustained
        avg_cpu = self.telemetry.avg_cpu_last_n(
            int(self.cfg.cpu_sustained_s / self.telemetry.poll_interval) + 1)
        if avg_cpu >= self.cfg.cpu_throttle_pct:
            if self._cpu_high_since is None:
                self._cpu_high_since = time.time()
            elif time.time() - self._cpu_high_since >= self.cfg.cpu_sustained_s:
                limit = max(self.cfg.min_concurrency, limit // 2)
                LOGGER.warning("governor: CPU avg=%.0f%% sustained → limit=%d", avg_cpu, limit)
        else:
            self._cpu_high_since = None

        return limit

    async def can_start_context(self) -> bool:
        """True nếu có thể spawn context mới ngay. Không block."""
        async with self._lock:
            return self._active < self._effective_limit()

    async def acquire(self, timeout_s: Optional[float] = None) -> bool:
        """Chờ cho đến khi có slot, rồi acquire. Trả False nếu timeout."""
        deadline = time.monotonic() + (timeout_s or self.cfg.wait_timeout_s)
        while time.monotonic() < deadline:
            async with self._lock:
                limit = self._effective_limit()
                if self._active < limit:
                    self._active += 1
                    self.telemetry.set_active_contexts(self._active)
                    LOGGER.debug("governor: acquire slot (%d/%d)", self._active, limit)
                    return True
            await asyncio.sleep(0.5)
        LOGGER.warning("governor: timeout chờ slot sau %.0fs", timeout_s or self.cfg.wait_timeout_s)
        return False

    async def release(self) -> None:
        """Giải phóng slot sau khi context đóng."""
        async with self._lock:
            self._active = max(0, self._active - 1)
            self.telemetry.set_active_contexts(self._active)
        LOGGER.debug("governor: release slot (%d active)", self._active)

    def status(self) -> dict[str, Any]:
        snap = self.telemetry.latest
        limit = self._effective_limit()
        return {
            "active": self._active,
            "effective_limit": limit,
            "max_concurrency": self.cfg.max_concurrency,
            "throttled": limit < self.cfg.max_concurrency,
            "paused": limit == 0,
            "telemetry": snap.to_dict() if snap else None,
        }


# ---------------------------------------------------------------------------
# ResourceGovernor — façade tổng hợp
# ---------------------------------------------------------------------------

class ResourceGovernor:
    """Façade: telemetry + throttler + context manager."""

    def __init__(self, max_concurrency: int = 4,
                 ram_throttle_pct: float = 80.0,
                 ram_pause_pct: float = 90.0,
                 cpu_throttle_pct: float = 85.0,
                 poll_interval_s: float = 3.0) -> None:
        cfg = ThrottleConfig(
            max_concurrency=max_concurrency,
            ram_throttle_pct=ram_throttle_pct,
            ram_pause_pct=ram_pause_pct,
            cpu_throttle_pct=cpu_throttle_pct,
            poll_interval_s=poll_interval_s,
        )
        self.telemetry = SystemTelemetry(poll_interval_s)
        self.throttler = ConcurrencyThrottler(self.telemetry, cfg)

    async def start(self) -> None:
        await self.telemetry.start()
        # Warm-up: đợi 1 đo đầu tiên
        await asyncio.sleep(self.telemetry.poll_interval + 0.5)

    async def stop(self) -> None:
        await self.telemetry.stop()

    async def acquire_context_slot(self, timeout_s: float = 60.0) -> bool:
        return await self.throttler.acquire(timeout_s)

    async def release_context_slot(self) -> None:
        await self.throttler.release()

    def status(self) -> dict[str, Any]:
        return self.throttler.status()

    def metrics_history(self, last_n: int = 20) -> list[dict[str, Any]]:
        return self.telemetry.history_dicts(last_n)
