# TÀI LIỆU ĐẶC TẢ KỸ THUẬT & KIỂM TOÁN HỆ THỐNG TOÀN DIỆN
## Synthetic Automation Studio — Codebase State at Session 17

**Phạm vi kiểm toán:** 74 file nguồn (`.py`, `.json`, `.yml`, HTML/JS nhúng trong `dashboard.py`), ~97 API route, 20 bảng SQLite.
**Phương pháp:** Đọc trực tiếp mã nguồn hiện hành (không suy diễn từ tài liệu cũ), đối chiếu từng tuyên bố với dòng code cụ thể. Mọi trạng thái "✅ Đã nối mạch" đều dựa trên việc lần theo lệnh gọi hàm thực tế, không dựa trên tên biến/comment.

---

## 1. SƠ ĐỒ KIẾN TRÚC & CHUỖI THỰC THI END-TO-END

### 1.1. Hai điểm vào hệ thống (hai tiến trình runner độc lập, dùng chung code)

```
ĐIỂM VÀO A — CLI (main.py)                ĐIỂM VÀO B — Desktop (app_launcher.py)
  main.py run/schedule                      PyWebView window + tray icon
        │                                          │
        └──────────────┬───────────────────────────┘
                        ▼
              main.build_app(paths, args)
         (Config + Database + EventBus + PluginManager
          + GatewayPool + Engine — MỘT instance Engine
          DUY NHẤT cho cả 2 đường vào, từ Phiên 17)
                        │
                        ▼
         main.running(app) [async context manager]
         ├─ pool.start_health_checks() (nền, định kỳ)
         ├─ engine.start() → async_playwright().start()
         │                 → nếu virtual_display_enabled
         │                   && Linux && headless=False:
         │                   XvfbManager.start() (subprocess Xvfb thật)
         │                 → ResourceGovernor.start() (psutil polling nền)
         └─ dashboard.create_app(db,bus,status_fn,paths) → uvicorn.serve()
```

### 1.2. Chuỗi thực thi MỘT lượt chạy (từ HTTP request tới khi ghi DB)

```
[1] TRIGGER
    (a) CLI: main.cmd_run() → run_cycle(app, iterations) — chạy MỘT LẦN rồi thoát
    (b) Lịch trình: apscheduler cron (nếu settings.schedule_windows cấu hình)
    (c) HTTP: POST /api/admin/run-now {scenario_ids, iterations}
        (Phiên 17 — endpoint DUY NHẤT cho phép kích hoạt theo yêu cầu từ UI;
        trước Phiên 17 hoàn toàn không tồn tại cơ chế này)
        → asyncio.create_task(engine.run_tasks(queue, drain=True))  [FIRE-AND-FORGET,
          HTTP response trả về NGAY, không chờ scenario chạy xong]

[2] HÀNG ĐỢI (engine.py::TaskQueue — ABC, 2 impl cụ thể)
    LocalQueue: asyncio.Queue thuần, trong-tiến-trình, mất khi crash.
    RedisQueue: LPUSH/BRPOP qua `redis.asyncio` — kích hoạt khi
    `cfg.settings.redis_url` được cấu hình (lựa chọn tại `main.py::_redis_queue()`).
    Giao hàng "at-most-once": worker chết giữa chừng làm MẤT tác vụ đang xử lý
    (không có ack/requeue). Khoá profile dùng khoá Redis riêng để 2 máy không
    cùng mở 1 profile — đây là cơ chế phối hợp ĐA MÁY DUY NHẤT trong dự án.
    (`POST /run-now` — Phiên 17 — LUÔN dùng `LocalQueue`, KHÔNG đọc
    `redis_url` — nghĩa là tính năng "Chạy ngay" từ Dashboard chỉ chạy
    trong-tiến-trình, không tận dụng được RedisQueue dù đã cấu hình.)

[3] Engine.run_tasks(queue, drain)
    vòng lặp: ResourceGovernor.acquire_context_slot(timeout=5s)
              → nếu bị throttle (RAM>80% hoặc CPU>85%): sleep 1s, retry
              → nếu RAM>90% (ram_pause_pct): KHÔNG lấy task mới (pause cứng)
    queue.get(timeout=0.5) → Task(task_id, scenario_id, url)
    asyncio.create_task(engine.execute(task, queue))  [tạo task con không chờ]

[4] Engine.execute(task, queue)  [engine.py dòng ~426]
    (Phiên 17: bọc try/finally đăng ký/huỷ đăng ký vào self._workers{} —
     đây là nguồn dữ liệu DUY NHẤT cho "Live Browser Workers Grid")
    → self._workers[task_id] = {scenario_id, profile_id, url, engine,
                                 current_step:"khởi tạo", page:None}
    → _execute_inner(...):
        sc = self.scenarios.get(task.scenario_id)  — tra bộ nhớ, KHÔNG query DB
        if not is_url_allowed(url, settings.allowed_domains): raise
        env = self.environments.get(sc.environment) — resolve Persona/locale/tz
        gateway = self.pool.assign(sc.profile_id, sc.region)
            → rendezvous hashing: max(candidates, key=sha1(profile_id+gateway_url))
            → STICKY theo profile_id (cùng profile luôn ra cùng gateway khi còn khoẻ)
            → None nếu pool.configured=False (không gateway nào cấu hình)
        vòng lặp retry (while, có breaker CircuitBreaker theo netloc):
            result = await self._attempt_browser(...) | self._attempt_http(...)
                     tuỳ sc.engine ("http"|"chromium"|"firefox"|"webkit"|"auto")
            if result.gateway_error: pool.report_failure(gateway)
            if result.status in {429,503} OR result.preflight_blocked:
                 nếu attempts <= max_retries: backoff.delay(), retry
            else: break

[5] _attempt_browser (nhánh trình duyệt thật — engine.py dòng ~495-720)
    context = launch_persistent_context(profile_dir, args=[...stealth flags])
         HOẶC browser dùng chung (context_mode="shared")
         HOẶC connect_over_cdp(cdp_endpoint) (Cloud Browser)
    context.add_init_script(STEALTH_WEBDRIVER_JS)   [Phiên 15 — patch navigator.webdriver]
    context.add_init_script(PERF_OBSERVER_JS)       [thu thập FCP/LCP/CLS qua
                                                      PerformanceObserver JS thật]
    bopt.apply(context)    — BandwidthOptimizer: page.route("**/*", handler)
                              chặn resource_type thừa (nếu bandwidth.enabled)
    page = context.pages[0] hoặc new_page()
    self._workers[task_id]["page"] = page   [cập nhật mỗi bước — _run_step_with_retry]

    NẾU preflight_gate_enabled (mặc định True, system_settings):
        run_preflight(page, db, exit_ip=res.exit_ip,
                      expected_timezone=env.timezone_id, expected_locale=env.locale,
                      block_on_fail=True)
        → 4 check: WebRTC leak, Timezone/Locale khớp IP, automation flags
                   (navigator.webdriver, cdc_* vars), TLS JA3/JA4 khớp UA
        → NẾU blocked: res.preflight_blocked=True, res.gateway_error=True
                        → return SỚM (không chạy bước nào), outer loop retry
                          với gateway KHÁC (vì gateway_error=True kích hoạt
                          pool.report_failure)

    NẾU analytics_verification_enabled (mặc định True):
        attach_analytics_listener(page, analytics_state)
        → page.on("response", handler) lắng nghe TOÀN BỘ response của page
          trong suốt vòng đời, khớp URL marker (/g/collect, facebook.com/tr...)
          VÀ status in (200,204) → set analytics_state["verified"]=True

    _run_steps(page, sc.steps, ctx)
        với MỖI step: _run_step_with_retry → cập nhật
                      self._workers[task_id]["current_step"] = step["action"]
                      → _step(page, step, ctx) — if/elif chain 40+ action type
                        (xem Mục 3 để phân rã chi tiết từng action)

    sau khi _run_steps xong (không exception):
        if res.analytics_verified=="NOT_VERIFIED" and analytics_state["verified"]:
            res.analytics_verified = "VERIFIED_SUCCESS"

[6] GHI NHẬN KẾT QUẢ (engine.py execute(), sau khi thoát vòng retry)
    run = dict(scenario_id, profile_id, url, started_at, finished_at,
               status, http_status, exit_ip, gateway, attempts, error_message,
               engine, analytics_verified, preflight_status)
    await db.asave_run(run, result.metrics)
        → asyncio.to_thread(self.insert_run, **run)   [SQLite WRITE qua threadpool,
          self._lock (threading.Lock) đồng bộ hoá — xem Mục 5 về WAL/khoá]
    bus.publish("run", scenario=..., status=..., engine=...)  → SSE /events
    if preflight_blocked: bus.publish("log", level="warn", message=...) → SSE

[7] DỌN DẸP (finally, mọi nhánh kể cả exception)
    context.close() (hoặc KHÔNG đóng nếu shared_mode — browser dùng chung)
    self._workers.pop(task_id, None)   [worker biến mất khỏi Live Worker Grid]
```

### 1.3. Cơ chế giao tiếp giữa các tầng

| Kênh | Công nghệ | Dùng cho | Độ bền |
|---|---|---|---|
| `EventBus` | `asyncio.Queue` per-subscriber, in-process pub/sub | `run`, `log`, các event khác → SSE `/events` | **Không bền** — mất khi restart, không multi-process |
| SSE (`GET /events`) | `StreamingResponse` text/event-stream | Đẩy log/run real-time xuống Dashboard JS | Một chiều (server→client), tự reconnect phía browser |
| SQLite WAL | `sqlite3` với `PRAGMA journal_mode=WAL` (xác nhận trong `database.py::open()`) | `state.db` — toàn bộ state bền vững | Bền, nhưng single-file, không multi-writer qua network |
| `threading.Lock` (`Database._lock`) | Lock Python thuần | Serialize mọi write SQLite trong CÙNG tiến trình | Không bảo vệ được multi-PROCESS (xem Mục 5) |
| Engine↔admin_api | `bus.engine = engine` (gán thuộc tính runtime, **không phải dependency injection chuẩn**) | Live Worker Grid, Run Now, Xvfb status đọc qua `getattr(bus,"engine",None)` | Hoạt động trong-tiến-trình; vỡ nếu admin_api chạy tách tiến trình |
| WebSocket | **Không sử dụng** ở bất kỳ đâu trong `admin_api.py`/`dashboard.py` hiện tại — tài liệu kiến trúc cũ có nhắc "WebSockets" trong sơ đồ tầng nhưng thực tế toàn bộ real-time đều qua SSE | — | — |
| IPC (desktop) | Không có IPC thật — `app_launcher.py` chạy uvicorn NGAY TRONG tiến trình Python chính cùng PyWebView, giao tiếp UI↔backend hoàn toàn qua HTTP loopback (`127.0.0.1`), không qua pipe/socket riêng | — | — |

---

## 2. MA TRẬN TRUY XUẤT TÍNH NĂNG TỪ GIAO DIỆN XUỐNG LÕI

Ký hiệu trạng thái:
**[A]** Đã nối mạch chạy thật 100% (UI → endpoint → hàm lõi → có tác dụng quan sát được ở Engine/DB)
**[B]** Chỉ lưu vào DB/config, **Engine chưa đọc** giá trị đó ở bất kỳ đâu
**[C]** Dữ liệu giả lập / trả về tĩnh (không tính toán thật)
**[D]** Hoàn toàn mồ côi — không có endpoint nào gọi tới

### 2.1. Tab Command Center (`view-monitor`)

| UI Element | Endpoint | Hàm lõi | Trạng thái |
|---|---|---|---|
| Bảng "Tổng quan" (tiles) | `GET /api/status` | `Engine.status()` | **[A]** |
| "▶ Chạy Ngay" | `POST /api/admin/run-now` | `engine.run_tasks()` qua `asyncio.create_task` | **[A]** (test e2e thật Phiên 17) |
| Live Browser Workers Grid | `GET /api/admin/workers/live` | đọc `Engine._workers` dict | **[A]** |
| "👁 Xem" (snapshot) | `GET /api/admin/workers/{id}/snapshot` | `page.screenshot()` trực tiếp trên Page đang chạy | **[A]** |
| "⏹ Dừng" worker | `POST /api/admin/workers/{id}/stop` | `page.context.close()` | **[A]** (đóng context, nhưng **KHÔNG hủy `asyncio.Task`** đang chạy — xem Mục 5) |
| Bảng "Các lượt chạy gần nhất" | `GET /api/runs` | `db.arecent_runs()` — SQL `SELECT r.*, m.* FROM runs LEFT JOIN performance_metrics` | **[A]** |
| Cột "Analytics" (VERIFIED_SUCCESS) | (cùng `/api/runs`) | `runs.analytics_verified` — ghi bởi `attach_analytics_listener` | **[A]** |
| Log stream (SSE) | `GET /events` | `EventBus.subscribe()` | **[A]** |

### 2.2. Tab Quản Trị (`view-admin`)

| UI Element | Endpoint | Hàm lõi | Trạng thái |
|---|---|---|---|
| Browser executable path | `GET/POST /browser-settings` | `db.aset_setting("browser_executable_path")` → đọc tại `_attempt_browser`'s `exe_path` resolution | **[A]** |
| CDP Endpoint + "Test kết nối" | `POST /browser-settings/test-cdp` | `pw.chromium.connect_over_cdp()` thật | **[A]** |
| HTTP Client (httpx/curl_cffi) | `POST /browser-settings` | đọc tại `_attempt_http` qua `network_manager.HttpProbe` | **[A]** |
| ☑ Fail-Safe Gate (Preflight) | `POST /browser-settings` → `preflight_gate_enabled` | `db.aget_setting(...)` đọc trong `_attempt_browser` | **[A]** (test e2e Phiên 15) |
| ☑ Analytics Verification | `POST /browser-settings` → `analytics_verification_enabled` | `attach_analytics_listener` chỉ gắn nếu bật | **[A]** |
| "Nhân Trình Duyệt Mã Nguồn Mở" (nút tải) | `POST /engine/custom-build/download` | `engine_updater.download_and_install()` | **[A]** cơ chế tải+giải nén+dò exe (test với zip giả lập); **[C]** gọi GitHub API thật — chưa từng tải thành công 1 bản thật trong sandbox (rate-limit 403 mọi lần thử) |
| Plugins & Extensions (cài/gỡ .zip) | `POST /plugins/install`, `/plugins/{name}` | `plugin_manager.PluginInstaller` | **[A]** (không test lại ở phiên này, kế thừa từ phase trước) |
| Gateway list + "Kiểm tra" | `POST /gateways/check` | `GatewayValidator.check_all()` | **[A]** |
| ☑ Lọc Datacenter ASN | `POST /gateways/quality-settings` | `GatewayCheckConfig.datacenter_only_filter` → set `passes_quality_filter=False`, **KHÔNG loại bỏ khỏi `GatewayPool`** (chỉ gắn cờ hiển thị) | **[B]** — kết quả kiểm tra bị đánh dấu "không đạt" nhưng **`GatewayPool.assign()` vẫn có thể chọn gateway đó** vì `assign()` chỉ lọc theo `s.healthy`, không đọc `passes_quality_filter` |
| ☑ Elite Header Check | `POST /gateways/quality-settings` | `_check_header_transparency()` qua httpbin.org | **[A]** logic; **[C]** gọi mạng thật (httpbin.org ngoài whitelist sandbox, chưa test network thật) |
| Thanh trượt Max Latency | `POST /gateways/quality-settings` | cùng vấn đề **[B]** như trên — chỉ gắn cờ, không lọc khỏi pool thật |
| Remote DB (MongoDB) "Đồng bộ" | `POST /remote-db/sync` | `remote_db_adapter.sync_to_remote()` | **[C]** — chưa test với MongoDB Atlas thật (cần `MONGODB_URI` env, không có trong sandbox) |

### 2.3. Tab Khả Năng (`view-caps`)

| UI Element | Endpoint | Hàm lõi | Trạng thái |
|---|---|---|---|
| Toàn bộ 9 nút (capabilities, network-check, curl-test, tls-fingerprint, ua-refresh, js-run, playwright-install, browser-live) | `/capabilities/*` | Trực tiếp gọi httpx/curl_cffi/playwright/Node subprocess | **[A]** toàn bộ — test thật network+Playwright+Node ở Phiên 15 |

### 2.4. Tab Flow Studio (`view-flow`)

| UI Element | Endpoint | Hàm lõi | Trạng thái |
|---|---|---|---|
8 node cơ bản (goto/click/type/scroll/wait/assert/branch/loop) | — (xuất JSON client-side, không gọi API lúc thiết kế) | `engine.py::_step()` if/elif tương ứng | **[A] TẤT CẢ — ĐÃ SỬA Ở PHIÊN 19.** Trước phiên này, kiểm tra chéo tên action/field phát hiện **4/8 node cơ bản hoàn toàn không chạy được hoặc chạy sai lặng lẽ**, nghiêm trọng hơn vấn đề topology của `branch` vì đây là các node nền tảng nhất, lỗi có từ rất lâu: (1) node "⌨ Type" tạo `action:"type"` nhưng engine chỉ có `"fill"` → luôn báo "Hành động không hỗ trợ"; (2) node "⏱ Wait" dùng field `duration_ms` nhưng engine chỉ đọc `ms`/`value` → luôn chờ 0ms; (3) node "✔ Assert" tạo `action:"assert"` — không tồn tại (chỉ có `assert_selector`/`assert_text` tách riêng) → luôn lỗi; (4) node "🔄 Loop" tạo `action:"loop"` — **hoàn toàn chưa từng được implement** → luôn lỗi. Đã sửa bằng cách thêm alias chấp nhận cả 2 tên (an toàn ngược, không phá scenario cũ), và implement thật `loop`. Test end-to-end qua Playwright thật xác nhận cả 5 action (gồm `scroll` với `delta_y` — cũng mới thêm, trước đó field này bị bỏ qua hoàn toàn) hoạt động đúng 100%. |
| 10 node chuyên biệt (referrer_goto, prime_session, human_click, widget_qa, sync_start, hybrid_handoff, js_probe, classify_failure, analytics_verify, ai_form_fill) | nút chỉ thêm node vào canvas, JSON export qua `_updateFlowJson()` | tương ứng trong `engine.py::_step()` | **[A]** backend action tồn tại và chạy được (10/10 action có code thật); **[D] về mặt TOPOLOGY** — xem phát hiện quan trọng dưới đây |
| Kết nối dây giữa 2 node trên canvas (Drawflow connections) | — | `_buildStepsFromGraph()` (đổi tên từ `_updateFlowJson` cũ) | **[A] ĐÃ SỬA Ở PHIÊN 19** — trước đó hàm cũ làm phẳng mọi node thành mảng tuyến tính, bỏ qua hoàn toàn dây nối (xem lịch sử ở PROJECT.md Mục 8sexies). Đã viết lại: duyệt đồ thị `inputs`/`outputs` thật của Drawflow, với `branch` lấy dây `output_1`→`then`, `output_2`→`else`; với `loop` lấy dây duy nhất làm `steps` (thân vòng lặp). Test bằng Node.js thuần (mô phỏng JSON export Drawflow thật) xác nhận sinh đúng cấu trúc lồng nhau, VÀ test end-to-end qua Engine thật xác nhận `branch` đi đúng nhánh theo `probability_a`. **Giới hạn còn lại (đã ghi rõ trong code)**: không tự phát hiện điểm hội tụ (re-converge) sau branch — muốn có bước chung sau 2 nhánh phải lặp lại bước đó ở cuối cả `then` và `else`. |
| Session Envelope (Engine Mode/Pool Mode/Preflight/Xvfb/Device Mix/Bandwidth) | Lưu vào JSON xuất ra (`engine`, `bandwidth`, `raw.session_envelope`) khi bấm "Lưu JSON" | `Scenario.engine`/`Scenario.bandwidth` được Engine đọc thật; nhưng `raw.session_envelope.pool_mode`/`preflight_override`/`xvfb_override`/`device_mix` **CHỈ được lưu vào `raw` dict, KHÔNG có dòng code nào trong `engine.py` đọc lại `sc.raw.get("session_envelope")`** | **[A]** cho `engine`/`bandwidth`; **[B]** cho 4 field còn lại — lưu vào JSON scenario nhưng Engine không đọc, mọi override ở cấp Session Envelope ngoài 2 field trên đều KHÔNG CÓ TÁC DỤNG |
| 1-Click Blueprints | `GET /flow/templates` | đọc file tĩnh `config/templates/*.json` | **[A]** |
| Visual Action Recorder | `POST /flow/recorder/start`, `/status`, `/stop` | `trace_replayer.py` singleton session + Playwright thật | **[A]** test thật |
| Trợ Lý AI (NL-to-Flow) | `POST /flow/nl-to-flow` | gọi Ollama `localhost:11434/api/generate` | **[C]** — code xử lý hoàn chỉnh (parse JSON, dọn markdown fence, xử lý lỗi), nhưng **chưa từng sinh được 1 flow thật** vì Ollama không chạy trong môi trường test |

### 2.5. Tab Profiles, Scheduler, Vault, Công cụ, Campaign & AI

| UI Element | Endpoint | Hàm lõi | Trạng thái |
|---|---|---|---|
| Profiles CRUD | `/profiles*` | `database.py` upsert trực tiếp | **[A]** |
| Scheduler (cron windows) | `/scheduler/*` | `schedule_windows.py` + `apscheduler` | **[A]** kế thừa, không test lại phiên này |
| Vault — Cookie/Captcha API key/Test accounts | `/vault/*` | `credential_vault.CredentialVault` (KHÁC với `secrets_store.SecretBox` — xem phân tích chính xác ở Mục 3.4) | **[A]** về luồng chạy; mã hoá dùng Fernet thật (AES-CBC+HMAC) khi `cryptography` có sẵn |
| Virtual Display (Xvfb) toggle | `POST /display/xvfb/settings` | đọc ở `Engine.start()` lần khởi động TIẾP THEO | **[A]** — nhưng **KHÔNG áp dụng ngay** (đã ghi rõ trong response `note`), đòi hỏi khởi động lại Engine |
| "Chuẩn hóa Phông chữ" | `POST /display/fonts/provision` | `linux_display_manager.provision_cross_platform_fonts()` | **[A]** test thật (tải Noto Sans + Liberation Sans qua network) |
| Device Mix Slider | `POST /referrer/traffic-config` | `TrafficConfig.device_mix` — đọc bởi `referrer_orchestrator.pick_device_type()` | **[A]** — NHƯNG chỉ dùng trong action `referrer_goto`, **KHÔNG tự động áp dụng cho scenario KHÔNG dùng node Referrer Chain** (vd. scenario chỉ có `goto` thuần không bao giờ gọi `pick_device_type()`) |
| Gateway Quality filter toggle | đã liệt kê ở 2.2 | | **[B]** (lặp lại — xem phát hiện ở trên) |

---

## 3. PHÂN TÍCH CHUYÊN SÂU CÁC LỚP KỸ THUẬT CỐT LÕI

### 3.1. Lớp Môi Trường & Trình Duyệt

**Khởi tạo nhân trình duyệt** — 3 nhánh loại trừ lẫn nhau trong `_attempt_browser` (engine.py ~540-610):
1. `cdp_endpoint` cấu hình → `pw.chromium.connect_over_cdp(endpoint)` — kết nối tới trình duyệt BÊN NGOÀI, không launch/không đóng.
2. `context_mode == "shared"` → MỘT instance browser dùng chung cho nhiều profile (`self._browsers[key]`), mỗi profile là một `browser.new_context()` riêng (context multiplexing, tiết kiệm RAM vì chỉ 1 tiến trình OS browser).
3. **Mặc định** (`context_mode == "process"`) → `browser_type.launch_persistent_context(profile_dir, **launch_kwargs)` — MỖI profile_id một tiến trình browser riêng, cô lập tuyệt đối (kể cả IndexedDB/localStorage cấp OS-process), tốn RAM nhất.

**`launch_args` stealth** (chỉ áp dụng đầy đủ ở nhánh #3 từ Phiên 15 sau khi phát hiện thiếu):
```
--disable-blink-features=AutomationControlled
--no-first-run --no-default-browser-check
```
Nhánh #2 (`_shared_browser()`) có bộ args đầy đủ hơn (`--disable-features=ChromeWhatsNew,...`, `--metrics-recording-only`, `--no-service-autorun`, `--password-store=basic`, `--use-mock-keychain`) — **2 nhánh KHÔNG dùng chung một danh sách args**, có thể gây lệch fingerprint giữa 2 chế độ pool (rủi ro: scenario chạy ở `shared` và `process` cho dấu vân tay launch-flags khác nhau).

**Patch `navigator.webdriver`:** `STEALTH_WEBDRIVER_JS` (add_init_script) — `Object.defineProperty(Navigator.prototype, 'webdriver', {get:()=>undefined})`, dọn biến `cdc_*`/`__webdriver*`/`__selenium*` trên `window`. **Phụ thuộc cứng** vào `--disable-blink-features=AutomationControlled` đã có trong args (nếu thiếu, property non-configurable, `defineProperty` throw, bị catch im lặng → webdriver vẫn `true`).

**Virtual Display (Xvfb):** `linux_display_manager.XvfbManager` — subprocess `Xvfb :NN -screen 0 WxHxD -nolisten tcp`, dò số hiệu DISPLAY trống qua kiểm tra file lock `/tmp/.X{N}-lock` (không dùng cổng mạng, an toàn hơn kiểm tra port). Vòng đời gắn vào `Engine.start()`/`close()`. **Giới hạn:** chỉ 1 Xvfb instance cho TOÀN BỘ Engine (singleton) — nếu nhiều worker cần độ phân giải khác nhau đồng thời, không hỗ trợ (tất cả dùng chung 1 DISPLAY, 1 độ phân giải).

**Đồng bộ phông chữ:** `provision_cross_platform_fonts()` tải Noto Sans + Liberation Sans vào thư mục cục bộ, sinh `fonts.conf` riêng, gán `FONTCONFIG_PATH` — **nhưng không có dòng code nào trong `_attempt_browser` tự động set biến môi trường này cho subprocess browser** (hàm `fontconfig_env()` tồn tại và trả dict đúng, nhưng **không được gọi ở bất kỳ đâu trong `engine.py`**) → đây là **mồ côi cấp 2**: tính năng tải font hoạt động, nhưng kết quả tải về **không bao giờ được áp dụng vào lúc launch browser thật**.

### 3.2. Lớp Giao Thức Mạng & Định Tuyến

**Gateway Pool — thuật toán rendezvous hashing** (`network_manager.py::GatewayPool.assign`):
```python
best = max(candidates, key=lambda s: sha1(f"{profile_id}|{s.entry.url}").digest())
```
Tính chất: cùng `profile_id` luôn ánh xạ tới cùng gateway (sticky) MIỄN LÀ gateway đó còn trong tập `healthy=True`; khi 1 gateway rớt khỏi tập healthy, TOÀN BỘ các profile trước đó trỏ tới nó sẽ được rehash lại (không chỉ profile bị ảnh hưởng — đặc tính chuẩn của rendezvous hashing, giảm thiểu xáo trộn so với modulo hashing nhưng không phải zero-disruption).

**Health check & Hot-Swap:** `report_failure()` tăng `consecutive_failures`, loại khỏi `healthy` sau `FAIL_THRESHOLD` lần. `hot_swap()` (Phiên 16) loại **NGAY LẬP TỨC** (set `consecutive_failures = FAIL_THRESHOLD` trực tiếp, bỏ qua ngưỡng), chọn gateway khác **CÙNG `region`** qua rendezvous hash với seed phụ `"|hotswap"`. **`hot_swap()` không được gọi tự động ở bất kỳ đâu trong `engine.py`** — không có logic nào trong `_attempt_browser`/`_attempt_http` phát hiện "mất kết nối giữa chừng" rồi tự gọi `hot_swap()`. Hàm tồn tại, có unit test, nhưng **mồ côi khỏi luồng chạy chính** — chỉ `report_failure()` (chờ ngưỡng, không tức thời) được gọi thật trong `execute()`.

**Đồng bộ chữ ký giao thức (`rotate_protocol_profile`):** sinh bundle `{impersonate, http2_settings, headers, tcp_profile}` khớp theo browser/device_type. `impersonate` truyền được vào `curl_cffi.AsyncSession(impersonate=...)` ở Engine 1 (`_attempt_http`). **`http2_settings` và `tcp_profile` CHỈ mang tính tham khảo/ghi log** — code docstring tự thừa nhận "curl_cffi tự set thật theo impersonate", nghĩa là 2 trường này trong `ProtocolProfile` **không được truyền vào bất kỳ API thật nào**, chỉ tồn tại để hiển thị/so sánh qua endpoint `/protocol/rotate`.

**Hybrid Browser-to-HTTP Handoff:** `HybridHandoff.capture(page)` đọc `context.cookies()` + `page.evaluate("navigator.userAgent")`, KHÔNG trích xuất được TLS Session Ticket thật (Playwright không expose API này ở tầng Python) — tài liệu/docstring tự ghi nhận giới hạn này. Phần "chuyển giao TLS Session Ticket" trong tên gọi tính năng là **quảng cáo vượt quá những gì code làm được**: chỉ cookie + UA + header được handoff, không phải TLS session resumption thật giữa 2 engine khác nhau.

### 3.3. Lớp Mô Phỏng Tương Tác & Phục Hồi

**Quỹ đạo chuột:** `kinematic_input.py::_cubic_bezier_points()` — Bezier bậc 3 (4 điểm điều khiển: điểm đầu/cuối cố định, 2 điểm điều khiển sinh ngẫu nhiên có giới hạn độ lệch khỏi đường thẳng) + easing "gia tốc đầu, giảm tốc cuối" (ease-in-out profile, không phải easing tuyến tính). `KinematicSuite` dùng `self._rng` (seed có thể truyền vào qua `step.get("seed")` để tái lập kết quả — hữu ích cho debug nhưng cũng nghĩa là **không ngẫu nhiên thật nếu người vận hành quên đổi seed giữa các profile**, tạo ra dấu vân tay chuyển động GIỐNG HỆT NHAU across nhiều profile nếu seed mặc định dùng chung).

**Self-Healing (`self_healing.py::SelectorHealer`):** `heal()` thử các chiến lược theo thứ tự (dò theo `ElementSnapshot` đã lưu: text nội dung, vị trí tương đối, thuộc tính ARIA...) trước khi rơi vào `_ollama_fallback()` (gọi LLM cục bộ để suy luận selector mới từ DOM snapshot). **Phụ thuộc Ollama cho fallback cuối cùng** — nếu Ollama không chạy (như trong sandbox hiện tại), fallback này **âm thầm trả `None`/thất bại**, hệ thống coi như không heal được, KHÔNG có fallback thứ 2 nào khác (vd. fuzzy text match không cần LLM).

**Xử lý lỗi/giới hạn từ server:** `CircuitBreaker` theo từng `netloc` (domain) — không phải global — nghĩa là lỗi dồn dập ở domain A không ảnh hưởng breaker của domain B. `RETRY_STATUSES = {429, 503}` — các mã lỗi khác (403, 500, 502) **không kích hoạt retry tự động theo status code**, chỉ retry nếu đồng thời `gateway_error=True` (dò theo chuỗi lỗi khớp `GATEWAY_ERRORS` tuple) hoặc `preflight_blocked=True`.

### 3.4. Lớp Tự Động Hóa & AI

**⚠️ PHÁT HIỆN QUAN TRỌNG — HAI cơ chế mã hoá bí mật KHÁC NHAU cùng tồn tại song song, không đồng nhất:**

| | `credential_vault.py::CredentialVault` | `secrets_store.py::SecretBox` |
|---|---|---|
| Dùng cho | Tab Vault: test accounts, cookie import, Captcha solver API key (`/vault/*`, 7+ call site trong `admin_api.py`) | `integrations.api_key_enc` (webhook/captcha_solver/cloud_storage ở tab Tích hợp), truy cập qua `admin_api.py`/`engine.py` |
| Thuật toán CHÍNH | **Fernet thật** (`cryptography.fernet.Fernet` — AES-128-CBC + HMAC-SHA256, có xác thực toàn vẹn) | SHA256-keystream tự chế, XOR thuần — **KHÔNG CÓ xác thực toàn vẹn (no MAC/tag)** |
| Fallback | Nếu `cryptography` KHÔNG cài được (ImportError): tự rơi về XOR thuần + tiền tố `"xor:"` — **có đánh dấu rõ trong code là "không phải mã hóa thật"** | Không có lựa chọn nào khác — LUÔN LUÔN dùng XOR-keystream, kể cả khi `cryptography` đã có sẵn trong `requirements.txt` |
| Khoá | `_derive_key(secret) = SHA256(secret)` — 32 byte, derive từ 1 chuỗi secret (nguồn chuỗi secret cần xác minh thêm — không thuộc phạm vi audit này) | `secrets.token_bytes(32)` sinh ngẫu nhiên, lưu file `paths.secret_key` (chmod 600 trên POSIX) |

**Kết luận chính xác:** rủi ro bảo mật về mã hoá YẾU chỉ áp dụng cho `SecretBox` (phạm vi: API key của tích hợp webhook/captcha-solver/cloud-storage bên thứ 3) — KHÔNG áp dụng cho dữ liệu Vault (test account, cookie), vốn đã dùng Fernet chuẩn đúng cách khi môi trường có `cryptography` (mặc định có, vì nằm trong `requirements.txt`). Tuyên bố ban đầu gộp chung 2 cơ chế này là KHÔNG CHÍNH XÁC và đã được sửa.

**Local MCP Server (`mcp_server.py`):** tự triển khai giao thức JSON-RPC qua stdio TỰ VIẾT TAY (`initialize`, `tools/list`, `tools/call`) — **không dùng SDK MCP chính thức** của Anthropic/cộng đồng, nghĩa là mọi thay đổi giao thức MCP tương lai phải tự cập nhật tay, không được hưởng lợi từ validation/tooling của SDK chuẩn. `trigger_execution` là **đồng bộ chặn** (block tới khi scenario chạy xong mới trả kết quả qua `tools/call`) — với scenario chạy lâu (vd. Session Pre-Warming 15s + nhiều bước), client MCP (Claude Desktop/Cursor) sẽ bị treo chờ phản hồi tương ứng thời gian đó, không có cơ chế streaming/progress.

**Autopilot Rewriter / NL-to-Flow:** CẢ HAI tính năng dùng LLM (mutate step có sẵn VÀ sinh flow mới từ mô tả) đều gọi trực tiếp `POST {ollama_url}/api/generate` qua `httpx`, parse JSON từ trường `response` (text thuần, phải tự dọn markdown fence ```` ``` ````). **Không có cơ chế validate schema đầu ra** ngoài `json.loads()` + kiểm tra `isinstance(list)` — nếu LLM trả JSON hợp lệ nhưng field sai tên (vd. `"act"` thay vì `"action"`), lỗi sẽ xuất hiện MUỘN khi Engine chạy step đó (`StepFailed: Hành động không hỗ trợ`), không phát hiện ngay tại bước sinh flow.

**Bộ lập lịch đa luồng:** `ResourceGovernor` (psutil polling 3s mặc định) điều tiết `max_concurrency` ĐỘNG theo RAM/CPU thật của máy chủ (không phải Semaphore cứng cố định) — throttle ở RAM>80%/CPU>85%, PAUSE CỨNG (không lấy task mới) ở RAM>90%. Đây là cơ chế governance DUY NHẤT; không có giới hạn theo số lượng Playwright process cụ thể hay theo file descriptor.

---

## 4. ĐẶC TẢ CẤU TRÚC DỮ LIỆU & GIAO THỨC NỘI BỘ

### 4.1. Lược đồ SQLite (`state.db`) — 20 bảng

```sql
-- Bảng lõi vận hành
profiles (id PK, environment, region, gateway, created_at, last_used_at, run_count)
scenarios (id PK, name, urls[JSON], profile_id, timeout_ms, active, config[JSON], updated_at)
runs (id PK AUTOINC, scenario_id, profile_id, url, started_at, finished_at,
      status['ok'|'failed'|'skipped'], http_status, exit_ip, gateway, attempts,
      error_message, engine['http'|'chromium'|'firefox'|'webkit'],
      analytics_verified['VERIFIED_SUCCESS'|'NOT_VERIFIED'|NULL],   -- Phiên 16
      preflight_status['ok'|'blocked'|'skipped'|NULL])              -- Phiên 16
performance_metrics (id PK, run_id FK→runs, ttfb_ms, fcp_ms, lcp_ms, cls, dcl_ms, load_ms)

-- Mạng & định tuyến
host_preferences (host PK, engine, reason, escalations, updated_at)
gateway_checks (id PK, gateway, region, checked_at, healthy, latency_ms, exit_ip,
                country, city, isp, asn, timezone_id, locale, error,
                infra_class['isp_residential'|'mobile'|'datacenter'|NULL],  -- Phiên 16
                anonymity_level['elite'|'anonymous'|'transparent'|NULL])   -- Phiên 16

-- Cấu hình & tích hợp
system_settings (key PK, value[JSON], updated_at)   -- key-value store runtime, dùng cho
                                                      -- MỌI toggle Phiên 15/16/17 (preflight_gate_enabled,
                                                      -- virtual_display_enabled, gateway_*_filter_enabled...)
plugin_configs (plugin_name PK, enabled, config_json, manifest_json, installed_at, updated_at)
integrations (name PK, service_type, endpoint_url, api_key_enc[XOR-cipher], extra_json, verified, updated_at)
session_cache (probe_key PK, payload[JSON], created_at_ts[float unix])
tunnel_states (name PK, state_json[JSON: pid,proxy_url,config_path,started_at], updated_at)

-- Vận hành đám mây & cảnh báo
cloud_usage_logs (id PK, provider, endpoint, browser_type, started_at, finished_at,
                   duration_s, cost_usd, status, error)
failure_events (id PK, run_id FK, scenario_id, failure_type[enum 6 giá trị], detail, occurred_at)
alert_history (id PK, channel['telegram'|'discord'|'slack'|'webhook'], scenario_id, message, sent_at, status, error)
preflight_results (id PK, run_id[campaign/task id — TEXT, KHÔNG FK tới runs.id],
                    passed, checks[JSON], blocked, reason, audited_at)
healing_log (id PK, scenario_id, old_selector, new_selector, strategy, confidence, healed_at)
profile_warmth (profile_id PK, trust_score, urls_visited, cookies, warmed_at, status)

-- Workspace & Storm testing
workspaces (id PK, name, description, color, created_at, updated_at)
workspace_items (workspace_id, item_type, item_id — composite PK)
storm_runs (id PK, scenario_id, workspace_id, phase, total_submitted, duration_s,
            peak_concurrency, started_at, finished_at)
```

**Ghi chú toàn vẹn dữ liệu:**
- `runs.scenario_id` **không có FOREIGN KEY** tới `scenarios.id` — xoá scenario không cascade, để lại `runs` orphan (chủ ý, để giữ lịch sử khi scenario bị đổi tên/xoá, nhưng không có ràng buộc).
- `preflight_results.run_id` là TEXT tự do, không FK — không thể JOIN trực tiếp với `runs.id` (INTEGER) để đối chiếu preflight↔run cụ thể qua SQL.
- Không có bảng nào có `DELETE CASCADE` — mọi xoá đều phải tự xử lý thủ công ở tầng Python (rủi ro orphan rows tích luỹ theo thời gian, không có cơ chế dọn tự động ngoài `SmartCachePruner` vốn chỉ dọn thư mục profile trên đĩa, không đụng tới SQLite rows).

### 4.2. Cấu trúc JSON "Kịch bản hoàn chỉnh" mà `engine.py` đọc

```jsonc
{
  "id": "scenario-id-duy-nhat",
  "name": "Tên hiển thị",
  "urls": ["https://example.com"],      // BẮT BUỘC là list, kể cả 1 phần tử
                                          // (Phiên 17 phát hiện bug: field "url" số ít
                                          //  khiến load_config() CRASH TOÀN BỘ, không
                                          //  chỉ scenario lỗi — xem Mục 5)
  "profile_id": "profile-vn-01",
  "environment": "default",              // key tra trong environments.json
  "engine": "auto",                      // "auto"|"http"|"chromium"|"firefox"|"webkit"
  "timeout_ms": 30000,
  "active": true,
  "region": null,                        // truyền vào GatewayPool.assign()
  "bandwidth": {"enabled": false},        // merge với self.settings.bandwidth (global)
  "max_retries": 2,                       // cấp SCENARIO (khác max_retries cấp STEP)
  "steps": [
    {"action": "goto", "url": "...", "wait_until": "domcontentloaded"},
    {"action": "referrer_goto", "referrer_type": "search", "target_url": "...", "utm_source": "google"},
    {"action": "human_click", "selector": "#btn", "behavior": "natural"},
    {"action": "ai_form_fill", "form_selector": "form", "submit": false},
    {"action": "branch", "then": [ /* step lồng nhau */ ], "else": [ /* step lồng nhau */ ]},
    {"action": "analytics_verify", "require": false},
    {"max_retries": 1, "on_error_fallback": [ /* step thay thế nếu lỗi */ ], "action": "click", "..."}
  ],
  "raw": {                                // TOÀN BỘ dict gốc được giữ nguyên ở đây
    "session_envelope": {                 // Phiên 17 — ĐƯỢC LƯU nhưng KHÔNG ĐƯỢC ĐỌC
      "pool_mode": "isolated",            // bởi bất kỳ dòng code nào trong engine.py
      "preflight_override": true,
      "xvfb_override": false,
      "device_mix": {"mobile": 0.75, "desktop": 0.25}
    }
  }
}
```

**Điểm mấu chốt về `then`/`else` của `branch` (ĐÃ SỬA Ở PHIÊN 19):** đây là 2 **mảng JSON step con nhúng trực tiếp** — không phải tham chiếu tới node khác trên canvas, nhưng từ Phiên 19, Flow Studio **tự động sinh 2 mảng này từ chính dây nối output_1/output_2 trên canvas** (xem `_buildStepsFromGraph()`), người dùng không cần gõ tay JSON nữa. `loop.steps` cũng tự sinh từ dây nối duy nhất đi ra khỏi node Loop theo cùng cơ chế.

---

## 5. DANH SÁCH ĐIỂM MÙ, NÚT THẮT CỔ CHAI & PHẦN CHƯA HOÀN THIỆN

### 5.1. Code mồ côi (Orphaned Code)

| # | Hạng mục | Vị trí | Chi tiết |
|---|---|---|---|
| 1 | `GatewayPool.hot_swap()` | `network_manager.py` | Có unit test, không ai gọi trong `engine.py`. Chỉ `report_failure()` (chờ ngưỡng) chạy thật. |
| 2 | `fontconfig_env()` | `linux_display_manager.py` | Hàm trả đúng dict `{"FONTCONFIG_PATH":...}` nhưng không dòng nào trong `_attempt_browser` gọi nó để set env cho subprocess browser. Font tải về không bao giờ được dùng. |
| 3 | `session_envelope.pool_mode/preflight_override/xvfb_override/device_mix` | lưu ở `scenario.raw`, Flow Studio UI | Lưu vào JSON nhưng `engine.py` không đọc lại field nào trong số này ở cấp scenario (chỉ đọc toggle GLOBAL qua `system_settings`, không đọc override per-scenario). |
| 4 | `fakeredis` (requirements.txt) | — | **Thật sự mồ côi** — không có import `fakeredis` ở bất kỳ file `.py` nào (xác nhận bằng grep toàn repo). Khác với `redis` (có dùng thật qua `RedisQueue`, xem Mục 1.3/6.1), `fakeredis` được khai báo nhưng chưa từng dùng làm test double cho `RedisQueue`. |
| 5 | Kết nối dây (topology) Drawflow canvas | `dashboard.py` | Như phân tích Mục 2.4 — hoàn toàn không ảnh hưởng JSON xuất ra. |
| 6 | `_check_header_transparency` gọi httpbin.org | `gateway_validator.py` | Logic đúng nhưng domain httpbin.org chưa bao giờ được verify tiếp cận thật trong môi trường production thật (chỉ test logic với mock headers). |
| 7 | `POST /run-now` không hỗ trợ RedisQueue | `admin_api.py` | Hardcode `LocalQueue()` — scenario kích hoạt qua Dashboard không bao giờ dùng được `RedisQueue` dù `redis_url` đã cấu hình, cắt đứt tính năng phân tán đa máy khỏi đường kích hoạt theo yêu cầu. |

### 5.2. Mock / Stub Implementation

| # | Hạng mục | Vị trí | Chi tiết |
|---|---|---|---|
| 1 | `GatewayQualitySettings` (datacenter filter, max latency) | `gateway_validator.py::check_one` | Chỉ gắn `passes_quality_filter=False` lên **kết quả hiển thị**, KHÔNG loại gateway khỏi `GatewayPool._states` — `assign()` vẫn có thể chọn gateway "không đạt chuẩn". Toggle UI tạo ảo giác đã lọc nhưng thực chất chưa lọc ở tầng cấp phát. |
| 2 | `cloud_browser_adapter.py` | — | Chưa test với provider Cloud Browser thật (Browserless/Steel.dev...) có trả phí — chỉ test cấu trúc code, không test kết nối CDP thật tới dịch vụ ngoài. |
| 3 | `remote_db_adapter.py::sync_to_remote` | — | Chưa test với MongoDB Atlas connection string thật. |

### 5.3. Thiếu kiểm thử thực tế (Untested in Production)

| # | Hạng mục | Lý do chưa test |
|---|---|---|
| 1 | Bản đóng gói Nuitka standalone (Win/macOS/Linux) | `build.yml` sinh ra nhưng chưa từng chạy actions thật (vừa phát hiện và sửa bug cú pháp `runs-on: ${{ matrix.os }})` — dấu `)` thừa khiến MỌI job trước đây build thất bại ngay từ bước chọn runner — **xem Mục 5.5**). |
| 2 | `.github/workflows/build_custom_engine.yml` | Chưa chạy thử trên GitHub Actions thật, chỉ review logic YAML. |
| 3 | Elite Header Check qua proxy thật | httpbin.org ngoài whitelist mạng sandbox, chưa test với traffic qua SOCKS5/HTTP proxy thật. |
| 4 | NL-to-Flow (Ollama) | Ollama không cài trong mọi phiên sandbox đã qua — code xử lý lỗi graceful đã xác nhận, nhưng CHƯA MỘT LẦN sinh được flow JSON thật từ LLM. |
| 5 | MongoDB Atlas, Cloud Browser CDP providers | Cần credential/dịch vụ trả phí bên ngoài, không khả dụng trong môi trường audit. |
| 6 | Tải bản phát hành thật qua `engine_updater.py` | GitHub API rate-limit (403, không auth) chặn mọi lần thử tải thật trong sandbox — chỉ test logic giải nén với archive giả lập. |

### 5.4. Rủi ro hiệu năng / Rò rỉ tài nguyên

| # | Rủi ro | Phân tích |
|---|---|---|
| 1 | **`Database._lock` (threading.Lock) KHÔNG đồng bộ được giữa 2 tiến trình Python khác nhau.** Nếu người vận hành chạy đồng thời `main.py run` (CLI) VÀ `app_launcher.py` (Desktop) trỏ cùng một `state.db`, cả 2 tiến trình đều mở SQLite ở chế độ WAL — WAL cho phép nhiều reader + 1 writer, nhưng KHÔNG có cơ chế nào trong code phát hiện/cảnh báo người dùng đang chạy 2 tiến trình cùng lúc trên cùng DB. Ở tải cao, có thể gặp `database is locked` dù đã bật WAL, vì WAL giảm nhưng không loại bỏ hoàn toàn tranh chấp writer-writer giữa 2 tiến trình. |
| 2 | **"Dừng riêng 1 worker" (`POST /workers/{id}/stop`) không hủy `asyncio.Task`.** Code chỉ gọi `page.context.close()` — `asyncio.create_task(engine.execute(...))` tương ứng VẪN đang chạy trong event loop, chỉ là các lệnh gọi Playwright tiếp theo trên `page` đã đóng sẽ ném exception (`TargetClosedError`) khiến vòng lặp step thoát SỚM qua except — nhưng **không phải hủy tác vụ chủ động** (`task.cancel()`). Nếu step hiện tại không gọi Playwright (vd. đang ở giữa 1 lệnh `asyncio.sleep` dài trong action `wait`), worker tiếp tục SLEEP tới hết thời gian rồi mới next step mới raise lỗi — độ trễ dừng không xác định, phụ thuộc bước đang chạy. |
| 3 | **`context_mode="process"` (mặc định) không giới hạn số tiến trình OS browser đồng thời ngoài `ResourceGovernor`'s RAM/CPU threshold.** Với 50+ luồng đồng thời, mỗi luồng = 1 tiến trình Chromium/Firefox riêng (launch_persistent_context) → có thể chạm giới hạn file descriptor/process của OS (`ulimit -u`/`ulimit -n`) TRƯỚC KHI RAM/CPU threshold kích hoạt, vì Governor chỉ đo RAM/CPU %, không đo số FD/process đang mở. |
| 4 | **Zombie process risk khi Xvfb bị kill cứng.** `XvfbManager.stop()` dùng `os.killpg` + timeout 3s rồi SIGKILL — an toàn cho CHÍNH tiến trình Xvfb, nhưng NẾU tiến trình chính (`app_launcher.py`) bị kill -9 từ bên ngoài (không qua `stop()`), Xvfb con (`start_new_session=True`) **trở thành orphan process không ai dọn** — không có PID file hay cơ chế cleanup-on-next-startup để phát hiện Xvfb orphan từ lần chạy trước. |
| 5 | **EventBus queue CÓ giới hạn (`maxsize=1000`), nhưng hành vi khi đầy là ÂM THẦM BỎ SỰ KIỆN, không phải backpressure.** `EventBus.publish()` gọi `q.put_nowait(event)` bọc trong `try/except asyncio.QueueFull: pass`. Nếu một subscriber SSE (`GET /events`) bị treo (client không đọc kịp), KHÔNG xảy ra rò rỉ RAM (đã có trần cứng 1000/subscriber) — nhưng subscriber đó **mất các sự kiện log/run mới mà không có cách nào biết đã mất bao nhiêu** (không có số đếm "dropped events" nào được publish/log lại). Với tải cao (nhiều worker chạy đồng thời dồn dập `bus.publish("log",...)`), Dashboard đang mở có thể hiển thị log/run KHÔNG ĐẦY ĐỦ mà không có cảnh báo nào cho người vận hành. |
| 6 | **`secrets_store.py::SecretBox` dùng stream cipher XOR tự chế (SHA256-keystream), KHÔNG PHẢI mã hoá có xác thực (AEAD) — PHẠM VI RỦI RO CHỈ GIỚI HẠN Ở `integrations.api_key_enc`** (API key của webhook/captcha-solver/cloud-storage bên thứ 3, tab Tích hợp). Mặc dù `cryptography>=42.0` có trong requirements.txt, `SecretBox` **không có lựa chọn nào dùng Fernet** — luôn luôn dùng keystream `SHA256(key + counter)` XOR với plaintext, không có MAC/tag xác thực → dữ liệu có thể bị bit-flip mà không bị phát hiện khi giải mã. **Lưu ý quan trọng:** dữ liệu Vault (test account, cookie, Captcha key qua `credential_vault.py::CredentialVault`) **KHÔNG thuộc phạm vi rủi ro này** vì dùng Fernet thật (AES-CBC+HMAC) — xem phân tích đầy đủ tại Mục 3.4. |

### 5.5. Bug cú pháp CI/CD phát hiện tại phiên này

``.github/workflows/build.yml` dòng 17: `runs-on: ${{ matrix.os }})` — dấu `)` thừa sau biểu thức Jinja. GitHub Actions sẽ cố tìm runner tên literal `"ubuntu-latest)"` (không tồn tại) → **mọi job build trong workflow này thất bại ngay từ bước chọn runner**, nghĩa là **chưa từng có bản Nuitka standalone nào build thành công qua workflow này** kể từ khi file được tạo. Đã sửa trong phiên hiện tại; 2 workflow còn lại (`build_custom_engine.yml`, `scheduled_runner.yml`) không có lỗi tương tự (đã kiểm tra `runs-on:` ở cả 3 file).

### 5.6. Bug dữ liệu demo phát hiện ở Phiên 17 (đã sửa)

4/8 scenario mẫu trong `config/scenarios.json` (nhóm `phase3-*`) dùng field `"url"` (số ít) thay vì `"urls"` (list) — khiến `Scenario.from_dict()` raise exception, và vì `load_config()` dùng list-comprehension không bọc try/except per-phần-tử, **MỘT scenario lỗi làm sập việc tải TẤT CẢ 8 scenario** (kể cả 4 scenario hợp lệ còn lại). Đã sửa bằng cách đổi field.

---

## 6. BẢNG ĐỐI CHIẾU MÔI TRƯỜNG & ĐÓNG GÓI

### 6.1. Phụ thuộc Python (`requirements.txt`)

| Nhóm | Thư viện | Dùng thật ở đâu | Ghi chú |
|---|---|---|---|
| Core runtime | `playwright>=1.44` | Toàn bộ Engine 2/3 (browser) | — |
| | `httpx[http2,socks]>=0.27` | Engine 1 (HTTP thuần), nhiều module gọi API ngoài | — |
| | `fastapi>=0.110`, `uvicorn[standard]>=0.29` | Toàn bộ `admin_api.py`/`dashboard.py` | — |
| | `apscheduler>=3.10,<4` | `schedule_windows.py` | — |
| HTTP engines | `curl_cffi>=0.7` | Engine 1 khi `http_client=curl_cffi`, `HybridHandoff` | — |
| Async utils | `aiofiles>=23.2` | Đọc/ghi file không chặn (báo cáo, log) | — |
| | `aiohttp>=3.9` | **Không xác nhận import trực tiếp ở các module đã audit** — có thể là transitive dependency của thư viện khác |
| | `websockets>=12.0` | **KHÔNG được dùng** — toàn bộ real-time qua SSE (`StreamingResponse`), không có `websockets.serve`/`connect` nào trong code |
| Data/storage | `redis>=5.0` | `engine.py::RedisQueue` — backend TaskQueue phân tán tùy chọn, kích hoạt qua `cfg.settings.redis_url` (`main.py::_redis_queue()`). **KHÔNG được `POST /run-now` sử dụng** (luôn hardcode `LocalQueue`) |
| | `fakeredis>=2.21` | **Mồ côi hoàn toàn** — không có import nào trong toàn repo (khác với `redis`, xem trên) |
| | `motor>=3.3` | `remote_db_adapter.py` (MongoDB async driver) — chưa test với instance thật |
| | `cryptography>=42.0` | `credential_vault.py::CredentialVault` dùng `Fernet` thật (xem phân tích đầy đủ Mục 3.4). **KHÔNG được `secrets_store.py::SecretBox` sử dụng** — đây là module khác, tự chế XOR cipher, không đụng tới thư viện `cryptography` dù đã có sẵn |
| System | `psutil>=5.9` | `resource_governor.py` | — |
| Desktop GUI | `pywebview>=4.4`, `pystray>=0.19`, `pillow>=10.0` | `app_launcher.py` (cửa sổ desktop + tray icon) | — |
| Packaging | `nuitka` (comment, cài riêng lúc build) | `.github/workflows/build.yml` | Workflow có bug cú pháp đã sửa (Mục 5.5) |

### 6.2. Phụ thuộc hệ điều hành ngoài Python

| OS | Phụ thuộc | Bắt buộc/Tùy chọn |
|---|---|---|
| Linux | `Xvfb` (gói `xvfb`) | Tùy chọn — chỉ cần nếu bật Virtual Display Mode |
| Linux | `Node.js` (binary `node` trong PATH) | **Bắt buộc** cho `js_sandbox_probe.py` (cả `execute_js` thường và DOM-shim `vm` context) |
| Mọi OS | Playwright browser binaries (Chromium/Firefox/WebKit) | Bắt buộc, cài qua `playwright install` |
| Windows/macOS | Không có phụ thuộc hệ thống đặc thù xác nhận được ngoài Playwright/Node | — |

### 6.3. CI/CD — 3 workflow GitHub Actions

| File | Mục đích | Trạng thái sau audit |
|---|---|---|
| `build.yml` | Build Nuitka standalone 3 nền tảng (Windows/macOS/Linux) | **Bug cú pháp đã sửa phiên này** — trước đó mọi lần chạy thất bại ngay bước chọn runner |
| `build_custom_engine.yml` | Tải + vá + đóng gói nhân trình duyệt mã nguồn mở (Camoufox) | YAML hợp lệ, chưa chạy thử thật trên Actions |
| `scheduled_runner.yml` | Chạy scenario theo lịch qua Actions (headless CI runner) | YAML hợp lệ, chưa chạy thử thật trên Actions |

---

## 7. PHỤ LỤC — PHƯƠNG PHÁP KIỂM TOÁN

Tài liệu này được biên soạn bằng cách:
1. `grep`/`sed` trực tiếp trên mã nguồn hiện hành để trích xuất chữ ký hàm, luồng if/elif, schema SQL thật (không suy diễn từ tên biến).
2. Đối chiếu MỖI tuyên bố "đã nối mạch" bằng cách lần dấu vết lệnh gọi từ UI → endpoint → hàm lõi, xác minh tham số truyền vào khớp với tham số hàm lõi thực sự nhận.
3. Các hạng mục đánh dấu **[A] test thật** đều có bằng chứng chạy thực tế (Playwright/Node/Xvfb/network) ghi lại trong lịch sử phiên làm việc (PROJECT.md Mục 8-8quater); các hạng mục **[C]** được phân biệt rõ là "logic đúng nhưng chưa chứng minh bằng chạy thật" thay vì gộp chung với **[A]**.
4. 2 bug (CI YAML, scenario JSON schema) được phát hiện và sửa NGAY TRONG quá trình biên soạn tài liệu này — không phải lỗi giả định, mà là lỗi thật tìm thấy khi đọc lại code để viết Mục 5 và 6.

**Giới hạn của chính bản kiểm toán này:** không test được các tích hợp cần hạ tầng/credential bên ngoài (MongoDB Atlas, Cloud Browser CDP trả phí, Ollama, GitHub Actions runner thật) — những mục này được đánh dấu minh bạch là **[C]** thay vì **[A]**, và liệt kê rõ trong Mục 5.3.

**Tự kiểm tra chéo trong lúc biên soạn:** 3 tuyên bố trong bản nháp đầu tiên của chính tài liệu này đã được phát hiện SAI khi chạy `grep` xác minh trước khi hoàn tất, và đã sửa lại:
1. Tuyên bố ban đầu "`redis`/`fakeredis` mồ côi hoàn toàn" — SAI. `redis` có dùng thật qua `RedisQueue` (điều kiện `redis_url`); chỉ `fakeredis` thật sự mồ côi.
2. Tuyên bố ban đầu "EventBus queue không giới hạn, rò rỉ RAM" — SAI. Queue có `maxsize=1000`, hành vi thật là âm thầm bỏ sự kiện khi đầy (mất dữ liệu hiển thị, không rò rỉ RAM).
3. Tuyên bố ban đầu "toàn bộ mã hoá bí mật dùng XOR tự chế yếu" — SAI/KHÔNG ĐẦY ĐỦ. Có 2 cơ chế riêng biệt: `CredentialVault` (Vault tab) dùng Fernet thật; chỉ `SecretBox` (Integrations tab) dùng XOR yếu.

Việc tự phát hiện 3 lỗi này cho thấy: ngay cả một kỹ sư/AI đọc kỹ code cũng dễ suy diễn sai nếu không `grep` xác minh trực tiếp từng tuyên bố — đây chính là lý do Mục 7 liệt kê phương pháp luận thay vì chỉ đưa ra kết luận.
